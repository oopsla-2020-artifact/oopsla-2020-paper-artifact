#!/usr/bin/env python
import os, sys, subprocess, string, time
from pandas import DataFrame

def FormatTime(d):
    millis = round(d * 1000) % 1000
    return time.strftime("%M:%S.", time.gmtime(d)) + ("%03i" % millis)

trace_deopt = False;
scoreKeys = ["average", "total", "MegaIC-Count", "Total time", "LoadingAot"];
value = {"noxts": {}, "last": {}}
tm = time.time()
pwd = os.getcwd();
d8 = pwd + "/bin/d8"
official_d8 = pwd + "/official_bin/d8"
node = pwd + "/bin/node"
official_node = pwd + "/official_bin/node"
noxts = "--no-xts --no-lazy"
aotbytecode = "--aot=bytecode --aot-out="
aotout = "--xts_aot_always_opt --aot=native --aot-out="
aotin = "--aot-in="
node_aot = "--xts-aot-source=typescript/aot_list"
node_bytecode = "--xts-aot-bytecode-mode"
node_aotin = "--xts-aot-in=default-aot"
node_normal = "--diagnostics -p typescript/tsconfig.json"
printcmd = False;
peek_cases = {
    "tsc": "./typescript/local/tsc.js",
    "Air": "./Air/air.js",
    "Babylon" : "./Babylon/babylon.js",
    "raytrace": "./raytrace/raytrace.js",
    "deltablue": "./deltablue/deltablue.js",
    "richard": "./richards/richards.js",
    "UniPoker" : "./UniPoker/poker.js",
    "WSL": "./WSL/wsl.js",
}

df_index = ["JSExcution-time",
            "GC-time",
            "DefineClass-time",
            "IC-time",
            "LoadAot-time",
            "Optimize-time",
            "BytecodeGen-time",
            "JSExcution-percent",
            "GC-percent",
            "DefineClass-percent",
            "IC-percent",
            "LoadAot-percent",
            "Optimize-percent",
            "BytecodeGen-percent",
            "JSExcution-Count",
            "GC-Count",
            "IC-Count",
            "DefineClass-Count",
            "LoadAot-Count",
            "Optimize-Count",
            "BytecodeGen-Count",
            "DeoptCount",
            "MegaIC-Count",
            "first",
            "firstVar",
            "worst4",
            "average",
            "stdLib",
            "mainRun",
            "total"];

class Recored:
    def __init__(self):
        self.percent = 0.0;
        self.count = 0;
        self.time = 0.0;

    def addTime(self, val):
        val = val.strip("ms");
        self.time = val;

    def addPercent(self, val):
        val = val.strip("%");
        self.percent = self.percent + float(val)/100;

    def addCount(self, val):
        self.count = self.count + val;

    def toString(self):
        ret = "%.4f%s      %d" % (self.percent*100, "%", self.count);
        return ret;

class CaseResult:
    def __init__(self, name, mode):
        self.js_ = Recored();
        self.gc_ = Recored();
        self.dc_ = Recored();
        self.ic_ = Recored();
        self.opt_ = Recored();
        self.ignation_ = Recored();
        self.aot_des_ = Recored();
        self.mode = mode;

        self.deopt_ = 0;
        self.mega_count_ = 0;
        self.name = name;

        self.normalResult = {};
        self.optKey = ["RecompileSynchronous", "OptimizeCode",
                       "StackGuard", "CompileOptimized_Concurrent",
                       "DeoptimizeCode", "NotifyDeoptimized",
                       "CompileGetFromOptimizedCodeMap"];

        self.ignationKey = ["CompileIgnition", "CompileFunction",
                            "CompileScopeAnalysis", "CompileIgnitionFinalization",
                            "CompileScript", "CompileLazy",
                            "CompileAnalyse", "API_ScriptCompiler_CompileUnbound",
                            "CompileRewriteReturnResult",
                            "ParseFunctionLiteral", "PreParseWithVariableResolution",
                            "ParseFunction", "ParseArrowFunctionLiteral",
                            "ParseProgram", "PreParseArrowFunctionLiteral"];

        self.gcKey = ["GC_SCAVENGER_SCAVENGE_PARALLEL", "GC_SCAVENGER_SCAVENGE",
                      "GC_SCAVENGER_SCAVENGE_ROOTS", "GC_Custom_SlowAllocateRaw",
                      "GC_SCAVENGER_SCAVENGE_FINALIZE", "GC_HEAP_EPILOGUE",
                      "GC_MC_EVACUATE_COPY_PARALLEL", "GC_MC_INCREMENTAL",
                       "GC_MC_INCREMENTAL_LAYOUT_CHANGE", "GC_SCAVENGER_PROCESS_ARRAY_BUFFERS",
                       "GC_MC_EVACUATE_UPDATE_POINTERS_SLOTS_MAIN", "GC_MC_EVACUATE_COPY",
                       "GC_MC_CLEAR_WEAK_REFERENCES", "GC_MC_INCREMENTAL_START",
                       "GC_HEAP_PROLOGUE", "GC_MC_EVACUATE_UPDATE_POINTERS_PARALLEL",
                       "GC_MC_EVACUATE_UPDATE_POINTERS_SLOTS_MAP_SPACE", "GC_MC_EVACUATE_REBALANCE",
                       "GC_MC_MARK_MAIN", "GC_MC_FINISH",
                       "GC_MC_INCREMENTAL_FINALIZE_BODY", "GC_HEAP_EXTERNAL_WEAK_GLOBAL_HANDLES",
                       "GC_MC_EVACUATE_UPDATE_POINTERS_TO_NEW_ROOTS", "GC_Custom_IncrementalMarkingObserver",
                       "GC_MC_CLEAR_WEAK_LISTS", "GC_MC_EVACUATE_PROLOGUE",
                       "GC_MC_PROLOGUE", "GC_MC_MARK_ROOTS",
                       "GC_SCAVENGER_SCAVENGE_WEAK_GLOBAL_HANDLES_PROCESS", "GC_SCAVENGER_SCAVENGE_UPDATE_REFS",
                       "GC_MC_CLEAR_STRING_TABLE", "GC_MC_MARK",
                       "GC_HEAP_EPILOGUE_REDUCE_NEW_SPACE", "GC_MC_SWEEP_OLD",
                       "GC_MC_CLEAR_FLUSHABLE_BYTECODE", "GC_MC_CLEAR",
                       "GC_MC_SWEEP", "GC_MC_EVACUATE_EPILOGUE",
                       "GC_HEAP_EXTERNAL_EPILOGUE", "GC_HEAP_EXTERNAL_PROLOGUE",
                       "GC_SCAVENGER_SCAVENGE_WEAK_GLOBAL_HANDLES_IDENTIFY", "GC_MC_EVACUATE",
                       "GC_MC_CLEAR_MAPS", "GC_MC_CLEAR_FLUSHED_JS_FUNCTIONS",
                       "GC_MC_MARK_FINISH_INCREMENTAL", "GC_MC_EVACUATE_UPDATE_POINTERS_WEAK",
                       "GC_MC_EVACUATE_CLEAN_UP", "GC_MC_MARK_WEAK_CLOSURE",
                       "GC_MC_EVACUATE_UPDATE_POINTERS", "GC_MC_MARK_WEAK_CLOSURE_EPHEMERON",
                       "GC_MC_EPILOGUE", "GC_MC_MARK_WEAK_CLOSURE_EPHEMERON_MARKING",
                       "GC_MC_SWEEP_CODE", "GC_MC_MARK_WEAK_CLOSURE_WEAK_ROOTS",
                       "GC_MC_INCREMENTAL_EMBEDDER_PROLOGUE", "GC_MC_MARK_WEAK_CLOSURE_WEAK_HANDLES",
                       "GC_MC_CLEAR_WEAK_COLLECTIONS", "GC_MC_MARK_EMBEDDER_TRACING_CLOSURE",
                       "GC_MC_INCREMENTAL_EXTERNAL_PROLOGUE", "GC_MC_INCREMENTAL_FINALIZE",
                       "GC_MC_MARK_WEAK_CLOSURE_HARMONY", "GC_MC_INCREMENTAL_EXTERNAL_EPILOGUE",
                       "GC_HEAP_EMBEDDER_TRACING_EPILOGUE", "GC_MC_SWEEP_MAP"];

    def setVal(self, key, val):
        self.normalResult[key] = val;

    def getVal(self, key):
        if key not in self.normalResult.keys():
            return 0;
        return self.normalResult[key];

    def normalResultKeys(self):
        return self.normalResult.keys();

    def addRuntime(self, val):
        key = val[0].strip();
        if key.endswith("_Miss"):
            self.ic_.addTime(val[1]);
            self.ic_.addPercent(val[2]);
            self.ic_.addCount(float(val[3]));
        elif key == "TestCounter1":
            self.aot_des_.addTime(val[1]);
            self.aot_des_.addPercent(val[2]);
            self.aot_des_.addCount(float(val[3]));
        elif key == "JS_Execution":
            self.js_.addTime(val[1]);
            self.js_.addPercent(val[2]);
            self.js_.addCount(float(val[3]));
        elif key == "DefineClass":
            self.dc_.addTime(val[1]);
            self.dc_.addPercent(val[2]);
            self.dc_.addCount(float(val[3]));
        elif key in self.gcKey:
            self.gc_.addTime(val[1]);
            self.gc_.addPercent(val[2]);
            self.gc_.addCount(float(val[3]));
        elif key in self.optKey:
            self.opt_.addTime(val[1]);
            self.opt_.addPercent(val[2]);
            self.opt_.addCount(float(val[3]));
        elif key in self.ignationKey:
            self.ignation_.addTime(val[1]);
            self.ignation_.addPercent(val[2]);
            self.ignation_.addCount(float(val[3]));

    def printSelf(self):
        print("JSExcution   %s" % (self.js_.toString()));
        print("IC           %s" % (self.ic_.toString()));
        print("LoadAot      %s" % (self.aot_des_.toString()));
        print("Optimize     %s" % (self.opt_.toString()));
        print("BytecodeGen  %s" % (self.ignation_.toString()));
        print("DeoptCount   %d" % (self.deopt_));

    def appendToDf(self, df):
        name = self.name + "-" + self.mode;
        if name not in df.columns:
            data = [ self.js_.time,
                     self.gc_.time,
                     self.dc_.time,
                     self.ic_.time,
                     self.aot_des_.time,
                     self.opt_.time,
                     self.ignation_.time,
                     self.js_.percent,
                     self.gc_.percent,
                     self.dc_.percent,
                     self.ic_.percent,
                     self.aot_des_.percent,
                     self.opt_.percent,
                     self.ignation_.percent,
                     self.js_.count,
                     self.gc_.count,
                     self.ic_.count,
                     self.dc_.count,
                     self.aot_des_.count,
                     self.opt_.count,
                     self.ignation_.count,
                     self.deopt_,
                     self.mega_count_, #MegaIC-Count
                     0, #first
                     0, #firstVar
                     0, #worst4
                     0, #average
                     0, #stdLib
                     0, #mainRun
                     0];#total

            df[name] = data;
        else:
            # update normal test info
            df.loc["first", name] = self.getVal("First");
            df.loc["worst4", name] = self.getVal("worst4");
            df.loc["average", name] = self.getVal("average");
            df.loc["stdLib", name] = self.getVal("stdLib");
            df.loc["mainRun", name] = self.getVal("mainRun");
            df.loc["total", name] = self.getVal("total");
            df.loc["MegaIC-Count", name] = self.getVal("MegaIC-Count");
            total = self.getVal("total");
            df.loc["JSExcution-time", name] = total * df.loc["JSExcution-time", name];
            df.loc["GC-time", name] = total * df.loc["GC-time", name];
            df.loc["DefineClass-time", name] = total * df.loc["DefineClass-time", name];
            df.loc["IC-time", name] = total * df.loc["IC-time", name];
            df.loc["LoadAot-time", name] = total * df.loc["LoadAot-time", name];
            df.loc["Optimize-time", name] = total * df.loc["Optimize-time", name];
            df.loc["BytecodeGen-time", name] = total * df.loc["BytecodeGen-time", name];

class Base:
    def __init__(self, mode, flags, cases):
       self.caseResult = [];
       self.mode = mode;
       self.cases = cases;
       self.flags = list(flags);

    def findCase(self, k):
        for case in self.caseResult:
            if case.name == k:
                return case;

    def findAllCase(self, k):
        ret = [];
        for case in self.caseResult:
            if case.name == k:
                ret.append(case);
        return ret;

    def processResult(self, k, output):
        global scoreKeys
        tmp = output.stdout.read().split('\n')
        caseResult = CaseResult(k, self.mode)
        deoptCount = 0
        processRuntime = False;
        for line in tmp:
            score = line.split(":")
            if score[0] == "[deoptimizing (DEOPT eager)":
                deoptCount = deoptCount + 1
            elif len(score) == 2 and (score[0] in scoreKeys):
                key = score[0]
                if key == "Total time":
                    tm = score[1]
                    val = round(string.atof(tm[:-1]), 4)
                elif key == "LoadingAot":
                    val = score[1]
                    caseResult.aot_des_.addTime(score[1])
                else:
                    val = round(string.atof(score[1]), 4)
                caseResult.setVal(key, val)
            elif line == "----------------------------------------------------------------------------------------":
                processRuntime = False;
            elif processRuntime:
                line = line.split();
                caseResult.addRuntime(line);
            elif line == "========================================================================================":
                processRuntime = True;

        caseResult.deopt_ = deoptCount
        caseResult.mega_count_ = caseResult.getVal("MegaIC-Count")
        self.caseResult.append(caseResult);

    def RmTSCOutCommand(self, k):
       if k == "tsc":
          if os.path.exists('typescript/out'):
            os.system("rm -rf typescript/out");

class NoXts(Base):
    def __init__(self, flags, cases):
       Base.__init__(self, "noxts", flags, cases);
       self.noxts = "--no-xts";

    def RunTest(self):
       global d8;
       global printcmd
       pwd = os.getcwd();

       cases = self.cases;
       flags = self.noxts;

       for k in cases.keys():
           self.RmTSCOutCommand(k)
           if k == "tsc":
               flags = node_normal.split(" ");
               cmd = [official_node]
               cmd.extend(self.flags)
               cmd.extend([cases[k]])
               cmd.extend(flags)
           else:
               cmd = [official_d8, cases[k]]
               cmd.extend(self.flags);
           if printcmd == True:
               print(' '.join(cmd));
           output = subprocess.Popen(cmd, stdout=subprocess.PIPE)

           self.processResult(k, output);

           if k == "tsc":
               os.system("rm -rf typescript/out");


class Bytecode(Base):
    def __init__(self, flags, cases):
       Base.__init__(self, "bytecode", flags, cases);

    def RunTest(self):
        cases = self.cases;
        pwd = os.getcwd();
        for k in cases.keys():
            path = pwd + "/" + cases[k]
            self.RmTSCOutCommand(k)
            self.RmOutPathCommand(k);
            if k == "tsc":
                tsc_out = subprocess.Popen(self.GetBytecodeOutCommand(k), stdout=subprocess.PIPE);
                time.sleep(20)
                tsc_out.kill()
            else:
                os.system(self.GetBytecodeOutCommand(k));
            time.sleep(8)
            output = subprocess.Popen(self.GetBytecodeInCommand(k), stdout=subprocess.PIPE);

            self.processResult(k, output);
            self.RmTSCOutCommand(k)
            self.RenameTSCOut(k)

    def RenameTSCOut(self, k):
       if k == "tsc":
          if os.path.exists('default-aot-bytecode'):
            os.remove("default-aot-bytecode")
          os.rename("default-aot", "default-aot-bytecode")

    def RmOutPathCommand(self, k):
       pwd = os.getcwd();
       cases = self.cases;
       if k != "tsc":
           path = pwd + "/" + cases[k]
           outflag = os.path.dirname(path) + "/" + k + ".bytecode.out";
           if os.path.exists(outflag):
              os.system("rm " + outflag)

    def GetBytecodeOutCommand(self, k):
       global aotbytecode;
       global d8;
       global printcmd
       pwd = os.getcwd();
       cases = self.cases;
       addflags = " ".join(self.flags);

       path = pwd + "/" + cases[k]
       outflag = aotbytecode + os.path.dirname(path) + "/" + k + ".bytecode.out" + " " + addflags + " " + cases[k];

       if k == "tsc":
           outputCommand = [node, node_bytecode, node_aot];
           #print(outputCommand);
           addflagArray = [];
           if len(self.flags) != 0:
              addflagArray = self.flags;
           outputCommand.extend(addflagArray)
           if printcmd == True:
               print(" ".join(outputCommand));
       else:
           outputCommand = d8 + " " + outflag + " > output ";
           if printcmd == True:
               print(outputCommand);

       return outputCommand;

    def GetBytecodeInCommand(self, k):
        global aotin;
        global d8;
        global printcmd
        pwd = os.getcwd();
        cases = self.cases;
        path = pwd + "/" + cases[k]
        inflag = aotbytecode;
        inflag = aotin + os.path.dirname(path) + "/" + k + ".bytecode.out";

        addflagArray = [];
        if len(self.flags) != 0:
            addflagArray = self.flags;

        command = [];
        if k == "tsc":
            command = [node]
            if "--runtime-call-stats" in addflagArray:
                addflagArray.append("--profile-deserialization")
            command.extend(addflagArray)
            command.extend([node_aotin, cases[k]])
            tsc_flags = node_normal.split(" ")
            command.extend(tsc_flags)
        else:
            command = [d8, inflag, cases[k]];

        if k != "tsc":
            command.extend(addflagArray);
        if printcmd == True:
            print(" ".join(command));
        return command;

class Xts(Base):
    def __init__(self, flags, cases):
       Base.__init__(self, "xts", flags, cases);

    def setMode(self, mode):
        self.mode = mode;

    def RunTest(self):
        # print("Run xts...");
        cases = self.cases;
        pwd = os.getcwd();
        for k in cases.keys():
            path = pwd + "/" + cases[k]
            self.RmTSCOutCommand(k)
            self.RmOutPathCommand(k);

            if k == "tsc":
                tsc_out = subprocess.Popen(self.GetAotOutFlagCommand(k), stdout=subprocess.PIPE);
                time.sleep(30)
                tsc_out.kill()
            else:
                os.system(self.GetAotOutFlagCommand(k));
            time.sleep(8)
            output = subprocess.Popen(self.GetAotInFlagCommand(k), stdout=subprocess.PIPE);

            self.processResult(k, output);

            self.RmTSCOutCommand(k)

    def RmOutPathCommand(self, k):
       cases = self.cases;
       if k != "tsc":
           path = pwd + "/" + cases[k]
           outflag = os.path.dirname(path) + "/" + k + ".native.out";
           if os.path.exists(outflag):
              os.system("rm " + outflag)

    def GetAotOutFlagCommand(self, k):
       global aotout;
       global d8;
       global printcmd
       pwd = os.getcwd();
       cases = self.cases;
       addflags = " ".join(self.flags);

       path = pwd + "/" + cases[k]
       outflag = aotout + os.path.dirname(path) + "/" + k + ".native.out" + " " + addflags + " " + cases[k];

       if k == "tsc":
           addflagArray = [];
           if len(self.flags) != 0:
               addflagArray = self.flags;
           outputCommand = [node, "--xts_aot_always_opt", node_aot];
           outputCommand.extend(addflagArray)
           if printcmd == True:
               print(" ".join(outputCommand));
       else:
           outputCommand = d8 + " " + outflag + " > output ";
           if printcmd == True:
               print(outputCommand);

       return outputCommand;

    def GetAotInFlagCommand(self, k):
        global aotin;
        global d8;
        global printcmd
        pwd = os.getcwd();
        cases = self.cases;
        path = pwd + "/" + cases[k]
        inflag = aotin + os.path.dirname(path) + "/" + k + ".native.out";

        addflagArray = [];
        if len(self.flags) != 0:
            addflagArray = self.flags;
        
        command = [];
        if k == "tsc":
            command = [node, "--no-opt"]
            if "--runtime-call-stats" in addflagArray:
                addflagArray.append("--profile-deserialization")
            command.extend(addflagArray)
            command.extend([node_aotin, cases[k]])
            tsc_flags = node_normal.split(" ")
            command.extend(tsc_flags)
        else:
            command = [d8, "--no-opt", inflag, cases[k]];

        if k != "tsc":
            command.extend(addflagArray);
        if printcmd == True:
            print(" ".join(command));
        return command;


class ResultPrint:
    def __init__(self, xts, noxts):
        global df_index;
        self.xts = xts;
        self.noxts = noxts;
        self.df = DataFrame(0., index=df_index, columns = [0]);
        self.df.index = df_index;

    def printNormal(self, mode):
        xts = self.xts.caseResult;

        if mode == "bytecode":
          print("\033[1;33;40mFig. 12\033[0m")
          print(("B1(ms)").rjust(25) + ("S1(ms)").rjust(15) + "ratio(S1/B1)".rjust(15))
        elif mode == "native":
          print("\033[1;33;40mFig. 14\033[0m")
          print(("B2(ms)").rjust(25) + ("S2(ms)").rjust(15) + "ratio(S2/B2)".rjust(15))
        for case in xts:
            key = case.name;
            noxts_case = self.noxts.findCase(key);
            for k in case.normalResultKeys():
                xts_val = case.getVal(k);
                noxts_val = noxts_case.getVal(k);

                if key == "tsc":
                    xts_val = xts_val * 1000
                    noxts_val = noxts_val * 1000
                xts_noxts = float(xts_val) / float(noxts_val);

                print((key + ": ").ljust(15) + str(noxts_val).rjust(10) + str(xts_val).rjust(15) + str(round(xts_noxts, 2)).rjust(15))
        print("-----------------------------------------------------------")

    def appendRuntimeInfo(self, result):
        for case in result.caseResult:
           case.appendToDf(self.df);

def normalTest():
    global peek_cases;
    print("[\033[1;32;40m" + "running bytecode mode ..."+ "\033[0m]");
    noxts = NoXts(["--no-lazy"], peek_cases);
    noxts.RunTest();

    xts = Bytecode([], peek_cases);
    xts.RunTest();

    printTool = ResultPrint(xts, noxts);
    printTool.printNormal("bytecode");

def nativeTest():
    global peek_cases;
    print("[\033[1;32;40m" + "running native mode ..."+ "\033[0m]");
    xts = Xts([], peek_cases);
    xts.RunTest();

    novtable = Xts(["--no-xts_use_subtyping_map"], peek_cases);
    novtable.RunTest();

    printTool = ResultPrint(xts, novtable);
    printTool.printNormal("native");

def getRuntimeInfo(mode, flags, tool, cases):
    if "bytecode" in mode:
        noxts = NoXts(flags, cases)
        noxts.RunTest();
        tool.appendRuntimeInfo(noxts);

        bytecode = Bytecode(flags, cases)
        bytecode.RunTest();
        tool.appendRuntimeInfo(bytecode);

    if "native" in mode:
        xts = Xts(flags, cases)
        xts.setMode("native")
        xts.RunTest();
        tool.appendRuntimeInfo(xts);

        flags.extend(["--no-xts_use_subtyping_map"])
        novtable = Xts(flags, peek_cases);
        novtable.setMode("NoHI");
        novtable.RunTest();
        tool.appendRuntimeInfo(novtable);

def PrintProf(mode, df):
    if mode == "bytecode":
        print("\033[1;33;40mFig. 13\033[0m")
    elif mode == "native":
        print("\033[1;33;40mFig. 15\033[0m")
    for k in peek_cases.keys():
        if mode == "native":
            col1 = k + "-NoHI"
            col2 = k + "-" +  mode
            print((k + "-B2").rjust(25) + (k + "-S2").rjust(15) + "ratio(S2/B2)".rjust(15))
            s2_load_time = df.loc["LoadAot-time", col2]
            b2_load_time = df.loc["LoadAot-time", col1]
            s2_deopt_count = df.loc["DeoptCount", col2]
            b2_deopt_count = df.loc["DeoptCount", col1]
            load_time_ratio = str(round(string.atof(s2_load_time)/string.atof(b2_load_time), 2)) if string.atof(b2_load_time) != 0 else ""
            deopt_count_ratio = str(round(float(s2_deopt_count)/b2_deopt_count, 2)) if b2_deopt_count != 0 else ""
            print("DeoptCount:    " + str(b2_deopt_count).rjust(10) + str(s2_deopt_count).rjust(15) + deopt_count_ratio.rjust(15))
        elif mode == "bytecode":
            col1 = k + "-noxts"
            col2 = k + "-" +  mode
            print((k + "-B1").rjust(25) + (k + "-S1").rjust(15) + "ratio(S1/B1)".rjust(15))
            s1_load_time = df.loc["LoadAot-time", col2]
            b1_load_time = df.loc["LoadAot-time", col1]
            s1_deopt_count = df.loc["DeoptCount", col2]
            b1_deopt_count = df.loc["DeoptCount", col1]
            s1_opt_count = df.loc["Optimize-Count", col2]
            b1_opt_count = df.loc["Optimize-Count", col1]
            s1_mega_count = df.loc["MegaIC-Count", col2]
            b1_mega_count = df.loc["MegaIC-Count", col1]
            load_time_ratio = str(round(string.atof(s1_load_time)/string.atof(b1_load_time), 2)) if string.atof(b1_load_time) != 0 else ""
            deopt_count_ratio = str(round(float(s1_deopt_count)/b1_deopt_count, 2)) if b1_deopt_count != 0 else ""
            opt_count_ratio = str(round(float(s1_opt_count)/b1_opt_count, 2)) if b1_opt_count != 0 else ""
            mega_count_ratio = str(round(float(s1_mega_count)/b1_mega_count, 2)) if b1_mega_count != 0 else ""
            print("DeoptCount:    " + str(b1_deopt_count).rjust(10) + str(s1_deopt_count).rjust(15) + deopt_count_ratio.rjust(15))
            print("OptimizeCount: " + str(int(b1_opt_count)).rjust(10) + str(int(s1_opt_count)).rjust(15) + opt_count_ratio.rjust(15))
            print("MegaICCount:   " + str(b1_mega_count).rjust(10) + str(s1_mega_count).rjust(15) + mega_count_ratio.rjust(15))

def GetFileSize(filePath):
    if os.path.exists(filePath):
        filePath = unicode(filePath,'utf8')
        fsize = os.path.getsize(filePath)
        fsize = fsize/float(1024)
        return round(fsize,2)

def PrintPerf(byteDf, nativeDf):
    print("\033[1;33;40mTable 6\033[0m")
    print("JS(KB)".rjust(20) + "Bytecode-S1(KB)".rjust(18) + "Native-S2(KB)".rjust(15) + "S1/JS(x)".rjust(10) + "S2/JS(x)".rjust(10) + "LoadingS1(ms)".rjust(15) + "LoadingS2(ms)".rjust(15))
    for k in peek_cases.keys():
        path = pwd + "/" + peek_cases[k]
        if k != "tsc":
          nativeout = os.path.dirname(path) + "/" + k + ".native.out";
          byteout = os.path.dirname(path) + "/" + k + ".bytecode.out";
        else:
          nativeout = pwd + "/default-aot"
          byteout = pwd + "/default-aot-bytecode"

        s1_load_time = byteDf.loc["LoadAot-time", k + "-bytecode"]
        s2_load_time = nativeDf.loc["LoadAot-time", k + "-native"]

        js_size = GetFileSize(path)
        byte_size = GetFileSize(byteout)
        native_size = GetFileSize(nativeout)

        print((k + ":").ljust(10) + str(js_size).rjust(10) + str(byte_size).rjust(18) + str(native_size).rjust(15) + str(round(byte_size/js_size, 2)).rjust(10) + str(round(native_size/js_size, 2)).rjust(10) +  str(s1_load_time).rjust(15) + str(s2_load_time).rjust(15))

def main():
    global printcmd

    normalArg = ["--bytecode", "--native", "--prof-bytecode", "--prof-native", "--prof", "--total"]
    args = sys.argv[1:]

    if "--printcmd" in args:
        printcmd = True

    actualArgus = [];

    for arg in args:
        if arg not in normalArg:
            actualArgus.append(arg);

    if "--bytecode" in args:
        normalTest();

    if "--native" in args:
        nativeTest();

    if "--prof-bytecode" in args:
        print("[\033[1;32;40m" + "profiling bytecode ..."+ "\033[0m]");
        actualArgus.extend(["--runtime-call-stats", "--trace-deopt", "--xts_prof_mega"]);
        bytecodeTool = ResultPrint(None, None);
        getRuntimeInfo("bytecode", actualArgus, bytecodeTool, peek_cases);
        PrintProf("bytecode", bytecodeTool.df)

    if "--prof-native" in args:
        print("[\033[1;32;40m" + "profiling native ..."+ "\033[0m]");
        actualArgus.extend(["--runtime-call-stats", "--trace-deopt", "--xts_prof_mega"]);
        nativeTool = ResultPrint(None, None);
        getRuntimeInfo("native", actualArgus, nativeTool, peek_cases);
        PrintProf("native", nativeTool.df)

    if "--prof" in args:
        print("[\033[1;32;40m" + "profiling ..."+ "\033[0m]");
        actualArgus.extend(["--runtime-call-stats", "--trace-deopt", "--xts_prof_mega"]);
        bytecodeTool = ResultPrint(None, None);
        getRuntimeInfo("bytecode", actualArgus, bytecodeTool, peek_cases);

        nativeTool = ResultPrint(None, None);
        getRuntimeInfo("native", actualArgus, nativeTool, peek_cases);
        PrintPerf(bytecodeTool.df, nativeTool.df)

    if len(sys.argv) < 2:
        normalTest()
        time.sleep(10)
        nativeTest()
        time.sleep(10)
        print("[\033[1;32;40m" + "profiling ..."+ "\033[0m]");
        actualArgus.extend(["--runtime-call-stats", "--trace-deopt", "--xts_prof_mega"]);
        bytecodeTool = ResultPrint(None, None);
        getRuntimeInfo("bytecode", actualArgus, bytecodeTool, peek_cases);

        nativeTool = ResultPrint(None, None);
        getRuntimeInfo("native", actualArgus, nativeTool, peek_cases);

        PrintProf("bytecode", bytecodeTool.df)
        print("-----------------------------------------------------------")
        PrintProf("native", nativeTool.df)
        print("-----------------------------------------------------------")
        PrintPerf(bytecodeTool.df, nativeTool.df)

main();

print "\nthis test takes " + FormatTime(time.time()-tm)
