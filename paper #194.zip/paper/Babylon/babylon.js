/*<@type>{
    "header": {
        "version": "3.0.1",
        "filename": "babylon.js",
        "sound": 1
    },
    "types": [
        "any",
        "number",
        "boolean",
        "string",
        "void",
        "int",
        "object",
        {
            "index": 7,
            "cname": "TmpBase",
            "fields": {
                "type": 9,
                "isReg": 2
            },
            "methods": [
                8,
                10,
                11,
                12,
                13,
                14,
                15,
                16
            ]
        },
        {
            "index": 8,
            "fname": "constructor",
            "ret": 7
        },
        {
            "index": 9,
            "bname": "Symbol"
        },
        {
            "index": 10,
            "fname": "get isGP",
            "ret": 2
        },
        {
            "index": 11,
            "fname": "get isFP",
            "ret": 2
        },
        {
            "index": 12,
            "fname": "get isGPR",
            "ret": 2
        },
        {
            "index": 13,
            "fname": "get isFPR",
            "ret": 2
        },
        {
            "index": 14,
            "fname": "get reg",
            "ret": 7
        },
        {
            "index": 15,
            "fname": "get gpr",
            "ret": 7
        },
        {
            "index": 16,
            "fname": "get fpr",
            "ret": 7
        },
        {
            "index": 17,
            "fname": "relCondCode",
            "params": {
                "cond": 9
            },
            "ret": 5
        },
        {
            "index": 18,
            "fname": "resCondCode",
            "params": {
                "cond": 9
            },
            "ret": 5
        },
        {
            "index": 19,
            "fname": "doubleCondCode",
            "params": {
                "cond": 9
            },
            "ret": 5
        },
        {
            "index": 20,
            "oname": "ReservedWords",
            "fields": {
                "6": -0,
                "strict": -0,
                "strictBind": -0
            }
        },
        {
            "index": 21,
            "oname": "UtilIdentifierJS",
            "fields": {
                "reservedWords": -0,
                "isKeyword": -0,
                "isIdentifierStart": -0,
                "isIdentifierChar": -0
            }
        },
        {
            "index": 22,
            "uname": "",
            "types": [
                4,
                5
            ]
        },
        {
            "index": 23,
            "fname": "makePredicate",
            "params": {
                "words": 3
            },
            "ret": 0
        },
        {
            "index": 24,
            "aname": "",
            "element": 3,
            "mode": "normal"
        },
        {
            "index": 25,
            "fname": "",
            "params": {
                "str": 3
            },
            "ret": 2
        },
        {
            "index": 26,
            "uname": "",
            "types": [
                3,
                4
            ]
        },
        {
            "index": 27,
            "bname": "RegExp"
        },
        {
            "index": 28,
            "aname": "",
            "element": 5,
            "mode": "normal"
        },
        {
            "index": 29,
            "fname": "isInAstralSet",
            "params": {
                "code": 5,
                "set": 28
            },
            "ret": 2
        },
        {
            "index": 30,
            "fname": "isIdentifierStart",
            "params": {
                "code": 5
            },
            "ret": 2
        },
        {
            "index": 31,
            "fname": "isIdentifierChar",
            "params": {
                "code": 5
            },
            "ret": 2
        },
        {
            "index": 32,
            "oname": "UtilWhitespaceJS",
            "fields": {
                "lineBreak": -27,
                "lineBreakG": -27,
                "isNewLine": -0,
                "nonASCIIwhitespace": -27
            }
        },
        {
            "index": 33,
            "fname": "isNewLine",
            "params": {
                "code": 5
            },
            "ret": 2
        },
        {
            "index": 34,
            "oname": "UtilLocationJS",
            "fields": {
                "Position": -36,
                "SourceLocation": -38,
                "getLineInfo": -0
            }
        },
        {
            "index": 35,
            "cname": "Position",
            "fields": {
                "line": -5,
                "column": -5
            },
            "methods": [
                36
            ]
        },
        {
            "index": 36,
            "fname": "constructor",
            "params": {
                "line": 5,
                "col": 5
            },
            "ret": 35
        },
        {
            "index": 37,
            "cname": "SourceLocation",
            "fields": {
                "start": -39,
                "end": -39,
                "filename": 3,
                "identifierName": 3
            },
            "methods": [
                38
            ]
        },
        {
            "index": 38,
            "fname": "constructor",
            "params": {
                "start": 39,
                "end": 39
            },
            "ret": 37
        },
        {
            "index": 39,
            "uname": "",
            "types": [
                4,
                35
            ]
        },
        {
            "index": 40,
            "fname": "getLineInfo",
            "params": {
                "input": 3,
                "offset": 5
            },
            "ret": 35
        },
        {
            "index": 41,
            "bname": "RegExpExecArray"
        },
        {
            "index": 42,
            "uname": "",
            "types": [
                4,
                41
            ]
        },
        {
            "index": 43,
            "oname": "TokenTypes",
            "fields": {
                "num": -44,
                "regexp": -44,
                "string": -44,
                "name": -44,
                "eof": -44,
                "bracketL": -44,
                "bracketR": -44,
                "braceL": -44,
                "braceBarL": -44,
                "braceR": -44,
                "braceBarR": -44,
                "parenL": -44,
                "parenR": -44,
                "comma": -44,
                "semi": -44,
                "colon": -44,
                "doubleColon": -44,
                "dot": -44,
                "question": -44,
                "arrow": -44,
                "template": -44,
                "ellipsis": -44,
                "backQuote": -44,
                "dollarBraceL": -44,
                "at": -44,
                "eq": -44,
                "assign": -44,
                "incDec": -44,
                "prefix": -44,
                "logicalOR": -44,
                "logicalAND": -44,
                "bitwiseOR": -44,
                "bitwiseXOR": -44,
                "bitwiseAND": -44,
                "equality": -44,
                "relational": -44,
                "bitShift": -44,
                "plusMin": -44,
                "modulo": -44,
                "star": -44,
                "slash": -44,
                "exponent": -44,
                "jsxName": -48,
                "jsxText": -48,
                "jsxTagStart": -48,
                "jsxTagEnd": -48,
                "_break": -51,
                "_case": -51,
                "_catch": -51,
                "_continue": -51,
                "_debugger": -51,
                "_default": -51,
                "_do": -51,
                "_else": -51,
                "_finally": -51,
                "_for": -51,
                "_function": -51,
                "_if": -51,
                "_return": -51,
                "_switch": -51,
                "_throw": -51,
                "_try": -51,
                "_var": -51,
                "_let": -51,
                "_const": -51,
                "_while": -51,
                "_with": -51,
                "_new": -51,
                "_this": -51,
                "_super": -51,
                "_class": -51,
                "_extends": -51,
                "_export": -51,
                "_import": -51,
                "_yield": -51,
                "_null": -51,
                "_true": -51,
                "_false": -51,
                "_in": -51,
                "_instanceof": -51,
                "_typeof": -51,
                "_void": -51,
                "_delete": -51
            }
        },
        {
            "index": 44,
            "cname": "TokenType",
            "fields": {
                "label": -3,
                "keyword": -26,
                "beforeExpr": -2,
                "startsExpr": -2,
                "rightAssociative": -2,
                "isLoop": -2,
                "isAssign": -2,
                "prefix": -2,
                "postfix": -2,
                "binop": -22,
                "updateContext": -0
            },
            "methods": [
                45
            ]
        },
        {
            "index": 45,
            "fname": "constructor",
            "params": {
                "label": 3,
                "conf": 46
            },
            "ret": 44
        },
        {
            "index": 46,
            "cname": "TokenConfig",
            "fields": {
                "keyword": -26,
                "beforeExpr": -2,
                "startsExpr": -2,
                "rightAssociative": -2,
                "isLoop": -2,
                "isAssign": -2,
                "prefix": -2,
                "postfix": -2,
                "binop": -22
            },
            "methods": [
                47
            ]
        },
        {
            "index": 47,
            "fname": "constructor",
            "params": {
                "keyword": 26,
                "beforeExpr": 2,
                "startsExpr": 2,
                "rightAssociative": 2,
                "isLoop": 2,
                "isAssign": 2,
                "prefix": 2,
                "postfix": 2,
                "binop": 22
            },
            "ret": 46
        },
        {
            "index": 48,
            "uname": "",
            "types": [
                4,
                44
            ]
        },
        {
            "index": 49,
            "cname": "KeywordTokenType",
            "supers": {
                "TokenType": 45
            },
            "fields": {
                "keyword": 3
            },
            "methods": [
                50
            ]
        },
        {
            "index": 50,
            "fname": "constructor",
            "params": {
                "name": 3,
                "options": 46
            },
            "ret": 49,
            "hobj": 1
        },
        {
            "index": 51,
            "uname": "",
            "types": [
                4,
                49
            ]
        },
        {
            "index": 52,
            "oname": "Keywords",
            "fields": {
                "break": -49,
                "case": -49,
                "catch": -49,
                "continue": -49,
                "debugger": -49,
                "default": -49,
                "do": -49,
                "else": -49,
                "finally": -49,
                "for": -49,
                "function": -49,
                "if": -49,
                "return": -49,
                "switch": -49,
                "throw": -49,
                "try": -49,
                "var": -49,
                "let": -49,
                "const": -49,
                "while": -49,
                "with": -49,
                "new": -49,
                "this": -49,
                "super": -49,
                "class": -49,
                "extends": -49,
                "export": -49,
                "import": -49,
                "yield": -49,
                "null": -49,
                "true": -49,
                "false": -49,
                "in": -49,
                "instanceof": -49,
                "typeof": -49,
                "void": -49,
                "delete": -49
            }
        },
        {
            "index": 53,
            "oname": "TokenizerTypesJS",
            "fields": {
                "TokenType": -45,
                "BinopTokenType": -55,
                "types": -0,
                "keywords": -0
            }
        },
        {
            "index": 54,
            "cname": "BinopTokenType",
            "supers": {
                "TokenType": 45
            },
            "methods": [
                55
            ]
        },
        {
            "index": 55,
            "fname": "constructor",
            "params": {
                "name": 3,
                "prec": 5
            },
            "ret": 54,
            "hobj": 1
        },
        {
            "index": 56,
            "oname": "",
            "fields": {
                "num": -44,
                "regexp": -44,
                "string": -44,
                "name": -44,
                "eof": -44,
                "bracketL": -44,
                "bracketR": -44,
                "braceL": -44,
                "braceBarL": -44,
                "braceR": -44,
                "braceBarR": -44,
                "parenL": -44,
                "parenR": -44,
                "comma": -44,
                "semi": -44,
                "colon": -44,
                "doubleColon": -44,
                "dot": -44,
                "question": -44,
                "arrow": -44,
                "template": -44,
                "ellipsis": -44,
                "backQuote": -44,
                "dollarBraceL": -44,
                "at": -44,
                "eq": -44,
                "assign": -44,
                "incDec": -44,
                "prefix": -44,
                "logicalOR": -54,
                "logicalAND": -54,
                "bitwiseOR": -54,
                "bitwiseXOR": -54,
                "bitwiseAND": -54,
                "equality": -54,
                "relational": -54,
                "bitShift": -54,
                "plusMin": -44,
                "modulo": -54,
                "star": -54,
                "slash": -54,
                "exponent": -44,
                "jsxName": -4,
                "jsxText": -4,
                "jsxTagStart": -4,
                "jsxTagEnd": -4,
                "_break": -4,
                "_case": -4,
                "_catch": -4,
                "_continue": -4,
                "_debugger": -4,
                "_default": -4,
                "_do": -4,
                "_else": -4,
                "_finally": -4,
                "_for": -4,
                "_function": -4,
                "_if": -4,
                "_return": -4,
                "_switch": -4,
                "_throw": -4,
                "_try": -4,
                "_var": -4,
                "_let": -4,
                "_const": -4,
                "_while": -4,
                "_with": -4,
                "_new": -4,
                "_this": -4,
                "_super": -4,
                "_class": -4,
                "_extends": -4,
                "_export": -4,
                "_import": -4,
                "_yield": -4,
                "_null": -4,
                "_true": -4,
                "_false": -4,
                "_in": -4,
                "_instanceof": -4,
                "_typeof": -4,
                "_void": -4,
                "_delete": -4
            }
        },
        {
            "index": 57,
            "oname": "Types",
            "fields": {
                "braceStatement": -58,
                "braceExpression": -58,
                "templateQuasi": -58,
                "parenStatement": -58,
                "parenExpression": -58,
                "template": -58,
                "functionExpression": -58,
                "j_oTag": -61,
                "j_cTag": -61,
                "j_expr": -61
            }
        },
        {
            "index": 58,
            "cname": "TokContext",
            "fields": {
                "token": -3,
                "isExpr": -2,
                "preserveSpace": -2,
                "override": -0
            },
            "methods": [
                59
            ]
        },
        {
            "index": 59,
            "fname": "constructor",
            "params": {
                "token": 3,
                "isExpr": 2,
                "preserveSpace": 60,
                "override": 0
            },
            "ret": 58
        },
        {
            "index": 60,
            "uname": "",
            "types": [
                2,
                4
            ]
        },
        {
            "index": 61,
            "uname": "",
            "types": [
                4,
                58
            ]
        },
        {
            "index": 62,
            "oname": "TokenizerContextJS",
            "fields": {
                "TokContext": -59,
                "types": -0
            }
        },
        {
            "index": 63,
            "cname": "Tokenizer",
            "fields": {
                "state": -65,
                "isLookahead": 2,
                "input": -3,
                "tt": -0,
                "inModule": -60
            },
            "sfields": {
                "static Token": -300
            },
            "methods": [
                64,
                307,
                308,
                309,
                310,
                311,
                312,
                313,
                314,
                315,
                316,
                317,
                318,
                319,
                320,
                321,
                322,
                323,
                324,
                325,
                326,
                327,
                328,
                329,
                330,
                331,
                333,
                334,
                335,
                336,
                337,
                338,
                339,
                340,
                341,
                342,
                343,
                344,
                345,
                346,
                347,
                348,
                349
            ]
        },
        {
            "index": 64,
            "fname": "constructor",
            "params": {
                "options": 0,
                "input": 3
            },
            "ret": 63
        },
        {
            "index": 65,
            "cname": "State",
            "fields": {
                "strict": 2,
                "context": 67,
                "input": 3,
                "potentialArrowAt": 5,
                "inMethod": 68,
                "inFunction": 2,
                "inGenerator": 2,
                "inAsync": 2,
                "inPropertyName": 2,
                "inType": 2,
                "noAnonFunctionType": 2,
                "labels": 119,
                "decorators": 119,
                "tokens": 302,
                "comments": 119,
                "trailingComments": 119,
                "leadingComments": 119,
                "commentStack": 119,
                "pos": 5,
                "lineStart": 5,
                "curLine": 5,
                "type": 44,
                "value": 104,
                "start": 5,
                "end": 5,
                "startLoc": 35,
                "endLoc": 35,
                "lastTokEndLoc": 39,
                "lastTokStartLoc": 39,
                "lastTokStart": 5,
                "lastTokEnd": 5,
                "exprAllowed": 2,
                "containsEsc": 2,
                "containsOctal": 2,
                "octalPosition": 22,
                "invalidTemplateEscapePosition": 22,
                "exportedIdentifiers": 24,
                "commentPreviousNode": 69
            },
            "methods": [
                66,
                304,
                305,
                306
            ]
        },
        {
            "index": 66,
            "fname": "constructor",
            "ret": 65
        },
        {
            "index": 67,
            "aname": "",
            "element": 58,
            "mode": "normal"
        },
        {
            "index": 68,
            "uname": "",
            "types": [
                2,
                3
            ]
        },
        {
            "index": 69,
            "cname": "Node",
            "fields": {
                "type": -3,
                "start": -22,
                "end": -5,
                "loc": -37,
                "range": 28,
                "leadingComments": 295,
                "trailingComments": 295,
                "innerComments": 119,
                "body": 296,
                "value": 104,
                "computed": 2,
                "kind": 3,
                "key": 69,
                "name": 297,
                "expressions": 119,
                "operator": 103,
                "prefix": 2,
                "argument": 111,
                "extra": 92,
                "left": 111,
                "right": 69,
                "test": 111,
                "properties": 119,
                "elements": 119,
                "consequent": 296,
                "alternate": 69,
                "async": 298,
                "generator": 2,
                "id": 111,
                "expression": 298,
                "params": 119,
                "pattern": 69,
                "flags": 5,
                "decorators": 119,
                "object": 111,
                "callee": 69,
                "property": 69,
                "arguments": 119,
                "tag": 69,
                "quasi": 69,
                "quasis": 119,
                "meta": 69,
                "tail": 2,
                "method": 2,
                "shorthand": 2,
                "delegate": 2,
                "program": 69,
                "comments": 119,
                "tokens": 302,
                "sourceType": 3,
                "label": 111,
                "declarations": 119,
                "init": 111,
                "discriminant": 69,
                "cases": 119,
                "block": 69,
                "handler": 111,
                "param": 69,
                "guardedHandlers": 119,
                "finalizer": 69,
                "statementStart": 5,
                "directives": 119,
                "directive": 3,
                "update": 69,
                "await": 2,
                "static": 2,
                "typeAnnotation": 69,
                "superClass": 69,
                "exported": 69,
                "specifiers": 119,
                "declaration": 111,
                "source": 111,
                "local": 69,
                "imported": 69,
                "regex": 226,
                "raw": 103,
                "elementType": 69,
                "typeParameters": 111,
                "rest": 111,
                "returnType": 69,
                "predicate": 111,
                "extends": 119,
                "mixins": 119,
                "qualification": 69,
                "variance": 111,
                "bound": 69,
                "default": 69,
                "optional": 2,
                "callProperties": 119,
                "indexers": 119,
                "exact": 2,
                "types": 119,
                "exportKind": 3,
                "_exprListItem": 2,
                "implements": 119,
                "superTypeParameters": 69,
                "importKind": 26,
                "namespace": 69,
                "attributes": 119,
                "selfClosing": 2,
                "openingElement": 69,
                "closingElement": 111,
                "children": 119
            },
            "methods": [
                70,
                303
            ]
        },
        {
            "index": 70,
            "fname": "constructor",
            "params": {
                "parser": 294,
                "pos": 22,
                "loc": 39
            },
            "ret": 69
        },
        {
            "index": 71,
            "cname": "Parser",
            "supers": {
                "Tokenizer": 64
            },
            "fields": {
                "options": -0,
                "plugins": -6,
                "filename": 26
            },
            "sfields": {
                "static plugins": -6
            },
            "methods": [
                72,
                73,
                74,
                75,
                76,
                77,
                78,
                79,
                80,
                81,
                82,
                83,
                84,
                85,
                86,
                87,
                88,
                91,
                93,
                96,
                97,
                98,
                99,
                101,
                102,
                105,
                107,
                108,
                110,
                112,
                114,
                115,
                116,
                117,
                118,
                120,
                121,
                122,
                123,
                124,
                125,
                126,
                127,
                129,
                130,
                131,
                132,
                133,
                134,
                135,
                136,
                137,
                138,
                139,
                140,
                141,
                142,
                143,
                144,
                145,
                147,
                148,
                149,
                150,
                151,
                152,
                153,
                154,
                155,
                156,
                157,
                158,
                159,
                160,
                161,
                162,
                163,
                164,
                165,
                166,
                167,
                168,
                169,
                170,
                171,
                172,
                173,
                174,
                175,
                176,
                177,
                178,
                179,
                180,
                181,
                182,
                183,
                184,
                185,
                186,
                187,
                188,
                189,
                190,
                191,
                192,
                193,
                194,
                195,
                196,
                197,
                198,
                199,
                200,
                201,
                202,
                203,
                204,
                205,
                206,
                207,
                208,
                209,
                210,
                211,
                212,
                213,
                214,
                215,
                216,
                217,
                218,
                219,
                220,
                221,
                222,
                223,
                224,
                225,
                227,
                228,
                229,
                230,
                231,
                232,
                233,
                234,
                235,
                236,
                237,
                238,
                239,
                240,
                241,
                242,
                243,
                244,
                245,
                246,
                247,
                248,
                249,
                250,
                251,
                252,
                253,
                254,
                255,
                256,
                257,
                258,
                259,
                260,
                261,
                263,
                264,
                265,
                266,
                267,
                268,
                269,
                270,
                271,
                272,
                273,
                274,
                275,
                276,
                277,
                278,
                279,
                280,
                281,
                282,
                283,
                284,
                285,
                286,
                287,
                288,
                289,
                290,
                291,
                292,
                293
            ]
        },
        {
            "index": 72,
            "fname": "constructor",
            "params": {
                "options": 0,
                "input": 3
            },
            "ret": 71,
            "hobj": 1
        },
        {
            "index": 73,
            "fname": "isReservedWord",
            "params": {
                "word": 3
            },
            "ret": 60
        },
        {
            "index": 74,
            "fname": "hasPlugin",
            "params": {
                "name": 3
            },
            "ret": 2
        },
        {
            "index": 75,
            "fname": "extends",
            "params": {
                "name": 3,
                "f": 0
            }
        },
        {
            "index": 76,
            "fname": "jsx_readToken"
        },
        {
            "index": 77,
            "fname": "loadPlugins",
            "params": {
                "pluginList": 24
            },
            "ret": 6
        },
        {
            "index": 78,
            "fname": "startNode",
            "ret": 69
        },
        {
            "index": 79,
            "fname": "startNodeAt",
            "params": {
                "pos": 22,
                "loc": 39
            },
            "ret": 69
        },
        {
            "index": 80,
            "fname": "parse",
            "ret": 69
        },
        {
            "index": 81,
            "fname": "addComment",
            "params": {
                "comment": 69
            }
        },
        {
            "index": 82,
            "fname": "processComment",
            "params": {
                "node": 69
            }
        },
        {
            "index": 83,
            "fname": "checkPropClash",
            "params": {
                "prop": 69,
                "propHash": 6
            }
        },
        {
            "index": 84,
            "fname": "finishNodeAt",
            "params": {
                "node": 69,
                "type": 3,
                "pos": 5,
                "loc": 39
            },
            "ret": 69
        },
        {
            "index": 85,
            "fname": "resetStartLocationFromNode",
            "params": {
                "node": 69,
                "locationNode": 69
            },
            "ret": 69
        },
        {
            "index": 86,
            "fname": "getExpression",
            "ret": 69
        },
        {
            "index": 87,
            "fname": "finishNode",
            "params": {
                "node": 69,
                "type": 3
            },
            "ret": 69
        },
        {
            "index": 88,
            "fname": "parseExpression",
            "params": {
                "noIn": 60,
                "refShorthandDefaultPos": 90
            },
            "ret": 69
        },
        {
            "index": 89,
            "oname": "",
            "fields": {
                "start": -5
            }
        },
        {
            "index": 90,
            "uname": "",
            "types": [
                4,
                89
            ]
        },
        {
            "index": 91,
            "fname": "checkLVal",
            "params": {
                "expr": 69,
                "isBinding": 60,
                "checkClashes": 92,
                "contextDescription": 3
            }
        },
        {
            "index": 92,
            "uname": "",
            "types": [
                4,
                6
            ]
        },
        {
            "index": 93,
            "fname": "parseMaybeAssign",
            "params": {
                "noIn": 60,
                "refShorthandDefaultPos": 90,
                "afterLeftParse": 95,
                "refNeedsArrowPos": 90
            },
            "ret": 69
        },
        {
            "index": 94,
            "bname": "Function"
        },
        {
            "index": 95,
            "uname": "",
            "types": [
                4,
                94
            ]
        },
        {
            "index": 96,
            "fname": "parseMaybeConditional",
            "params": {
                "noIn": 2,
                "refShorthandDefaultPos": 89,
                "refNeedsArrowPos": 89
            },
            "ret": 69
        },
        {
            "index": 97,
            "fname": "expect",
            "params": {
                "type": 48,
                "pos": 22
            },
            "ret": 60
        },
        {
            "index": 98,
            "fname": "parseConditional",
            "params": {
                "expr": 69,
                "noIn": 2,
                "startPos": 5,
                "startLoc": 35
            },
            "ret": 69
        },
        {
            "index": 99,
            "fname": "parseExprOps",
            "params": {
                "noIn": 2,
                "refShorthandDefaultPos": 100
            },
            "ret": 69
        },
        {
            "index": 100,
            "oname": "",
            "fields": {
                "start": -1
            }
        },
        {
            "index": 101,
            "fname": "parseExprOp",
            "params": {
                "left": 69,
                "leftStartPos": 5,
                "leftStartLoc": 35,
                "minPrec": 5,
                "noIn": 2
            },
            "ret": 69
        },
        {
            "index": 102,
            "fname": "addExtra",
            "params": {
                "node": 69,
                "key": 3,
                "val": 104
            }
        },
        {
            "index": 103,
            "bname": "Object"
        },
        {
            "index": 104,
            "uname": "",
            "types": [
                4,
                103
            ]
        },
        {
            "index": 105,
            "fname": "unexpected",
            "params": {
                "pos": 22,
                "messageOrType": 106
            }
        },
        {
            "index": 106,
            "uname": "",
            "types": [
                3,
                4,
                44
            ]
        },
        {
            "index": 107,
            "fname": "parseMaybeUnary",
            "params": {
                "refShorthandDefaultPos": 90
            },
            "ret": 69
        },
        {
            "index": 108,
            "fname": "parseExprSubscripts",
            "params": {
                "refShorthandDefaultPos": 109
            },
            "ret": 69
        },
        {
            "index": 109,
            "uname": "",
            "types": [
                4,
                100
            ]
        },
        {
            "index": 110,
            "fname": "parseSubscripts",
            "params": {
                "base": 111,
                "startPos": 5,
                "startLoc": 35,
                "noCalls": 60
            },
            "ret": 69
        },
        {
            "index": 111,
            "uname": "",
            "types": [
                4,
                69
            ]
        },
        {
            "index": 112,
            "fname": "parseCallExpressionArguments",
            "params": {
                "close": 44,
                "possibleAsyncArrow": 2
            },
            "ret": 113
        },
        {
            "index": 113,
            "aname": "",
            "element": 111,
            "mode": "normal"
        },
        {
            "index": 114,
            "fname": "shouldParseAsyncArrow",
            "ret": 2
        },
        {
            "index": 115,
            "fname": "parseAsyncArrowFromCallExpression",
            "params": {
                "node": 69,
                "call": 69
            },
            "ret": 69
        },
        {
            "index": 116,
            "fname": "parseNoCallExpr",
            "ret": 69
        },
        {
            "index": 117,
            "fname": "toAssignable",
            "params": {
                "node": 111,
                "isBinding": 60,
                "contextDescription": 26
            },
            "ret": 111
        },
        {
            "index": 118,
            "fname": "toAssignableList",
            "params": {
                "exprList": 119,
                "isBinding": 60,
                "contextDescription": 26
            },
            "ret": 119
        },
        {
            "index": 119,
            "aname": "",
            "element": 69,
            "mode": "normal"
        },
        {
            "index": 120,
            "fname": "toReferencedList",
            "params": {
                "exprList": 119
            },
            "ret": 119
        },
        {
            "index": 121,
            "fname": "parseSpread",
            "params": {
                "refShorthandDefaultPos": 109
            },
            "ret": 69
        },
        {
            "index": 122,
            "fname": "parseRest",
            "ret": 69
        },
        {
            "index": 123,
            "fname": "parseBindingAtom",
            "ret": 111
        },
        {
            "index": 124,
            "fname": "parseBindingList",
            "params": {
                "close": 44,
                "allowEmpty": 60
            },
            "ret": 113
        },
        {
            "index": 125,
            "fname": "parseAssignableListItemTypes",
            "params": {
                "param": 69
            },
            "ret": 69
        },
        {
            "index": 126,
            "fname": "parseMaybeDefault",
            "params": {
                "startPos": 22,
                "startLoc": 39,
                "left": 111
            },
            "ret": 111
        },
        {
            "index": 127,
            "fname": "raise",
            "params": {
                "pos": 22,
                "message": 128
            }
        },
        {
            "index": 128,
            "uname": "",
            "types": [
                3,
                44
            ]
        },
        {
            "index": 129,
            "fname": "shouldAllowYieldIdentifier",
            "ret": 2
        },
        {
            "index": 130,
            "fname": "parseBindingIdentifier",
            "ret": 69
        },
        {
            "index": 131,
            "fname": "parseFunction",
            "params": {
                "node": 69,
                "isStatement": 2,
                "allowExpressionBody": 60,
                "isAsync": 60,
                "optionalId": 60
            },
            "ret": 69
        },
        {
            "index": 132,
            "fname": "parseExprAtom",
            "params": {
                "refShorthandDefaultPos": 90
            },
            "ret": 111
        },
        {
            "index": 133,
            "fname": "parseFunctionExpression",
            "ret": 69
        },
        {
            "index": 134,
            "fname": "parseMetaProperty",
            "params": {
                "node": 69,
                "meta": 69,
                "propertyName": 3
            },
            "ret": 69
        },
        {
            "index": 135,
            "fname": "parseLiteral",
            "params": {
                "value": 92,
                "type": 3,
                "startPos": 22,
                "startLoc": 39
            },
            "ret": 69
        },
        {
            "index": 136,
            "fname": "parseParenExpression",
            "ret": 69
        },
        {
            "index": 137,
            "fname": "parseParenAndDistinguishExpression",
            "params": {
                "startPos": 22,
                "startLoc": 39,
                "canBeArrow": 2
            },
            "ret": 69
        },
        {
            "index": 138,
            "fname": "shouldParseArrow",
            "ret": 2
        },
        {
            "index": 139,
            "fname": "parseArrow",
            "params": {
                "node": 69
            },
            "ret": 111
        },
        {
            "index": 140,
            "fname": "parseParenItem",
            "params": {
                "node": 69,
                "p2": 22,
                "p3": 39
            },
            "ret": 69
        },
        {
            "index": 141,
            "fname": "parseNew",
            "ret": 69
        },
        {
            "index": 142,
            "fname": "parseTemplateElement",
            "params": {
                "isTagged": 2
            },
            "ret": 69
        },
        {
            "index": 143,
            "fname": "parseTemplate",
            "params": {
                "isTagged": 2
            },
            "ret": 69
        },
        {
            "index": 144,
            "fname": "parseObj",
            "params": {
                "isPattern": 2,
                "refShorthandDefaultPos": 90
            },
            "ret": 69
        },
        {
            "index": 145,
            "fname": "isGetterOrSetterMethod",
            "params": {
                "prop": 69,
                "isPattern": 60
            },
            "ret": 146
        },
        {
            "index": 146,
            "uname": "",
            "types": [
                2,
                3,
                4
            ]
        },
        {
            "index": 147,
            "fname": "checkGetterSetterParamCount",
            "params": {
                "method": 69
            }
        },
        {
            "index": 148,
            "fname": "parseObjectMethod",
            "params": {
                "prop": 69,
                "isGenerator": 2,
                "isAsync": 60,
                "isPattern": 60
            },
            "ret": 111
        },
        {
            "index": 149,
            "fname": "parseObjectProperty",
            "params": {
                "prop": 69,
                "startPos": 22,
                "startLoc": 39,
                "isPattern": 60,
                "refShorthandDefaultPos": 109
            },
            "ret": 111
        },
        {
            "index": 150,
            "fname": "parseObjPropValue",
            "params": {
                "prop": 69,
                "startPos": 22,
                "startLoc": 39,
                "isGenerator": 2,
                "isAsync": 60,
                "isPattern": 60,
                "refShorthandDefaultPos": 90
            },
            "ret": 111
        },
        {
            "index": 151,
            "fname": "parsePropertyName",
            "params": {
                "prop": 69
            },
            "ret": 69
        },
        {
            "index": 152,
            "fname": "initFunction",
            "params": {
                "node": 69,
                "isAsync": 60
            }
        },
        {
            "index": 153,
            "fname": "parseMethod",
            "params": {
                "node": 69,
                "isGenerator": 60,
                "isAsync": 60
            },
            "ret": 69
        },
        {
            "index": 154,
            "fname": "parseArrowExpression",
            "params": {
                "node": 69,
                "params": 119,
                "isAsync": 60
            },
            "ret": 69
        },
        {
            "index": 155,
            "fname": "isStrictBody",
            "params": {
                "node": 69,
                "isExpression": 60
            },
            "ret": 2
        },
        {
            "index": 156,
            "fname": "parseFunctionBody",
            "params": {
                "node": 69,
                "allowExpression": 60
            }
        },
        {
            "index": 157,
            "fname": "parseExprList",
            "params": {
                "close": 44,
                "allowEmpty": 60,
                "refShorthandDefaultPos": 90
            },
            "ret": 113
        },
        {
            "index": 158,
            "fname": "parseExprListItem",
            "params": {
                "allowEmpty": 60,
                "refShorthandDefaultPos": 90,
                "refNeedsArrowPos": 90
            },
            "ret": 111
        },
        {
            "index": 159,
            "fname": "parseIdentifier",
            "params": {
                "liberal": 60
            },
            "ret": 69
        },
        {
            "index": 160,
            "fname": "checkReservedWord",
            "params": {
                "word": 3,
                "startLoc": 22,
                "checkKeywords": 2,
                "isBinding": 2
            }
        },
        {
            "index": 161,
            "fname": "parseAwait",
            "params": {
                "node": 69
            },
            "ret": 69
        },
        {
            "index": 162,
            "fname": "parseYield",
            "ret": 69
        },
        {
            "index": 163,
            "fname": "parseTopLevel",
            "params": {
                "file": 69,
                "program": 69
            },
            "ret": 69
        },
        {
            "index": 164,
            "fname": "stmtToDirective",
            "params": {
                "stmt": 69
            },
            "ret": 69
        },
        {
            "index": 165,
            "fname": "parseStatement",
            "params": {
                "declaration": 2,
                "topLevel": 60
            },
            "ret": 69
        },
        {
            "index": 166,
            "fname": "takeDecorators",
            "params": {
                "node": 69
            }
        },
        {
            "index": 167,
            "fname": "parseDecorators",
            "params": {
                "allowExport": 60
            }
        },
        {
            "index": 168,
            "fname": "parseDecorator",
            "ret": 69
        },
        {
            "index": 169,
            "fname": "parseBreakContinueStatement",
            "params": {
                "node": 69,
                "keyword": 26
            },
            "ret": 69
        },
        {
            "index": 170,
            "fname": "parseDebuggerStatement",
            "params": {
                "node": 69
            },
            "ret": 69
        },
        {
            "index": 171,
            "fname": "parseDoStatement",
            "params": {
                "node": 69
            },
            "ret": 69
        },
        {
            "index": 172,
            "fname": "parseForStatement",
            "params": {
                "node": 69
            },
            "ret": 69
        },
        {
            "index": 173,
            "fname": "parseFunctionStatement",
            "params": {
                "node": 69
            },
            "ret": 69
        },
        {
            "index": 174,
            "fname": "parseIfStatement",
            "params": {
                "node": 69
            },
            "ret": 69
        },
        {
            "index": 175,
            "fname": "parseReturnStatement",
            "params": {
                "node": 69
            },
            "ret": 69
        },
        {
            "index": 176,
            "fname": "parseSwitchStatement",
            "params": {
                "node": 69
            },
            "ret": 69
        },
        {
            "index": 177,
            "fname": "parseThrowStatement",
            "params": {
                "node": 69
            },
            "ret": 69
        },
        {
            "index": 178,
            "fname": "parseTryStatement",
            "params": {
                "node": 69
            },
            "ret": 69
        },
        {
            "index": 179,
            "fname": "parseVarStatement",
            "params": {
                "node": 69,
                "kind": 44
            },
            "ret": 69
        },
        {
            "index": 180,
            "fname": "parseWhileStatement",
            "params": {
                "node": 69
            },
            "ret": 69
        },
        {
            "index": 181,
            "fname": "parseWithStatement",
            "params": {
                "node": 69
            },
            "ret": 69
        },
        {
            "index": 182,
            "fname": "parseEmptyStatement",
            "params": {
                "node": 69
            },
            "ret": 69
        },
        {
            "index": 183,
            "fname": "parseLabeledStatement",
            "params": {
                "node": 69,
                "maybeName": 26,
                "expr": 111
            },
            "ret": 69
        },
        {
            "index": 184,
            "fname": "parseExpressionStatement",
            "params": {
                "node": 69,
                "expr": 69
            },
            "ret": 69
        },
        {
            "index": 185,
            "fname": "parseBlock",
            "params": {
                "allowDirectives": 60,
                "next": 60
            },
            "ret": 69
        },
        {
            "index": 186,
            "fname": "isValidDirective",
            "params": {
                "stmt": 69
            },
            "ret": 2
        },
        {
            "index": 187,
            "fname": "parseBlockBody",
            "params": {
                "node": 69,
                "allowDirectives": 2,
                "topLevel": 2,
                "end": 44
            }
        },
        {
            "index": 188,
            "fname": "parseFor",
            "params": {
                "node": 69,
                "init": 111
            },
            "ret": 69
        },
        {
            "index": 189,
            "fname": "parseForIn",
            "params": {
                "node": 69,
                "init": 69,
                "forAwait": 2
            },
            "ret": 69
        },
        {
            "index": 190,
            "fname": "parseVar",
            "params": {
                "node": 69,
                "isFor": 2,
                "kind": 44
            },
            "ret": 69
        },
        {
            "index": 191,
            "fname": "parseVarHead",
            "params": {
                "decl": 69
            }
        },
        {
            "index": 192,
            "fname": "parseFunctionParams",
            "params": {
                "node": 69
            }
        },
        {
            "index": 193,
            "fname": "parseClass",
            "params": {
                "node": 69,
                "isStatement": 60,
                "optionalId": 60
            },
            "ret": 69
        },
        {
            "index": 194,
            "fname": "isClassProperty",
            "ret": 2
        },
        {
            "index": 195,
            "fname": "isClassMethod",
            "ret": 2
        },
        {
            "index": 196,
            "fname": "isNonstaticConstructor",
            "params": {
                "method": 69
            },
            "ret": 2
        },
        {
            "index": 197,
            "fname": "parseClassBody",
            "params": {
                "node": 69
            }
        },
        {
            "index": 198,
            "fname": "parseClassProperty",
            "params": {
                "node": 69
            },
            "ret": 69
        },
        {
            "index": 199,
            "fname": "parseClassMethod",
            "params": {
                "classBody": 69,
                "method": 69,
                "isGenerator": 2,
                "isAsync": 2
            }
        },
        {
            "index": 200,
            "fname": "parseClassId",
            "params": {
                "node": 69,
                "isStatement": 2,
                "optionalId": 2
            }
        },
        {
            "index": 201,
            "fname": "parseClassSuper",
            "params": {
                "node": 69
            }
        },
        {
            "index": 202,
            "fname": "parseExport",
            "params": {
                "node": 69
            },
            "ret": 69
        },
        {
            "index": 203,
            "fname": "parseExportDeclaration",
            "params": {
                "p1": 111
            },
            "ret": 69
        },
        {
            "index": 204,
            "fname": "isExportDefaultSpecifier",
            "ret": 2
        },
        {
            "index": 205,
            "fname": "parseExportSpecifiersMaybe",
            "params": {
                "node": 69
            }
        },
        {
            "index": 206,
            "fname": "parseExportFrom",
            "params": {
                "node": 69,
                "expect": 60
            }
        },
        {
            "index": 207,
            "fname": "shouldParseExportDeclaration",
            "ret": 2
        },
        {
            "index": 208,
            "fname": "checkExport",
            "params": {
                "node": 69,
                "checkNames": 60,
                "isDefault": 60
            }
        },
        {
            "index": 209,
            "fname": "checkDeclaration",
            "params": {
                "node": 69
            }
        },
        {
            "index": 210,
            "fname": "checkDuplicateExports",
            "params": {
                "node": 69,
                "name": 3
            }
        },
        {
            "index": 211,
            "fname": "raiseDuplicateExportError",
            "params": {
                "node": 69,
                "name": 3
            }
        },
        {
            "index": 212,
            "fname": "parseExportSpecifiers",
            "ret": 119
        },
        {
            "index": 213,
            "fname": "parseImport",
            "params": {
                "node": 69
            },
            "ret": 69
        },
        {
            "index": 214,
            "fname": "parseImportSpecifiers",
            "params": {
                "node": 69
            }
        },
        {
            "index": 215,
            "fname": "parseImportSpecifier",
            "params": {
                "node": 69
            }
        },
        {
            "index": 216,
            "fname": "parseImportSpecifierDefault",
            "params": {
                "id": 69,
                "startPos": 5,
                "startLoc": 35
            },
            "ret": 69
        },
        {
            "index": 217,
            "fname": "isRelational",
            "params": {
                "op": 3
            },
            "ret": 2
        },
        {
            "index": 218,
            "fname": "expectRelational",
            "params": {
                "op": 3
            }
        },
        {
            "index": 219,
            "fname": "isContextual",
            "params": {
                "name": 3
            },
            "ret": 2
        },
        {
            "index": 220,
            "fname": "eatContextual",
            "params": {
                "name": 3
            },
            "ret": 2
        },
        {
            "index": 221,
            "fname": "expectContextual",
            "params": {
                "name": 3,
                "message": 26
            }
        },
        {
            "index": 222,
            "fname": "canInsertSemicolon",
            "ret": 2
        },
        {
            "index": 223,
            "fname": "isLineTerminator",
            "ret": 2
        },
        {
            "index": 224,
            "fname": "semicolon"
        },
        {
            "index": 225,
            "fname": "estreeParseRegExpLiteral",
            "params": {
                "value": 226
            },
            "ret": 69
        },
        {
            "index": 226,
            "oname": "",
            "fields": {
                "pattern": -3,
                "flags": -3
            }
        },
        {
            "index": 227,
            "fname": "estreeParseLiteral",
            "params": {
                "value": 92
            },
            "ret": 69
        },
        {
            "index": 228,
            "fname": "directiveToStmt",
            "params": {
                "directive": 69
            },
            "ret": 69
        },
        {
            "index": 229,
            "fname": "flowParseTypeInitialiser",
            "params": {
                "tok": 48
            },
            "ret": 69
        },
        {
            "index": 230,
            "fname": "flowParsePredicate",
            "ret": 69
        },
        {
            "index": 231,
            "fname": "flowParseTypeAndPredicateInitialiser",
            "ret": 113
        },
        {
            "index": 232,
            "fname": "flowParseDeclareClass",
            "params": {
                "node": 69
            },
            "ret": 69
        },
        {
            "index": 233,
            "fname": "flowParseDeclareFunction",
            "params": {
                "node": 69
            },
            "ret": 69
        },
        {
            "index": 234,
            "fname": "flowParseDeclare",
            "params": {
                "node": 69,
                "p2": 60
            },
            "ret": 111
        },
        {
            "index": 235,
            "fname": "flowParseDeclareVariable",
            "params": {
                "node": 69
            },
            "ret": 69
        },
        {
            "index": 236,
            "fname": "flowParseDeclareModule",
            "params": {
                "node": 69
            },
            "ret": 69
        },
        {
            "index": 237,
            "fname": "flowParseDeclareModuleExports",
            "params": {
                "node": 69
            },
            "ret": 69
        },
        {
            "index": 238,
            "fname": "flowParseDeclareTypeAlias",
            "params": {
                "node": 69
            },
            "ret": 69
        },
        {
            "index": 239,
            "fname": "flowParseDeclareInterface",
            "params": {
                "node": 69
            },
            "ret": 69
        },
        {
            "index": 240,
            "fname": "flowParseInterfaceish",
            "params": {
                "node": 69,
                "allowStatic": 60
            }
        },
        {
            "index": 241,
            "fname": "flowParseInterfaceExtends",
            "ret": 69
        },
        {
            "index": 242,
            "fname": "flowParseInterface",
            "params": {
                "node": 69
            },
            "ret": 69
        },
        {
            "index": 243,
            "fname": "flowParseRestrictedIdentifier",
            "params": {
                "liberal": 60
            },
            "ret": 69
        },
        {
            "index": 244,
            "fname": "flowParseTypeAlias",
            "params": {
                "node": 69
            },
            "ret": 69
        },
        {
            "index": 245,
            "fname": "flowParseTypeParameter",
            "ret": 69
        },
        {
            "index": 246,
            "fname": "flowParseTypeParameterDeclaration",
            "ret": 69
        },
        {
            "index": 247,
            "fname": "flowParseTypeParameterInstantiation",
            "ret": 69
        },
        {
            "index": 248,
            "fname": "flowParseObjectPropertyKey",
            "ret": 111
        },
        {
            "index": 249,
            "fname": "flowParseObjectTypeIndexer",
            "params": {
                "node": 69,
                "isStatic": 2,
                "variance": 69
            },
            "ret": 69
        },
        {
            "index": 250,
            "fname": "flowParseObjectTypeMethodish",
            "params": {
                "node": 69
            },
            "ret": 69
        },
        {
            "index": 251,
            "fname": "flowParseObjectTypeMethod",
            "params": {
                "startPos": 5,
                "startLoc": 35,
                "isStatic": 2,
                "key": 69
            },
            "ret": 69
        },
        {
            "index": 252,
            "fname": "flowParseObjectTypeCallProperty",
            "params": {
                "node": 69,
                "isStatic": 2
            },
            "ret": 69
        },
        {
            "index": 253,
            "fname": "flowParseObjectType",
            "params": {
                "allowStatic": 2,
                "allowExact": 60
            },
            "ret": 69
        },
        {
            "index": 254,
            "fname": "flowObjectTypeSemicolon"
        },
        {
            "index": 255,
            "fname": "flowParseQualifiedTypeIdentifier",
            "params": {
                "startPos": 22,
                "startLoc": 39,
                "id": 111
            },
            "ret": 69
        },
        {
            "index": 256,
            "fname": "flowParseGenericType",
            "params": {
                "startPos": 5,
                "startLoc": 35,
                "id": 69
            },
            "ret": 69
        },
        {
            "index": 257,
            "fname": "flowParseTypeofType",
            "ret": 69
        },
        {
            "index": 258,
            "fname": "flowParseTupleType",
            "ret": 69
        },
        {
            "index": 259,
            "fname": "flowParseFunctionTypeParam",
            "ret": 69
        },
        {
            "index": 260,
            "fname": "reinterpretTypeAsFunctionTypeParam",
            "params": {
                "type": 69
            },
            "ret": 69
        },
        {
            "index": 261,
            "fname": "flowParseFunctionTypeParams",
            "params": {
                "params": 119
            },
            "ret": 262
        },
        {
            "index": 262,
            "oname": "",
            "fields": {
                "params": -119,
                "rest": -111
            }
        },
        {
            "index": 263,
            "fname": "flowIdentToTypeAnnotation",
            "params": {
                "startPos": 5,
                "startLoc": 35,
                "node": 69,
                "id": 69
            },
            "ret": 69
        },
        {
            "index": 264,
            "fname": "flowParsePrimaryType",
            "ret": 111
        },
        {
            "index": 265,
            "fname": "flowParsePostfixType",
            "ret": 111
        },
        {
            "index": 266,
            "fname": "flowParsePrefixType",
            "ret": 69
        },
        {
            "index": 267,
            "fname": "flowParseAnonFunctionWithoutParens",
            "ret": 69
        },
        {
            "index": 268,
            "fname": "flowParseIntersectionType",
            "ret": 69
        },
        {
            "index": 269,
            "fname": "flowParseUnionType",
            "ret": 69
        },
        {
            "index": 270,
            "fname": "flowParseType",
            "ret": 69
        },
        {
            "index": 271,
            "fname": "flowParseTypeAnnotation",
            "ret": 69
        },
        {
            "index": 272,
            "fname": "flowParseTypeAndPredicateAnnotation",
            "ret": 69
        },
        {
            "index": 273,
            "fname": "flowParseTypeAnnotatableIdentifier",
            "ret": 69
        },
        {
            "index": 274,
            "fname": "typeCastToParameter",
            "params": {
                "node": 69
            },
            "ret": 69
        },
        {
            "index": 275,
            "fname": "flowParseVariance",
            "ret": 111
        },
        {
            "index": 276,
            "fname": "jsxReadToken"
        },
        {
            "index": 277,
            "fname": "jsxReadNewLine",
            "params": {
                "normalizeCRLF": 2
            },
            "ret": 3
        },
        {
            "index": 278,
            "fname": "jsxReadString",
            "params": {
                "quote": 5
            }
        },
        {
            "index": 279,
            "fname": "getJsxXhtmlJS",
            "params": {
                "str": 3
            },
            "ret": 26
        },
        {
            "index": 280,
            "fname": "jsxReadEntity",
            "ret": 3
        },
        {
            "index": 281,
            "fname": "jsxReadWord"
        },
        {
            "index": 282,
            "fname": "jsxParseIdentifier",
            "ret": 69
        },
        {
            "index": 283,
            "fname": "jsxParseNamespacedName",
            "ret": 69
        },
        {
            "index": 284,
            "fname": "jsxParseElementName",
            "ret": 69
        },
        {
            "index": 285,
            "fname": "jsxParseAttributeValue",
            "ret": 111
        },
        {
            "index": 286,
            "fname": "jsxParseEmptyExpression",
            "ret": 69
        },
        {
            "index": 287,
            "fname": "jsxParseSpreadChild",
            "ret": 69
        },
        {
            "index": 288,
            "fname": "jsxParseExpressionContainer",
            "ret": 69
        },
        {
            "index": 289,
            "fname": "jsxParseAttribute",
            "ret": 69
        },
        {
            "index": 290,
            "fname": "jsxParseOpeningElementAt",
            "params": {
                "startPos": 5,
                "startLoc": 35
            },
            "ret": 69
        },
        {
            "index": 291,
            "fname": "jsxParseClosingElementAt",
            "params": {
                "startPos": 5,
                "startLoc": 35
            },
            "ret": 69
        },
        {
            "index": 292,
            "fname": "jsxParseElementAt",
            "params": {
                "startPos": 5,
                "startLoc": 35
            },
            "ret": 69
        },
        {
            "index": 293,
            "fname": "jsxParseElement",
            "ret": 69
        },
        {
            "index": 294,
            "uname": "",
            "types": [
                4,
                71
            ]
        },
        {
            "index": 295,
            "uname": "",
            "types": [
                4,
                119
            ]
        },
        {
            "index": 296,
            "uname": "",
            "types": [
                69,
                119
            ]
        },
        {
            "index": 297,
            "uname": "",
            "types": [
                3,
                4,
                69
            ]
        },
        {
            "index": 298,
            "uname": "",
            "types": [
                2,
                69
            ]
        },
        {
            "index": 299,
            "cname": "Token",
            "fields": {
                "type": -128,
                "value": -104,
                "start": -22,
                "end": -5,
                "loc": -37
            },
            "methods": [
                300
            ]
        },
        {
            "index": 300,
            "fname": "constructor",
            "params": {
                "state": 65
            },
            "ret": 299
        },
        {
            "index": 301,
            "uname": "",
            "types": [
                69,
                299
            ]
        },
        {
            "index": 302,
            "aname": "",
            "element": 301,
            "mode": "normal"
        },
        {
            "index": 303,
            "fname": "__clone",
            "ret": 69
        },
        {
            "index": 304,
            "fname": "init",
            "params": {
                "options": 0,
                "input": 3
            },
            "ret": 65
        },
        {
            "index": 305,
            "fname": "curPosition",
            "ret": 35
        },
        {
            "index": 306,
            "fname": "clone",
            "params": {
                "skipArrays": 60
            },
            "ret": 65
        },
        {
            "index": 307,
            "fname": "next"
        },
        {
            "index": 308,
            "fname": "eat",
            "params": {
                "type": 48
            },
            "ret": 2
        },
        {
            "index": 309,
            "fname": "match",
            "params": {
                "type": 48
            },
            "ret": 2
        },
        {
            "index": 310,
            "fname": "isKeyword",
            "params": {
                "word": 3
            },
            "ret": 2
        },
        {
            "index": 311,
            "fname": "lookahead",
            "ret": 65
        },
        {
            "index": 312,
            "fname": "setStrict",
            "params": {
                "strict": 2
            }
        },
        {
            "index": 313,
            "fname": "curContext",
            "ret": 58
        },
        {
            "index": 314,
            "fname": "nextToken"
        },
        {
            "index": 315,
            "fname": "readToken",
            "params": {
                "code": 5
            }
        },
        {
            "index": 316,
            "fname": "fullCharCodeAtPos",
            "ret": 5
        },
        {
            "index": 317,
            "fname": "addComment",
            "params": {
                "comment": 69
            }
        },
        {
            "index": 318,
            "fname": "raise",
            "params": {
                "pos": 5,
                "message": 128
            }
        },
        {
            "index": 319,
            "fname": "pushComment",
            "params": {
                "block": 2,
                "text": 3,
                "start": 5,
                "end": 5,
                "startLoc": 35,
                "endLoc": 35
            }
        },
        {
            "index": 320,
            "fname": "skipBlockComment"
        },
        {
            "index": 321,
            "fname": "skipLineComment",
            "params": {
                "startSkip": 5
            }
        },
        {
            "index": 322,
            "fname": "skipSpace"
        },
        {
            "index": 323,
            "fname": "finishToken",
            "params": {
                "type": 48,
                "val": 104
            }
        },
        {
            "index": 324,
            "fname": "readToken_dot"
        },
        {
            "index": 325,
            "fname": "readToken_slash"
        },
        {
            "index": 326,
            "fname": "readToken_mult_modulo",
            "params": {
                "code": 5
            }
        },
        {
            "index": 327,
            "fname": "hasPlugin",
            "params": {
                "name": 3
            },
            "ret": 2
        },
        {
            "index": 328,
            "fname": "readToken_pipe_amp",
            "params": {
                "code": 5
            }
        },
        {
            "index": 329,
            "fname": "readToken_caret"
        },
        {
            "index": 330,
            "fname": "readToken_plus_min",
            "params": {
                "code": 5
            }
        },
        {
            "index": 331,
            "fname": "unexpected",
            "params": {
                "pos": 22,
                "messageOrType": 332
            }
        },
        {
            "index": 332,
            "uname": "",
            "types": [
                3,
                6
            ]
        },
        {
            "index": 333,
            "fname": "readToken_lt_gt",
            "params": {
                "code": 5
            }
        },
        {
            "index": 334,
            "fname": "readToken_eq_excl",
            "params": {
                "code": 5
            }
        },
        {
            "index": 335,
            "fname": "getTokenFromCode",
            "params": {
                "code": 5
            }
        },
        {
            "index": 336,
            "fname": "finishOp",
            "params": {
                "type": 44,
                "size": 5
            }
        },
        {
            "index": 337,
            "fname": "readRegexp"
        },
        {
            "index": 338,
            "fname": "readInt",
            "params": {
                "radix": 5,
                "len": 22
            },
            "ret": 22
        },
        {
            "index": 339,
            "fname": "readRadixNumber",
            "params": {
                "radix": 5
            }
        },
        {
            "index": 340,
            "fname": "readNumber",
            "params": {
                "startsWithDot": 2
            }
        },
        {
            "index": 341,
            "fname": "readCodePoint",
            "params": {
                "throwOnInvalid": 2
            },
            "ret": 22
        },
        {
            "index": 342,
            "fname": "readString",
            "params": {
                "quote": 5
            }
        },
        {
            "index": 343,
            "fname": "readTmplToken"
        },
        {
            "index": 344,
            "fname": "readEscapedChar",
            "params": {
                "inTemplate": 2
            },
            "ret": 26
        },
        {
            "index": 345,
            "fname": "readHexChar",
            "params": {
                "len": 5,
                "throwOnInvalid": 2
            },
            "ret": 22
        },
        {
            "index": 346,
            "fname": "readWord1",
            "ret": 3
        },
        {
            "index": 347,
            "fname": "readWord"
        },
        {
            "index": 348,
            "fname": "braceIsBlock",
            "params": {
                "prevType": 48
            },
            "ret": 2
        },
        {
            "index": 349,
            "fname": "updateContext",
            "params": {
                "prevType": 48
            }
        },
        {
            "index": 350,
            "oname": "",
            "fields": {
                "braceStatement": -58,
                "braceExpression": -58,
                "templateQuasi": -58,
                "parenStatement": -58,
                "parenExpression": -58,
                "template": -58,
                "functionExpression": -58,
                "j_oTag": -4,
                "j_cTag": -4,
                "j_expr": -4
            }
        },
        {
            "index": 351,
            "fname": "",
            "params": {
                "p": 63
            }
        },
        {
            "index": 352,
            "fname": ""
        },
        {
            "index": 353,
            "fname": "",
            "params": {
                "prevType": 48
            }
        },
        {
            "index": 354,
            "fname": "",
            "params": {
                "prevType": 48
            }
        },
        {
            "index": 355,
            "fname": ""
        },
        {
            "index": 356,
            "fname": "",
            "params": {
                "prevType": 48
            }
        },
        {
            "index": 357,
            "fname": ""
        },
        {
            "index": 358,
            "fname": ""
        },
        {
            "index": 359,
            "fname": ""
        },
        {
            "index": 360,
            "oname": "StateOptions",
            "fields": {
                "sourceType": -3,
                "startLine": -5,
                "sourceFilename": -26,
                "allowReturnOutsideFunction": -2,
                "allowImportExportEverywhere": -2,
                "allowSuperOutsideMethod": -2,
                "plugins": -24,
                "strictMode": -60,
                "ranges": -2
            }
        },
        {
            "index": 361,
            "aname": "",
            "element": 0,
            "mode": "normal"
        },
        {
            "index": 362,
            "fname": "codePointToString",
            "params": {
                "code": 5
            },
            "ret": 3
        },
        {
            "index": 363,
            "bname": "RegExpMatchArray"
        },
        {
            "index": 364,
            "oname": "",
            "fields": {
                "sourceType": -3,
                "sourceFilename": -4,
                "startLine": -1,
                "allowReturnOutsideFunction": -2,
                "allowImportExportEverywhere": -2,
                "allowSuperOutsideMethod": -2,
                "plugins": -361,
                "strictMode": -4,
                "ranges": -2
            }
        },
        {
            "index": 365,
            "fname": "getOptions",
            "params": {
                "opts": 0
            },
            "ret": 0
        },
        {
            "index": 366,
            "oname": "",
            "fields": {
                "defaultOptions": -0,
                "getOptions": -365
            }
        },
        {
            "index": 367,
            "fname": "last",
            "params": {
                "stack": 119
            },
            "ret": 69
        },
        {
            "index": 368,
            "fname": "",
            "params": {
                "plugin": 3
            },
            "ret": 2
        },
        {
            "index": 369,
            "fname": "",
            "params": {
                "plugin": 3
            },
            "ret": 2
        },
        {
            "index": 370,
            "bname": "SyntaxError"
        },
        {
            "index": 371,
            "oname": "",
            "fields": {
                "raw": -3,
                "cooked": -104
            }
        },
        {
            "index": 372,
            "uname": "",
            "types": [
                4,
                27
            ]
        },
        {
            "index": 373,
            "uname": "",
            "types": [
                4,
                262
            ]
        },
        {
            "index": 374,
            "fname": "isSimpleProperty",
            "params": {
                "node": 69
            },
            "ret": 2
        },
        {
            "index": 375,
            "fname": "pluginsEstreeJS",
            "params": {
                "instance": 71
            }
        },
        {
            "index": 376,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 377
        },
        {
            "index": 377,
            "fname": "",
            "params": {
                "node": 69
            }
        },
        {
            "index": 378,
            "fname": "",
            "ret": 379
        },
        {
            "index": 379,
            "fname": "",
            "params": {
                "prop": 69
            }
        },
        {
            "index": 380,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 381
        },
        {
            "index": 381,
            "fname": "",
            "params": {
                "expr": 69,
                "isBinding": 2,
                "checkClashes": 6,
                "contextDescription": 26
            }
        },
        {
            "index": 382,
            "fname": "",
            "params": {
                "prop": 69
            }
        },
        {
            "index": 383,
            "fname": "",
            "ret": 384
        },
        {
            "index": 384,
            "fname": "",
            "params": {
                "prop": 69,
                "propHash": 6
            }
        },
        {
            "index": 385,
            "fname": "",
            "ret": 386
        },
        {
            "index": 386,
            "fname": "",
            "params": {
                "node": 69,
                "isExpression": 2
            },
            "ret": 2
        },
        {
            "index": 387,
            "fname": "",
            "ret": 388
        },
        {
            "index": 388,
            "fname": "",
            "params": {
                "stmt": 69
            },
            "ret": 2
        },
        {
            "index": 389,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 390
        },
        {
            "index": 390,
            "fname": "",
            "params": {
                "node": 69,
                "allowDirectives": 60,
                "topLevel": 60,
                "end": 48
            }
        },
        {
            "index": 391,
            "fname": "",
            "params": {
                "directive": 69
            }
        },
        {
            "index": 392,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 393
        },
        {
            "index": 393,
            "fname": "",
            "params": {
                "classBody": 69,
                "method": 111,
                "isGenerator": 60,
                "isAsync": 60
            }
        },
        {
            "index": 394,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 395
        },
        {
            "index": 395,
            "fname": "",
            "params": {
                "refShorthandDefaultPos": 90
            },
            "ret": 0
        },
        {
            "index": 396,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 397
        },
        {
            "index": 397,
            "fname": "",
            "params": {
                "value": 6,
                "type": 26,
                "startPos": 22,
                "startLoc": 39
            },
            "ret": 69
        },
        {
            "index": 398,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 399
        },
        {
            "index": 399,
            "fname": "",
            "params": {
                "node": 69,
                "isGenerator": 60,
                "isAsync": 60
            },
            "ret": 69
        },
        {
            "index": 400,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 401
        },
        {
            "index": 401,
            "fname": "",
            "params": {
                "prop": 69,
                "isGenerator": 2,
                "isAsync": 2,
                "isPattern": 2
            },
            "ret": 69
        },
        {
            "index": 402,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 403
        },
        {
            "index": 403,
            "fname": "",
            "params": {
                "prop": 69,
                "startPos": 5,
                "startLoc": 35,
                "isPattern": 2,
                "refShorthandDefaultPos": 100
            },
            "ret": 69
        },
        {
            "index": 404,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 405
        },
        {
            "index": 405,
            "fname": "",
            "params": {
                "node": 69,
                "isBinding": 2,
                "contextDescription": 26
            },
            "ret": 0
        },
        {
            "index": 406,
            "fname": "pluginsFlowJS",
            "params": {
                "instance": 71
            }
        },
        {
            "index": 407,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 408
        },
        {
            "index": 408,
            "fname": "",
            "params": {
                "node": 69,
                "allowExpression": 2
            },
            "ret": 0
        },
        {
            "index": 409,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 410
        },
        {
            "index": 410,
            "fname": "",
            "params": {
                "declaration": 69,
                "topLevel": 2
            },
            "ret": 0
        },
        {
            "index": 411,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 412
        },
        {
            "index": 412,
            "fname": "",
            "params": {
                "node": 69,
                "expr": 69
            },
            "ret": 0
        },
        {
            "index": 413,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 414
        },
        {
            "index": 414,
            "fname": "",
            "ret": 0
        },
        {
            "index": 415,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 416
        },
        {
            "index": 416,
            "fname": "",
            "params": {
                "expr": 69,
                "noIn": 2,
                "startPos": 5,
                "startLoc": 35,
                "refNeedsArrowPos": 100
            },
            "ret": 0
        },
        {
            "index": 417,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 418
        },
        {
            "index": 418,
            "fname": "",
            "params": {
                "node": 69,
                "startPos": 5,
                "startLoc": 35
            },
            "ret": 69
        },
        {
            "index": 419,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 420
        },
        {
            "index": 420,
            "fname": "",
            "params": {
                "node": 69
            },
            "ret": 69
        },
        {
            "index": 421,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 422
        },
        {
            "index": 422,
            "fname": "",
            "params": {
                "node": 69
            },
            "ret": 0
        },
        {
            "index": 423,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 424
        },
        {
            "index": 424,
            "fname": "",
            "params": {
                "node": 69
            }
        },
        {
            "index": 425,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 426
        },
        {
            "index": 426,
            "fname": "",
            "params": {
                "name": 3
            },
            "ret": 0
        },
        {
            "index": 427,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 428
        },
        {
            "index": 428,
            "fname": "",
            "params": {
                "code": 5
            },
            "ret": 0
        },
        {
            "index": 429,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 430
        },
        {
            "index": 430,
            "fname": "",
            "ret": 0
        },
        {
            "index": 431,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 432
        },
        {
            "index": 432,
            "fname": "",
            "params": {
                "node": 69,
                "isBinding": 2,
                "contextDescription": 3
            },
            "ret": 0
        },
        {
            "index": 433,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 434
        },
        {
            "index": 434,
            "fname": "",
            "params": {
                "exprList": 119,
                "isBinding": 2,
                "contextDescription": 3
            },
            "ret": 0
        },
        {
            "index": 435,
            "fname": "",
            "ret": 436
        },
        {
            "index": 436,
            "fname": "",
            "params": {
                "exprList": 119
            },
            "ret": 119
        },
        {
            "index": 437,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 438
        },
        {
            "index": 438,
            "fname": "",
            "params": {
                "allowEmpty": 2,
                "refShorthandDefaultPos": 89,
                "refNeedsArrowPos": 90
            },
            "ret": 69
        },
        {
            "index": 439,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 440
        },
        {
            "index": 440,
            "fname": "",
            "params": {
                "node": 69,
                "isBinding": 2,
                "checkClashes": 6,
                "contextDescription": 26
            },
            "ret": 0
        },
        {
            "index": 441,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 442
        },
        {
            "index": 442,
            "fname": "",
            "params": {
                "node": 69
            },
            "ret": 0
        },
        {
            "index": 443,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 444
        },
        {
            "index": 444,
            "fname": "",
            "ret": 0
        },
        {
            "index": 445,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 446
        },
        {
            "index": 446,
            "fname": "",
            "ret": 0
        },
        {
            "index": 447,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 448
        },
        {
            "index": 448,
            "fname": "",
            "params": {
                "classBody": 69,
                "method": 69,
                "isGenerator": 2,
                "isAsync": 2
            }
        },
        {
            "index": 449,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 450
        },
        {
            "index": 450,
            "fname": "",
            "params": {
                "node": 69,
                "isStatement": 2
            }
        },
        {
            "index": 451,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 452
        },
        {
            "index": 452,
            "fname": "",
            "params": {
                "node": 69
            },
            "ret": 69
        },
        {
            "index": 453,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 454
        },
        {
            "index": 454,
            "fname": "",
            "params": {
                "prop": 69
            }
        },
        {
            "index": 455,
            "fname": "",
            "ret": 456
        },
        {
            "index": 456,
            "fname": "",
            "params": {
                "param": 69
            },
            "ret": 69
        },
        {
            "index": 457,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 458
        },
        {
            "index": 458,
            "fname": "",
            "params": {
                "startPos": 22,
                "startLoc": 39,
                "left": 111
            },
            "ret": 69
        },
        {
            "index": 459,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 460
        },
        {
            "index": 460,
            "fname": "",
            "params": {
                "node": 69
            }
        },
        {
            "index": 461,
            "fname": "",
            "ret": 462
        },
        {
            "index": 462,
            "fname": "",
            "params": {
                "node": 69
            }
        },
        {
            "index": 463,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 464
        },
        {
            "index": 464,
            "fname": "",
            "params": {
                "node": 69
            }
        },
        {
            "index": 465,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 466
        },
        {
            "index": 466,
            "fname": "",
            "params": {
                "decl": 69
            }
        },
        {
            "index": 467,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 468
        },
        {
            "index": 468,
            "fname": "",
            "params": {
                "node": 69,
                "call": 94
            },
            "ret": 0
        },
        {
            "index": 469,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 470
        },
        {
            "index": 470,
            "fname": "",
            "ret": 0
        },
        {
            "index": 471,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 472
        },
        {
            "index": 472,
            "fname": "",
            "params": {
                "noIn": 60,
                "refShorthandDefaultPos": 90,
                "afterLeftParse": 95,
                "refNeedsArrowPos": 90
            },
            "ret": 0
        },
        {
            "index": 473,
            "uname": "",
            "types": [
                4,
                370
            ]
        },
        {
            "index": 474,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 475
        },
        {
            "index": 475,
            "fname": "",
            "params": {
                "node": 69
            },
            "ret": 0
        },
        {
            "index": 476,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 477
        },
        {
            "index": 477,
            "fname": "",
            "ret": 0
        },
        {
            "index": 478,
            "oname": "",
            "fields": {
                "quot": -3,
                "amp": -3,
                "apos": -3,
                "lt": -3,
                "gt": -3,
                "nbsp": -3,
                "iexcl": -3,
                "cent": -3,
                "pound": -3,
                "curren": -3,
                "yen": -3,
                "brvbar": -3,
                "sect": -3,
                "uml": -3,
                "copy": -3,
                "ordf": -3,
                "laquo": -3,
                "not": -3,
                "shy": -3,
                "reg": -3,
                "macr": -3,
                "deg": -3,
                "plusmn": -3,
                "sup2": -3,
                "sup3": -3,
                "acute": -3,
                "micro": -3,
                "para": -3,
                "middot": -3,
                "cedil": -3,
                "sup1": -3,
                "ordm": -3,
                "raquo": -3,
                "frac14": -3,
                "frac12": -3,
                "frac34": -3,
                "iquest": -3,
                "Agrave": -3,
                "Aacute": -3,
                "Acirc": -3,
                "Atilde": -3,
                "Auml": -3,
                "Aring": -3,
                "AElig": -3,
                "Ccedil": -3,
                "Egrave": -3,
                "Eacute": -3,
                "Ecirc": -3,
                "Euml": -3,
                "Igrave": -3,
                "Iacute": -3,
                "Icirc": -3,
                "Iuml": -3,
                "ETH": -3,
                "Ntilde": -3,
                "Ograve": -3,
                "Oacute": -3,
                "Ocirc": -3,
                "Otilde": -3,
                "Ouml": -3,
                "times": -3,
                "Oslash": -3,
                "Ugrave": -3,
                "Uacute": -3,
                "Ucirc": -3,
                "Uuml": -3,
                "Yacute": -3,
                "THORN": -3,
                "szlig": -3,
                "agrave": -3,
                "aacute": -3,
                "acirc": -3,
                "atilde": -3,
                "auml": -3,
                "aring": -3,
                "aelig": -3,
                "ccedil": -3,
                "egrave": -3,
                "eacute": -3,
                "ecirc": -3,
                "euml": -3,
                "igrave": -3,
                "iacute": -3,
                "icirc": -3,
                "iuml": -3,
                "eth": -3,
                "ntilde": -3,
                "ograve": -3,
                "oacute": -3,
                "ocirc": -3,
                "otilde": -3,
                "ouml": -3,
                "divide": -3,
                "oslash": -3,
                "ugrave": -3,
                "uacute": -3,
                "ucirc": -3,
                "uuml": -3,
                "yacute": -3,
                "thorn": -3,
                "yuml": -3,
                "OElig": -3,
                "oelig": -3,
                "Scaron": -3,
                "scaron": -3,
                "Yuml": -3,
                "fnof": -3,
                "circ": -3,
                "tilde": -3,
                "Alpha": -3,
                "Beta": -3,
                "Gamma": -3,
                "Delta": -3,
                "Epsilon": -3,
                "Zeta": -3,
                "Eta": -3,
                "Theta": -3,
                "Iota": -3,
                "Kappa": -3,
                "Lambda": -3,
                "Mu": -3,
                "Nu": -3,
                "Xi": -3,
                "Omicron": -3,
                "Pi": -3,
                "Rho": -3,
                "Sigma": -3,
                "Tau": -3,
                "Upsilon": -3,
                "Phi": -3,
                "Chi": -3,
                "Psi": -3,
                "Omega": -3,
                "alpha": -3,
                "beta": -3,
                "gamma": -3,
                "delta": -3,
                "epsilon": -3,
                "zeta": -3,
                "eta": -3,
                "theta": -3,
                "iota": -3,
                "kappa": -3,
                "lambda": -3,
                "mu": -3,
                "nu": -3,
                "xi": -3,
                "omicron": -3,
                "pi": -3,
                "rho": -3,
                "sigmaf": -3,
                "sigma": -3,
                "tau": -3,
                "upsilon": -3,
                "phi": -3,
                "chi": -3,
                "psi": -3,
                "omega": -3,
                "thetasym": -3,
                "upsih": -3,
                "piv": -3,
                "ensp": -3,
                "emsp": -3,
                "thinsp": -3,
                "zwnj": -3,
                "zwj": -3,
                "lrm": -3,
                "rlm": -3,
                "ndash": -3,
                "mdash": -3,
                "lsquo": -3,
                "rsquo": -3,
                "sbquo": -3,
                "ldquo": -3,
                "rdquo": -3,
                "bdquo": -3,
                "dagger": -3,
                "Dagger": -3,
                "bull": -3,
                "hellip": -3,
                "permil": -3,
                "prime": -3,
                "Prime": -3,
                "lsaquo": -3,
                "rsaquo": -3,
                "oline": -3,
                "frasl": -3,
                "euro": -3,
                "image": -3,
                "weierp": -3,
                "real": -3,
                "trade": -3,
                "alefsym": -3,
                "larr": -3,
                "uarr": -3,
                "rarr": -3,
                "darr": -3,
                "harr": -3,
                "crarr": -3,
                "lArr": -3,
                "uArr": -3,
                "rArr": -3,
                "dArr": -3,
                "hArr": -3,
                "forall": -3,
                "part": -3,
                "exist": -3,
                "empty": -3,
                "nabla": -3,
                "isin": -3,
                "notin": -3,
                "ni": -3,
                "prod": -3,
                "sum": -3,
                "minus": -3,
                "lowast": -3,
                "radic": -3,
                "prop": -3,
                "infin": -3,
                "ang": -3,
                "and": -3,
                "or": -3,
                "cap": -3,
                "cup": -3,
                "number": -3,
                "there4": -3,
                "sim": -3,
                "cong": -3,
                "asymp": -3,
                "ne": -3,
                "equiv": -3,
                "le": -3,
                "ge": -3,
                "sub": -3,
                "sup": -3,
                "nsub": -3,
                "sube": -3,
                "supe": -3,
                "oplus": -3,
                "otimes": -3,
                "perp": -3,
                "sdot": -3,
                "lceil": -3,
                "rceil": -3,
                "lfloor": -3,
                "rfloor": -3,
                "lang": -3,
                "rang": -3,
                "loz": -3,
                "spades": -3,
                "clubs": -3,
                "hearts": -3,
                "diams": -3
            }
        },
        {
            "index": 479,
            "fname": ""
        },
        {
            "index": 480,
            "fname": "",
            "params": {
                "prevType": 48
            }
        },
        {
            "index": 481,
            "fname": "getQualifiedJSXName",
            "params": {
                "object": 69
            },
            "ret": 26
        },
        {
            "index": 482,
            "fname": "pluginsJsxIndexJS",
            "params": {
                "instance": 71
            }
        },
        {
            "index": 483,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 484
        },
        {
            "index": 484,
            "fname": "",
            "params": {
                "refShortHandDefaultPos": 89
            },
            "ret": 0
        },
        {
            "index": 485,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 486
        },
        {
            "index": 486,
            "fname": "",
            "params": {
                "code": 5
            },
            "ret": 0
        },
        {
            "index": 487,
            "fname": "",
            "params": {
                "inner": 94
            },
            "ret": 488
        },
        {
            "index": 488,
            "fname": "",
            "params": {
                "prevType": 44
            },
            "ret": 0
        },
        {
            "index": 489,
            "cname": "Benchmark",
            "fields": {
                "sources": 491
            },
            "methods": [
                490,
                492
            ]
        },
        {
            "index": 490,
            "fname": "constructor",
            "params": {
                "verbose": 5
            },
            "ret": 489
        },
        {
            "index": 491,
            "aname": "",
            "element": 361,
            "mode": "normal"
        },
        {
            "index": 492,
            "fname": "runIteration"
        },
        {
            "index": 493,
            "oname": "",
            "fields": {
                "sourceType": -3
            }
        },
        {
            "index": 494,
            "fname": "appendSource",
            "params": {
                "s": 3
            }
        },
        {
            "index": 495,
            "fname": "parse",
            "params": {
                "input": 3,
                "options": 0
            },
            "ret": 69
        },
        {
            "index": 496,
            "fname": "parseExpression",
            "params": {
                "input": 3,
                "options": 0
            },
            "ret": 69
        },
        {
            "index": 497,
            "fname": "static now",
            "ret": 1
        },
        {
            "index": 498,
            "fname": "summation",
            "params": {
                "values": 499
            },
            "ret": 5
        },
        {
            "index": 499,
            "aname": "",
            "element": 103,
            "mode": "normal"
        },
        {
            "index": 500,
            "fname": "toScore",
            "params": {
                "timeValue": 103
            },
            "ret": 1
        },
        {
            "index": 501,
            "fname": "mean",
            "params": {
                "values": 499
            },
            "ret": 1
        },
        {
            "index": 502,
            "fname": "assert",
            "params": {
                "condition": 2
            }
        },
        {
            "index": 503,
            "fname": "processResults",
            "params": {
                "results": 499
            }
        },
        {
            "index": 504,
            "fname": "copyArray",
            "params": {
                "a": 499
            },
            "ret": 499
        },
        {
            "index": 505,
            "fname": "",
            "params": {
                "a": 103,
                "b": 103
            },
            "ret": 5
        },
        {
            "index": 506,
            "fname": "printScore"
        },
        {
            "index": 507,
            "fname": "main"
        }
    ]
}*/
"use strict";
var babylon;
(function (babylon) {
    class /*<@8>*/TmpBase {
        get /*<@10>*/isGP() { return this.type == GP; }
        get /*<@11>*/isFP() { return this.type == FP; }
        get /*<@12>*/isGPR() { return this.isReg && this.isGP; }
        get /*<@13>*/isFPR() { return this.isReg && this.isFP; }
        get /*<@14>*/reg() {
            if (!this.isReg)
                throw new Error("Called .reg on non-Reg");
            return this;
        }
        get /*<@15>*/gpr() {
            if (!this.isGPR)
                throw new Error("Called .gpr on non-GPR");
            return this;
        }
        get /*<@16>*/fpr() {
            if (!this.isFPR)
                throw new Error("Called .fpr on non-FPR");
            return this;
        }
    }
    const /*<@9>*/Void = Symbol("Void");
    const /*<@9>*/Int32 = Symbol("Int32");
    const /*<@9>*/Int64 = Symbol("Int64");
    const /*<@9>*/Float = Symbol("Float");
    const /*<@9>*/Double = Symbol("Double");
    // Arg type
    const /*<@9>*/GP = Symbol("GP");
    const /*<@9>*/FP = Symbol("FP");
    // Stack slot kind
    const /*<@9>*/Locked = Symbol("Locked");
    const /*<@9>*/Spill = Symbol("Spill");
    // Frequency class
    const /*<@9>*/Normal = Symbol("Normal");
    const /*<@9>*/Rare = Symbol("Rare");
    // Relational conditions
    const /*<@9>*/Equal = Symbol("Equal");
    const /*<@9>*/NotEqual = Symbol("NotEqual");
    const /*<@9>*/Above = Symbol("Above");
    const /*<@9>*/AboveOrEqual = Symbol("AboveOrEqual");
    const /*<@9>*/Below = Symbol("Below");
    const /*<@9>*/BelowOrEqual = Symbol("BelowOrEqual");
    const /*<@9>*/GreaterThan = Symbol("GreaterThan");
    const /*<@9>*/GreaterThanOrEqual = Symbol("GreaterThanOrEqual");
    const /*<@9>*/LessThan = Symbol("LessThan");
    const /*<@9>*/LessThanOrEqual = Symbol("LessThanOrEqual");
    function /*<@17>*/relCondCode(/*<@9>*/cond) {
        switch (cond) {
            case Equal:
                return 4;
            case NotEqual:
                return 5;
            case Above:
                return 7;
            case AboveOrEqual:
                return 3;
            case Below:
                return 2;
            case BelowOrEqual:
                return 6;
            case GreaterThan:
                return 15;
            case GreaterThanOrEqual:
                return 13;
            case LessThan:
                return 12;
            case LessThanOrEqual:
                return 14;
            default:
                throw new Error("Bad rel cond");
        }
    }
    // Result conditions
    const /*<@9>*/Overflow = Symbol("Overflow");
    const /*<@9>*/Signed = Symbol("Signed");
    const /*<@9>*/PositiveOrZero = Symbol("PositiveOrZero");
    const /*<@9>*/Zero = Symbol("Zero");
    const /*<@9>*/NonZero = Symbol("NonZero");
    function /*<@18>*/resCondCode(/*<@9>*/cond) {
        switch (cond) {
            case Overflow:
                return 0;
            case Signed:
                return 8;
            case PositiveOrZero:
                return 9;
            case Zero:
                return 4;
            case NonZero:
                return 5;
            default:
                throw new Error("Bad res cond: " + cond.toString());
        }
    }
    // Double conditions
    const /*<@9>*/DoubleEqual = Symbol("DoubleEqual");
    const /*<@9>*/DoubleNotEqual = Symbol("DoubleNotEqual");
    const /*<@9>*/DoubleGreaterThan = Symbol("DoubleGreaterThan");
    const /*<@9>*/DoubleGreaterThanOrEqual = Symbol("DoubleGreaterThanOrEqual");
    const /*<@9>*/DoubleLessThan = Symbol("DoubleLessThan");
    const /*<@9>*/DoubleLessThanOrEqual = Symbol("DoubleLessThanOrEqual");
    const /*<@9>*/DoubleEqualOrUnordered = Symbol("DoubleEqualOrUnordered");
    const /*<@9>*/DoubleNotEqualOrUnordered = Symbol("DoubleNotEqualOrUnordered");
    const /*<@9>*/DoubleGreaterThanOrUnordered = Symbol("DoubleGreaterThanOrUnordered");
    const /*<@9>*/DoubleGreaterThanOrEqualOrUnordered = Symbol("DoubleGreaterThanOrEqualOrUnordered");
    const /*<@9>*/DoubleLessThanOrUnordered = Symbol("DoubleLessThanOrUnordered");
    const /*<@9>*/DoubleLessThanOrEqualOrUnordered = Symbol("DoubleLessThanOrEqualOrUnordered");
    function /*<@19>*/doubleCondCode(/*<@9>*/cond) {
        const /*<@5>*/bitInvert = 0x10;
        const /*<@5>*/bitSpecial = 0x20;
        switch (cond) {
            case DoubleEqual:
                return 4 | bitSpecial;
            case DoubleNotEqual:
                return 5;
            case DoubleGreaterThan:
                return 7;
            case DoubleGreaterThanOrEqual:
                return 3;
            case DoubleLessThan:
                return 7 | bitInvert;
            case DoubleLessThanOrEqual:
                return 3 | bitInvert;
            case DoubleEqualOrUnordered:
                return 4;
            case DoubleNotEqualOrUnordered:
                return 5 | bitSpecial;
            case DoubleGreaterThanOrUnordered:
                return 2 | bitInvert;
            case DoubleGreaterThanOrEqualOrUnordered:
                return 6 | bitInvert;
            case DoubleLessThanOrUnordered:
                return 2;
            case DoubleLessThanOrEqualOrUnordered:
                return 6;
            default:
                throw new Error("Bad cond");
        }
    }
    // Define pointerType()
    const /*<@5>*/Ptr = 64;
    const utilIdentifierJS = /*<@6>*/{};
    {
        /* eslint max-len: 0 */
        // This is a trick taken from Esprima. It turns out that, on
        // non-Chrome browsers, to check whether a string is in a set, a
        // predicate containing a big ugly `switch` statement is faster than
        // a regular expression, and on Chrome the two are about on par.
        // This function uses `eval` (non-lexical) to produce such a
        // predicate from a space-separated string of words.
        //
        // It starts by sorting the words by length.
        function /*<@23>*/makePredicate(/*<@3>*/words) {
            let /*<@24>*/ret;
            ret = words.split(" ");
            return function /*<@25>*/(/*<@3>*/str) {
                return ret.indexOf(str) >= 0;
            };
        }
        // Reserved word lists for various dialects of the language
        const reservedWords = /*<@20>*/{
            6: makePredicate("enum await"),
            strict: makePredicate("implements interface let package private protected public static yield"),
            strictBind: makePredicate("eval arguments")
        };
        utilIdentifierJS.reservedWords = reservedWords;
        // And the keywords
        const isKeyword = makePredicate("break case catch continue debugger default do else finally for function if return switch throw try var while with null true false instanceof typeof void delete new in this let const class extends export import yield super");
        utilIdentifierJS.isKeyword = isKeyword;
        // ## Character categories
        // Big ugly regular expressions that match characters in the
        // whitespace, identifier, and identifier-start categories. These
        // are only applied when a character is found to actually have a
        // code point above 128.
        // Generated by `bin/generate-identifier-regex.js`.
        let /*<@26>*/nonASCIIidentifierStartChars = "\xaa\xb5\xba\xc0-\xd6\xd8-\xf6\xf8-\u02c1\u02c6-\u02d1\u02e0-\u02e4\u02ec\u02ee\u0370-\u0374\u0376\u0377\u037a-\u037d\u037f\u0386\u0388-\u038a\u038c\u038e-\u03a1\u03a3-\u03f5\u03f7-\u0481\u048a-\u052f\u0531-\u0556\u0559\u0561-\u0587\u05d0-\u05ea\u05f0-\u05f2\u0620-\u064a\u066e\u066f\u0671-\u06d3\u06d5\u06e5\u06e6\u06ee\u06ef\u06fa-\u06fc\u06ff\u0710\u0712-\u072f\u074d-\u07a5\u07b1\u07ca-\u07ea\u07f4\u07f5\u07fa\u0800-\u0815\u081a\u0824\u0828\u0840-\u0858\u08a0-\u08b4\u08b6-\u08bd\u0904-\u0939\u093d\u0950\u0958-\u0961\u0971-\u0980\u0985-\u098c\u098f\u0990\u0993-\u09a8\u09aa-\u09b0\u09b2\u09b6-\u09b9\u09bd\u09ce\u09dc\u09dd\u09df-\u09e1\u09f0\u09f1\u0a05-\u0a0a\u0a0f\u0a10\u0a13-\u0a28\u0a2a-\u0a30\u0a32\u0a33\u0a35\u0a36\u0a38\u0a39\u0a59-\u0a5c\u0a5e\u0a72-\u0a74\u0a85-\u0a8d\u0a8f-\u0a91\u0a93-\u0aa8\u0aaa-\u0ab0\u0ab2\u0ab3\u0ab5-\u0ab9\u0abd\u0ad0\u0ae0\u0ae1\u0af9\u0b05-\u0b0c\u0b0f\u0b10\u0b13-\u0b28\u0b2a-\u0b30\u0b32\u0b33\u0b35-\u0b39\u0b3d\u0b5c\u0b5d\u0b5f-\u0b61\u0b71\u0b83\u0b85-\u0b8a\u0b8e-\u0b90\u0b92-\u0b95\u0b99\u0b9a\u0b9c\u0b9e\u0b9f\u0ba3\u0ba4\u0ba8-\u0baa\u0bae-\u0bb9\u0bd0\u0c05-\u0c0c\u0c0e-\u0c10\u0c12-\u0c28\u0c2a-\u0c39\u0c3d\u0c58-\u0c5a\u0c60\u0c61\u0c80\u0c85-\u0c8c\u0c8e-\u0c90\u0c92-\u0ca8\u0caa-\u0cb3\u0cb5-\u0cb9\u0cbd\u0cde\u0ce0\u0ce1\u0cf1\u0cf2\u0d05-\u0d0c\u0d0e-\u0d10\u0d12-\u0d3a\u0d3d\u0d4e\u0d54-\u0d56\u0d5f-\u0d61\u0d7a-\u0d7f\u0d85-\u0d96\u0d9a-\u0db1\u0db3-\u0dbb\u0dbd\u0dc0-\u0dc6\u0e01-\u0e30\u0e32\u0e33\u0e40-\u0e46\u0e81\u0e82\u0e84\u0e87\u0e88\u0e8a\u0e8d\u0e94-\u0e97\u0e99-\u0e9f\u0ea1-\u0ea3\u0ea5\u0ea7\u0eaa\u0eab\u0ead-\u0eb0\u0eb2\u0eb3\u0ebd\u0ec0-\u0ec4\u0ec6\u0edc-\u0edf\u0f00\u0f40-\u0f47\u0f49-\u0f6c\u0f88-\u0f8c\u1000-\u102a\u103f\u1050-\u1055\u105a-\u105d\u1061\u1065\u1066\u106e-\u1070\u1075-\u1081\u108e\u10a0-\u10c5\u10c7\u10cd\u10d0-\u10fa\u10fc-\u1248\u124a-\u124d\u1250-\u1256\u1258\u125a-\u125d\u1260-\u1288\u128a-\u128d\u1290-\u12b0\u12b2-\u12b5\u12b8-\u12be\u12c0\u12c2-\u12c5\u12c8-\u12d6\u12d8-\u1310\u1312-\u1315\u1318-\u135a\u1380-\u138f\u13a0-\u13f5\u13f8-\u13fd\u1401-\u166c\u166f-\u167f\u1681-\u169a\u16a0-\u16ea\u16ee-\u16f8\u1700-\u170c\u170e-\u1711\u1720-\u1731\u1740-\u1751\u1760-\u176c\u176e-\u1770\u1780-\u17b3\u17d7\u17dc\u1820-\u1877\u1880-\u18a8\u18aa\u18b0-\u18f5\u1900-\u191e\u1950-\u196d\u1970-\u1974\u1980-\u19ab\u19b0-\u19c9\u1a00-\u1a16\u1a20-\u1a54\u1aa7\u1b05-\u1b33\u1b45-\u1b4b\u1b83-\u1ba0\u1bae\u1baf\u1bba-\u1be5\u1c00-\u1c23\u1c4d-\u1c4f\u1c5a-\u1c7d\u1c80-\u1c88\u1ce9-\u1cec\u1cee-\u1cf1\u1cf5\u1cf6\u1d00-\u1dbf\u1e00-\u1f15\u1f18-\u1f1d\u1f20-\u1f45\u1f48-\u1f4d\u1f50-\u1f57\u1f59\u1f5b\u1f5d\u1f5f-\u1f7d\u1f80-\u1fb4\u1fb6-\u1fbc\u1fbe\u1fc2-\u1fc4\u1fc6-\u1fcc\u1fd0-\u1fd3\u1fd6-\u1fdb\u1fe0-\u1fec\u1ff2-\u1ff4\u1ff6-\u1ffc\u2071\u207f\u2090-\u209c\u2102\u2107\u210a-\u2113\u2115\u2118-\u211d\u2124\u2126\u2128\u212a-\u2139\u213c-\u213f\u2145-\u2149\u214e\u2160-\u2188\u2c00-\u2c2e\u2c30-\u2c5e\u2c60-\u2ce4\u2ceb-\u2cee\u2cf2\u2cf3\u2d00-\u2d25\u2d27\u2d2d\u2d30-\u2d67\u2d6f\u2d80-\u2d96\u2da0-\u2da6\u2da8-\u2dae\u2db0-\u2db6\u2db8-\u2dbe\u2dc0-\u2dc6\u2dc8-\u2dce\u2dd0-\u2dd6\u2dd8-\u2dde\u3005-\u3007\u3021-\u3029\u3031-\u3035\u3038-\u303c\u3041-\u3096\u309b-\u309f\u30a1-\u30fa\u30fc-\u30ff\u3105-\u312d\u3131-\u318e\u31a0-\u31ba\u31f0-\u31ff\u3400-\u4db5\u4e00-\u9fd5\ua000-\ua48c\ua4d0-\ua4fd\ua500-\ua60c\ua610-\ua61f\ua62a\ua62b\ua640-\ua66e\ua67f-\ua69d\ua6a0-\ua6ef\ua717-\ua71f\ua722-\ua788\ua78b-\ua7ae\ua7b0-\ua7b7\ua7f7-\ua801\ua803-\ua805\ua807-\ua80a\ua80c-\ua822\ua840-\ua873\ua882-\ua8b3\ua8f2-\ua8f7\ua8fb\ua8fd\ua90a-\ua925\ua930-\ua946\ua960-\ua97c\ua984-\ua9b2\ua9cf\ua9e0-\ua9e4\ua9e6-\ua9ef\ua9fa-\ua9fe\uaa00-\uaa28\uaa40-\uaa42\uaa44-\uaa4b\uaa60-\uaa76\uaa7a\uaa7e-\uaaaf\uaab1\uaab5\uaab6\uaab9-\uaabd\uaac0\uaac2\uaadb-\uaadd\uaae0-\uaaea\uaaf2-\uaaf4\uab01-\uab06\uab09-\uab0e\uab11-\uab16\uab20-\uab26\uab28-\uab2e\uab30-\uab5a\uab5c-\uab65\uab70-\uabe2\uac00-\ud7a3\ud7b0-\ud7c6\ud7cb-\ud7fb\uf900-\ufa6d\ufa70-\ufad9\ufb00-\ufb06\ufb13-\ufb17\ufb1d\ufb1f-\ufb28\ufb2a-\ufb36\ufb38-\ufb3c\ufb3e\ufb40\ufb41\ufb43\ufb44\ufb46-\ufbb1\ufbd3-\ufd3d\ufd50-\ufd8f\ufd92-\ufdc7\ufdf0-\ufdfb\ufe70-\ufe74\ufe76-\ufefc\uff21-\uff3a\uff41-\uff5a\uff66-\uffbe\uffc2-\uffc7\uffca-\uffcf\uffd2-\uffd7\uffda-\uffdc";
        let /*<@26>*/nonASCIIidentifierChars = "\u200c\u200d\xb7\u0300-\u036f\u0387\u0483-\u0487\u0591-\u05bd\u05bf\u05c1\u05c2\u05c4\u05c5\u05c7\u0610-\u061a\u064b-\u0669\u0670\u06d6-\u06dc\u06df-\u06e4\u06e7\u06e8\u06ea-\u06ed\u06f0-\u06f9\u0711\u0730-\u074a\u07a6-\u07b0\u07c0-\u07c9\u07eb-\u07f3\u0816-\u0819\u081b-\u0823\u0825-\u0827\u0829-\u082d\u0859-\u085b\u08d4-\u08e1\u08e3-\u0903\u093a-\u093c\u093e-\u094f\u0951-\u0957\u0962\u0963\u0966-\u096f\u0981-\u0983\u09bc\u09be-\u09c4\u09c7\u09c8\u09cb-\u09cd\u09d7\u09e2\u09e3\u09e6-\u09ef\u0a01-\u0a03\u0a3c\u0a3e-\u0a42\u0a47\u0a48\u0a4b-\u0a4d\u0a51\u0a66-\u0a71\u0a75\u0a81-\u0a83\u0abc\u0abe-\u0ac5\u0ac7-\u0ac9\u0acb-\u0acd\u0ae2\u0ae3\u0ae6-\u0aef\u0b01-\u0b03\u0b3c\u0b3e-\u0b44\u0b47\u0b48\u0b4b-\u0b4d\u0b56\u0b57\u0b62\u0b63\u0b66-\u0b6f\u0b82\u0bbe-\u0bc2\u0bc6-\u0bc8\u0bca-\u0bcd\u0bd7\u0be6-\u0bef\u0c00-\u0c03\u0c3e-\u0c44\u0c46-\u0c48\u0c4a-\u0c4d\u0c55\u0c56\u0c62\u0c63\u0c66-\u0c6f\u0c81-\u0c83\u0cbc\u0cbe-\u0cc4\u0cc6-\u0cc8\u0cca-\u0ccd\u0cd5\u0cd6\u0ce2\u0ce3\u0ce6-\u0cef\u0d01-\u0d03\u0d3e-\u0d44\u0d46-\u0d48\u0d4a-\u0d4d\u0d57\u0d62\u0d63\u0d66-\u0d6f\u0d82\u0d83\u0dca\u0dcf-\u0dd4\u0dd6\u0dd8-\u0ddf\u0de6-\u0def\u0df2\u0df3\u0e31\u0e34-\u0e3a\u0e47-\u0e4e\u0e50-\u0e59\u0eb1\u0eb4-\u0eb9\u0ebb\u0ebc\u0ec8-\u0ecd\u0ed0-\u0ed9\u0f18\u0f19\u0f20-\u0f29\u0f35\u0f37\u0f39\u0f3e\u0f3f\u0f71-\u0f84\u0f86\u0f87\u0f8d-\u0f97\u0f99-\u0fbc\u0fc6\u102b-\u103e\u1040-\u1049\u1056-\u1059\u105e-\u1060\u1062-\u1064\u1067-\u106d\u1071-\u1074\u1082-\u108d\u108f-\u109d\u135d-\u135f\u1369-\u1371\u1712-\u1714\u1732-\u1734\u1752\u1753\u1772\u1773\u17b4-\u17d3\u17dd\u17e0-\u17e9\u180b-\u180d\u1810-\u1819\u18a9\u1920-\u192b\u1930-\u193b\u1946-\u194f\u19d0-\u19da\u1a17-\u1a1b\u1a55-\u1a5e\u1a60-\u1a7c\u1a7f-\u1a89\u1a90-\u1a99\u1ab0-\u1abd\u1b00-\u1b04\u1b34-\u1b44\u1b50-\u1b59\u1b6b-\u1b73\u1b80-\u1b82\u1ba1-\u1bad\u1bb0-\u1bb9\u1be6-\u1bf3\u1c24-\u1c37\u1c40-\u1c49\u1c50-\u1c59\u1cd0-\u1cd2\u1cd4-\u1ce8\u1ced\u1cf2-\u1cf4\u1cf8\u1cf9\u1dc0-\u1df5\u1dfb-\u1dff\u203f\u2040\u2054\u20d0-\u20dc\u20e1\u20e5-\u20f0\u2cef-\u2cf1\u2d7f\u2de0-\u2dff\u302a-\u302f\u3099\u309a\ua620-\ua629\ua66f\ua674-\ua67d\ua69e\ua69f\ua6f0\ua6f1\ua802\ua806\ua80b\ua823-\ua827\ua880\ua881\ua8b4-\ua8c5\ua8d0-\ua8d9\ua8e0-\ua8f1\ua900-\ua909\ua926-\ua92d\ua947-\ua953\ua980-\ua983\ua9b3-\ua9c0\ua9d0-\ua9d9\ua9e5\ua9f0-\ua9f9\uaa29-\uaa36\uaa43\uaa4c\uaa4d\uaa50-\uaa59\uaa7b-\uaa7d\uaab0\uaab2-\uaab4\uaab7\uaab8\uaabe\uaabf\uaac1\uaaeb-\uaaef\uaaf5\uaaf6\uabe3-\uabea\uabec\uabed\uabf0-\uabf9\ufb1e\ufe00-\ufe0f\ufe20-\ufe2f\ufe33\ufe34\ufe4d-\ufe4f\uff10-\uff19\uff3f";
        const /*<@27>*/nonASCIIidentifierStart = new RegExp("[" + nonASCIIidentifierStartChars + "]");
        const /*<@27>*/nonASCIIidentifier = new RegExp("[" + nonASCIIidentifierStartChars + nonASCIIidentifierChars + "]");
        nonASCIIidentifierStartChars = nonASCIIidentifierChars = null;
        // These are a run-length and offset encoded representation of the
        // >0xffff code points that are a valid part of identifiers. The
        // offset starts at 0x10000, and each pair of numbers represents an
        // offset to the next range, and then a size of the range. They were
        // generated by `bin/generate-identifier-regex.js`.
        // eslint-disable-next-line comma-spacing
        const /*<@28>*/astralIdentifierStartCodes = /*<@28>*/[0, 11, 2, 25, 2, 18, 2, 1, 2, 14, 3, 13, 35, 122, 70, 52, 268, 28, 4, 48, 48, 31, 17, 26, 6, 37, 11, 29, 3, 35, 5, 7, 2, 4, 43, 157, 19, 35, 5, 35, 5, 39, 9, 51, 157, 310, 10, 21, 11, 7, 153, 5, 3, 0, 2, 43, 2, 1, 4, 0, 3, 22, 11, 22, 10, 30, 66, 18, 2, 1, 11, 21, 11, 25, 71, 55, 7, 1, 65, 0, 16, 3, 2, 2, 2, 26, 45, 28, 4, 28, 36, 7, 2, 27, 28, 53, 11, 21, 11, 18, 14, 17, 111, 72, 56, 50, 14, 50, 785, 52, 76, 44, 33, 24, 27, 35, 42, 34, 4, 0, 13, 47, 15, 3, 22, 0, 2, 0, 36, 17, 2, 24, 85, 6, 2, 0, 2, 3, 2, 14, 2, 9, 8, 46, 39, 7, 3, 1, 3, 21, 2, 6, 2, 1, 2, 4, 4, 0, 19, 0, 13, 4, 159, 52, 19, 3, 54, 47, 21, 1, 2, 0, 185, 46, 42, 3, 37, 47, 21, 0, 60, 42, 86, 25, 391, 63, 32, 0, 449, 56, 264, 8, 2, 36, 18, 0, 50, 29, 881, 921, 103, 110, 18, 195, 2749, 1070, 4050, 582, 8634, 568, 8, 30, 114, 29, 19, 47, 17, 3, 32, 20, 6, 18, 881, 68, 12, 0, 67, 12, 65, 0, 32, 6124, 20, 754, 9486, 1, 3071, 106, 6, 12, 4, 8, 8, 9, 5991, 84, 2, 70, 2, 1, 3, 0, 3, 1, 3, 3, 2, 11, 2, 0, 2, 6, 2, 64, 2, 3, 3, 7, 2, 6, 2, 27, 2, 3, 2, 4, 2, 0, 4, 6, 2, 339, 3, 24, 2, 24, 2, 30, 2, 24, 2, 30, 2, 24, 2, 30, 2, 24, 2, 30, 2, 24, 2, 7, 4149, 196, 60, 67, 1213, 3, 2, 26, 2, 1, 2, 0, 3, 0, 2, 9, 2, 3, 2, 0, 2, 0, 7, 0, 5, 0, 2, 0, 2, 0, 2, 2, 2, 1, 2, 0, 3, 0, 2, 0, 2, 0, 2, 0, 2, 0, 2, 1, 2, 0, 3, 3, 2, 6, 2, 3, 2, 3, 2, 0, 2, 9, 2, 16, 6, 2, 2, 4, 2, 16, 4421, 42710, 42, 4148, 12, 221, 3, 5761, 10591, 541];
        // eslint-disable-next-line comma-spacing
        const /*<@28>*/astralIdentifierCodes = /*<@28>*/[509, 0, 227, 0, 150, 4, 294, 9, 1368, 2, 2, 1, 6, 3, 41, 2, 5, 0, 166, 1, 1306, 2, 54, 14, 32, 9, 16, 3, 46, 10, 54, 9, 7, 2, 37, 13, 2, 9, 52, 0, 13, 2, 49, 13, 10, 2, 4, 9, 83, 11, 7, 0, 161, 11, 6, 9, 7, 3, 57, 0, 2, 6, 3, 1, 3, 2, 10, 0, 11, 1, 3, 6, 4, 4, 193, 17, 10, 9, 87, 19, 13, 9, 214, 6, 3, 8, 28, 1, 83, 16, 16, 9, 82, 12, 9, 9, 84, 14, 5, 9, 423, 9, 838, 7, 2, 7, 17, 9, 57, 21, 2, 13, 19882, 9, 135, 4, 60, 6, 26, 9, 1016, 45, 17, 3, 19723, 1, 5319, 4, 4, 5, 9, 7, 3, 6, 31, 3, 149, 2, 1418, 49, 513, 54, 5, 49, 9, 0, 15, 0, 23, 4, 2, 14, 1361, 6, 2, 16, 3, 6, 2, 1, 2, 4, 2214, 6, 110, 6, 6, 9, 792487, 239];
        // This has a complexity linear to the value of the code. The
        // assumption is that looking up astral identifier characters is
        // rare.
        function /*<@29>*/isInAstralSet(/*<@5>*/code, /*<@28>*/set) {
            let /*<@5>*/pos = 0x10000;
            for (let /*<@5>*/i = 0; i < set.length; i += 2) {
                pos += set[i];
                if (pos > code)
                    return false;
                pos += set[i + 1];
                if (pos >= code)
                    return true;
            }
            return false;
        }
        // Test whether a given character code starts an identifier.
        function /*<@30>*/isIdentifierStart(/*<@5>*/code) {
            if (code < 65)
                return code === 36;
            if (code < 91)
                return true;
            if (code < 97)
                return code === 95;
            if (code < 123)
                return true;
            if (code <= 0xffff)
                return code >= 0xaa && nonASCIIidentifierStart.test(String.fromCharCode(code));
            return isInAstralSet(code, astralIdentifierStartCodes);
        }
        utilIdentifierJS.isIdentifierStart = isIdentifierStart;
        // Test whether a given character is part of an identifier.
        function /*<@31>*/isIdentifierChar(/*<@5>*/code) {
            if (code < 48)
                return code === 36;
            if (code < 58)
                return true;
            if (code < 65)
                return false;
            if (code < 91)
                return true;
            if (code < 97)
                return code === 95;
            if (code < 123)
                return true;
            if (code <= 0xffff)
                return code >= 0xaa && nonASCIIidentifier.test(String.fromCharCode(code));
            return isInAstralSet(code, astralIdentifierStartCodes) || isInAstralSet(code, astralIdentifierCodes);
        }
        utilIdentifierJS.isIdentifierChar = isIdentifierChar;
    }
    const utilWhitespaceJS = /*<@6>*/{};
    {
        const /*<@27>*/lineBreak = /\r\n?|\n|\u2028|\u2029/;
        utilWhitespaceJS.lineBreak = lineBreak;
        const /*<@27>*/lineBreakG = new RegExp(lineBreak.source, "g");
        utilWhitespaceJS.lineBreakG = lineBreakG;
        function /*<@33>*/isNewLine(/*<@5>*/code) {
            return code === 10 || code === 13 || code === 0x2028 || code === 0x2029;
        }
        utilWhitespaceJS.isNewLine = isNewLine;
        const /*<@27>*/nonASCIIwhitespace = /[\u1680\u180e\u2000-\u200a\u202f\u205f\u3000\ufeff]/;
        utilWhitespaceJS.nonASCIIwhitespace = nonASCIIwhitespace;
    }
    const utilLocationJS = /*<@6>*/{};
    class /*<@36>*/Position {
        constructor(/*<@5>*/line, /*<@5>*/col) {
            this.line = line;
            this.column = col;
        }
    }
    utilLocationJS.Position = Position;
    class /*<@38>*/SourceLocation {
        constructor(/*<@39>*/start, /*<@35>*/end) {
            this.start = start;
            this.end = end;
        }
    }
    utilLocationJS.SourceLocation = SourceLocation;
    {
        const /*<@27>*/lineBreakG = utilWhitespaceJS.lineBreakG;
        // These are used when `options.locations` is on, for the
        // `startLoc` and `endLoc` properties.
        // The `getLineInfo` function is mostly useful when the
        // `locations` option is off (for performance reasons) and you
        // want to find the line/column position for a given character
        // offset. `input` should be the code string that the offset refers
        // into.
        function /*<@40>*/getLineInfo(/*<@3>*/input, /*<@5>*/offset) {
            for (let /*<@5>*/line = 1, /*<@5>*/cur = 0;;) {
                lineBreakG.lastIndex = cur;
                const /*<@42>*/match = lineBreakG.exec(input);
                if (match && match.index < offset) {
                    ++line;
                    cur = match.index + match[0].length;
                }
                else {
                    return new Position(line, offset - cur);
                }
            }
        }
        utilLocationJS.getLineInfo = getLineInfo;
    }
    const tokenizerTypesJS = /*<@6>*/{};
    class /*<@47>*/TokenConfig {
        constructor(/*<@26>*/keyword = undefined, /*<@2>*/beforeExpr = false, /*<@2>*/startsExpr = false, /*<@2>*/rightAssociative = false, /*<@2>*/isLoop = false, /*<@2>*/isAssign = false, /*<@2>*/prefix = false, /*<@2>*/postfix = false, /*<@22>*/binop = null) {
            this.keyword = keyword;
            this.beforeExpr = beforeExpr;
            this.startsExpr = startsExpr;
            this.rightAssociative = rightAssociative;
            this.isLoop = isLoop;
            this.isAssign = isAssign;
            this.prefix = prefix;
            this.postfix = postfix;
            this.binop = binop;
        }
    }
    class /*<@45>*/TokenType {
        constructor(/*<@3>*/label, /*<@46>*/conf) {
            this.label = label;
            this.keyword = conf.keyword;
            this.beforeExpr = !!conf.beforeExpr;
            this.startsExpr = !!conf.startsExpr;
            this.rightAssociative = !!conf.rightAssociative;
            this.isLoop = !!conf.isLoop;
            this.isAssign = !!conf.isAssign;
            this.prefix = !!conf.prefix;
            this.postfix = !!conf.postfix;
            this.binop = conf.binop || null;
            this.updateContext = null;
        }
    }
    tokenizerTypesJS.TokenType = TokenType;
    class /*<@50>*/KeywordTokenType extends TokenType {
        constructor(/*<@3>*/name, /*<@46>*/options) {
            options.keyword = name;
            super(name, options);
        }
    }
    class /*<@55>*/BinopTokenType extends TokenType {
        constructor(/*<@3>*/name, /*<@5>*/prec) {
            let /*<@46>*/config = new TokenConfig(undefined, true, false, false, false, false, false, false, prec);
            super(name, config);
        }
    }
    tokenizerTypesJS.BinopTokenType = BinopTokenType;
    {
        // ## Token types
        // The assignment of fine-grained, information-carrying type objects
        // allows the tokenizer to store the information it has about a
        // token in a way that is very cheap for the parser to look up.
        // All token type variables start with an underscore, to make them
        // easy to recognize.
        // The `beforeExpr` property is used to disambiguate between regular
        // expressions and divisions. It is set on all token types that can
        // be followed by an expression (thus, a slash after them would be a
        // regular expression).
        //
        // `isLoop` marks a keyword as starting a loop, which is important
        // to know when parsing a label, in order to allow or disallow
        // continue jumps to that label.
        const /*<@2>*/beforeExpr = true;
        const /*<@2>*/startsExpr = true;
        const /*<@2>*/isLoop = true;
        const /*<@2>*/isAssign = true;
        const /*<@2>*/prefix = true;
        const /*<@2>*/postfix = true;
        const /*<@46>*/emptyConfig = new TokenConfig();
        const /*<@46>*/startExprConfig = new TokenConfig(undefined, false, startsExpr);
        const /*<@46>*/startBeforeConfig = new TokenConfig(undefined, beforeExpr, startsExpr);
        const /*<@46>*/beforeConfig = new TokenConfig(undefined, beforeExpr);
        const types = /*<@56>*/{
            num: new TokenType("num", startExprConfig),
            regexp: new TokenType("regexp", startExprConfig),
            string: new TokenType("string", startExprConfig),
            name: new TokenType("name", startExprConfig),
            eof: new TokenType("eof", emptyConfig),
            // Punctuation token types.
            bracketL: new TokenType("[", startBeforeConfig),
            bracketR: new TokenType("]", emptyConfig),
            braceL: new TokenType("{", startBeforeConfig),
            braceBarL: new TokenType("{|", startBeforeConfig),
            braceR: new TokenType("}", emptyConfig),
            braceBarR: new TokenType("|}", emptyConfig),
            parenL: new TokenType("(", startBeforeConfig),
            parenR: new TokenType(")", emptyConfig),
            comma: new TokenType(",", beforeConfig),
            semi: new TokenType(";", beforeConfig),
            colon: new TokenType(":", beforeConfig),
            doubleColon: new TokenType("::", beforeConfig),
            dot: new TokenType(".", emptyConfig),
            question: new TokenType("?", beforeConfig),
            arrow: new TokenType("=>", beforeConfig),
            template: new TokenType("template", emptyConfig),
            ellipsis: new TokenType("...", beforeConfig),
            backQuote: new TokenType("`", startExprConfig),
            dollarBraceL: new TokenType("${", startBeforeConfig),
            at: new TokenType("@", emptyConfig),
            // Operators. These carry several kinds of properties to help the
            // parser use them properly (the presence of these properties is
            // what categorizes them as operators).
            //
            // `binop`, when present, specifies that this operator is a binary
            // operator, and will refer to its precedence.
            //
            // `prefix` and `postfix` mark the operator as a prefix or postfix
            // unary operator.
            //
            // `isAssign` marks all of `=`, `+=`, `-=` etcetera, which act as
            // binary operators with a very low precedence, that should result
            // in AssignmentExpression nodes.
            eq: new TokenType("=", new TokenConfig(undefined, beforeExpr, false, false, false, isAssign)),
            assign: new TokenType("_=", new TokenConfig(undefined, beforeExpr, false, false, false, isAssign)),
            incDec: new TokenType("++/--", new TokenConfig(undefined, false, startsExpr, false, false, false, prefix, postfix)),
            prefix: new TokenType("prefix", new TokenConfig(undefined, beforeExpr, startsExpr, false, false, false, prefix)),
            logicalOR: new BinopTokenType("||", 1),
            logicalAND: new BinopTokenType("&&", 2),
            bitwiseOR: new BinopTokenType("|", 3),
            bitwiseXOR: new BinopTokenType("^", 4),
            bitwiseAND: new BinopTokenType("&", 5),
            equality: new BinopTokenType("==/!=", 6),
            relational: new BinopTokenType("</>", 7),
            bitShift: new BinopTokenType("<</>>", 8),
            plusMin: new TokenType("+/-", new TokenConfig(undefined, beforeExpr, startsExpr, false, false, false, prefix, false, 9)),
            modulo: new BinopTokenType("%", 10),
            star: new BinopTokenType("*", 10),
            slash: new BinopTokenType("/", 10),
            exponent: new TokenType("**", new TokenConfig(undefined, beforeExpr, false, true, false, false, false, false, 11)),
            jsxName: undefined,
            jsxText: undefined,
            jsxTagStart: undefined,
            jsxTagEnd: undefined,
            _break: undefined,
            _case: undefined,
            _catch: undefined,
            _continue: undefined,
            _debugger: undefined,
            _default: undefined,
            _do: undefined,
            _else: undefined,
            _finally: undefined,
            _for: undefined,
            _function: undefined,
            _if: undefined,
            _return: undefined,
            _switch: undefined,
            _throw: undefined,
            _try: undefined,
            _var: undefined,
            _let: undefined,
            _const: undefined,
            _while: undefined,
            _with: undefined,
            _new: undefined,
            _this: undefined,
            _super: undefined,
            _class: undefined,
            _extends: undefined,
            _export: undefined,
            _import: undefined,
            _yield: undefined,
            _null: undefined,
            _true: undefined,
            _false: undefined,
            _in: undefined,
            _instanceof: undefined,
            _typeof: undefined,
            _void: undefined,
            _delete: undefined
        };
        tokenizerTypesJS.types = types;
        const keywords = /*<@52>*/{
            "break": new KeywordTokenType("break", emptyConfig),
            "case": new KeywordTokenType("case", beforeConfig),
            "catch": new KeywordTokenType("catch", emptyConfig),
            "continue": new KeywordTokenType("continue", emptyConfig),
            "debugger": new KeywordTokenType("debugger", emptyConfig),
            "default": new KeywordTokenType("default", beforeConfig),
            "do": new KeywordTokenType("do", new TokenConfig(undefined, beforeExpr, false, false, isLoop)),
            "else": new KeywordTokenType("else", beforeConfig),
            "finally": new KeywordTokenType("finally", emptyConfig),
            "for": new KeywordTokenType("for", new TokenConfig(undefined, false, false, false, isLoop)),
            "function": new KeywordTokenType("function", startExprConfig),
            "if": new KeywordTokenType("if", emptyConfig),
            "return": new KeywordTokenType("return", beforeConfig),
            "switch": new KeywordTokenType("switch", emptyConfig),
            "throw": new KeywordTokenType("throw", beforeConfig),
            "try": new KeywordTokenType("try", emptyConfig),
            "var": new KeywordTokenType("var", emptyConfig),
            "let": new KeywordTokenType("let", emptyConfig),
            "const": new KeywordTokenType("const", emptyConfig),
            "while": new KeywordTokenType("while", new TokenConfig(undefined, false, false, false, isLoop)),
            "with": new KeywordTokenType("with", emptyConfig),
            "new": new KeywordTokenType("new", startBeforeConfig),
            "this": new KeywordTokenType("this", startExprConfig),
            "super": new KeywordTokenType("super", startExprConfig),
            "class": new KeywordTokenType("class", emptyConfig),
            "extends": new KeywordTokenType("extends", beforeConfig),
            "export": new KeywordTokenType("export", emptyConfig),
            "import": new KeywordTokenType("import", startExprConfig),
            "yield": new KeywordTokenType("yield", startBeforeConfig),
            "null": new KeywordTokenType("null", startExprConfig),
            "true": new KeywordTokenType("true", startExprConfig),
            "false": new KeywordTokenType("false", startExprConfig),
            "in": new KeywordTokenType("in", new TokenConfig(undefined, beforeExpr, false, false, false, false, false, false, 7)),
            "instanceof": new KeywordTokenType("instanceof", new TokenConfig(undefined, beforeExpr, false, false, false, false, false, false, 7)),
            "typeof": new KeywordTokenType("typeof", new TokenConfig(undefined, beforeExpr, startsExpr, false, false, false, prefix)),
            "void": new KeywordTokenType("void", new TokenConfig(undefined, beforeExpr, startsExpr, false, false, false, prefix)),
            "delete": new KeywordTokenType("delete", new TokenConfig(undefined, beforeExpr, startsExpr, false, false, false, prefix))
        };
        tokenizerTypesJS.keywords = keywords;
        // Map keyword names to token types.
        types._break = keywords.break;
        types._case = keywords.case;
        types._catch = keywords.catch;
        types._continue = keywords.continue;
        types._debugger = keywords.debugger;
        types._default = keywords.default;
        types._do = keywords.do;
        types._else = keywords.else;
        types._finally = keywords.finally;
        types._for = keywords.for;
        types._function = keywords.function;
        types._if = keywords.if;
        types._return = keywords.return;
        types._switch = keywords.switch;
        types._throw = keywords.throw;
        types._try = keywords.try;
        types._var = keywords.var;
        types._let = keywords.let;
        types._const = keywords.const;
        types._while = keywords.while;
        types._with = keywords.with;
        types._new = keywords.new;
        types._this = keywords.this;
        types._super = keywords.super;
        types._class = keywords.class;
        types._extends = keywords.extends;
        types._export = keywords.export;
        types._import = keywords.import;
        types._yield = keywords.yield;
        types._null = keywords.null;
        types._true = keywords.true;
        types._false = keywords.false;
        types._in = keywords.in;
        types._instanceof = keywords.instanceof;
        types._typeof = keywords.typeof;
        types._void = keywords.void;
        types._delete = keywords.delete;
    }
    const tokenizerContextJS = /*<@6>*/{};
    class /*<@59>*/TokContext {
        constructor(/*<@3>*/token, /*<@2>*/isExpr, /*<@60>*/preserveSpace, override) {
            this.token = token;
            this.isExpr = !!isExpr;
            this.preserveSpace = !!preserveSpace;
            this.override = override;
        }
    }
    tokenizerContextJS.TokContext = TokContext;
    {
        // The algorithm used to determine whether a regexp can appear at a
        // given point in the program is loosely based on sweet.js' approach.
        // See https://github.com/mozilla/sweet.js/wiki/design
        const tt = tokenizerTypesJS.types;
        const /*<@27>*/lineBreak = utilWhitespaceJS.lineBreak;
        const types = /*<@350>*/{
            braceStatement: new TokContext("{", false, undefined, undefined),
            braceExpression: new TokContext("{", true, undefined, undefined),
            templateQuasi: new TokContext("${", true, undefined, undefined),
            parenStatement: new TokContext("(", false, undefined, undefined),
            parenExpression: new TokContext("(", true, undefined, undefined),
            template: new TokContext("`", true, true, /*<@351>*/(/*<@63>*/p) => { p.readTmplToken(); }),
            functionExpression: new TokContext("function", true, undefined, undefined),
            j_oTag: undefined,
            j_cTag: undefined,
            j_expr: undefined
        };
        tokenizerContextJS.types = types;
        // Token-specific context update code
        tt.parenR.updateContext = tt.braceR.updateContext = function /*<@352>*/() {
            let /*<@63>*/thisObj = (/*<@63>*/this);
            if (thisObj.state.context.length === 1) {
                thisObj.state.exprAllowed = true;
                return;
            }
            const /*<@61>*/out = thisObj.state.context.pop();
            if (out === types.braceStatement && thisObj.curContext() === types.functionExpression) {
                thisObj.state.context.pop();
                thisObj.state.exprAllowed = false;
            }
            else if (out === types.templateQuasi) {
                thisObj.state.exprAllowed = true;
            }
            else {
                thisObj.state.exprAllowed = !/*<@58>*/out.isExpr;
            }
        };
        tt.name.updateContext = function /*<@353>*/(/*<@48>*/prevType) {
            let /*<@63>*/thisObj = (/*<@63>*/this);
            thisObj.state.exprAllowed = false;
            if (prevType === tt._let || prevType === tt._const || prevType === tt._var) {
                if (lineBreak.test(thisObj.input.slice(thisObj.state.end))) {
                    thisObj.state.exprAllowed = true;
                }
            }
        };
        tt.braceL.updateContext = function /*<@354>*/(/*<@48>*/prevType) {
            let /*<@63>*/thisObj = (/*<@63>*/this);
            thisObj.state.context.push(thisObj.braceIsBlock(prevType) ? types.braceStatement : types.braceExpression);
            thisObj.state.exprAllowed = true;
        };
        tt.dollarBraceL.updateContext = function /*<@355>*/() {
            let /*<@63>*/thisObj = (/*<@63>*/this);
            thisObj.state.context.push(types.templateQuasi);
            thisObj.state.exprAllowed = true;
        };
        tt.parenL.updateContext = function /*<@356>*/(/*<@48>*/prevType) {
            let /*<@63>*/thisObj = (/*<@63>*/this);
            const /*<@2>*/statementParens = prevType === tt._if || prevType === tt._for ||
                prevType === tt._with || prevType === tt._while;
            thisObj.state.context.push(statementParens ? types.parenStatement : types.parenExpression);
            thisObj.state.exprAllowed = true;
        };
        tt.incDec.updateContext = function /*<@357>*/() {
            // tokExprAllowed stays unchanged
        };
        tt./*<@49>*/_function.updateContext = function /*<@358>*/() {
            let /*<@63>*/thisObj = (/*<@63>*/this);
            if (thisObj.curContext() !== types.braceStatement) {
                thisObj.state.context.push(types.functionExpression);
            }
            thisObj.state.exprAllowed = false;
        };
        tt.backQuote.updateContext = function /*<@359>*/() {
            let /*<@63>*/thisObj = (/*<@63>*/this);
            if (thisObj.curContext() === types.template) {
                thisObj.state.context.pop();
            }
            else {
                thisObj.state.context.push(types.template);
            }
            thisObj.state.exprAllowed = false;
        };
    }
    class /*<@66>*/State {
        /*<@304>*/init(options, /*<@3>*/input) {
            this.strict = options.strictMode === false ? false : options.sourceType === "module";
            this.input = input;
            this.potentialArrowAt = -1;
            this.inMethod =
                this.inFunction =
                    this.inGenerator =
                        this.inAsync =
                            this.inPropertyName =
                                this.inType =
                                    this.noAnonFunctionType =
                                        false;
            this.labels = /*<@361>*/[];
            this.decorators = /*<@361>*/[];
            this.tokens = /*<@361>*/[];
            this.comments = /*<@361>*/[];
            this.trailingComments = /*<@361>*/[];
            this.leadingComments = /*<@361>*/[];
            this.commentStack = /*<@361>*/[];
            this.pos = this.lineStart = 0;
            this.curLine = options.startLine;
            this.type = tokenizerTypesJS.types.eof;
            this.value = null;
            this.start = this.end = this.pos;
            this.startLoc = this.endLoc = this.curPosition();
            this.lastTokEndLoc = this.lastTokStartLoc = null;
            this.lastTokStart = this.lastTokEnd = this.pos;
            this.context = /*<@67>*/[tokenizerContextJS.types.braceStatement];
            this.exprAllowed = true;
            this.containsEsc = this.containsOctal = false;
            this.octalPosition = null;
            this.invalidTemplateEscapePosition = null;
            this.exportedIdentifiers = /*<@361>*/[];
            return this;
        }
        /*<@305>*/curPosition() {
            return new Position(this.curLine, this.pos - this.lineStart);
        }
        /*<@306>*/clone(/*<@60>*/skipArrays) {
            const /*<@65>*/state = new State();
            state.strict = this.strict;
            if (this.context) {
                state.context = this.context.slice();
            }
            state.input = this.input;
            state.potentialArrowAt = this.potentialArrowAt;
            state.inMethod = this.inMethod;
            state.inFunction = this.inFunction;
            state.inGenerator = this.inGenerator;
            state.inAsync = this.inAsync;
            state.inPropertyName = this.inPropertyName;
            state.inType = this.inType;
            state.noAnonFunctionType = this.noAnonFunctionType;
            if (!skipArrays && this.labels) {
                state.labels = this.labels.slice();
            }
            else {
                state.labels = this.labels;
            }
            if (!skipArrays && this.decorators) {
                state.decorators = this.decorators.slice();
            }
            else {
                state.decorators = this.decorators;
            }
            if (!skipArrays && this.tokens) {
                state.tokens = this.tokens.slice();
            }
            else {
                state.tokens = this.tokens;
            }
            if (!skipArrays && this.comments) {
                state.comments = this.comments.slice();
            }
            else {
                state.comments = this.comments;
            }
            if (!skipArrays && this.trailingComments) {
                state.trailingComments = this.trailingComments.slice();
            }
            else {
                state.trailingComments = this.trailingComments;
            }
            if (!skipArrays && this.leadingComments) {
                state.leadingComments = this.leadingComments.slice();
            }
            else {
                state.leadingComments = this.leadingComments;
            }
            if (!skipArrays && this.commentStack) {
                state.commentStack = this.commentStack.slice();
            }
            else {
                state.commentStack = this.commentStack;
            }
            state.pos = this.pos;
            state.lineStart = this.lineStart;
            state.curLine = this.curLine;
            state.type = this.type;
            state.value = this.value;
            state.start = this.start;
            state.end = this.end;
            state.startLoc = this.startLoc;
            state.endLoc = this.endLoc;
            state.lastTokEndLoc = this.lastTokEndLoc;
            state.lastTokStartLoc = this.lastTokStartLoc;
            state.lastTokStart = this.lastTokStart;
            state.lastTokEnd = this.lastTokEnd;
            state.exprAllowed = this.exprAllowed;
            state.containsEsc = this.containsEsc;
            state.containsOctal = this.containsOctal;
            state.octalPosition = this.octalPosition;
            state.invalidTemplateEscapePosition = this.invalidTemplateEscapePosition;
            if (!skipArrays && this.exportedIdentifiers) {
                state.exportedIdentifiers = this.exportedIdentifiers.slice();
            }
            else {
                state.exportedIdentifiers = this.exportedIdentifiers;
            }
            state.commentPreviousNode = this.commentPreviousNode;
            return state;
        }
    }
    const /*<@24>*/primitiveTypes = /*<@24>*/[
        "any",
        "mixed",
        "empty",
        "bool",
        "boolean",
        "number",
        "string",
        "void",
        "null"
    ];
    // tokenizer/index.js
    // Object type used to represent tokens. Note that normally, tokens
    // simply exist as properties on the parser object. This is only
    // used for the onToken callback and the external tokenizer.
    //export class Token {
    class /*<@300>*/Token {
        constructor(/*<@65>*/state) {
            this.type = state ? state.type : undefined;
            this.value = state ? state.value : undefined;
            this.start = state ? state.start : undefined;
            this.end = state ? state.end : undefined;
            this.loc = new SourceLocation(state.startLoc, state.endLoc);
        }
    }
    // ## Tokenizer
    function /*<@362>*/codePointToString(/*<@5>*/code) {
        // UTF-16 Decoding
        if (code <= 0xFFFF) {
            return String.fromCharCode(code);
        }
        else {
            return String.fromCharCode(((code - 0x10000) >> 10) + 0xD800, ((code - 0x10000) & 1023) + 0xDC00);
        }
    }
    class /*<@64>*/Tokenizer {
        constructor(options, /*<@3>*/input) {
            this.tt = tokenizerTypesJS.types;
            this.state = new State();
            this.state.init(options, input);
            this.inModule = undefined;
        }
        // Move to the next token
        /*<@307>*/next() {
            if (!this.isLookahead) {
                this.state.tokens.push(new Token(this.state));
            }
            this.state.lastTokEnd = this.state.end;
            this.state.lastTokStart = this.state.start;
            this.state.lastTokEndLoc = this.state.endLoc;
            this.state.lastTokStartLoc = this.state.startLoc;
            this.nextToken();
        }
        // TODO
        /*<@308>*/eat(/*<@44>*/type) {
            if (this.match(type)) {
                this.next();
                return true;
            }
            else {
                return false;
            }
        }
        // TODO
        /*<@309>*/match(/*<@44>*/type) {
            return this.state.type === type;
        }
        // TODO
        /*<@310>*/isKeyword(/*<@3>*/word) {
            return utilIdentifierJS.isKeyword(word);
        }
        // TODO
        /*<@311>*/lookahead() {
            const /*<@65>*/old = this.state;
            this.state = old.clone(true);
            this.isLookahead = true;
            this.next();
            this.isLookahead = false;
            const /*<@65>*/curr = this.state.clone(true);
            this.state = old;
            return curr;
        }
        // Toggle strict mode. Re-reads the next number or string to please
        // pedantic tests (`"use strict"; 010;` should fail).
        /*<@312>*/setStrict(/*<@2>*/strict) {
            this.state.strict = strict;
            if (!this.match(this.tt.num) && !this.match(this.tt.string))
                return;
            this.state.pos = this.state.start;
            while (this.state.pos < this.state.lineStart) {
                this.state.lineStart = this.input.lastIndexOf("\n", this.state.lineStart - 2) + 1;
                --this.state.curLine;
            }
            this.nextToken();
        }
        /*<@313>*/curContext() {
            return this.state.context[this.state.context.length - 1];
        }
        // Read a single token, updating the parser object's token-related
        // properties.
        /*<@314>*/nextToken() {
            const /*<@58>*/curContext = this.curContext();
            if (!curContext || !curContext.preserveSpace)
                this.skipSpace();
            this.state.containsOctal = false;
            this.state.octalPosition = null;
            this.state.start = this.state.pos;
            this.state.startLoc = this.state.curPosition();
            if (this.state.pos >= this.input.length)
                return this.finishToken(this.tt.eof, undefined);
            if (curContext.override) {
                return curContext.override(this);
            }
            else {
                return this.readToken(this.fullCharCodeAtPos());
            }
        }
        /*<@315>*/readToken(/*<@5>*/code) {
            // Identifier or keyword. '\uXXXX' sequences are allowed in
            // identifiers, so '\' also dispatches to that.
            if (utilIdentifierJS.isIdentifierStart(code) || code === 92 /* '\' */) {
                return this.readWord();
            }
            else {
                return this.getTokenFromCode(code);
            }
        }
        /*<@316>*/fullCharCodeAtPos() {
            const /*<@5>*/code = this.input.charCodeAt(this.state.pos);
            if (code <= 0xd7ff || code >= 0xe000)
                return code;
            const /*<@5>*/next = this.input.charCodeAt(this.state.pos + 1);
            return (code << 10) + next - 0x35fdc00;
        }
        /*<@317>*/addComment(/*<@69>*/comment) {
            throw new Error("no addComment");
        }
        /*<@318>*/raise(/*<@5>*/pos, /*<@128>*/message) {
            throw new Error("no raise");
        }
        /*<@319>*/pushComment(/*<@2>*/block, /*<@3>*/text, /*<@5>*/start, /*<@5>*/end, /*<@35>*/startLoc, /*<@35>*/endLoc) {
            const /*<@69>*/comment = new Node(undefined);
            comment.type = block ? "CommentBlock" : "CommentLine";
            comment.value = text;
            comment.start = start;
            comment.end = end;
            comment.loc = new SourceLocation(startLoc, endLoc);
            if (!this.isLookahead) {
                this.state.tokens.push(comment);
                this.state.comments.push(comment);
                this.addComment(comment);
            }
        }
        /*<@320>*/skipBlockComment() {
            const /*<@35>*/startLoc = this.state.curPosition();
            const /*<@5>*/start = this.state.pos;
            const /*<@1>*/end = this.input.indexOf("*/", this.state.pos += 2);
            if (end === -1)
                this.raise(this.state.pos - 2, "Unterminated comment");
            this.state.pos = end + 2;
            utilWhitespaceJS.lineBreakG.lastIndex = start;
            let /*<@42>*/match;
            while ((match = utilWhitespaceJS.lineBreakG.exec(this.input)) && match.index < this.state.pos) {
                ++this.state.curLine;
                this.state.lineStart = match.index + match[0].length;
            }
            this.pushComment(true, this.input.slice(start + 2, end), start, this.state.pos, startLoc, this.state.curPosition());
        }
        /*<@321>*/skipLineComment(/*<@5>*/startSkip) {
            const /*<@5>*/start = this.state.pos;
            const /*<@35>*/startLoc = this.state.curPosition();
            let /*<@5>*/ch = this.input.charCodeAt(this.state.pos += startSkip);
            while (this.state.pos < this.input.length && ch !== 10 && ch !== 13 && ch !== 8232 && ch !== 8233) {
                ++this.state.pos;
                ch = this.input.charCodeAt(this.state.pos);
            }
            this.pushComment(false, this.input.slice(start + startSkip, this.state.pos), start, this.state.pos, startLoc, this.state.curPosition());
        }
        // Called at the start of the parse and after every token. Skips
        // whitespace and comments, and.
        /*<@322>*/skipSpace() {
            loop: while (this.state.pos < this.input.length) {
                const /*<@5>*/ch = this.input.charCodeAt(this.state.pos);
                switch (ch) {
                    case 32:
                    case 160: // ' '
                        ++this.state.pos;
                        break;
                    case 13:
                        if (this.input.charCodeAt(this.state.pos + 1) === 10) {
                            ++this.state.pos;
                        }
                    case 10:
                    case 8232:
                    case 8233:
                        ++this.state.pos;
                        ++this.state.curLine;
                        this.state.lineStart = this.state.pos;
                        break;
                    case 47: // '/'
                        switch (this.input.charCodeAt(this.state.pos + 1)) {
                            case 42: // '*'
                                this.skipBlockComment();
                                break;
                            case 47:
                                this.skipLineComment(2);
                                break;
                            default:
                                break loop;
                        }
                        break;
                    default:
                        if (ch > 8 && ch < 14 || ch >= 5760 &&
                            utilWhitespaceJS.nonASCIIwhitespace.test(String.fromCharCode(ch))) {
                            ++this.state.pos;
                        }
                        else {
                            break loop;
                        }
                }
            }
        }
        // Called at the end of every token. Sets `end`, `val`, and
        // maintains `context` and `exprAllowed`, and skips the space after
        // the token, so that the next one's `start` will point at the
        // right position.
        /*<@323>*/finishToken(/*<@44>*/type, /*<@104>*/val) {
            this.state.end = this.state.pos;
            this.state.endLoc = this.state.curPosition();
            const /*<@44>*/prevType = this.state.type;
            this.state.type = /*<@44>*/type;
            this.state.value = val;
            this.updateContext(prevType);
        }
        // ### Token reading
        // This is the function that is called to fetch the next token. It
        // is somewhat obscure, because it works in character codes rather
        // than characters, and because operator parsing has been inlined
        // into it.
        //
        // All in the name of speed.
        //
        /*<@324>*/readToken_dot() {
            const /*<@5>*/next = this.input.charCodeAt(this.state.pos + 1);
            if (next >= 48 && next <= 57) {
                return this.readNumber(true);
            }
            const /*<@5>*/next2 = this.input.charCodeAt(this.state.pos + 2);
            if (next === 46 && next2 === 46) { // 46 = dot '.'
                this.state.pos += 3;
                return this.finishToken(this.tt.ellipsis);
            }
            else {
                ++this.state.pos;
                return this.finishToken(this.tt.dot);
            }
        }
        /*<@325>*/readToken_slash() {
            if (this.state.exprAllowed) {
                ++this.state.pos;
                return this.readRegexp();
            }
            const /*<@5>*/next = this.input.charCodeAt(this.state.pos + 1);
            if (next === 61) {
                return this.finishOp(this.tt.assign, 2);
            }
            else {
                return this.finishOp(this.tt.slash, 1);
            }
        }
        /*<@326>*/readToken_mult_modulo(/*<@5>*/code) {
            let /*<@44>*/type = code === 42 ? this.tt.star : this.tt.modulo;
            let /*<@5>*/width = 1;
            let /*<@5>*/next = this.input.charCodeAt(this.state.pos + 1);
            if (next === 42) { // '*'
                width++;
                next = this.input.charCodeAt(this.state.pos + 2);
                type = this.tt.exponent;
            }
            if (next === 61) {
                width++;
                type = this.tt.assign;
            }
            return this.finishOp(type, width);
        }
        /*<@327>*/hasPlugin(/*<@3>*/name) {
            throw new Error("no hasPlugin");
            return false;
        }
        /*<@328>*/readToken_pipe_amp(/*<@5>*/code) {
            const /*<@5>*/next = this.input.charCodeAt(this.state.pos + 1);
            if (next === code)
                return this.finishOp(code === 124 ? this.tt.logicalOR : this.tt.logicalAND, 2);
            if (next === 61)
                return this.finishOp(this.tt.assign, 2);
            if (code === 124 && next === 125 && this.hasPlugin("flow"))
                return this.finishOp(this.tt.braceBarR, 2);
            return this.finishOp(code === 124 ? this.tt.bitwiseOR : this.tt.bitwiseAND, 1);
        }
        /*<@329>*/readToken_caret() {
            const /*<@5>*/next = this.input.charCodeAt(this.state.pos + 1);
            if (next === 61) {
                return this.finishOp(this.tt.assign, 2);
            }
            else {
                return this.finishOp(this.tt.bitwiseXOR, 1);
            }
        }
        /*<@330>*/readToken_plus_min(/*<@5>*/code) {
            const /*<@5>*/next = this.input.charCodeAt(this.state.pos + 1);
            if (next === code) {
                if (next === 45 && this.input.charCodeAt(this.state.pos + 2) === 62 && utilWhitespaceJS.lineBreak.test(this.input.slice(this.state.lastTokEnd, this.state.pos))) {
                    // A `-->` line comment
                    this.skipLineComment(3);
                    this.skipSpace();
                    return this.nextToken();
                }
                return this.finishOp(this.tt.incDec, 2);
            }
            if (next === 61) {
                return this.finishOp(this.tt.assign, 2);
            }
            else {
                return this.finishOp(this.tt.plusMin, 1);
            }
        }
        /*<@331>*/unexpected(/*<@22>*/pos, /*<@332>*/messageOrType) {
            throw new Error("no unexpected");
        }
        /*<@333>*/readToken_lt_gt(/*<@5>*/code) {
            const /*<@5>*/next = (this.input.charCodeAt(this.state.pos + 1));
            let /*<@5>*/size = 1;
            if (next === code) {
                size = code === 62 && this.input.charCodeAt(this.state.pos + 2) === 62 ? 3 : 2;
                if ((this.input.charCodeAt(this.state.pos + size)) === 61)
                    return this.finishOp(this.tt.assign, size + 1);
                return this.finishOp(this.tt.bitShift, size);
            }
            if (next === 33 && code === 60 && this.input.charCodeAt(this.state.pos + 2) === 45 && this.input.charCodeAt(this.state.pos + 3) === 45) {
                if (this.inModule)
                    this.unexpected();
                // `<!--`, an XML-style comment that should be interpreted as a line comment
                this.skipLineComment(4);
                this.skipSpace();
                return this.nextToken();
            }
            if (next === 61) {
                // <= | >=
                size = 2;
            }
            return this.finishOp(this.tt.relational, size);
        }
        /*<@334>*/readToken_eq_excl(/*<@5>*/code) {
            const /*<@5>*/next = (this.input.charCodeAt(this.state.pos + 1));
            if (next === 61)
                return this.finishOp(this.tt.equality, this.input.charCodeAt(this.state.pos + 2) === 61 ? 3 : 2);
            if (code === 61 && next === 62) { // '=>'
                this.state.pos += 2;
                return this.finishToken(this.tt.arrow);
            }
            return this.finishOp(code === 61 ? this.tt.eq : this.tt.prefix, 1);
        }
        /*<@335>*/getTokenFromCode(/*<@5>*/code) {
            switch (code) {
                // The interpretation of a dot depends on whether it is followed
                // by a digit or another two dots.
                case 46: // '.'
                    return this.readToken_dot();
                // Punctuation tokens.
                case 40:
                    ++this.state.pos;
                    return this.finishToken(this.tt.parenL);
                case 41:
                    ++this.state.pos;
                    return this.finishToken(this.tt.parenR);
                case 59:
                    ++this.state.pos;
                    return this.finishToken(this.tt.semi);
                case 44:
                    ++this.state.pos;
                    return this.finishToken(this.tt.comma);
                case 91:
                    ++this.state.pos;
                    return this.finishToken(this.tt.bracketL);
                case 93:
                    ++this.state.pos;
                    return this.finishToken(this.tt.bracketR);
                case 123:
                    if (this.hasPlugin("flow") && this.input.charCodeAt(this.state.pos + 1) === 124) {
                        return this.finishOp(this.tt.braceBarL, 2);
                    }
                    else {
                        ++this.state.pos;
                        return this.finishToken(this.tt.braceL);
                    }
                case 125:
                    ++this.state.pos;
                    return this.finishToken(this.tt.braceR);
                case 58:
                    if (this.hasPlugin("functionBind") && this.input.charCodeAt(this.state.pos + 1) === 58) {
                        return this.finishOp(this.tt.doubleColon, 2);
                    }
                    else {
                        ++this.state.pos;
                        return this.finishToken(this.tt.colon);
                    }
                case 63:
                    ++this.state.pos;
                    return this.finishToken(this.tt.question);
                case 64:
                    ++this.state.pos;
                    return this.finishToken(this.tt.at);
                case 96: // '`'
                    ++this.state.pos;
                    return this.finishToken(this.tt.backQuote);
                case 48: // '0'
                    const /*<@5>*/next = this.input.charCodeAt(this.state.pos + 1);
                    if (next === 120 || next === 88)
                        return this.readRadixNumber(16); // '0x', '0X' - hex number
                    if (next === 111 || next === 79)
                        return this.readRadixNumber(8); // '0o', '0O' - octal number
                    if (next === 98 || next === 66)
                        return this.readRadixNumber(2); // '0b', '0B' - binary number
                // Anything else beginning with a digit is an integer, octal
                // number, or float.
                case 49:
                case 50:
                case 51:
                case 52:
                case 53:
                case 54:
                case 55:
                case 56:
                case 57: // 1-9
                    return this.readNumber(false);
                // Quotes produce strings.
                case 34:
                case 39: // '"', "'"
                    return this.readString(code);
                // Operators are parsed inline in tiny state machines. '=' (61) is
                // often referred to. `finishOp` simply skips the amount of
                // characters it is given as second argument, and returns a token
                // of the type given by its first argument.
                case 47: // '/'
                    return this.readToken_slash();
                case 37:
                case 42: // '%*'
                    return this.readToken_mult_modulo(code);
                case 124:
                case 38: // '|&'
                    return this.readToken_pipe_amp(code);
                case 94: // '^'
                    return this.readToken_caret();
                case 43:
                case 45: // '+-'
                    return this.readToken_plus_min(code);
                case 60:
                case 62: // '<>'
                    return this.readToken_lt_gt(code);
                case 61:
                case 33: // '=!'
                    return this.readToken_eq_excl(code);
                case 126: // '~'
                    return this.finishOp(this.tt.prefix, 1);
            }
            this.raise(this.state.pos, `Unexpected character '${codePointToString(code)}'`);
        }
        /*<@336>*/finishOp(/*<@44>*/type, /*<@5>*/size) {
            const /*<@3>*/str = this.input.slice(this.state.pos, this.state.pos + size);
            this.state.pos += size;
            return this.finishToken(type, str);
        }
        /*<@337>*/readRegexp() {
            const /*<@5>*/start = this.state.pos;
            let /*<@60>*/escaped, /*<@60>*/inClass;
            for (;;) {
                if (this.state.pos >= this.input.length)
                    this.raise(start, "Unterminated regular expression");
                const /*<@3>*/ch = this.input.charAt(this.state.pos);
                if (utilWhitespaceJS.lineBreak.test(ch)) {
                    this.raise(start, "Unterminated regular expression");
                }
                if (escaped) {
                    escaped = false;
                }
                else {
                    if (ch === "[") {
                        inClass = true;
                    }
                    else if (ch === "]" && inClass) {
                        inClass = false;
                    }
                    else if (ch === "/" && !inClass) {
                        break;
                    }
                    escaped = ch === "\\";
                }
                ++this.state.pos;
            }
            const /*<@3>*/content = this.input.slice(start, this.state.pos);
            ++this.state.pos;
            // Need to use `readWord1` because '\uXXXX' sequences are allowed
            // here (don't ask).
            const /*<@3>*/mods = this.readWord1();
            if (mods) {
                const /*<@27>*/validFlags = /^[gmsiyu]*$/;
                if (!validFlags.test(mods))
                    this.raise(start, "Invalid regular expression flag");
            }
            return this.finishToken(this.tt.regexp, /*<@226>*/{
                pattern: content,
                flags: mods
            });
        }
        // Read an integer in the given radix. Return null if zero digits
        // were read, the integer value otherwise. When `len` is given, this
        // will return `null` unless the integer has exactly `len` digits.
        /*<@338>*/readInt(/*<@5>*/radix, /*<@22>*/len) {
            const /*<@5>*/start = this.state.pos;
            let /*<@5>*/total = 0;
            for (let /*<@5>*/i = 0, /*<@5>*/e = len == null ? Infinity : len; i < e; ++i) {
                const /*<@5>*/code = this.input.charCodeAt(this.state.pos);
                let /*<@5>*/val;
                if (code >= 97) {
                    val = code - 97 + 10; // a
                }
                else if (code >= 65) {
                    val = code - 65 + 10; // A
                }
                else if (code >= 48 && code <= 57) {
                    val = code - 48; // 0-9
                }
                else {
                    val = Infinity;
                }
                if (val >= radix)
                    break;
                ++this.state.pos;
                total = total * radix + val;
            }
            if (this.state.pos === start || len != null && this.state.pos - start !== len)
                return null;
            return total;
        }
        /*<@339>*/readRadixNumber(/*<@5>*/radix) {
            this.state.pos += 2; // 0x
            const /*<@22>*/val = this.readInt(radix, undefined);
            if (val == null)
                this.raise(this.state.start + 2, "Expected number in radix " + radix);
            if (utilIdentifierJS.isIdentifierStart(this.fullCharCodeAtPos()))
                this.raise(this.state.pos, "Identifier directly after number");
            return (this.finishToken(this.tt.num, val));
        }
        // Read an integer, octal integer, or floating-point number.
        /*<@340>*/readNumber(/*<@2>*/startsWithDot) {
            const /*<@5>*/start = this.state.pos;
            const /*<@2>*/octal = this.input.charCodeAt(this.state.pos) === 48;
            let /*<@2>*/isFloat = false;
            if (!startsWithDot && this.readInt(10) === null)
                this.raise(start, "Invalid number");
            let /*<@5>*/next = this.input.charCodeAt(this.state.pos);
            if (next === 46) { // '.'
                ++this.state.pos;
                this.readInt(10);
                isFloat = true;
                next = this.input.charCodeAt(this.state.pos);
            }
            if (next === 69 || next === 101) { // 'eE'
                next = this.input.charCodeAt(++this.state.pos);
                if (next === 43 || next === 45)
                    ++this.state.pos; // '+-'
                if (this.readInt(10) === null)
                    this.raise(start, "Invalid number");
                isFloat = true;
            }
            if (utilIdentifierJS.isIdentifierStart(this.fullCharCodeAtPos()))
                this.raise(this.state.pos, "Identifier directly after number");
            const /*<@3>*/str = this.input.slice(start, this.state.pos);
            let /*<@22>*/val;
            if (isFloat) {
                val = parseFloat(str);
            }
            else if (!octal || str.length === 1) {
                val = parseInt(str, 10);
            }
            else if (/[89]/.test(str) || this.state.strict) {
                this.raise(start, "Invalid number");
            }
            else {
                val = parseInt(str, 8);
            }
            return this.finishToken(this.tt.num, val);
        }
        // Read a string value, interpreting backslash-escapes.
        /*<@341>*/readCodePoint(/*<@2>*/throwOnInvalid) {
            const /*<@5>*/ch = this.input.charCodeAt(this.state.pos);
            let /*<@22>*/code;
            if (ch === 123) { // '{'
                const /*<@5>*/codePos = ++this.state.pos;
                code = this.readHexChar(this.input.indexOf("}", this.state.pos) - this.state.pos, throwOnInvalid);
                ++this.state.pos;
                if (code === null) {
                    --this.state./*<@5>*/invalidTemplateEscapePosition; // to point to the '\'' instead of the 'u'
                }
                else if (code > 0x10FFFF) {
                    if (throwOnInvalid) {
                        this.raise(codePos, "Code point out of bounds");
                    }
                    else {
                        this.state.invalidTemplateEscapePosition = codePos - 2;
                        return null;
                    }
                }
            }
            else {
                code = this.readHexChar(4, throwOnInvalid);
            }
            return code;
        }
        /*<@342>*/readString(/*<@5>*/quote) {
            let /*<@3>*/out = "", /*<@5>*/chunkStart = ++this.state.pos;
            for (;;) {
                if (this.state.pos >= this.input.length)
                    this.raise(this.state.start, "Unterminated string constant");
                const /*<@5>*/ch = this.input.charCodeAt(this.state.pos);
                if (ch === quote)
                    break;
                if (ch === 92) { // '\'
                    out += this.input.slice(chunkStart, this.state.pos);
                    out += this.readEscapedChar(false);
                    chunkStart = this.state.pos;
                }
                else {
                    if (utilWhitespaceJS.isNewLine(ch))
                        this.raise(this.state.start, "Unterminated string constant");
                    ++this.state.pos;
                }
            }
            out += this.input.slice(chunkStart, this.state.pos++);
            return this.finishToken(this.tt.string, out);
        }
        // Reads template string tokens.
        /*<@343>*/readTmplToken() {
            let /*<@3>*/out = "", /*<@5>*/chunkStart = this.state.pos, /*<@2>*/containsInvalid = false;
            for (;;) {
                if (this.state.pos >= this.input.length)
                    this.raise(this.state.start, "Unterminated template");
                const /*<@5>*/ch = this.input.charCodeAt(this.state.pos);
                if (ch === 96 || ch === 36 && this.input.charCodeAt(this.state.pos + 1) === 123) { // '`', '${'
                    if (this.state.pos === this.state.start && this.match(this.tt.template)) {
                        if (ch === 36) {
                            this.state.pos += 2;
                            return this.finishToken(this.tt.dollarBraceL);
                        }
                        else {
                            ++this.state.pos;
                            return this.finishToken(this.tt.backQuote);
                        }
                    }
                    out += this.input.slice(chunkStart, this.state.pos);
                    return this.finishToken(this.tt.template, containsInvalid ? null : out);
                }
                if (ch === 92) { // '\'
                    out += this.input.slice(chunkStart, this.state.pos);
                    const /*<@26>*/escaped = this.readEscapedChar(true);
                    if (escaped === null) {
                        containsInvalid = true;
                    }
                    else {
                        out += escaped;
                    }
                    chunkStart = this.state.pos;
                }
                else if (utilWhitespaceJS.isNewLine(ch)) {
                    out += this.input.slice(chunkStart, this.state.pos);
                    ++this.state.pos;
                    switch (ch) {
                        case 13:
                            if (this.input.charCodeAt(this.state.pos) === 10)
                                ++this.state.pos;
                        case 10:
                            out += "\n";
                            break;
                        default:
                            out += String.fromCharCode(ch);
                            break;
                    }
                    ++this.state.curLine;
                    this.state.lineStart = this.state.pos;
                    chunkStart = this.state.pos;
                }
                else {
                    ++this.state.pos;
                }
            }
        }
        // Used to read escaped characters
        /*<@344>*/readEscapedChar(/*<@2>*/inTemplate) {
            const /*<@2>*/throwOnInvalid = !inTemplate;
            const /*<@5>*/ch = this.input.charCodeAt(++this.state.pos);
            ++this.state.pos;
            switch (ch) {
                case 110: return "\n"; // 'n' -> '\n'
                case 114: return "\r"; // 'r' -> '\r'
                case 120: { // 'x'
                    const /*<@22>*/code = this.readHexChar(2, throwOnInvalid);
                    return code === null ? null : String.fromCharCode(code);
                }
                case 117: { // 'u'
                    const /*<@22>*/code = this.readCodePoint(throwOnInvalid);
                    return code === null ? null : codePointToString(code);
                }
                case 116: return "\t"; // 't' -> '\t'
                case 98: return "\b"; // 'b' -> '\b'
                case 118: return "\u000b"; // 'v' -> '\u000b'
                case 102: return "\f"; // 'f' -> '\f'
                case 13: if (this.input.charCodeAt(this.state.pos) === 10)
                    ++this.state.pos; // '\r\n'
                case 10: // ' \n'
                    this.state.lineStart = this.state.pos;
                    ++this.state.curLine;
                    return "";
                default:
                    if (ch >= 48 && ch <= 55) {
                        const /*<@5>*/codePos = this.state.pos - 1;
                        let /*<@3>*/octalStr = this.input.substr(this.state.pos - 1, 3).match(/^[0-7]+/)[0];
                        let /*<@1>*/octal = parseInt(octalStr, 8);
                        if (octal > 255) {
                            octalStr = octalStr.slice(0, -1);
                            octal = parseInt(octalStr, 8);
                        }
                        if (octal > 0) {
                            if (inTemplate) {
                                this.state.invalidTemplateEscapePosition = codePos;
                                return null;
                            }
                            else if (this.state.strict) {
                                this.raise(codePos, "Octal literal in strict mode");
                            }
                            else if (!this.state.containsOctal) {
                                // These properties are only used to throw an error for an octal which occurs
                                // in a directive which occurs prior to a "use strict" directive.
                                this.state.containsOctal = true;
                                this.state.octalPosition = codePos;
                            }
                        }
                        this.state.pos += octalStr.length - 1;
                        return String.fromCharCode(octal);
                    }
                    return String.fromCharCode(ch);
            }
        }
        // Used to read character escape sequences ('\x', '\u').
        /*<@345>*/readHexChar(/*<@5>*/len, /*<@2>*/throwOnInvalid) {
            const /*<@5>*/codePos = this.state.pos;
            const /*<@22>*/n = this.readInt(16, len);
            if (n === null) {
                if (throwOnInvalid) {
                    this.raise(codePos, "Bad character escape sequence");
                }
                else {
                    this.state.pos = codePos - 1;
                    this.state.invalidTemplateEscapePosition = codePos - 1;
                }
            }
            return n;
        }
        // Read an identifier, and return it as a string. Sets `this.state.containsEsc`
        // to whether the word contained a '\u' escape.
        //
        // Incrementally adds only escaped chars, adding other chunks as-is
        // as a micro-optimization.
        /*<@346>*/readWord1() {
            this.state.containsEsc = false;
            let /*<@3>*/word = "", /*<@2>*/first = true, /*<@5>*/chunkStart = this.state.pos;
            while (this.state.pos < this.input.length) {
                const /*<@5>*/ch = this.fullCharCodeAtPos();
                if (utilIdentifierJS.isIdentifierChar(ch)) {
                    this.state.pos += ch <= 0xffff ? 1 : 2;
                }
                else if (ch === 92) { // "\"
                    this.state.containsEsc = true;
                    word += this.input.slice(chunkStart, this.state.pos);
                    const /*<@5>*/escStart = this.state.pos;
                    if (this.input.charCodeAt(++this.state.pos) !== 117) { // "u"
                        this.raise(this.state.pos, "Expecting Unicode escape sequence \\uXXXX");
                    }
                    ++this.state.pos;
                    const /*<@22>*/esc = this.readCodePoint(true);
                    if (!(first ? utilIdentifierJS.isIdentifierStart : utilIdentifierJS.isIdentifierChar)(esc)) {
                        this.raise(escStart, "Invalid Unicode escape");
                    }
                    word += codePointToString(/*<@5>*/esc);
                    chunkStart = this.state.pos;
                }
                else {
                    break;
                }
                first = false;
            }
            return word + this.input.slice(chunkStart, this.state.pos);
        }
        // Read an identifier or keyword token. Will check for reserved
        // words when necessary.
        /*<@347>*/readWord() {
            const /*<@3>*/word = this.readWord1();
            let /*<@44>*/type = this.tt.name;
            if (!this.state.containsEsc && this.isKeyword(word)) {
                switch (word) {
                    case "break":
                        type = tokenizerTypesJS.keywords.break;
                        break;
                    case "case":
                        type = tokenizerTypesJS.keywords.case;
                        break;
                    case "catch":
                        type = tokenizerTypesJS.keywords.catch;
                        break;
                    case "continue":
                        type = tokenizerTypesJS.keywords.continue;
                        break;
                    case "debugger":
                        type = tokenizerTypesJS.keywords.debugger;
                        break;
                    case "default":
                        type = tokenizerTypesJS.keywords.default;
                        break;
                    case "do":
                        type = tokenizerTypesJS.keywords.do;
                        break;
                    case "else":
                        type = tokenizerTypesJS.keywords.else;
                        break;
                    case "finally":
                        type = tokenizerTypesJS.keywords.finally;
                        break;
                    case "for":
                        type = tokenizerTypesJS.keywords.for;
                        break;
                    case "function":
                        type = tokenizerTypesJS.keywords.function;
                        break;
                    case "if":
                        type = tokenizerTypesJS.keywords.if;
                        break;
                    case "return":
                        type = tokenizerTypesJS.keywords.return;
                        break;
                    case "switch":
                        type = tokenizerTypesJS.keywords.switch;
                        break;
                    case "throw":
                        type = tokenizerTypesJS.keywords.throw;
                        break;
                    case "try":
                        type = tokenizerTypesJS.keywords.try;
                        break;
                    case "var":
                        type = tokenizerTypesJS.keywords.var;
                        break;
                    case "let":
                        type = tokenizerTypesJS.keywords.let;
                        break;
                    case "const":
                        type = tokenizerTypesJS.keywords.const;
                        break;
                    case "while":
                        type = tokenizerTypesJS.keywords.while;
                        break;
                    case "with":
                        type = tokenizerTypesJS.keywords.with;
                        break;
                    case "new":
                        type = tokenizerTypesJS.keywords.new;
                        break;
                    case "this":
                        type = tokenizerTypesJS.keywords.this;
                        break;
                    case "super":
                        type = tokenizerTypesJS.keywords.super;
                        break;
                    case "class":
                        type = tokenizerTypesJS.keywords.class;
                        break;
                    case "extends":
                        type = tokenizerTypesJS.keywords.extends;
                        break;
                    case "export":
                        type = tokenizerTypesJS.keywords.export;
                        break;
                    case "import":
                        type = tokenizerTypesJS.keywords.import;
                        break;
                    case "yield":
                        type = tokenizerTypesJS.keywords.yield;
                        break;
                    case "null":
                        type = tokenizerTypesJS.keywords.null;
                        break;
                    case "true":
                        type = tokenizerTypesJS.keywords.true;
                        break;
                    case "false":
                        type = tokenizerTypesJS.keywords.false;
                        break;
                    case "in":
                        type = tokenizerTypesJS.keywords.in;
                        break;
                    case "instanceof":
                        type = tokenizerTypesJS.keywords.instanceof;
                        break;
                    case "typeof":
                        type = tokenizerTypesJS.keywords.typeof;
                        break;
                    case "void":
                        type = tokenizerTypesJS.keywords.void;
                        break;
                    case "delete":
                        type = tokenizerTypesJS.keywords.delete;
                        break;
                }
            }
            return this.finishToken(type, word);
        }
        /*<@348>*/braceIsBlock(/*<@44>*/prevType) {
            if (prevType === this.tt.colon) {
                const /*<@58>*/parent = this.curContext();
                if (parent === tokenizerContextJS.types.braceStatement || parent === tokenizerContextJS.types.braceExpression) {
                    return !parent.isExpr;
                }
            }
            if (prevType === this.tt._return) {
                return utilWhitespaceJS.lineBreak.test(this.input.slice(this.state.lastTokEnd, this.state.start));
            }
            if (prevType === this.tt._else || prevType === this.tt.semi || prevType === this.tt.eof || prevType === this.tt.parenR) {
                return true;
            }
            if (prevType === this.tt.braceL) {
                return this.curContext() === tokenizerContextJS.types.braceStatement;
            }
            return !this.state.exprAllowed;
        }
        /*<@349>*/updateContext(/*<@44>*/prevType) {
            const /*<@44>*/type = this.state./*<@44>*/type;
            let update;
            if (type.keyword && prevType === this.tt.dot) {
                this.state.exprAllowed = false;
            }
            else if (update = type.updateContext) {
                update.call(this, prevType);
            }
            else {
                this.state.exprAllowed = type.beforeExpr;
            }
        }
    }
    Tokenizer.Token = Token;
    const /*<@64>*/tokenizerIndexJS = Tokenizer;
    // A second optional argument can be given to further configure
    // the parser process. These options are recognized:
    const defaultOptions = /*<@364>*/{
        // Source type ("script" or "module") for different semantics
        sourceType: "script",
        // Source filename.
        sourceFilename: undefined,
        // Line from which to start counting source. Useful for
        // integration with other tools.
        startLine: 1,
        // When enabled, a return at the top level is not considered an
        // error.
        allowReturnOutsideFunction: false,
        // When enabled, import/export statements are not constrained to
        // appearing at the top of the program.
        allowImportExportEverywhere: false,
        // TODO
        allowSuperOutsideMethod: false,
        // An array of plugins to enable
        plugins: /*<@361>*/[],
        // TODO
        strictMode: null,
        // Nodes have their start and end characters offsets recorded in
        // `start` and `end` properties (directly on the node, rather than
        // the `loc` object, which holds line/column data. To also add a
        // [semi-standardized][range] `range` property holding a `[start,
        // end]` array with the same numbers, set the `ranges` option to
        // `true`.
        //
        // [range]: https://bugzilla.mozilla.org/show_bug.cgi?id=745678
        ranges: false,
    };
    // options.js
    const /*<@366>*/optionsJS = /*<@366>*/{
        defaultOptions,
        /*<@365>*/getOptions(opts) {
            const options = /*<@364>*/{
                sourceType: "",
                sourceFilename: undefined,
                startLine: 1,
                allowReturnOutsideFunction: false,
                allowImportExportEverywhere: false,
                allowSuperOutsideMethod: false,
                plugins: /*<@361>*/[],
                strictMode: null,
                ranges: false,
            };
            if (opts.sourceType)
                options.sourceType = opts.sourceType;
            if (opts.sourceFilename)
                options.sourceFilename = opts.sourceFilename;
            if (opts.startLine)
                options.startLine = opts.startLine;
            if (opts.allowReturnOutsideFunction)
                options.allowReturnOutsideFunction = opts.allowReturnOutsideFunction;
            if (opts.allowImportExportEverywhere)
                options.allowImportExportEverywhere = opts.allowImportExportEverywhere;
            if (opts.allowSuperOutsideMethod)
                options.allowSuperOutsideMethod = opts.allowSuperOutsideMethod;
            if (opts.plugins)
                options.plugins = opts.plugins;
            if (opts.strictMode)
                options.strictMode = opts.strictMode;
            if (opts.ranges)
                options.ranges = opts.ranges;
            return options;
        }
    };
    // parser/index.js
    function /*<@367>*/last(/*<@119>*/stack) {
        return stack[stack.length - 1];
    }
    const /*<@24>*/commentKeys = /*<@24>*/["leadingComments", "trailingComments", "innerComments"];
    const /*<@27>*/HEX_NUMBER = /^[\da-fA-F]+$/;
    const /*<@27>*/DECIMAL_NUMBER = /^\d+$/;
    class /*<@70>*/Node {
        constructor(/*<@71>*/parser, /*<@22>*/pos, /*<@35>*/loc) {
            this.type = "";
            this.start = pos;
            this.end = 0;
            this.loc = new SourceLocation(loc);
            if (parser && parser.options.ranges)
                this.range = /*<@28>*/[/*<@5>*/pos, 0];
            if (parser && parser.filename)
                this.loc.filename = parser.filename;
        }
        /*<@303>*/__clone() {
            const /*<@69>*/node2 = new Node();
            node2.type = this.type;
            node2.start = this.start;
            node2.end = this.end;
            node2.loc = this.loc;
            node2.range = this.range;
            node2.body = this.body;
            node2.value = this.value;
            node2.computed = this.computed;
            node2.kind = this.kind;
            node2.key = this.key;
            node2.name = this.name;
            node2.expressions = this.expressions;
            node2.operator = this.operator;
            node2.prefix = this.prefix;
            node2.argument = this.argument;
            node2.extra = this.extra;
            node2.left = this.left;
            node2.right = this.right;
            node2.test = this.test;
            node2.properties = this.properties;
            node2.elements = this.elements;
            node2.consequent = this.consequent;
            node2.alternate = this.alternate;
            node2.async = this.async;
            node2.generator = this.generator;
            node2.id = this.id;
            node2.expression = this.expression;
            node2.params = this.params;
            node2.pattern = this.pattern;
            node2.flags = this.flags;
            node2.decorators = this.decorators;
            node2.object = this.object;
            node2.callee = this.callee;
            node2.property = this.property;
            node2.arguments = this.arguments;
            node2.tag = this.tag;
            node2.quasi = this.quasi;
            node2.quasis = this.quasis;
            node2.meta = this.meta;
            node2.tail = this.tail;
            node2.method = this.method;
            node2.shorthand = this.shorthand;
            node2.delegate = this.delegate;
            node2.program = this.program;
            node2.comments = this.comments;
            node2.tokens = this.tokens;
            node2.sourceType = this.sourceType;
            node2.label = this.label;
            node2.declarations = this.declarations;
            node2.init = this.init;
            node2.discriminant = this.discriminant;
            node2.cases = this.cases;
            node2.block = this.block;
            node2.handler = this.handler;
            node2.param = this.param;
            node2.guardedHandlers = this.guardedHandlers;
            node2.finalizer = this.finalizer;
            node2.statementStart = this.statementStart;
            node2.directives = this.directives;
            node2.directive = this.directive;
            node2.update = this.update;
            node2.await = this.await;
            node2.static = this.static;
            node2.typeAnnotation = this.typeAnnotation;
            node2.superClass = this.superClass;
            node2.exported = this.exported;
            node2.specifiers = this.specifiers;
            node2.declaration = this.declaration;
            node2.source = this.source;
            node2.local = this.local;
            node2.imported = this.imported;
            node2.regex = this.regex;
            node2.raw = this.raw;
            node2.elementType = this.elementType;
            node2.typeParameters = this.typeParameters;
            node2.rest = this.rest;
            node2.returnType = this.returnType;
            node2.predicate = this.predicate;
            node2.extends = this.extends;
            node2.mixins = this.mixins;
            node2.qualification = this.qualification;
            node2.variance = this.variance;
            node2.bound = this.bound;
            node2.default = this.default;
            node2.optional = this.optional;
            node2.callProperties = this.callProperties;
            node2.indexers = this.indexers;
            node2.exact = this.exact;
            node2.types = this.types;
            node2.exportKind = this.exportKind;
            node2._exprListItem = this._exprListItem;
            node2.implements = this.implements;
            node2.superTypeParameters = this.superTypeParameters;
            node2.importKind = this.importKind;
            node2.namespace = this.namespace;
            node2.attributes = this.attributes;
            node2.selfClosing = this.selfClosing;
            node2.openingElement = this.openingElement;
            node2.closingElement = this.closingElement;
            node2.children = this.children;
            return node2;
        }
    }
    const /*<@69>*/loopLabel = new Node();
    loopLabel.kind = "loop";
    const /*<@69>*/switchLabel = new Node();
    switchLabel.kind = "switch";
    class /*<@72>*/Parser extends Tokenizer {
        constructor(options, /*<@3>*/input) {
            super(options = optionsJS.getOptions(options), input);
            this.options = options;
            this.inModule = this.options.sourceType === "module";
            this.input = input;
            this.plugins = this.loadPlugins(this.options.plugins);
            this.filename = options.sourceFilename;
            // If enabled, skip leading hashbang line.
            if (this.state.pos === 0 && this.input[0] === "#" && this.input[1] === "!") {
                this.skipLineComment(2);
            }
        }
        /*<@73>*/isReservedWord(/*<@3>*/word) {
            if (word === "await") {
                return this.inModule;
            }
            else {
                return utilIdentifierJS.reservedWords[6](word);
            }
        }
        /*<@74>*/hasPlugin(/*<@3>*/name) {
            return !!this.plugins[name];
        }
        /*<@75>*/extends(/*<@3>*/name, f) {
            let /*<@94>*/superFunc;
            if (name == "checkDeclaration") {
                superFunc = this.checkDeclaration;
                this.checkDeclaration =
                    f(superFunc);
            }
            else if (name == "checkGetterSetterParamCount") {
                superFunc = this.checkGetterSetterParamCount;
                this.checkGetterSetterParamCount =
                    f(superFunc);
            }
            else if (name == "checkLVal") {
                superFunc = this.checkLVal;
                this.checkLVal =
                    f(superFunc);
            }
            else if (name == "checkPropClash") {
                superFunc = this.checkPropClash;
                this.checkPropClash =
                    f(superFunc);
            }
            else if (name == "isStrictBody") {
                superFunc = this.isStrictBody;
                this.isStrictBody =
                    f(superFunc);
            }
            else if (name == "isValidDirective") {
                superFunc = this.isValidDirective;
                this.isValidDirective =
                    (f(superFunc));
            }
            else if (name == "parseBlockBody") {
                superFunc = this.parseBlockBody;
                this.parseBlockBody =
                    (f(superFunc));
            }
            else if (name == "parseClassMethod") {
                superFunc = this.parseClassMethod;
                this.parseClassMethod =
                    f(superFunc);
            }
            else if (name == "parseExprAtom") {
                superFunc = this.parseExprAtom;
                this.parseExprAtom =
                    (f(superFunc));
            }
            else if (name == "parseLiteral") {
                superFunc = this.parseLiteral;
                this.parseLiteral =
                    f(superFunc);
            }
            else if (name == "parseMethod") {
                superFunc = this.parseMethod;
                this.parseMethod =
                    (f(superFunc));
            }
            else if (name == "parseObjectMethod") {
                superFunc = this.parseObjectMethod;
                this.parseObjectMethod =
                    (f(superFunc));
            }
            else if (name == "parseObjectProperty") {
                superFunc = this.parseObjectProperty;
                this.parseObjectProperty =
                    (f(superFunc));
            }
            else if (name == "toAssignable") {
                superFunc = this.toAssignable;
                this.toAssignable =
                    (f(superFunc));
            }
            else if (name == "parseFunctionBody") {
                superFunc = this.parseFunctionBody;
                this.parseFunctionBody =
                    (f(superFunc));
            }
            else if (name == "parseStatement") {
                superFunc = this.parseStatement;
                this.parseStatement =
                    (f(superFunc));
            }
            else if (name == "parseExpressionStatement") {
                superFunc = this.parseExpressionStatement;
                this.parseExpressionStatement =
                    (this.parseExpressionStatement);
            }
            else if (name == "shouldParseExportDeclaration") {
                superFunc = this.shouldParseExportDeclaration;
                this.shouldParseExportDeclaration =
                    (f(superFunc));
            }
            else if (name == "parseConditional") {
                superFunc = this.parseConditional;
                this.parseConditional =
                    (f(superFunc));
            }
            else if (name == "parseParenItem") {
                superFunc = this.parseParenItem;
                this.parseParenItem =
                    (f(superFunc));
            }
            else if (name == "parseExport") {
                superFunc = this.parseExport;
                this.parseExport =
                    f(superFunc);
            }
            else if (name == "parseExportDeclaration") {
                superFunc = this.parseExportDeclaration;
                this.parseExportDeclaration =
                    (f(superFunc));
            }
            else if (name == "parseClassId") {
                superFunc = this.parseClassId;
                this.parseClassId =
                    (f(superFunc));
            }
            else if (name == "isKeyword") {
                superFunc = this.isKeyword;
                this.isKeyword =
                    (f(superFunc));
            }
            else if (name == "readToken") {
                superFunc = this.readToken;
                this.readToken =
                    (f(superFunc));
            }
            else if (name == "jsx_readToken") {
                superFunc = this.jsx_readToken;
                this.jsx_readToken =
                    (f(superFunc));
            }
            else if (name == "toAssignable") {
                superFunc = this.toAssignable;
                this.toAssignable =
                    (f(superFunc));
            }
            else if (name == "toAssignableList") {
                superFunc = this.toAssignableList;
                this.toAssignableList =
                    (f(superFunc));
            }
            else if (name == "toReferencedList") {
                superFunc = this.toReferencedList;
                this.toReferencedList =
                    (f(superFunc));
            }
            else if (name == "parseExprListItem") {
                superFunc = this.parseExprListItem;
                this.parseExprListItem =
                    f(superFunc);
            }
            else if (name == "parseClassProperty") {
                superFunc = this.parseClassProperty;
                this.parseClassProperty =
                    (f(superFunc));
            }
            else if (name == "isClassMethod") {
                superFunc = this.isClassMethod;
                this.isClassMethod =
                    (f(superFunc));
            }
            else if (name == "isClassProperty") {
                superFunc = this.isClassProperty;
                this.isClassProperty =
                    (f(superFunc));
            }
            else if (name == "parseClassMethod") {
                superFunc = this.parseClassMethod;
                this.parseClassMethod =
                    (f(superFunc));
            }
            else if (name == "parseClassSuper") {
                superFunc = this.parseClassSuper;
                this.parseClassSuper =
                    (f(superFunc));
            }
            else if (name == "parsePropertyName") {
                superFunc = this.parsePropertyName;
                this.parsePropertyName =
                    (f(superFunc));
            }
            else if (name == "parseObjPropValue") {
                superFunc = this.parseObjPropValue;
                this.parseObjPropValue =
                    (f(superFunc));
            }
            else if (name == "parseAssignableListItemTypes") {
                superFunc = this.parseAssignableListItemTypes;
                this.parseAssignableListItemTypes =
                    (f(superFunc));
            }
            else if (name == "parseMaybeDefault") {
                superFunc = this.parseMaybeDefault;
                this.parseMaybeDefault =
                    (f(superFunc));
            }
            else if (name == "parseImportSpecifiers") {
                superFunc = this.parseImportSpecifiers;
                this.parseImportSpecifiers =
                    (f(superFunc));
            }
            else if (name == "parseImportSpecifier") {
                superFunc = this.parseImportSpecifier;
                this.parseImportSpecifier =
                    (f(superFunc));
            }
            else if (name == "parseFunctionParams") {
                superFunc = this.parseFunctionParams;
                this.parseFunctionParams =
                    (f(superFunc));
            }
            else if (name == "parseVarHead") {
                superFunc = this.parseVarHead;
                this.parseVarHead =
                    (f(superFunc));
            }
            else if (name == "parseAsyncArrowFromCallExpression") {
                superFunc = this.parseAsyncArrowFromCallExpression;
                this.parseAsyncArrowFromCallExpression =
                    (f(superFunc));
            }
            else if (name == "shouldParseAsyncArrow") {
                superFunc = this.shouldParseAsyncArrow;
                this.shouldParseAsyncArrow =
                    (f(superFunc));
            }
            else if (name == "parseMaybeAssign") {
                superFunc = this.parseMaybeAssign;
                this.parseMaybeAssign =
                    (f(superFunc));
            }
            else if (name == "parseArrow") {
                superFunc = this.parseArrow;
                this.parseArrow =
                    (f(superFunc));
            }
            else if (name == "shouldParseArrow") {
                superFunc = this.shouldParseArrow;
                this.shouldParseArrow =
                    (f(superFunc));
            }
            else if (name == "parseExprAtom") {
                superFunc = this.parseExprAtom;
                this.parseExprAtom =
                    (f(superFunc));
            }
            else if (name == "readToken") {
                superFunc = this.readToken;
                this.readToken =
                    (f(superFunc));
            }
            else if (name == "updateContext") {
                superFunc = this.updateContext;
                this.updateContext =
                    (f(superFunc));
            }
            else {
                throw new Error("unknow extends " + name);
            }
        }
        /*<@76>*/jsx_readToken() {
            throw new Error("no jsx_readToken");
        }
        /*<@77>*/loadPlugins(/*<@24>*/pluginList) {
            const /*<@6>*/pluginMap = /*<@6>*/{};
            if (pluginList.indexOf("flow") >= 0) {
                // ensure flow plugin loads last
                pluginList = pluginList.filter(/*<@368>*/(/*<@3>*/plugin) => plugin !== "flow");
                pluginList.push("flow");
            }
            if (pluginList.indexOf("estree") >= 0) {
                // ensure estree plugin loads first
                pluginList = pluginList.filter(/*<@369>*/(/*<@3>*/plugin) => plugin !== "estree");
                pluginList.unshift("estree");
            }
            for (const /*<@3>*/name of pluginList) {
                if (!pluginMap[name]) {
                    pluginMap[name] = true;
                    const plugin = Parser.plugins[name];
                    if (plugin)
                        plugin(this);
                }
            }
            return pluginMap;
        }
        /*<@78>*/startNode() {
            return new Node(this, this.state.start, this.state.startLoc);
        }
        /*<@79>*/startNodeAt(/*<@22>*/pos, /*<@39>*/loc) {
            return new Node(this, pos, /*<@35>*/loc);
        }
        /*<@80>*/parse() {
            const /*<@69>*/file = this.startNode();
            const /*<@69>*/program = this.startNode();
            this.nextToken();
            return this.parseTopLevel(file, program);
        }
        /*<@81>*/addComment(/*<@69>*/comment) {
            if (this.filename)
                comment./*<@37>*/loc.filename = this.filename;
            this.state.trailingComments.push(comment);
            this.state.leadingComments.push(comment);
        }
        /*<@82>*/processComment(/*<@69>*/node) {
            if (node.type === "Program" && (node./*<@119>*/body).length > 0)
                return;
            const /*<@119>*/stack = this.state.commentStack;
            let /*<@111>*/lastChild = void 0, /*<@295>*/trailingComments = void 0, i, j;
            if (this.state.trailingComments.length > 0) {
                // If the first comment in trailingComments comes after the
                // current node, then we're good - all comments in the array will
                // come after the node and so it's safe to add them as official
                // trailingComments.
                if (this.state.trailingComments[0]./*<@103>*/start >= node.end) {
                    trailingComments = this.state.trailingComments;
                    this.state.trailingComments = /*<@361>*/[];
                }
                else {
                    // Otherwise, if the first comment doesn't come after the
                    // current node, that means we have a mix of leading and trailing
                    // comments in the array and that leadingComments contains the
                    // same items as trailingComments. Reset trailingComments to
                    // zero items and we'll handle this by evaluating leadingComments
                    // later.
                    this.state.trailingComments.length = 0;
                }
            }
            else {
                const /*<@69>*/lastInStack = last(stack);
                if (stack.length > 0 && lastInStack.trailingComments && lastInStack.trailingComments[0]./*<@103>*/start >= node.end) {
                    trailingComments = lastInStack.trailingComments;
                    lastInStack.trailingComments = null;
                }
            }
            // Eating the stack.
            while (stack.length > 0 && last(stack)./*<@103>*/start >= node./*<@103>*/start) {
                lastChild = stack.pop();
            }
            if (lastChild) {
                if (lastChild.leadingComments) {
                    if (lastChild !== node && last(lastChild.leadingComments).end <= node./*<@103>*/start) {
                        node.leadingComments = lastChild.leadingComments;
                        lastChild.leadingComments = null;
                    }
                    else {
                        // A leading comment for an anonymous class had been stolen by its first ClassMethod,
                        // so this takes back the leading comment.
                        // See also: https://github.com/eslint/espree/issues/158
                        for (let /*<@1>*/i = lastChild.leadingComments.length - 2; i >= 0; --i) {
                            if (lastChild.leadingComments[i].end <= node./*<@103>*/start) {
                                node.leadingComments = lastChild.leadingComments.splice(0, i + 1);
                                break;
                            }
                        }
                    }
                }
            }
            else if (this.state.leadingComments.length > 0) {
                if (last(this.state.leadingComments).end <= node./*<@103>*/start) {
                    if (this.state.commentPreviousNode) {
                        for (let /*<@5>*/j = 0; j < this.state.leadingComments.length; j++) {
                            if (this.state.leadingComments[j].end < this.state.commentPreviousNode.end) {
                                this.state.leadingComments.splice(j, 1);
                                j--;
                            }
                        }
                    }
                    if (this.state.leadingComments.length > 0) {
                        node.leadingComments = this.state.leadingComments;
                        this.state.leadingComments = /*<@361>*/[];
                    }
                }
                else {
                    // https://github.com/eslint/espree/issues/2
                    //
                    // In special cases, such as return (without a value) and
                    // debugger, all comments will end up as leadingComments and
                    // will otherwise be eliminated. This step runs when the
                    // commentStack is empty and there are comments left
                    // in leadingComments.
                    //
                    // This loop figures out the stopping point between the actual
                    // leading and trailing comments by finding the location of the
                    // first comment that comes after the given node.
                    for (let /*<@5>*/i = 0; i < this.state.leadingComments.length; i++) {
                        if (this.state.leadingComments[i].end > node./*<@103>*/start) {
                            break;
                        }
                    }
                    // Split the array based on the location of the first comment
                    // that comes after the node. Keep in mind that this could
                    // result in an empty array, and if so, the array must be
                    // deleted.
                    node.leadingComments = this.state.leadingComments.slice(0, i);
                    if ((node.leadingComments).length === 0) {
                        node.leadingComments = null;
                    }
                    // Similarly, trailing comments are attached later. The variable
                    // must be reset to null if there are no trailing comments.
                    trailingComments = this.state.leadingComments.slice(i);
                    if (trailingComments.length === 0) {
                        trailingComments = null;
                    }
                }
            }
            this.state.commentPreviousNode = node;
            if (trailingComments) {
                if (trailingComments.length && trailingComments[0]./*<@103>*/start >= node./*<@103>*/start && last(trailingComments).end <= node.end) {
                    node.innerComments = trailingComments;
                }
                else {
                    node.trailingComments = trailingComments;
                }
            }
            stack.push(node);
        }
        /*<@83>*/checkPropClash(/*<@69>*/prop, /*<@6>*/propHash) {
            if (prop.computed || prop.kind)
                return;
            const /*<@69>*/key = prop.key;
            // It is either an Identifier or a String/NumericLiteral
            const /*<@297>*/name = key.type === "Identifier" ? key.name : String(key.value);
            if (name === "__proto__") {
                if (propHash.proto)
                    this.raise(key.start, "Redefinition of __proto__ property");
                propHash.proto = true;
            }
        }
        /*<@84>*/finishNodeAt(/*<@69>*/node, /*<@3>*/type, /*<@5>*/pos, /*<@39>*/loc) {
            node.type = type;
            node.end = pos;
            node./*<@37>*/loc.end = /*<@35>*/loc;
            if (this.options.ranges)
                node.range[1] = pos;
            this.processComment(node);
            return node;
        }
        /*<@85>*/resetStartLocationFromNode(/*<@69>*/node, /*<@69>*/locationNode) {
            node.start = locationNode.start;
            node./*<@37>*/loc.start = locationNode./*<@37>*/loc.start;
            if (this.options.ranges)
                node.range[0] = locationNode.range[0];
            return node;
        }
        /*<@86>*/getExpression() {
            this.nextToken();
            const /*<@69>*/expr = this.parseExpression();
            if (!this.match(this.tt.eof)) {
                this.unexpected();
            }
            return expr;
        }
        /*<@87>*/finishNode(/*<@69>*/node, /*<@3>*/type) {
            return this.finishNodeAt(node, type, this.state.lastTokEnd, this.state.lastTokEndLoc);
        }
        /*<@88>*/parseExpression(/*<@60>*/noIn, /*<@89>*/refShorthandDefaultPos) {
            const /*<@5>*/startPos = this.state.start;
            const /*<@35>*/startLoc = this.state.startLoc;
            const /*<@69>*/expr = this.parseMaybeAssign(noIn, refShorthandDefaultPos);
            if (this.match(this.tt.comma)) {
                const /*<@69>*/node = this.startNodeAt(startPos, startLoc);
                node.expressions = /*<@119>*/[expr];
                while (this.eat(this.tt.comma)) {
                    node.expressions.push(this.parseMaybeAssign(noIn, refShorthandDefaultPos));
                }
                this.toReferencedList(node.expressions);
                return this.finishNode(node, "SequenceExpression");
            }
            return expr;
        }
        /*<@91>*/checkLVal(/*<@69>*/expr, /*<@60>*/isBinding, /*<@92>*/checkClashes, /*<@3>*/contextDescription) {
            switch (expr.type) {
                case "Identifier":
                    this.checkReservedWord(expr./*<@3>*/name, expr.start, false, true);
                    if (checkClashes) {
                        // we need to prefix this with an underscore for the cases where we have a key of
                        // `__proto__`. there's a bug in old V8 where the following wouldn't work:
                        //
                        //   > var obj = Object.create(null);
                        //   undefined
                        //   > obj.__proto__
                        //   null
                        //   > obj.__proto__ = true;
                        //   true
                        //   > obj.__proto__
                        //   null
                        const /*<@3>*/key = `_${expr.name}`;
                        if (checkClashes[key]) {
                            this.raise(expr.start, "Argument name clash in strict mode");
                        }
                        else {
                            checkClashes[key] = true;
                        }
                    }
                    break;
                case "MemberExpression":
                    if (isBinding)
                        this.raise(expr.start, (isBinding ? "Binding" : "Assigning to") + " member expression");
                    break;
                case "ObjectPattern":
                    for (let /*<@69>*/prop of (expr.properties)) {
                        if (prop.type === "ObjectProperty")
                            prop = (prop./*<@69>*/value);
                        this.checkLVal(prop, isBinding, checkClashes, "object destructuring pattern");
                    }
                    break;
                case "ArrayPattern":
                    for (const /*<@69>*/elem of (expr.elements)) {
                        if (elem)
                            this.checkLVal(elem, isBinding, checkClashes, "array destructuring pattern");
                    }
                    break;
                case "AssignmentPattern":
                    this.checkLVal(expr./*<@69>*/left, isBinding, checkClashes, "assignment pattern");
                    break;
                case "RestElement":
                    this.checkLVal(expr./*<@69>*/argument, isBinding, checkClashes, "rest element");
                    break;
                default: {
                    const /*<@3>*/message = (isBinding ? /* istanbul ignore next */ "Binding invalid" : "Invalid") +
                        " left-hand side" +
                        (contextDescription ? " in " + contextDescription : /* istanbul ignore next */ "expression");
                    this.raise(expr.start, message);
                }
            }
        }
        /*<@93>*/parseMaybeAssign(/*<@60>*/noIn, /*<@92>*/refShorthandDefaultPos, /*<@94>*/afterLeftParse, /*<@92>*/refNeedsArrowPos) {
            const /*<@5>*/startPos = this.state.start;
            const /*<@35>*/startLoc = this.state.startLoc;
            if (this.match(this.tt._yield) && this.state.inGenerator) {
                let /*<@69>*/left = this.parseYield();
                if (afterLeftParse)
                    left = (afterLeftParse.call(left, startPos, startLoc));
                return left;
            }
            let /*<@2>*/failOnShorthandAssign;
            if (refShorthandDefaultPos) {
                failOnShorthandAssign = false;
            }
            else {
                refShorthandDefaultPos = /*<@89>*/{ start: 0 };
                failOnShorthandAssign = true;
            }
            if (this.match(this.tt.parenL) || this.match(this.tt.name)) {
                this.state.potentialArrowAt = this.state.start;
            }
            let /*<@69>*/left = this.parseMaybeConditional(/*<@2>*/noIn, refShorthandDefaultPos, /*<@89>*/refNeedsArrowPos);
            if (afterLeftParse)
                left = (afterLeftParse.call(this, left, startPos, startLoc));
            if (this.state.type.isAssign) {
                const /*<@69>*/node = this.startNodeAt(startPos, startLoc);
                node.operator = this.state./*<@103>*/value;
                node.left = this.match(this.tt.eq) ? this.toAssignable(left, undefined, "assignment expression") : left;
                refShorthandDefaultPos.start = 0; // reset because shorthand default was used correctly
                this.checkLVal(left, undefined, undefined, "assignment expression");
                if (left.extra && left.extra.parenthesized) {
                    let /*<@26>*/errorMsg = void 0;
                    if (left.type === "ObjectPathis.tt.rn") {
                        errorMsg = "`({a}) = 0` use `({a} = 0)`";
                    }
                    else if (left.type === "ArrayPathis.tt.rn") {
                        errorMsg = "`([a]) = 0` use `([a] = 0)`";
                    }
                    if (errorMsg) {
                        this.raise(left.start, `You're trying to assign to a parenthesized expression, eg. instead of ${errorMsg}`);
                    }
                }
                this.next();
                node.right = this.parseMaybeAssign(noIn);
                return this.finishNode(node, "AssignmentExpression");
            }
            else if (failOnShorthandAssign && refShorthandDefaultPos.start) {
                this.unexpected(refShorthandDefaultPos.start);
            }
            return left;
        }
        /*<@96>*/parseMaybeConditional(/*<@2>*/noIn, /*<@6>*/refShorthandDefaultPos, /*<@6>*/refNeedsArrowPos) {
            const /*<@5>*/startPos = this.state.start;
            const /*<@35>*/startLoc = this.state.startLoc;
            const /*<@69>*/expr = this.parseExprOps(noIn, refShorthandDefaultPos);
            if (refShorthandDefaultPos && refShorthandDefaultPos.start)
                return expr;
            return this.parseConditional(expr, noIn, startPos, startLoc);
        }
        ;
        /*<@97>*/expect(/*<@44>*/type, /*<@22>*/pos) {
            return this.eat(/*<@44>*/type) || this.unexpected(pos, type);
        }
        ;
        /*<@98>*/parseConditional(/*<@69>*/expr, /*<@2>*/noIn, /*<@5>*/startPos, /*<@35>*/startLoc) {
            if (this.eat(this.tt.question)) {
                const /*<@69>*/node = this.startNodeAt(startPos, startLoc);
                node.test = expr;
                node.consequent = this.parseMaybeAssign();
                this.expect(this.tt.colon);
                node.alternate = this.parseMaybeAssign(noIn);
                return this.finishNode(node, "ConditionalExpression");
            }
            return expr;
        }
        ;
        // Start the precedence parser.
        /*<@99>*/parseExprOps(/*<@2>*/noIn, /*<@100>*/refShorthandDefaultPos) {
            const /*<@5>*/startPos = this.state.start;
            const /*<@35>*/startLoc = this.state.startLoc;
            const /*<@69>*/expr = this.parseMaybeUnary(refShorthandDefaultPos);
            if (refShorthandDefaultPos && refShorthandDefaultPos.start) {
                return expr;
            }
            else {
                return this.parseExprOp(expr, startPos, startLoc, -1, noIn);
            }
        }
        ;
        // Parse binary operators with the operator precedence parsing
        // algorithm. `left` is the left-hand side of the operator.
        // `minPrec` provides context that allows the function to stop and
        // defer further parser to one of its callers when it encounters an
        // operator that has a lower precedence than the set it is parsing.
        /*<@101>*/parseExprOp(/*<@69>*/left, /*<@5>*/leftStartPos, /*<@35>*/leftStartLoc, /*<@5>*/minPrec, /*<@2>*/noIn) {
            const /*<@22>*/prec = this.state.type.binop;
            if (prec != null && (!noIn || !this.match(this.tt._in))) {
                if (prec > minPrec) {
                    const /*<@69>*/node = this.startNodeAt(leftStartPos, leftStartLoc);
                    node.left = left;
                    node.operator = this.state./*<@103>*/value;
                    if (node.operator === "**" &&
                        left.type === "UnaryExpression" &&
                        left.extra &&
                        !left.extra.parenthesizedArgument &&
                        !left.extra.parenthesized) {
                        this.raise(left./*<@69>*/argument.start, "Illegal expression. Wrap left hand side or entire exponentiation in parentheses.");
                    }
                    const /*<@44>*/op = this.state.type;
                    this.next();
                    const /*<@5>*/startPos = this.state.start;
                    const /*<@35>*/startLoc = this.state.startLoc;
                    node.right = this.parseExprOp(this.parseMaybeUnary(), startPos, startLoc, op.rightAssociative ? prec - 1 : prec, noIn);
                    this.finishNode(node, (op === this.tt.logicalOR || op === this.tt.logicalAND) ? "LogicalExpression" : "BinaryExpression");
                    return this.parseExprOp(node, leftStartPos, leftStartLoc, minPrec, noIn);
                }
            }
            return left;
        }
        ;
        /*<@102>*/addExtra(/*<@69>*/node, /*<@3>*/key, /*<@104>*/val) {
            if (!node)
                return;
            const /*<@6>*/extra = node.extra = node.extra || {};
            extra[key] = /*<@103>*/val;
        }
        ;
        /*<@105>*/unexpected(/*<@22>*/pos, /*<@128>*/messageOrType) {
            if (messageOrType && typeof messageOrType === "object" && messageOrType.label) {
                messageOrType = `Unexpected token, expected ${messageOrType.label}`;
            }
            this.raise(pos != null ? pos : this.state.start, /*<@3>*/messageOrType);
        }
        // Parse unary operators, both prefix and postfix.
        /*<@107>*/parseMaybeUnary(/*<@92>*/refShorthandDefaultPos) {
            if (this.state.type.prefix) {
                const /*<@69>*/node = this.startNode();
                const /*<@2>*/update = this.match(this.tt.incDec);
                node.operator = this.state./*<@103>*/value;
                node.prefix = true;
                this.next();
                const /*<@44>*/argType = this.state.type;
                node.argument = this.parseMaybeUnary();
                this.addExtra(node, "parenthesizedArgument", argType === this.tt.parenL && (!node.argument.extra || !node.argument.extra.parenthesized));
                if (refShorthandDefaultPos && refShorthandDefaultPos.start) {
                    this.unexpected(refShorthandDefaultPos.start);
                }
                if (update) {
                    this.checkLVal(node.argument, undefined, undefined, "prefix operation");
                }
                else if (this.state.strict && node.operator === "delete" && node.argument.type === "Identifier") {
                    this.raise(node.start, "Deleting local variable in strict mode");
                }
                return this.finishNode(node, update ? "UpdateExpression" : "UnaryExpression");
            }
            const /*<@5>*/startPos = this.state.start;
            const /*<@35>*/startLoc = this.state.startLoc;
            let /*<@69>*/expr = this.parseExprSubscripts(refShorthandDefaultPos);
            if (refShorthandDefaultPos && refShorthandDefaultPos.start)
                return expr;
            while (this.state.type.postfix && !this.canInsertSemicolon()) {
                const /*<@69>*/node = this.startNodeAt(startPos, startLoc);
                node.operator = this.state./*<@103>*/value;
                node.prefix = false;
                node.argument = expr;
                this.checkLVal(expr, undefined, undefined, "postfix operation");
                this.next();
                expr = this.finishNode(node, "UpdateExpression");
            }
            return expr;
        }
        ;
        // Parse call, dot, and `[]`-subscript expressions.
        /*<@108>*/parseExprSubscripts(/*<@92>*/refShorthandDefaultPos) {
            const /*<@5>*/startPos = this.state.start;
            const /*<@35>*/startLoc = this.state.startLoc;
            const /*<@5>*/potentialArrowAt = this.state.potentialArrowAt;
            const /*<@69>*/expr = this.parseExprAtom(refShorthandDefaultPos);
            if (expr.type === "ArrowFunctionExpression" && expr.start === potentialArrowAt) {
                return expr;
            }
            if (refShorthandDefaultPos && refShorthandDefaultPos.start) {
                return expr;
            }
            return this.parseSubscripts(expr, startPos, startLoc);
        }
        ;
        /*<@110>*/parseSubscripts(/*<@111>*/base, /*<@5>*/startPos, /*<@35>*/startLoc, /*<@60>*/noCalls) {
            for (;;) {
                if (!noCalls && this.eat(this.tt.doubleColon)) {
                    const /*<@69>*/node = this.startNodeAt(startPos, startLoc);
                    node.object = /*<@69>*/base;
                    node.callee = this.parseNoCallExpr();
                    return this.parseSubscripts(this.finishNode(node, "BindExpression"), startPos, startLoc, noCalls);
                }
                else if (this.eat(this.tt.dot)) {
                    const /*<@69>*/node = this.startNodeAt(startPos, startLoc);
                    node.object = /*<@69>*/base;
                    node.property = this.parseIdentifier(true);
                    node.computed = false;
                    base = this.finishNode(node, "MemberExpression");
                }
                else if (this.eat(this.tt.bracketL)) {
                    const /*<@69>*/node = this.startNodeAt(startPos, startLoc);
                    node.object = /*<@69>*/base;
                    node.property = this.parseExpression();
                    node.computed = true;
                    this.expect(this.tt.bracketR);
                    base = this.finishNode(node, "MemberExpression");
                }
                else if (!noCalls && this.match(this.tt.parenL)) {
                    const /*<@2>*/possibleAsync = this.state.potentialArrowAt === /*<@69>*/base.start && /*<@69>*/base.type === "Identifier" && /*<@69>*/base.name === "async" && !this.canInsertSemicolon();
                    this.next();
                    const /*<@69>*/node = this.startNodeAt(startPos, startLoc);
                    node.callee = /*<@69>*/base;
                    node.arguments = this.parseCallExpressionArguments(this.tt.parenR, possibleAsync);
                    if (node.callee.type === "Import" && node.arguments.length !== 1) {
                        this.raise(node.start, "import() requires exactly one argument");
                    }
                    base = this.finishNode(node, "CallExpression");
                    if (possibleAsync && this.shouldParseAsyncArrow()) {
                        return this.parseAsyncArrowFromCallExpression(this.startNodeAt(startPos, startLoc), node);
                    }
                    else {
                        this.toReferencedList(node.arguments);
                    }
                }
                else if (this.match(this.tt.backQuote)) {
                    const /*<@69>*/node = this.startNodeAt(startPos, startLoc);
                    node.tag = /*<@69>*/base;
                    node.quasi = this.parseTemplate(true);
                    base = this.finishNode(node, "TaggedTemplateExpression");
                }
                else {
                    return /*<@69>*/base;
                }
            }
        }
        ;
        /*<@112>*/parseCallExpressionArguments(/*<@44>*/close, /*<@2>*/possibleAsyncArrow) {
            const /*<@361>*/elts = /*<@361>*/[];
            let /*<@22>*/innerParenStart = void 0;
            let /*<@2>*/first = true;
            while (!this.eat(close)) {
                if (first) {
                    first = false;
                }
                else {
                    this.expect(this.tt.comma);
                    if (this.eat(close))
                        break;
                }
                // we need to make sure that if this is an async arrow functions, that we don't allow inner parens inside the params
                if (this.match(this.tt.parenL) && !innerParenStart) {
                    innerParenStart = this.state.start;
                }
                elts.push(this.parseExprListItem(false, possibleAsyncArrow ? /*<@89>*/{ start: 0 } : undefined, possibleAsyncArrow ? /*<@89>*/{ start: 0 } : undefined));
            }
            // we found an async arrow function so let's not allow any inner parens
            if (possibleAsyncArrow && innerParenStart && this.shouldParseAsyncArrow()) {
                this.unexpected();
            }
            return elts;
        }
        ;
        /*<@114>*/shouldParseAsyncArrow() {
            return this.match(this.tt.arrow);
        }
        ;
        /*<@115>*/parseAsyncArrowFromCallExpression(/*<@69>*/node, /*<@69>*/call) {
            this.expect(this.tt.arrow);
            return this.parseArrowExpression(node, call.arguments, true);
        }
        ;
        // Parse a no-call expression (like argument of `new` or `::` operators).
        /*<@116>*/parseNoCallExpr() {
            const /*<@5>*/startPos = this.state.start;
            const /*<@35>*/startLoc = this.state.startLoc;
            return this.parseSubscripts(this.parseExprAtom(), startPos, startLoc, true);
        }
        ;
        /*<@117>*/toAssignable(/*<@111>*/node, /*<@60>*/isBinding, /*<@26>*/contextDescription) {
            if (node) {
                switch (node.type) {
                    case "Identifier":
                    case "ObjectPattern":
                    case "ArrayPattern":
                    case "AssignmentPattern":
                        break;
                    case "ObjectExpression":
                        node.type = "ObjectPattern";
                        for (const /*<@69>*/prop of (node.properties)) {
                            if (prop.type === "ObjectMethod") {
                                if (prop.kind === "get" || prop.kind === "set") {
                                    this.raise(prop.key.start, "Object pattern can't contain getter or setter");
                                }
                                else {
                                    this.raise(prop.key.start, "Object pattern can't contain methods");
                                }
                            }
                            else {
                                this.toAssignable(prop, isBinding, "object destructuring pattern");
                            }
                        }
                        break;
                    case "ObjectProperty":
                        this.toAssignable(node./*<@69>*/value, isBinding, contextDescription);
                        break;
                    case "SpreadElement":
                        node.type = "RestElement";
                        break;
                    case "ArrayExpression":
                        node.type = "ArrayPattern";
                        this.toAssignableList(node.elements, isBinding, contextDescription);
                        break;
                    case "AssignmentExpression":
                        if (node.operator === "=") {
                            node.type = "AssignmentPattern";
                            delete node.operator;
                        }
                        else {
                            this.raise(node./*<@69>*/left.end, "Only '=' operator can be used for specifying default value.");
                        }
                        break;
                    case "MemberExpression":
                        if (!isBinding)
                            break;
                    default: {
                        const /*<@3>*/message = "Invalid left-hand side" +
                            (contextDescription ? " in " + contextDescription : /* istanbul ignore next */ "expression");
                        this.raise(node.start, message);
                    }
                }
            }
            return node;
        }
        ;
        // Convert list of expression atoms to binding list.
        /*<@118>*/toAssignableList(/*<@119>*/exprList, /*<@60>*/isBinding, /*<@26>*/contextDescription) {
            let /*<@1>*/end = exprList.length;
            if (end) {
                const /*<@69>*/last = exprList[end - 1];
                if (last && last.type === "RestElement") {
                    --end;
                }
                else if (last && last.type === "SpreadElement") {
                    last.type = "RestElement";
                    const /*<@69>*/arg = last./*<@69>*/argument;
                    this.toAssignable(arg, isBinding, contextDescription);
                    if (arg.type !== "Identifier" && arg.type !== "MemberExpression" && arg.type !== "ArrayPattern") {
                        this.unexpected(arg.start);
                    }
                    --end;
                }
            }
            for (let /*<@5>*/i = 0; i < end; i++) {
                const /*<@69>*/elt = exprList[i];
                if (elt && elt.type === "SpreadElement")
                    this.raise(elt.start, "The rest element has to be the last element when destructuring");
                if (elt)
                    this.toAssignable(elt, isBinding, contextDescription);
            }
            return exprList;
        }
        ;
        // Convert list of expression atoms to a list of
        /*<@120>*/toReferencedList(/*<@119>*/exprList) {
            return exprList;
        }
        ;
        // Parses spread element.
        /*<@121>*/parseSpread(/*<@92>*/refShorthandDefaultPos) {
            const /*<@69>*/node = this.startNode();
            this.next();
            node.argument = this.parseMaybeAssign(false, refShorthandDefaultPos);
            return this.finishNode(node, "SpreadElement");
        }
        ;
        /*<@122>*/parseRest() {
            const /*<@69>*/node = this.startNode();
            this.next();
            node.argument = this.parseBindingIdentifier();
            return this.finishNode(node, "RestElement");
        }
        ;
        /*<@123>*/parseBindingAtom() {
            switch (this.state.type) {
                case this.tt._yield:
                    if (this.state.strict || this.state.inGenerator)
                        this.unexpected();
                // fall-through
                case this.tt.name:
                    return this.parseIdentifier(true);
                case this.tt.bracketL:
                    const /*<@69>*/node = this.startNode();
                    this.next();
                    node.elements = this.parseBindingList(this.tt.bracketR, true);
                    return this.finishNode(node, "ArrayPattern");
                case this.tt.braceL:
                    return this.parseObj(true);
                default:
                    this.unexpected();
            }
        }
        ;
        /*<@124>*/parseBindingList(/*<@44>*/close, /*<@60>*/allowEmpty) {
            const /*<@361>*/elts = /*<@361>*/[];
            let /*<@2>*/first = true;
            while (!this.eat(close)) {
                if (first) {
                    first = false;
                }
                else {
                    this.expect(this.tt.comma);
                }
                if (allowEmpty && this.match(this.tt.comma)) {
                    elts.push(null);
                }
                else if (this.eat(close)) {
                    break;
                }
                else if (this.match(this.tt.ellipsis)) {
                    elts.push(this.parseAssignableListItemTypes(this.parseRest()));
                    this.expect(close);
                    break;
                }
                else {
                    const /*<@361>*/decorators = /*<@361>*/[];
                    while (this.match(this.tt.at)) {
                        decorators.push(this.parseDecorator());
                    }
                    const /*<@69>*/left = this.parseMaybeDefault();
                    if (decorators.length) {
                        left.decorators = decorators;
                    }
                    this.parseAssignableListItemTypes(left);
                    elts.push(this.parseMaybeDefault(left.start, left.loc.start, left));
                }
            }
            return elts;
        }
        ;
        /*<@125>*/parseAssignableListItemTypes(/*<@69>*/param) {
            return param;
        }
        // Parses assignment pattern around given atom if possible.
        /*<@126>*/parseMaybeDefault(/*<@22>*/startPos, /*<@35>*/startLoc, /*<@69>*/left) {
            startLoc = startLoc || this.state.startLoc;
            startPos = startPos || this.state.start;
            left = left || this.parseBindingAtom();
            if (!this.eat(this.tt.eq))
                return left;
            const /*<@69>*/node = this.startNodeAt(startPos, startLoc);
            node.left = /*<@69>*/left;
            node.right = this.parseMaybeAssign();
            return this.finishNode(node, "AssignmentPattern");
        }
        /*<@127>*/raise(/*<@22>*/pos, /*<@128>*/message) {
            const /*<@35>*/loc = utilLocationJS.getLineInfo(this.input, pos);
            message += ` (${loc.line}:${loc.column})`;
            const /*<@370>*/err = new SyntaxError(/*<@3>*/message);
            /*
            err.pos = pos;
            err.loc = loc;
            */
            throw err;
        }
        ;
        // Parse an atomic expression — either a single token that is an
        // expression, an expression started by a keyword like `function` or
        // `new`, or an expression wrapped in punctuation like `()`, `[]`,
        // or `{}`.
        /*<@129>*/shouldAllowYieldIdentifier() {
            return this.match(this.tt._yield) && !this.state.strict && !this.state.inGenerator;
        }
        /*<@130>*/parseBindingIdentifier() {
            return this.parseIdentifier(this.shouldAllowYieldIdentifier());
        }
        ;
        /*<@131>*/parseFunction(/*<@69>*/node, /*<@2>*/isStatement, /*<@60>*/allowExpressionBody, /*<@60>*/isAsync, /*<@60>*/optionalId) {
            const /*<@68>*/oldInMethod = this.state.inMethod;
            this.state.inMethod = false;
            this.initFunction(node, /*<@2>*/isAsync);
            if (this.match(this.tt.star)) {
                if (node.async && !this.hasPlugin("asyncGenerators")) {
                    this.unexpected();
                }
                else {
                    node.generator = true;
                    this.next();
                }
            }
            if (isStatement && !optionalId && !this.match(this.tt.name) && !this.match(this.tt._yield)) {
                this.unexpected();
            }
            if (this.match(this.tt.name) || this.match(this.tt._yield)) {
                node.id = this.parseBindingIdentifier();
            }
            this.parseFunctionParams(node);
            this.parseFunctionBody(node, allowExpressionBody);
            this.state.inMethod = oldInMethod;
            return this.finishNode(node, isStatement ? "FunctionDeclaration" : "FunctionExpression");
        }
        ;
        /*<@132>*/parseExprAtom(/*<@92>*/refShorthandDefaultPos) {
            const /*<@2>*/canBeArrow = this.state.potentialArrowAt === this.state.start;
            let /*<@111>*/node = void 0;
            switch (this.state.type) {
                case this.tt._super:
                    if (!this.state.inMethod && !this.options.allowSuperOutsideMethod) {
                        this.raise(this.state.start, "'super' outside of function or class");
                    }
                    node = this.startNode();
                    this.next();
                    if (!this.match(this.tt.parenL) && !this.match(this.tt.bracketL) && !this.match(this.tt.dot)) {
                        this.unexpected();
                    }
                    if (this.match(this.tt.parenL) && this.state.inMethod !== "constructor" && !this.options.allowSuperOutsideMethod) {
                        this.raise(node.start, "super() is only valid inside a class constructor. Make sure the method name is spelled exactly as 'constructor'.");
                    }
                    return this.finishNode(node, "Super");
                case this.tt._import:
                    if (!this.hasPlugin("dynamicImport"))
                        this.unexpected();
                    node = this.startNode();
                    this.next();
                    if (!this.match(this.tt.parenL)) {
                        this.unexpected(null, this.tt.parenL);
                    }
                    return this.finishNode(node, "Import");
                case this.tt._this:
                    node = this.startNode();
                    this.next();
                    return this.finishNode(node, "ThisExpression");
                case this.tt._yield:
                    if (this.state.inGenerator)
                        this.unexpected();
                case this.tt.name:
                    node = this.startNode();
                    const /*<@2>*/allowAwait = this.state.value === "await" && this.state.inAsync;
                    const /*<@2>*/allowYield = this.shouldAllowYieldIdentifier();
                    const /*<@69>*/id = this.parseIdentifier(allowAwait || allowYield);
                    if (id.name === "await") {
                        if (this.state.inAsync || this.inModule) {
                            return this.parseAwait(node);
                        }
                    }
                    else if (id.name === "async" && this.match(this.tt._function) && !this.canInsertSemicolon()) {
                        this.next();
                        return this.parseFunction(node, false, false, true);
                    }
                    else if (canBeArrow && id.name === "async" && this.match(this.tt.name)) {
                        const /*<@119>*/params = /*<@119>*/[this.parseIdentifier()];
                        this.expect(this.tt.arrow);
                        // let foo = bar => {};
                        return this.parseArrowExpression(node, params, true);
                    }
                    if (canBeArrow && !this.canInsertSemicolon() && this.eat(this.tt.arrow)) {
                        return this.parseArrowExpression(node, /*<@119>*/[id]);
                    }
                    return id;
                case this.tt._do:
                    if (this.hasPlugin("doExpressions")) {
                        const /*<@69>*/node = this.startNode();
                        this.next();
                        const /*<@2>*/oldInFunction = this.state.inFunction;
                        const /*<@119>*/oldLabels = this.state.labels;
                        this.state.labels = /*<@361>*/[];
                        this.state.inFunction = false;
                        node.body = this.parseBlock(false, true);
                        this.state.inFunction = oldInFunction;
                        this.state.labels = oldLabels;
                        return this.finishNode(node, "DoExpression");
                    }
                case this.tt.regexp:
                    const /*<@69>*/value = (this.state./*<@69>*/value);
                    node = this.parseLiteral((value.value), "RegExpLiteral");
                    node.pattern = value.pattern;
                    node.flags = value.flags;
                    return node;
                case this.tt.num:
                    return this.parseLiteral(this.state.value, "NumericLiteral");
                case this.tt.string:
                    return this.parseLiteral(this.state.value, "StringLiteral");
                case this.tt._null:
                    node = this.startNode();
                    this.next();
                    return this.finishNode(node, "NullLiteral");
                case this.tt._true:
                case this.tt._false:
                    node = this.startNode();
                    node.value = this.match(this.tt._true);
                    this.next();
                    return this.finishNode(node, "BooleanLiteral");
                case this.tt.parenL:
                    return this.parseParenAndDistinguishExpression(null, null, canBeArrow);
                case this.tt.bracketL:
                    node = this.startNode();
                    this.next();
                    node.elements = this.parseExprList(this.tt.bracketR, true, refShorthandDefaultPos);
                    this.toReferencedList(node.elements);
                    return this.finishNode(node, "ArrayExpression");
                case this.tt.braceL:
                    return this.parseObj(false, refShorthandDefaultPos);
                case this.tt._function:
                    return this.parseFunctionExpression();
                case this.tt.at:
                    this.parseDecorators();
                case this.tt._class:
                    node = this.startNode();
                    this.takeDecorators(node);
                    return this.parseClass(node, false);
                case this.tt._new:
                    return this.parseNew();
                case this.tt.backQuote:
                    return this.parseTemplate(false);
                case this.tt.doubleColon:
                    node = this.startNode();
                    this.next();
                    node.object = null;
                    const /*<@69>*/callee = node.callee = this.parseNoCallExpr();
                    if (callee.type === "MemberExpression") {
                        return this.finishNode(node, "BindExpression");
                    }
                    else {
                        this.raise(callee.start, "Binding should be performed on object property.");
                    }
                default:
                    this.unexpected();
            }
        }
        /*<@133>*/parseFunctionExpression() {
            const /*<@69>*/node = this.startNode();
            const /*<@69>*/meta = this.parseIdentifier(true);
            if (this.state.inGenerator && this.eat(this.tt.dot) && this.hasPlugin("functionSent")) {
                return this.parseMetaProperty(node, meta, "sent");
            }
            else {
                return this.parseFunction(node, false);
            }
        }
        ;
        /*<@134>*/parseMetaProperty(/*<@69>*/node, /*<@69>*/meta, /*<@3>*/propertyName) {
            node.meta = meta;
            node.property = this.parseIdentifier(true);
            if (node.property.name !== propertyName) {
                this.raise(node.property.start, `The only valid meta property for new is ${meta.name}.${propertyName}`);
            }
            return this.finishNode(node, "MetaProperty");
        }
        ;
        /*<@135>*/parseLiteral(/*<@92>*/value, /*<@3>*/type, /*<@22>*/startPos, /*<@35>*/startLoc) {
            startPos = startPos || this.state.start;
            startLoc = startLoc || this.state.startLoc;
            const /*<@69>*/node = this.startNodeAt(startPos, startLoc);
            this.addExtra(node, "rawValue", value);
            this.addExtra(node, "raw", (this.input.slice(startPos, this.state.end)));
            node.value = value;
            this.next();
            return this.finishNode(node, type);
        }
        ;
        /*<@136>*/parseParenExpression() {
            this.expect(this.tt.parenL);
            const /*<@69>*/val = this.parseExpression();
            this.expect(this.tt.parenR);
            return val;
        }
        ;
        /*<@137>*/parseParenAndDistinguishExpression(/*<@22>*/startPos, /*<@39>*/startLoc, /*<@2>*/canBeArrow) {
            startPos = startPos || this.state.start;
            startLoc = startLoc || this.state.startLoc;
            let /*<@69>*/val;
            this.expect(this.tt.parenL);
            const /*<@5>*/innerStartPos = this.state.start;
            const /*<@35>*/innerStartLoc = this.state.startLoc;
            const /*<@119>*/exprList = /*<@119>*/[];
            const /*<@89>*/refShorthandDefaultPos = /*<@89>*/{ start: 0 };
            const /*<@89>*/refNeedsArrowPos = /*<@89>*/{ start: 0 };
            let /*<@2>*/first = true;
            let /*<@22>*/spreadStart = void 0;
            let /*<@22>*/optionalCommaStart = void 0;
            while (!this.match(this.tt.parenR)) {
                if (first) {
                    first = false;
                }
                else {
                    this.expect(this.tt.comma, refNeedsArrowPos.start || null);
                    if (this.match(this.tt.parenR)) {
                        optionalCommaStart = this.state.start;
                        break;
                    }
                }
                if (this.match(this.tt.ellipsis)) {
                    const /*<@5>*/spreadNodeStartPos = this.state.start;
                    const /*<@35>*/spreadNodeStartLoc = this.state.startLoc;
                    spreadStart = this.state.start;
                    exprList.push(this.parseParenItem(this.parseRest(), spreadNodeStartPos, spreadNodeStartLoc));
                    break;
                }
                else {
                    exprList.push(this.parseMaybeAssign(false, refShorthandDefaultPos, this.parseParenItem, refNeedsArrowPos));
                }
            }
            const /*<@5>*/innerEndPos = this.state.start;
            const /*<@35>*/innerEndLoc = this.state.startLoc;
            this.expect(this.tt.parenR);
            let /*<@111>*/arrowNode = this.startNodeAt(startPos, startLoc);
            if (canBeArrow && this.shouldParseArrow() && (arrowNode = this.parseArrow(arrowNode))) {
                for (const /*<@69>*/param of exprList) {
                    if (param.extra && param.extra.parenthesized)
                        this.unexpected((param.extra./*<@5>*/parenStart));
                }
                return this.parseArrowExpression(arrowNode, exprList);
            }
            if (!exprList.length) {
                this.unexpected(this.state.lastTokStart);
            }
            if (optionalCommaStart)
                this.unexpected(optionalCommaStart);
            if (spreadStart)
                this.unexpected(spreadStart);
            if (refShorthandDefaultPos.start)
                this.unexpected(refShorthandDefaultPos.start);
            if (refNeedsArrowPos.start)
                this.unexpected(refNeedsArrowPos.start);
            if (exprList.length > 1) {
                val = this.startNodeAt(innerStartPos, innerStartLoc);
                val.expressions = exprList;
                this.toReferencedList(val.expressions);
                this.finishNodeAt(val, "SequenceExpression", innerEndPos, innerEndLoc);
            }
            else {
                val = exprList[0];
            }
            this.addExtra(val, "parenthesized", true);
            this.addExtra(val, "parenStart", startPos);
            return val;
        }
        ;
        /*<@138>*/shouldParseArrow() {
            return !this.canInsertSemicolon();
        }
        ;
        /*<@139>*/parseArrow(/*<@69>*/node) {
            if (this.eat(this.tt.arrow)) {
                return node;
            }
        }
        ;
        /*<@140>*/parseParenItem(/*<@69>*/node, /*<@22>*/p2, /*<@35>*/p3) {
            return node;
        }
        ;
        // New's precedence is slightly tricky. It must allow its argument
        // to be a `[]` or dot subscript expression, but not a call — at
        // least, not without wrang it in parentheses. Thus, it uses the
        /*<@141>*/parseNew() {
            const /*<@69>*/node = this.startNode();
            const /*<@69>*/meta = this.parseIdentifier(true);
            if (this.eat(this.tt.dot)) {
                const /*<@69>*/metaProp = this.parseMetaProperty(node, meta, "target");
                if (!this.state.inFunction) {
                    this.raise(metaProp.property.start, "new.target can only be used in functions");
                }
                return metaProp;
            }
            node.callee = this.parseNoCallExpr();
            if (this.eat(this.tt.parenL)) {
                node.arguments = this.parseExprList(this.tt.parenR);
                this.toReferencedList(node.arguments);
            }
            else {
                node.arguments = /*<@361>*/[];
            }
            return this.finishNode(node, "NewExpression");
        }
        ;
        // Parse template expression.
        /*<@142>*/parseTemplateElement(/*<@2>*/isTagged) {
            const /*<@69>*/elem = this.startNode();
            if (this.state.value === null) {
                if (!isTagged) {
                    this.raise(this.state.invalidTemplateEscapePosition, "Invalid escape sequence in template");
                }
                else {
                    this.state.invalidTemplateEscapePosition = null;
                }
            }
            elem.value = /*<@371>*/{
                raw: this.input.slice(this.state.start, this.state.end).replace(/\r\n?/g, "\n"),
                cooked: this.state.value
            };
            this.next();
            elem.tail = this.match(this.tt.backQuote);
            return this.finishNode(elem, "TemplateElement");
        }
        ;
        /*<@143>*/parseTemplate(/*<@2>*/isTagged) {
            const /*<@69>*/node = this.startNode();
            this.next();
            node.expressions = /*<@361>*/[];
            let /*<@69>*/curElt = this.parseTemplateElement(isTagged);
            node.quasis = /*<@119>*/[curElt];
            while (!curElt.tail) {
                this.expect(this.tt.dollarBraceL);
                node.expressions.push(this.parseExpression());
                this.expect(this.tt.braceR);
                node.quasis.push(curElt = this.parseTemplateElement(isTagged));
            }
            this.next();
            return this.finishNode(node, "TemplateLiteral");
        }
        ;
        // Parse an object literal or binding pathis.tt.rn.
        /*<@144>*/parseObj(/*<@2>*/isPattern, /*<@92>*/refShorthandDefaultPos) {
            let /*<@361>*/decorators = /*<@361>*/[];
            const /*<@6>*/propHash = Object.create(null);
            let /*<@2>*/first = true;
            const /*<@69>*/node = this.startNode();
            node.properties = /*<@361>*/[];
            this.next();
            let /*<@22>*/firstRestLocation = null;
            while (!this.eat(this.tt.braceR)) {
                if (first) {
                    first = false;
                }
                else {
                    this.expect(this.tt.comma);
                    if (this.eat(this.tt.braceR))
                        break;
                }
                while (this.match(this.tt.at)) {
                    decorators.push(this.parseDecorator());
                }
                let /*<@69>*/prop = this.startNode(), /*<@2>*/isGenerator = false, /*<@2>*/isAsync = false, /*<@22>*/startPos = void 0, /*<@39>*/startLoc = void 0;
                if (decorators.length) {
                    prop.decorators = decorators;
                    decorators = /*<@361>*/[];
                }
                if (this.hasPlugin("objectRestSpread") && this.match(this.tt.ellipsis)) {
                    prop = this.parseSpread(isPattern ? /*<@89>*/{ start: 0 } : undefined);
                    prop.type = isPattern ? "RestElement" : "SpreadElement";
                    if (isPattern)
                        this.toAssignable(prop.argument, true, "object pathis.tt.rn");
                    node.properties.push(prop);
                    if (isPattern) {
                        const /*<@5>*/position = this.state.start;
                        if (firstRestLocation !== null) {
                            this.unexpected(firstRestLocation, "Cannot have multiple rest elements when destructuring");
                        }
                        else if (this.eat(this.tt.braceR)) {
                            break;
                        }
                        else if (this.match(this.tt.comma) && this.lookahead().type === this.tt.braceR) {
                            this.unexpected(position, "A trailing comma is not permithis.tt.d after the rest element");
                        }
                        else {
                            firstRestLocation = position;
                            continue;
                        }
                    }
                    else {
                        continue;
                    }
                }
                prop.method = false;
                prop.shorthand = false;
                if (isPattern || refShorthandDefaultPos) {
                    startPos = this.state.start;
                    startLoc = this.state.startLoc;
                }
                if (!isPattern) {
                    isGenerator = this.eat(this.tt.star);
                }
                if (!isPattern && this.isContextual("async")) {
                    if (isGenerator)
                        this.unexpected();
                    const /*<@69>*/asyncId = this.parseIdentifier();
                    if (this.match(this.tt.colon) || this.match(this.tt.parenL) || this.match(this.tt.braceR) || this.match(this.tt.eq) || this.match(this.tt.comma)) {
                        prop.key = asyncId;
                        prop.computed = false;
                    }
                    else {
                        isAsync = true;
                        if (this.hasPlugin("asyncGenerators"))
                            isGenerator = this.eat(this.tt.star);
                        this.parsePropertyName(prop);
                    }
                }
                else {
                    this.parsePropertyName(prop);
                }
                this.parseObjPropValue(prop, startPos, startLoc, isGenerator, isAsync, isPattern, refShorthandDefaultPos);
                this.checkPropClash(prop, propHash);
                if (prop.shorthand) {
                    this.addExtra(prop, "shorthand", true);
                }
                node.properties.push(prop);
            }
            if (firstRestLocation !== null) {
                this.unexpected(firstRestLocation, "The rest element has to be the last element when destructuring");
            }
            if (decorators.length) {
                this.raise(this.state.start, "You have trailing decorators with no property");
            }
            return this.finishNode(node, isPattern ? "ObjectPathis.tt.rn" : "ObjectExpression");
        }
        ;
        /*<@145>*/isGetterOrSetterMethod(/*<@69>*/prop, /*<@60>*/isPattern) {
            return !isPattern &&
                !prop.computed &&
                prop.key.type === "Identifier" &&
                (prop.key.name === "get" || prop.key.name === "set") &&
                (this.match(this.tt.string) || // get "string"() {}
                    this.match(this.tt.num) || // get 1() {}
                    this.match(this.tt.bracketL) || // get ["string"]() {}
                    this.match(this.tt.name) || // get foo() {}
                    this.state.type.keyword // get debugger() {}
                );
        }
        ;
        // get methods aren't allowed to have any parameters
        // set methods must have exactly 1 parameter
        /*<@147>*/checkGetterSetterParamCount(/*<@69>*/method) {
            const /*<@5>*/paramCount = method.kind === "get" ? 0 : 1;
            if (method.params.length !== paramCount) {
                const /*<@22>*/start = method.start;
                if (method.kind === "get") {
                    this.raise(start, "gethis.tt.r should have no params");
                }
                else {
                    this.raise(start, "sethis.tt.r should have exactly one param");
                }
            }
        }
        ;
        /*<@148>*/parseObjectMethod(/*<@69>*/prop, /*<@2>*/isGenerator, /*<@60>*/isAsync, /*<@60>*/isPattern) {
            if (isAsync || isGenerator || this.match(this.tt.parenL)) {
                if (isPattern)
                    this.unexpected();
                prop.kind = "method";
                prop.method = true;
                this.parseMethod(prop, isGenerator, isAsync);
                return this.finishNode(prop, "ObjectMethod");
            }
            if (this.isGetterOrSetterMethod(prop, isPattern)) {
                if (isGenerator || isAsync)
                    this.unexpected();
                prop.kind = prop.key./*<@3>*/name;
                this.parsePropertyName(prop);
                this.parseMethod(prop);
                this.checkGetterSetterParamCount(prop);
                return this.finishNode(prop, "ObjectMethod");
            }
        }
        ;
        /*<@149>*/parseObjectProperty(/*<@69>*/prop, /*<@22>*/startPos, /*<@39>*/startLoc, /*<@60>*/isPattern, /*<@92>*/refShorthandDefaultPos) {
            if (this.eat(this.tt.colon)) {
                prop.value = (isPattern ? this.parseMaybeDefault(this.state.start, this.state.startLoc) : this.parseMaybeAssign(false, refShorthandDefaultPos));
                return this.finishNode(prop, "ObjectProperty");
            }
            if (!prop.computed && prop.key.type === "Identifier") {
                if (isPattern) {
                    this.checkReservedWord(prop.key./*<@3>*/name, prop.key.start, true, true);
                    prop.value = this.parseMaybeDefault(startPos, startLoc, prop.key.__clone());
                }
                else if (this.match(this.tt.eq) && refShorthandDefaultPos) {
                    if (!refShorthandDefaultPos.start) {
                        refShorthandDefaultPos.start = this.state.start;
                    }
                    prop.value = (this.parseMaybeDefault(startPos, startLoc, prop.key.__clone()));
                }
                else {
                    prop.value = prop.key.__clone();
                }
                prop.shorthand = true;
                return this.finishNode(prop, "ObjectProperty");
            }
        }
        ;
        /*<@150>*/parseObjPropValue(/*<@69>*/prop, /*<@22>*/startPos, /*<@39>*/startLoc, /*<@2>*/isGenerator, /*<@60>*/isAsync, /*<@60>*/isPattern, /*<@92>*/refShorthandDefaultPos) {
            const /*<@111>*/node = this.parseObjectMethod(prop, isGenerator, isAsync, isPattern) ||
                this.parseObjectProperty(prop, startPos, startLoc, isPattern, refShorthandDefaultPos);
            if (!node)
                this.unexpected();
            return node;
        }
        ;
        /*<@151>*/parsePropertyName(/*<@69>*/prop) {
            if (this.eat(this.tt.bracketL)) {
                prop.computed = true;
                prop.key = this.parseMaybeAssign();
                this.expect(this.tt.bracketR);
            }
            else {
                prop.computed = false;
                const /*<@2>*/oldInPropertyName = this.state.inPropertyName;
                this.state.inPropertyName = true;
                prop.key = (this.match(this.tt.num) || this.match(this.tt.string)) ? this.parseExprAtom() : this.parseIdentifier(true);
                this.state.inPropertyName = oldInPropertyName;
            }
            return prop.key;
        }
        ;
        // Initialize empty function node.
        /*<@152>*/initFunction(/*<@69>*/node, /*<@60>*/isAsync) {
            node.id = null;
            node.generator = false;
            node.expression = false;
            node.async = !!isAsync;
        }
        ;
        // Parse object or class method.
        /*<@153>*/parseMethod(/*<@69>*/node, /*<@60>*/isGenerator, /*<@60>*/isAsync) {
            const /*<@68>*/oldInMethod = this.state.inMethod;
            this.state.inMethod = node.kind || true;
            this.initFunction(node, isAsync);
            this.expect(this.tt.parenL);
            node.params = this.parseBindingList(this.tt.parenR);
            node.generator = !!isGenerator;
            this.parseFunctionBody(node);
            this.state.inMethod = oldInMethod;
            return node;
        }
        ;
        // Parse arrow function expression with given parameters.
        /*<@154>*/parseArrowExpression(/*<@69>*/node, /*<@119>*/params, /*<@60>*/isAsync) {
            this.initFunction(node, isAsync);
            node.params = this.toAssignableList(params, true, "arrow function parameters");
            this.parseFunctionBody(node, true);
            return this.finishNode(node, "ArrowFunctionExpression");
        }
        ;
        /*<@155>*/isStrictBody(/*<@69>*/node, /*<@60>*/isExpression) {
            if (!isExpression && node./*<@69>*/body.directives.length) {
                for (const /*<@69>*/directive of (node./*<@69>*/body.directives)) {
                    if (directive./*<@69>*/value.value === "use strict") {
                        return true;
                    }
                }
            }
            return false;
        }
        ;
        // Parse function body and check parameters.
        /*<@156>*/parseFunctionBody(/*<@69>*/node, /*<@60>*/allowExpression) {
            const /*<@60>*/isExpression = allowExpression && !this.match(this.tt.braceL);
            const /*<@2>*/oldInAsync = this.state.inAsync;
            this.state.inAsync = node./*<@2>*/async;
            if (isExpression) {
                node.body = this.parseMaybeAssign();
                node.expression = true;
            }
            else {
                // Start a new scope with regard to labels and the `inFunction`
                // flag (restore them to their old value afterwards).
                const /*<@2>*/oldInFunc = this.state.inFunction;
                const /*<@2>*/oldInGen = this.state.inGenerator;
                const /*<@119>*/oldLabels = this.state.labels;
                this.state.inFunction = true;
                this.state.inGenerator = node.generator;
                this.state.labels = /*<@361>*/[];
                node.body = this.parseBlock(true);
                node.expression = false;
                this.state.inFunction = oldInFunc;
                this.state.inGenerator = oldInGen;
                this.state.labels = oldLabels;
            }
            this.state.inAsync = oldInAsync;
            // If this is a strict mode function, verify that argument names
            // are not repeated, and it does not try to bind the words `eval`
            // or `arguments`.
            const /*<@2>*/isStrict = this.isStrictBody(node, isExpression);
            // Also check when allowExpression === true for arrow functions
            const /*<@2>*/checkLVal = this.state.strict || allowExpression || isStrict;
            if (isStrict && node.id && node.id.type === "Identifier" && node.id.name === "yield") {
                this.raise(node.id.start, "Binding yield in strict mode");
            }
            if (checkLVal) {
                const /*<@6>*/nameHash = Object.create(null);
                const /*<@2>*/oldStrict = this.state.strict;
                if (isStrict)
                    this.state.strict = true;
                if (node.id) {
                    this.checkLVal(node.id, true, undefined, "function name");
                }
                for (const /*<@69>*/param of (node.params)) {
                    if (isStrict && param.type !== "Identifier") {
                        this.raise(param.start, "Non-simple parameter in strict mode");
                    }
                    this.checkLVal(param, true, nameHash, "function parameter list");
                }
                this.state.strict = oldStrict;
            }
        }
        ;
        // Parses a comma-separated list of expressions, and returns them as
        // an array. `close` is the token type that ends the list, and
        // `allowEmpty` can be turned on to allow subsequent commas with
        // nothing in between them to be parsed as `null` (which is needed
        // for array literals).
        /*<@157>*/parseExprList(/*<@44>*/close, /*<@60>*/allowEmpty, /*<@92>*/refShorthandDefaultPos) {
            const /*<@361>*/elts = /*<@361>*/[];
            let /*<@2>*/first = true;
            while (!this.eat(close)) {
                if (first) {
                    first = false;
                }
                else {
                    this.expect(this.tt.comma);
                    if (this.eat(close))
                        break;
                }
                elts.push(this.parseExprListItem(allowEmpty, refShorthandDefaultPos));
            }
            return elts;
        }
        ;
        /*<@158>*/parseExprListItem(/*<@60>*/allowEmpty, /*<@92>*/refShorthandDefaultPos, /*<@92>*/refNeedsArrowPos) {
            let /*<@111>*/elt = void 0;
            if (allowEmpty && this.match(this.tt.comma)) {
                elt = null;
            }
            else if (this.match(this.tt.ellipsis)) {
                elt = this.parseSpread(/*<@89>*/refShorthandDefaultPos);
            }
            else {
                elt = this.parseMaybeAssign(false, refShorthandDefaultPos, this.parseParenItem, refNeedsArrowPos);
            }
            return elt;
        }
        ;
        // Parse the next token as an identifier. If `liberal` is true (used
        // when parsing properties), it will also convert keywords into
        // identifiers.
        /*<@159>*/parseIdentifier(/*<@60>*/liberal) {
            const /*<@69>*/node = this.startNode();
            if (!liberal) {
                this.checkReservedWord(this.state./*<@3>*/value, this.state.start, !!this.state.type.keyword, false);
            }
            if (this.match(this.tt.name)) {
                node.name = (this.state./*<@3>*/value);
            }
            else if (this.state.type.keyword) {
                node.name = this.state.type.keyword;
            }
            else {
                this.unexpected();
            }
            if (!liberal && node.name === "await" && this.state.inAsync) {
                this.raise(node.start, "invalid use of await inside of an async function");
            }
            node.loc.identifierName = node./*<@3>*/name;
            this.next();
            return this.finishNode(node, "Identifier");
        }
        ;
        /*<@160>*/checkReservedWord(/*<@3>*/word, /*<@22>*/startLoc, /*<@2>*/checkKeywords, /*<@2>*/isBinding) {
            if (this.isReservedWord(word) || (checkKeywords && this.isKeyword(word))) {
                this.raise(startLoc, word + " is a reserved word");
            }
            if (this.state.strict && (utilIdentifierJS.reservedWords.strict(word) || (isBinding && utilIdentifierJS.reservedWords.strictBind(word)))) {
                this.raise(startLoc, word + " is a reserved word in strict mode");
            }
        }
        ;
        // Parses await expression inside async function.
        /*<@161>*/parseAwait(/*<@69>*/node) {
            // istanbul ignore next: this condition is checked at the call site so won't be hit here
            if (!this.state.inAsync) {
                this.unexpected();
            }
            if (this.match(this.tt.star)) {
                this.raise(node.start, "await* has been removed from the async functions proposal. Use Promise.all() instead.");
            }
            node.argument = this.parseMaybeUnary();
            return this.finishNode(node, "AwaitExpression");
        }
        ;
        // Parses yield expression inside generator.
        /*<@162>*/parseYield() {
            const /*<@69>*/node = this.startNode();
            this.next();
            if (this.match(this.tt.semi) ||
                this.canInsertSemicolon() ||
                (!this.match(this.tt.star) && !this.state.type.startsExpr)) {
                node.delegate = false;
                node.argument = null;
            }
            else {
                node.delegate = this.eat(this.tt.star);
                node.argument = this.parseMaybeAssign();
            }
            return this.finishNode(node, "YieldExpression");
        }
        ;
        /*<@163>*/parseTopLevel(/*<@69>*/file, /*<@69>*/program) {
            program.sourceType = this.options.sourceType;
            this.parseBlockBody(program, true, true, this.tt.eof);
            file.program = this.finishNode(program, "Program");
            file.comments = this.state.comments;
            file.tokens = this.state.tokens;
            return this.finishNode(file, "File");
        }
        ;
        // TODO
        /*<@164>*/stmtToDirective(/*<@69>*/stmt) {
            const /*<@69>*/expr = (stmt./*<@69>*/expression);
            const /*<@69>*/directiveLiteral = this.startNodeAt(expr.start, expr.loc.start);
            const /*<@69>*/directive = this.startNodeAt(stmt.start, stmt.loc.start);
            const /*<@3>*/raw = this.input.slice(expr.start, expr.end);
            const /*<@3>*/val = directiveLiteral.value = raw.slice(1, -1); // remove quotes
            this.addExtra(directiveLiteral, "raw", raw);
            this.addExtra(directiveLiteral, "rawValue", val);
            directive.value = this.finishNodeAt(directiveLiteral, "DirectiveLiteral", expr.end, expr.loc.end);
            return this.finishNodeAt(directive, "Directive", stmt.end, stmt.loc.end);
        }
        ;
        // Parse a single statement.
        //
        // If expecting a statement and finding a slash operator, parse a
        // regular expression literal. This is to handle cases like
        // `if (foo) /blah/.exec(foo)`, where looking at the previous token
        // does not help.
        /*<@165>*/parseStatement(/*<@2>*/declaration, /*<@60>*/topLevel) {
            if (this.match(this.tt.at)) {
                this.parseDecorators(true);
            }
            const /*<@44>*/starttype = this.state.type;
            const /*<@69>*/node = this.startNode();
            // Most types of statements are recognized by the keyword they
            // start with. Many are trivial to parse, some require a bit of
            // complexity.
            switch (starttype) {
                case this.tt._break:
                case this.tt._continue: return this.parseBreakContinueStatement(node, starttype.keyword);
                case this.tt._debugger: return this.parseDebuggerStatement(node);
                case this.tt._do: return this.parseDoStatement(node);
                case this.tt._for: return this.parseForStatement(node);
                case this.tt._function:
                    if (!declaration)
                        this.unexpected();
                    return this.parseFunctionStatement(node);
                case this.tt._class:
                    if (!declaration)
                        this.unexpected();
                    return this.parseClass(node, true);
                case this.tt._if: return this.parseIfStatement(node);
                case this.tt._return: return this.parseReturnStatement(node);
                case this.tt._switch: return this.parseSwitchStatement(node);
                case this.tt._throw: return this.parseThrowStatement(node);
                case this.tt._try: return this.parseTryStatement(node);
                case this.tt._let:
                case this.tt._const:
                    if (!declaration)
                        this.unexpected(); // NOTE: falls through to _var
                case this.tt._var:
                    return this.parseVarStatement(node, starttype);
                case this.tt._while: return this.parseWhileStatement(node);
                case this.tt._with: return this.parseWithStatement(node);
                case this.tt.braceL: return this.parseBlock();
                case this.tt.semi: return this.parseEmptyStatement(node);
                case this.tt._export:
                case this.tt._import:
                    if (this.hasPlugin("dynamicImport") && this.lookahead().type === this.tt.parenL)
                        break;
                    if (!this.options.allowImportExportEverywhere) {
                        if (!topLevel) {
                            this.raise(this.state.start, "'import' and 'export' may only aar at the top level");
                        }
                        if (!this.inModule) {
                            this.raise(this.state.start, "'import' and 'export' may aar only with 'sourceType: module'");
                        }
                    }
                    return starttype === this.tt._import ? this.parseImport(node) : this.parseExport(node);
                case this.tt.name:
                    if (this.state.value === "async") {
                        // peek ahead and see if next token is a function
                        const /*<@65>*/state = this.state.clone();
                        this.next();
                        if (this.match(this.tt._function) && !this.canInsertSemicolon()) {
                            this.expect(this.tt._function);
                            return this.parseFunction(node, true, false, true);
                        }
                        else {
                            this.state = state;
                        }
                    }
            }
            // If the statement does not start with a statement keyword or a
            // brace, it's an ExpressionStatement or LabeledStatement. We
            // simply start parsing an expression, and afterwards, if the
            // next token is a colon and the expression was a simple
            // Identifier node, we switch to interpreting it as a label.
            const /*<@3>*/maybeName = (this.state./*<@3>*/value);
            const /*<@69>*/expr = this.parseExpression();
            if (starttype === this.tt.name && expr.type === "Identifier" && this.eat(this.tt.colon)) {
                return this.parseLabeledStatement(node, maybeName, expr);
            }
            else {
                return this.parseExpressionStatement(node, expr);
            }
        }
        ;
        /*<@166>*/takeDecorators(/*<@69>*/node) {
            if (this.state.decorators.length) {
                node.decorators = this.state.decorators;
                this.state.decorators = /*<@361>*/[];
            }
        }
        ;
        /*<@167>*/parseDecorators(/*<@60>*/allowExport) {
            while (this.match(this.tt.at)) {
                const /*<@69>*/decorator = this.parseDecorator();
                this.state.decorators.push(decorator);
            }
            if (allowExport && this.match(this.tt._export)) {
                return;
            }
            if (!this.match(this.tt._class)) {
                this.raise(this.state.start, "Leading decorators must be athis.ttached to a class declaration");
            }
        }
        ;
        /*<@168>*/parseDecorator() {
            if (!this.hasPlugin("decorators")) {
                this.unexpected();
            }
            const /*<@69>*/node = this.startNode();
            this.next();
            node.expression = this.parseMaybeAssign();
            return this.finishNode(node, "Decorator");
        }
        ;
        /*<@169>*/parseBreakContinueStatement(/*<@69>*/node, /*<@26>*/keyword) {
            const /*<@2>*/isBreak = keyword === "break";
            this.next();
            if (this.isLineTerminator()) {
                node.label = null;
            }
            else if (!this.match(this.tt.name)) {
                this.unexpected();
            }
            else {
                node.label = this.parseIdentifier();
                this.semicolon();
            }
            // Verify that there is an actual destination to break or
            // continue to.
            let /*<@5>*/i;
            for (i = 0; i < this.state.labels.length; ++i) {
                const /*<@69>*/lab = this.state.labels[i];
                if (node.label == null || lab.name === node.label.name) {
                    if (lab.kind != null && (isBreak || lab.kind === "loop"))
                        break;
                    if (node.label && isBreak)
                        break;
                }
            }
            if (i === this.state.labels.length)
                this.raise(node.start, "Unsyntactic " + keyword);
            return this.finishNode(node, isBreak ? "BreakStatement" : "ContinueStatement");
        }
        ;
        /*<@170>*/parseDebuggerStatement(/*<@69>*/node) {
            this.next();
            this.semicolon();
            return this.finishNode(node, "DebuggerStatement");
        }
        ;
        /*<@171>*/parseDoStatement(/*<@69>*/node) {
            this.next();
            this.state.labels.push(loopLabel);
            node.body = this.parseStatement(false);
            this.state.labels.pop();
            this.expect(this.tt._while);
            node.test = this.parseParenExpression();
            this.eat(this.tt.semi);
            return this.finishNode(node, "DoWhileStatement");
        }
        ;
        // Disambiguating between a `for` and a `for`/`in` or `for`/`of`
        // loop is non-trivial. Basically, we have to parse the init `var`
        // statement or expression, disallowing the `in` operator (see
        // the second parameter to `parseExpression`), and then check
        // whether the next token is `in` or `of`. When there is no init
        // part (semicolon immediately after the opening parenthesis), it
        // is a regular `for` loop.
        /*<@172>*/parseForStatement(/*<@69>*/node) {
            this.next();
            this.state.labels.push(loopLabel);
            let /*<@2>*/forAwait = false;
            if (this.hasPlugin("asyncGenerators") && this.state.inAsync && this.isContextual("await")) {
                forAwait = true;
                this.next();
            }
            this.expect(this.tt.parenL);
            if (this.match(this.tt.semi)) {
                if (forAwait) {
                    this.unexpected();
                }
                return this.parseFor(node, null);
            }
            if (this.match(this.tt._var) || this.match(this.tt._let) || this.match(this.tt._const)) {
                const /*<@69>*/init = this.startNode();
                const /*<@44>*/varKind = this.state.type;
                this.next();
                this.parseVar(init, true, varKind);
                this.finishNode(init, "VariableDeclaration");
                if (this.match(this.tt._in) || this.isContextual("of")) {
                    if (init.declarations.length === 1 && !init.declarations[0].init) {
                        return this.parseForIn(node, init, forAwait);
                    }
                }
                if (forAwait) {
                    this.unexpected();
                }
                return this.parseFor(node, init);
            }
            const /*<@89>*/refShorthandDefaultPos = /*<@89>*/{ start: 0 };
            const /*<@69>*/init = this.parseExpression(true, refShorthandDefaultPos);
            if (this.match(this.tt._in) || this.isContextual("of")) {
                const /*<@3>*/description = this.isContextual("of") ? "for-of statement" : "for-in statement";
                this.toAssignable(init, undefined, description);
                this.checkLVal(init, undefined, undefined, description);
                return this.parseForIn(node, init, forAwait);
            }
            else if (refShorthandDefaultPos.start) {
                this.unexpected(refShorthandDefaultPos.start);
            }
            if (forAwait) {
                this.unexpected();
            }
            return this.parseFor(node, init);
        }
        ;
        /*<@173>*/parseFunctionStatement(/*<@69>*/node) {
            this.next();
            return this.parseFunction(node, true);
        }
        ;
        /*<@174>*/parseIfStatement(/*<@69>*/node) {
            this.next();
            node.test = this.parseParenExpression();
            node.consequent = this.parseStatement(false);
            node.alternate = (this.eat(this.tt._else) ? this.parseStatement(false) : null);
            return this.finishNode(node, "IfStatement");
        }
        ;
        /*<@175>*/parseReturnStatement(/*<@69>*/node) {
            if (!this.state.inFunction && !this.options.allowReturnOutsideFunction) {
                this.raise(this.state.start, "'return' outside of function");
            }
            this.next();
            // In `return` (and `break`/`continue`), the keywords with
            // optional arguments, we eagerly look for a semicolon or the
            // possibility to insert one.
            if (this.isLineTerminator()) {
                node.argument = null;
            }
            else {
                node.argument = this.parseExpression();
                this.semicolon();
            }
            return this.finishNode(node, "ReturnStatement");
        }
        ;
        /*<@176>*/parseSwitchStatement(/*<@69>*/node) {
            this.next();
            node.discriminant = this.parseParenExpression();
            node.cases = /*<@361>*/[];
            this.expect(this.tt.braceL);
            this.state.labels.push(switchLabel);
            // Statements under must be grouped (by label) in SwitchCase
            // nodes. `cur` is used to keep the node that we are currently
            // adding statements to.
            let /*<@111>*/cur = void 0;
            for (let /*<@60>*/sawDefault = void 0; !this.match(this.tt.braceR);) {
                if (this.match(this.tt._case) || this.match(this.tt._default)) {
                    const /*<@2>*/isCase = this.match(this.tt._case);
                    if (cur)
                        this.finishNode(cur, "SwitchCase");
                    node.cases.push(cur = this.startNode());
                    cur.consequent = /*<@361>*/[];
                    this.next();
                    if (isCase) {
                        cur.test = this.parseExpression();
                    }
                    else {
                        if (sawDefault)
                            this.raise(this.state.lastTokStart, "Multiple default clauses");
                        sawDefault = true;
                        /*<@69>*/cur.test = null;
                    }
                    this.expect(this.tt.colon);
                }
                else {
                    if (cur) {
                        cur./*<@119>*/consequent.push(this.parseStatement(true));
                    }
                    else {
                        this.unexpected();
                    }
                }
            }
            if (cur)
                this.finishNode(cur, "SwitchCase");
            this.next(); // Closing brace
            this.state.labels.pop();
            return this.finishNode(node, "SwitchStatement");
        }
        ;
        /*<@177>*/parseThrowStatement(/*<@69>*/node) {
            this.next();
            if (utilWhitespaceJS.lineBreak.test(this.input.slice(this.state.lastTokEnd, this.state.start)))
                this.raise(this.state.lastTokEnd, "Illegal newline after throw");
            node.argument = this.parseExpression();
            this.semicolon();
            return this.finishNode(node, "ThrowStatement");
        }
        ;
        // Reused empty array added for node fields that are always empty.
        /*<@178>*/parseTryStatement(/*<@69>*/node) {
            this.next();
            node.block = this.parseBlock();
            node.handler = null;
            if (this.match(this.tt._catch)) {
                const /*<@69>*/clause = this.startNode();
                this.next();
                this.expect(this.tt.parenL);
                clause.param = this.parseBindingAtom();
                this.checkLVal(clause.param, true, Object.create(null), "catch clause");
                this.expect(this.tt.parenR);
                clause.body = this.parseBlock();
                node.handler = this.finishNode(clause, "CatchClause");
            }
            node.guardedHandlers = /*<@361>*/[];
            node.finalizer = (this.eat(this.tt._finally) ? this.parseBlock() : null);
            if (!node.handler && !node.finalizer) {
                this.raise(node.start, "Missing catch or finally clause");
            }
            return this.finishNode(node, "TryStatement");
        }
        ;
        /*<@179>*/parseVarStatement(/*<@69>*/node, /*<@44>*/kind) {
            this.next();
            this.parseVar(node, false, kind);
            this.semicolon();
            return this.finishNode(node, "VariableDeclaration");
        }
        ;
        /*<@180>*/parseWhileStatement(/*<@69>*/node) {
            this.next();
            node.test = this.parseParenExpression();
            this.state.labels.push(loopLabel);
            node.body = this.parseStatement(false);
            this.state.labels.pop();
            return this.finishNode(node, "WhileStatement");
        }
        ;
        /*<@181>*/parseWithStatement(/*<@69>*/node) {
            if (this.state.strict)
                this.raise(this.state.start, "'with' in strict mode");
            this.next();
            node.object = this.parseParenExpression();
            node.body = this.parseStatement(false);
            return this.finishNode(node, "WithStatement");
        }
        ;
        /*<@182>*/parseEmptyStatement(/*<@69>*/node) {
            this.next();
            return this.finishNode(node, "EmptyStatement");
        }
        ;
        /*<@183>*/parseLabeledStatement(/*<@69>*/node, /*<@26>*/maybeName, /*<@69>*/expr) {
            for (const /*<@69>*/label of (this.state.labels)) {
                if (label.name === maybeName) {
                    this.raise(/*<@69>*/expr.start, `Label '${maybeName}' is already declared`);
                }
            }
            const /*<@26>*/kind = this.state.type.isLoop ? "loop" : this.match(this.tt._switch) ? "switch" : null;
            for (let /*<@1>*/i = this.state.labels.length - 1; i >= 0; i--) {
                const /*<@69>*/label = this.state.labels[i];
                if (label.statementStart === node.start) {
                    label.statementStart = this.state.start;
                    label.kind = /*<@3>*/kind;
                }
                else {
                    break;
                }
            }
            let /*<@69>*/newLabel = new Node();
            node.name = /*<@3>*/maybeName;
            node.kind = /*<@3>*/kind;
            node.statementStart = this.state.start;
            this.state.labels.push(newLabel);
            node.body = this.parseStatement(true);
            this.state.labels.pop();
            node.label = /*<@69>*/expr;
            return this.finishNode(node, "LabeledStatement");
        }
        ;
        /*<@184>*/parseExpressionStatement(/*<@69>*/node, /*<@69>*/expr) {
            node.expression = expr;
            this.semicolon();
            return this.finishNode(node, "ExpressionStatement");
        }
        ;
        // Parse a semicolon-enclosed block of statements, handling `"use
        // strict"` declarations when `allowStrict` is true (used for
        // function bodies).
        /*<@185>*/parseBlock(/*<@60>*/allowDirectives, /*<@60>*/next) {
            const /*<@69>*/node = this.startNode();
            this.expect(this.tt.braceL);
            this.parseBlockBody(node, /*<@2>*/allowDirectives, false, this.tt.braceR);
            return this.finishNode(node, "BlockStatement");
        }
        ;
        /*<@186>*/isValidDirective(/*<@69>*/stmt) {
            return stmt.type === "ExpressionStatement" &&
                stmt./*<@69>*/expression.type === "StringLiteral" &&
                !stmt./*<@69>*/expression.extra.parenthesized;
        }
        ;
        /*<@187>*/parseBlockBody(/*<@69>*/node, /*<@2>*/allowDirectives, /*<@2>*/topLevel, /*<@44>*/end) {
            node.body = /*<@361>*/[];
            node.directives = /*<@361>*/[];
            let /*<@2>*/parsedNonDirective = false;
            let /*<@60>*/oldStrict = void 0;
            let /*<@22>*/octalPosition = void 0;
            while (!this.eat(end)) {
                if (!parsedNonDirective && this.state.containsOctal && !octalPosition) {
                    octalPosition = this.state.octalPosition;
                }
                const /*<@69>*/stmt = this.parseStatement(true, topLevel);
                if (allowDirectives && !parsedNonDirective && this.isValidDirective(stmt)) {
                    const /*<@69>*/directive = this.stmtToDirective(stmt);
                    node.directives.push(directive);
                    if (oldStrict === undefined && (directive./*<@69>*/value).value === "use strict") {
                        oldStrict = this.state.strict;
                        this.setStrict(true);
                        if (octalPosition) {
                            this.raise(octalPosition, "Octal literal in strict mode");
                        }
                    }
                    continue;
                }
                parsedNonDirective = true;
                node.body.push(stmt);
            }
            if (oldStrict === false) {
                this.setStrict(false);
            }
        }
        ;
        // Parse a regular `for` loop. The disambiguation code in
        // `parseStatement` will already have parsed the init statement or
        // expression.
        /*<@188>*/parseFor(/*<@69>*/node, /*<@111>*/init) {
            node.init = init;
            this.expect(this.tt.semi);
            node.test = (this.match(this.tt.semi) ? null : this.parseExpression());
            this.expect(this.tt.semi);
            node.update = (this.match(this.tt.parenR) ? null : this.parseExpression());
            this.expect(this.tt.parenR);
            node.body = this.parseStatement(false);
            this.state.labels.pop();
            return this.finishNode(node, "ForStatement");
        }
        ;
        // Parse a `for`/`in` and `for`/`of` loop, which are almost
        // same from parser's perspective.
        /*<@189>*/parseForIn(/*<@69>*/node, /*<@69>*/init, /*<@2>*/forAwait) {
            const /*<@3>*/type = this.match(this.tt._in) ? "ForInStatement" : "ForOfStatement";
            if (forAwait) {
                this.eatContextual("of");
            }
            else {
                this.next();
            }
            node.await = !!forAwait;
            node.left = init;
            node.right = this.parseExpression();
            this.expect(this.tt.parenR);
            node.body = this.parseStatement(false);
            this.state.labels.pop();
            return this.finishNode(node, type);
        }
        ;
        // Parse a list of variable declarations.
        /*<@190>*/parseVar(/*<@69>*/node, /*<@2>*/isFor, /*<@44>*/kind) {
            node.declarations = /*<@361>*/[];
            node.kind = kind./*<@3>*/keyword;
            for (;;) {
                const /*<@69>*/decl = this.startNode();
                this.parseVarHead(decl);
                if (this.eat(this.tt.eq)) {
                    decl.init = this.parseMaybeAssign(isFor);
                }
                else if (kind === this.tt._const && !(this.match(this.tt._in) || this.isContextual("of"))) {
                    this.unexpected();
                }
                else if (decl./*<@69>*/id.type !== "Identifier" && !(isFor && (this.match(this.tt._in) || this.isContextual("of")))) {
                    this.raise(this.state.lastTokEnd, "Complex binding pathis.tterns require an initialization value");
                }
                else {
                    decl.init = null;
                }
                node.declarations.push(this.finishNode(decl, "VariableDeclarator"));
                if (!this.eat(this.tt.comma))
                    break;
            }
            return node;
        }
        ;
        /*<@191>*/parseVarHead(/*<@69>*/decl) {
            decl.id = this.parseBindingAtom();
            this.checkLVal(decl./*<@69>*/id, true, undefined, "variable declaration");
        }
        ;
        /*<@192>*/parseFunctionParams(/*<@69>*/node) {
            this.expect(this.tt.parenL);
            node.params = this.parseBindingList(this.tt.parenR);
        }
        ;
        // Parse a class declaration or literal (depending on the
        // `isStatement` parameter).
        /*<@193>*/parseClass(/*<@69>*/node, /*<@60>*/isStatement, /*<@60>*/optionalId) {
            this.next();
            this.takeDecorators(node);
            this.parseClassId(node, /*<@2>*/isStatement, /*<@2>*/optionalId);
            this.parseClassSuper(node);
            this.parseClassBody(node);
            return this.finishNode(node, isStatement ? "ClassDeclaration" : "ClassExpression");
        }
        ;
        /*<@194>*/isClassProperty() {
            return this.match(this.tt.eq) || this.match(this.tt.semi) || this.match(this.tt.braceR);
        }
        ;
        /*<@195>*/isClassMethod() {
            return this.match(this.tt.parenL);
        }
        ;
        /*<@196>*/isNonstaticConstructor(/*<@69>*/method) {
            return !method.computed && !method.static && ((method.key.name === "constructor") || // Identifier
                (method.key.value === "constructor") // Literal
            );
        }
        ;
        /*<@197>*/parseClassBody(/*<@69>*/node) {
            // class bodies are implicitly strict
            const /*<@2>*/oldStrict = this.state.strict;
            this.state.strict = true;
            let /*<@2>*/hadConstructor = false;
            let /*<@361>*/decorators = /*<@361>*/[];
            const /*<@69>*/classBody = this.startNode();
            classBody.body = /*<@361>*/[];
            this.expect(this.tt.braceL);
            while (!this.eat(this.tt.braceR)) {
                if (this.eat(this.tt.semi)) {
                    if (decorators.length > 0) {
                        this.raise(this.state.lastTokEnd, "Decorators must not be followed by a semicolon");
                    }
                    continue;
                }
                if (this.match(this.tt.at)) {
                    decorators.push(this.parseDecorator());
                    continue;
                }
                const /*<@69>*/method = this.startNode();
                // steal the decorators if there are any
                if (decorators.length) {
                    method.decorators = decorators;
                    decorators = /*<@361>*/[];
                }
                method.static = false;
                if (this.match(this.tt.name) && this.state.value === "static") {
                    const /*<@69>*/key = this.parseIdentifier(true); // eats 'static'
                    if (this.isClassMethod()) {
                        // a method named 'static'
                        method.kind = "method";
                        method.computed = false;
                        method.key = key;
                        this.parseClassMethod(classBody, method, false, false);
                        continue;
                    }
                    else if (this.isClassProperty()) {
                        // a property named 'static'
                        method.computed = false;
                        method.key = key;
                        classBody.body.push(this.parseClassProperty(method));
                        continue;
                    }
                    // otherwise something static
                    method.static = true;
                }
                if (this.eat(this.tt.star)) {
                    // a generator
                    method.kind = "method";
                    this.parsePropertyName(method);
                    if (this.isNonstaticConstructor(method)) {
                        this.raise(method.key.start, "Constructor can't be a generator");
                    }
                    if (!method.computed && method.static && (method.key.name === "prototype" || method.key.value === "prototype")) {
                        this.raise(method.key.start, "Classes may not have static property named prototype");
                    }
                    this.parseClassMethod(classBody, method, true, false);
                }
                else {
                    const /*<@2>*/isSimple = this.match(this.tt.name);
                    const /*<@69>*/key = this.parsePropertyName(method);
                    if (!method.computed && method.static && (method.key.name === "prototype" || method.key.value === "prototype")) {
                        this.raise(method.key.start, "Classes may not have static property named prototype");
                    }
                    if (this.isClassMethod()) {
                        // a normal method
                        if (this.isNonstaticConstructor(method)) {
                            if (hadConstructor) {
                                this.raise(key.start, "Duplicate constructor in the same class");
                            }
                            else if (method.decorators) {
                                this.raise(method.start, "You can't athis.ttach decorators to a class constructor");
                            }
                            hadConstructor = true;
                            method.kind = "constructor";
                        }
                        else {
                            method.kind = "method";
                        }
                        this.parseClassMethod(classBody, method, false, false);
                    }
                    else if (this.isClassProperty()) {
                        // a normal property
                        if (this.isNonstaticConstructor(method)) {
                            this.raise(method.key.start, "Classes may not have a non-static field named 'constructor'");
                        }
                        classBody.body.push(this.parseClassProperty(method));
                    }
                    else if (isSimple && key.name === "async" && !this.isLineTerminator()) {
                        // an async method
                        const /*<@2>*/isGenerator = this.hasPlugin("asyncGenerators") && this.eat(this.tt.star);
                        method.kind = "method";
                        this.parsePropertyName(method);
                        if (this.isNonstaticConstructor(method)) {
                            this.raise(method.key.start, "Constructor can't be an async function");
                        }
                        this.parseClassMethod(classBody, method, isGenerator, true);
                    }
                    else if (isSimple && (key.name === "get" || key.name === "set") && !(this.isLineTerminator() && this.match(this.tt.star))) { // `get\n*` is an uninitialized property named 'get' followed by a generator.
                        // a gethis.tter or sethis.tter
                        method.kind = key.name;
                        this.parsePropertyName(method);
                        if (this.isNonstaticConstructor(method)) {
                            this.raise(method.key.start, "Constructor can't have get/set modifier");
                        }
                        this.parseClassMethod(classBody, method, false, false);
                        this.checkGetterSetterParamCount(method);
                    }
                    else if (this.isLineTerminator()) {
                        // an uninitialized class property (due to ASI, since we don't otherwise recognize the next token)
                        if (this.isNonstaticConstructor(method)) {
                            this.raise(method.key.start, "Classes may not have a non-static field named 'constructor'");
                        }
                        classBody.body.push(this.parseClassProperty(method));
                    }
                    else {
                        this.unexpected();
                    }
                }
            }
            if (decorators.length) {
                this.raise(this.state.start, "You have trailing decorators with no method");
            }
            node.body = this.finishNode(classBody, "ClassBody");
            this.state.strict = oldStrict;
        }
        ;
        /*<@198>*/parseClassProperty(/*<@69>*/node) {
            const /*<@3>*/noPluginMsg = "You can only use Class Properties when the 'classProperties' plugin is enabled.";
            if (!node.typeAnnotation && !this.hasPlugin("classProperties")) {
                this.raise(node.start, noPluginMsg);
            }
            if (this.match(this.tt.eq)) {
                if (!this.hasPlugin("classProperties"))
                    this.raise(this.state.start, noPluginMsg);
                this.next();
                node.value = this.parseMaybeAssign();
            }
            else {
                node.value = null;
            }
            this.semicolon();
            return this.finishNode(node, "ClassProperty");
        }
        ;
        /*<@199>*/parseClassMethod(/*<@69>*/classBody, /*<@69>*/method, /*<@2>*/isGenerator, /*<@2>*/isAsync) {
            this.parseMethod(method, isGenerator, isAsync);
            classBody./*<@119>*/body.push(this.finishNode(method, "ClassMethod"));
        }
        ;
        /*<@200>*/parseClassId(/*<@69>*/node, /*<@2>*/isStatement, /*<@2>*/optionalId) {
            if (this.match(this.tt.name)) {
                node.id = this.parseIdentifier();
            }
            else {
                if (optionalId || !isStatement) {
                    node.id = null;
                }
                else {
                    this.unexpected();
                }
            }
        }
        ;
        /*<@201>*/parseClassSuper(/*<@69>*/node) {
            node.superClass = (this.eat(this.tt._extends) ? this.parseExprSubscripts() : null);
        }
        ;
        // Parses module export declaration.
        /*<@202>*/parseExport(/*<@69>*/node) {
            this.next();
            // export * from '...'
            if (this.match(this.tt.star)) {
                const /*<@69>*/specifier = this.startNode();
                this.next();
                if (this.hasPlugin("exportExtensions") && this.eatContextual("as")) {
                    specifier.exported = this.parseIdentifier();
                    node.specifiers = /*<@119>*/[this.finishNode(specifier, "ExportNamespaceSpecifier")];
                    this.parseExportSpecifiersMaybe(node);
                    this.parseExportFrom(node, true);
                }
                else {
                    this.parseExportFrom(node, true);
                    return this.finishNode(node, "ExportAllDeclaration");
                }
            }
            else if (this.hasPlugin("exportExtensions") && this.isExportDefaultSpecifier()) {
                const /*<@69>*/specifier = this.startNode();
                specifier.exported = this.parseIdentifier(true);
                node.specifiers = /*<@119>*/[this.finishNode(specifier, "ExportDefaultSpecifier")];
                if (this.match(this.tt.comma) && this.lookahead().type === this.tt.star) {
                    this.expect(this.tt.comma);
                    const /*<@69>*/specifier = this.startNode();
                    this.expect(this.tt.star);
                    this.expectContextual("as");
                    specifier.exported = this.parseIdentifier();
                    node.specifiers.push(this.finishNode(specifier, "ExportNamespaceSpecifier"));
                }
                else {
                    this.parseExportSpecifiersMaybe(node);
                }
                this.parseExportFrom(node, true);
            }
            else if (this.eat(this.tt._default)) { // export default ...
                let /*<@69>*/expr = this.startNode();
                let /*<@2>*/needsSemi = false;
                if (this.eat(this.tt._function)) {
                    expr = this.parseFunction(expr, true, false, false, true);
                }
                else if (this.isContextual("async") &&
                    this.lookahead().type === this.tt._function) { // async function declaration
                    this.eatContextual("async");
                    this.eat(this.tt._function);
                    expr = this.parseFunction(expr, true, false, true, true);
                }
                else if (this.match(this.tt._class)) {
                    expr = this.parseClass(expr, true, true);
                }
                else {
                    needsSemi = true;
                    expr = this.parseMaybeAssign();
                }
                node.declaration = expr;
                if (needsSemi)
                    this.semicolon();
                this.checkExport(node, true, true);
                return this.finishNode(node, "ExportDefaultDeclaration");
            }
            else if (this.shouldParseExportDeclaration()) {
                node.specifiers = /*<@361>*/[];
                node.source = null;
                node.declaration = this.parseExportDeclaration(node);
            }
            else { // export { x, y as z } [from '...']
                node.declaration = null;
                node.specifiers = this.parseExportSpecifiers();
                this.parseExportFrom(node);
            }
            this.checkExport(node, true);
            return this.finishNode(node, "ExportNamedDeclaration");
        }
        ;
        /*<@203>*/parseExportDeclaration(/*<@69>*/p1) {
            return this.parseStatement(true);
        }
        ;
        /*<@204>*/isExportDefaultSpecifier() {
            if (this.match(this.tt.name)) {
                return this.state.value !== "type"
                    && this.state.value !== "async"
                    && this.state.value !== "interface";
            }
            if (!this.match(this.tt._default)) {
                return false;
            }
            const /*<@65>*/lookahead = this.lookahead();
            return lookahead.type === this.tt.comma || (lookahead.type === this.tt.name && lookahead.value === "from");
        }
        ;
        /*<@205>*/parseExportSpecifiersMaybe(/*<@69>*/node) {
            if (this.eat(this.tt.comma)) {
                node.specifiers = node.specifiers.concat(this.parseExportSpecifiers());
            }
        }
        ;
        /*<@206>*/parseExportFrom(/*<@69>*/node, /*<@60>*/expect) {
            if (this.eatContextual("from")) {
                node.source = this.match(this.tt.string) ? this.parseExprAtom() : this.unexpected();
                this.checkExport(node);
            }
            else {
                if (expect) {
                    this.unexpected();
                }
                else {
                    node.source = null;
                }
            }
            this.semicolon();
        }
        ;
        /*<@207>*/shouldParseExportDeclaration() {
            return this.state.type.keyword === "var"
                || this.state.type.keyword === "const"
                || this.state.type.keyword === "let"
                || this.state.type.keyword === "function"
                || this.state.type.keyword === "class"
                || this.isContextual("async");
        }
        ;
        /*<@208>*/checkExport(/*<@69>*/node, /*<@60>*/checkNames, /*<@60>*/isDefault) {
            if (checkNames) {
                // Check for duplicate exports
                if (isDefault) {
                    // Default exports
                    this.checkDuplicateExports(node, "default");
                }
                else if (node.specifiers && node.specifiers.length) {
                    // Named exports
                    for (const /*<@69>*/specifier of node.specifiers) {
                        this.checkDuplicateExports(specifier, specifier.exported./*<@3>*/name);
                    }
                }
                else if (node.declaration) {
                    // Exported declarations
                    if (node.declaration.type === "FunctionDeclaration" || node.declaration.type === "ClassDeclaration") {
                        this.checkDuplicateExports(node, node./*<@69>*/declaration./*<@69>*/id./*<@3>*/name);
                    }
                    else if (node.declaration.type === "VariableDeclaration") {
                        for (const /*<@69>*/declaration of node.declaration.declarations) {
                            this.checkDeclaration(declaration./*<@69>*/id);
                        }
                    }
                }
            }
            if (this.state.decorators.length) {
                const /*<@60>*/isClass = node.declaration && (node.declaration.type === "ClassDeclaration" || node.declaration.type === "ClassExpression");
                if (!node.declaration || !isClass) {
                    this.raise(node.start, "You can only use decorators on an export when exporting a class");
                }
                this.takeDecorators(node./*<@69>*/declaration);
            }
        }
        ;
        /*<@209>*/checkDeclaration(/*<@69>*/node) {
            if (node.type === "ObjectPathis.ttern") {
                for (const /*<@69>*/prop of node.properties) {
                    this.checkDeclaration(prop);
                }
            }
            else if (node.type === "ArrayPathis.ttern") {
                for (const /*<@69>*/elem of node.elements) {
                    if (elem) {
                        this.checkDeclaration(elem);
                    }
                }
            }
            else if (node.type === "ObjectProperty") {
                this.checkDeclaration(node./*<@69>*/value);
            }
            else if (node.type === "RestElement") {
                this.checkDeclaration(node./*<@69>*/argument);
            }
            else if (node.type === "Identifier") {
                this.checkDuplicateExports(node, node./*<@3>*/name);
            }
        }
        ;
        /*<@210>*/checkDuplicateExports(/*<@69>*/node, /*<@3>*/name) {
            if (this.state.exportedIdentifiers.indexOf(name) > -1) {
                this.raiseDuplicateExportError(node, name);
            }
            this.state.exportedIdentifiers.push(name);
        }
        ;
        /*<@211>*/raiseDuplicateExportError(/*<@69>*/node, /*<@3>*/name) {
            this.raise(node.start, name === "default" ?
                "Only one default export allowed per module." :
                `\`${name}\` has already been exported. Exported identifiers must be unique.`);
        }
        ;
        // Parses a comma-separated list of module exports.
        /*<@212>*/parseExportSpecifiers() {
            const /*<@361>*/nodes = /*<@361>*/[];
            let /*<@2>*/first = true;
            let /*<@60>*/needsFrom = void 0;
            // export { x, y as z } [from '...']
            this.expect(this.tt.braceL);
            while (!this.eat(this.tt.braceR)) {
                if (first) {
                    first = false;
                }
                else {
                    this.expect(this.tt.comma);
                    if (this.eat(this.tt.braceR))
                        break;
                }
                const /*<@2>*/isDefault = this.match(this.tt._default);
                if (isDefault && !needsFrom)
                    needsFrom = true;
                const /*<@69>*/node = this.startNode();
                node.local = this.parseIdentifier(isDefault);
                node.exported = this.eatContextual("as") ? this.parseIdentifier(true) : node.local.__clone();
                nodes.push(this.finishNode(node, "ExportSpecifier"));
            }
            // hthis.ttps://github.com/ember-cli/ember-cli/pull/3739
            if (needsFrom && !this.isContextual("from")) {
                this.unexpected();
            }
            return nodes;
        }
        ;
        // Parses import declaration.
        /*<@213>*/parseImport(/*<@69>*/node) {
            this.eat(this.tt._import);
            // import '...'
            if (this.match(this.tt.string)) {
                node.specifiers = /*<@361>*/[];
                node.source = this.parseExprAtom();
            }
            else {
                node.specifiers = /*<@361>*/[];
                this.parseImportSpecifiers(node);
                this.expectContextual("from");
                node.source = this.match(this.tt.string) ? this.parseExprAtom() : this.unexpected();
            }
            this.semicolon();
            return this.finishNode(node, "ImportDeclaration");
        }
        ;
        // Parses a comma-separated list of module imports.
        /*<@214>*/parseImportSpecifiers(/*<@69>*/node) {
            let /*<@2>*/first = true;
            if (this.match(this.tt.name)) {
                // import defaultObj, { x, y as z } from '...'
                const /*<@5>*/startPos = this.state.start;
                const /*<@35>*/startLoc = this.state.startLoc;
                node.specifiers.push(this.parseImportSpecifierDefault(this.parseIdentifier(), startPos, startLoc));
                if (!this.eat(this.tt.comma))
                    return;
            }
            if (this.match(this.tt.star)) {
                const /*<@69>*/specifier = this.startNode();
                this.next();
                this.expectContextual("as");
                specifier.local = this.parseIdentifier();
                this.checkLVal(specifier.local, true, undefined, "import namespace specifier");
                node.specifiers.push(this.finishNode(specifier, "ImportNamespaceSpecifier"));
                return;
            }
            this.expect(this.tt.braceL);
            while (!this.eat(this.tt.braceR)) {
                if (first) {
                    first = false;
                }
                else {
                    // Detect an athis.ttempt to deep destructure
                    if (this.eat(this.tt.colon)) {
                        this.unexpected(null, "ES2015 named imports do not destructure. Use another statement for destructuring after the import.");
                    }
                    this.expect(this.tt.comma);
                    if (this.eat(this.tt.braceR))
                        break;
                }
                this.parseImportSpecifier(node);
            }
        }
        ;
        /*<@215>*/parseImportSpecifier(/*<@69>*/node) {
            const /*<@69>*/specifier = this.startNode();
            specifier.imported = this.parseIdentifier(true);
            if (this.eatContextual("as")) {
                specifier.local = this.parseIdentifier();
            }
            else {
                this.checkReservedWord(specifier.imported./*<@3>*/name, specifier./*<@5>*/start, true, true);
                specifier.local = specifier.imported.__clone();
            }
            this.checkLVal(specifier.local, true, undefined, "import specifier");
            node.specifiers.push(this.finishNode(specifier, "ImportSpecifier"));
        }
        ;
        /*<@216>*/parseImportSpecifierDefault(/*<@69>*/id, /*<@5>*/startPos, /*<@35>*/startLoc) {
            const /*<@69>*/node = this.startNodeAt(startPos, startLoc);
            node.local = id;
            this.checkLVal(node.local, true, undefined, "default import specifier");
            return this.finishNode(node, "ImportDefaultSpecifier");
        }
        ;
        /*<@217>*/isRelational(/*<@3>*/op) {
            return this.match(this.tt.relational) && this.state.value === op;
        }
        ;
        // TODO
        /*<@218>*/expectRelational(/*<@3>*/op) {
            if (this.isRelational(op)) {
                this.next();
            }
            else {
                this.unexpected(null, this.tt.relational);
            }
        }
        ;
        // Tests whether parsed token is a contextual keyword.
        /*<@219>*/isContextual(/*<@3>*/name) {
            return this.match(this.tt.name) && this.state.value === name;
        }
        ;
        // Consumes contextual keyword if possible.
        /*<@220>*/eatContextual(/*<@3>*/name) {
            return this.state.value === name && this.eat(this.tt.name);
        }
        ;
        // Asserts that following token is given contextual keyword.
        /*<@221>*/expectContextual(/*<@3>*/name, /*<@26>*/message) {
            if (!this.eatContextual(name))
                this.unexpected(null, message);
        }
        // Test whether a semicolon can be inserted at the current position.
        /*<@222>*/canInsertSemicolon() {
            return this.match(this.tt.eof) ||
                this.match(this.tt.braceR) ||
                utilWhitespaceJS.lineBreak.test(this.input.slice(this.state.lastTokEnd, this.state.start));
        }
        // TODO
        /*<@223>*/isLineTerminator() {
            return this.eat(this.tt.semi) || this.canInsertSemicolon();
        }
        // Consume a semicolon, or, failing that, see if we are allowed to
        // pretend that there is a semicolon at this position.
        /*<@224>*/semicolon() {
            if (!this.isLineTerminator())
                this.unexpected(null, this.tt.semi);
        }
        /*<@225>*/estreeParseRegExpLiteral(/*<@226>*/value) {
            let /*<@372>*/regex = null;
            try {
                regex = new RegExp(value.pattern, value.flags);
            }
            catch (e) {
                // In environments that don't support these flags value will
                // be null as the regex can't be represented natively.
            }
            const /*<@69>*/node = this.estreeParseLiteral(regex);
            node.regex = /*<@226>*/{ pattern: value.pattern, flags: value.flags };
            return node;
        }
        /*<@227>*/estreeParseLiteral(/*<@92>*/value) {
            return this.parseLiteral(value, "Literal");
        }
        ;
        /*<@228>*/directiveToStmt(/*<@69>*/directive) {
            const /*<@69>*/directiveLiteral = (directive./*<@69>*/value);
            const /*<@69>*/stmt = this.startNodeAt(directive.start, directive.loc.start);
            const /*<@69>*/expression = this.startNodeAt(directiveLiteral.start, directiveLiteral.loc.start);
            expression.value = directiveLiteral.value;
            expression.raw = directiveLiteral.extra.raw;
            stmt.expression = this.finishNodeAt(expression, "Literal", directiveLiteral.end, directiveLiteral.loc.end);
            stmt.directive = (directiveLiteral.extra./*<@3>*/raw).slice(1, -1);
            return this.finishNodeAt(stmt, "ExpressionStatement", directive.end, directive.loc.end);
        }
        ;
        /*<@229>*/flowParseTypeInitialiser(/*<@44>*/tok) {
            const /*<@2>*/oldInType = this.state.inType;
            this.state.inType = true;
            this.expect(tok || this.tt.colon);
            const /*<@69>*/type = this.flowParseType();
            this.state.inType = oldInType;
            return type;
        }
        ;
        /*<@230>*/flowParsePredicate() {
            const /*<@69>*/node = this.startNode();
            const /*<@35>*/moduloLoc = this.state.startLoc;
            const /*<@5>*/moduloPos = this.state.start;
            this.expect(this.tt.modulo);
            const /*<@35>*/checksLoc = this.state.startLoc;
            this.expectContextual("checks");
            // Force '%' and 'checks' to be adjacent
            if (moduloLoc.line !== checksLoc.line || moduloLoc.column !== checksLoc.column - 1) {
                this.raise(moduloPos, "Spaces between ´%´ and ´checks´ are not allowed here.");
            }
            if (this.eat(this.tt.parenL)) {
                node.expression = this.parseExpression();
                this.expect(this.tt.parenR);
                return this.finishNode(node, "DeclaredPredicate");
            }
            else {
                return this.finishNode(node, "InferredPredicate");
            }
        }
        ;
        /*<@231>*/flowParseTypeAndPredicateInitialiser() {
            const /*<@2>*/oldInType = this.state.inType;
            this.state.inType = true;
            this.expect(this.tt.colon);
            let /*<@111>*/type = null;
            let /*<@111>*/predicate = null;
            if (this.match(this.tt.modulo)) {
                this.state.inType = oldInType;
                predicate = this.flowParsePredicate();
            }
            else {
                type = this.flowParseType();
                this.state.inType = oldInType;
                if (this.match(this.tt.modulo)) {
                    predicate = this.flowParsePredicate();
                }
            }
            return /*<@113>*/[type, predicate];
        }
        ;
        /*<@232>*/flowParseDeclareClass(/*<@69>*/node) {
            this.next();
            this.flowParseInterfaceish(node, true);
            return this.finishNode(node, "DeclareClass");
        }
        ;
        /*<@233>*/flowParseDeclareFunction(/*<@69>*/node) {
            this.next();
            const /*<@69>*/id = node.id = this.parseIdentifier();
            const /*<@69>*/typeNode = this.startNode();
            const /*<@69>*/typeContainer = this.startNode();
            if (this.isRelational("<")) {
                typeNode.typeParameters = this.flowParseTypeParameterDeclaration();
            }
            else {
                typeNode.typeParameters = null;
            }
            this.expect(this.tt.parenL);
            const /*<@262>*/tmp = this.flowParseFunctionTypeParams();
            typeNode.params = tmp.params;
            typeNode.rest = tmp.rest;
            this.expect(this.tt.parenR);
            let /*<@111>*/predicate = null;
            /*<@113>*/[typeNode./*<@111>*/returnType, predicate] = this.flowParseTypeAndPredicateInitialiser();
            typeContainer.typeAnnotation = this.finishNode(typeNode, "FunctionTypeAnnotation");
            typeContainer.predicate = predicate;
            id.typeAnnotation = this.finishNode(typeContainer, "TypeAnnotation");
            this.finishNode(id, id.type);
            this.semicolon();
            return this.finishNode(node, "DeclareFunction");
        }
        ;
        /*<@234>*/flowParseDeclare(/*<@69>*/node, /*<@60>*/p2) {
            if (this.match(this.tt._class)) {
                return this.flowParseDeclareClass(node);
            }
            else if (this.match(this.tt._function)) {
                return this.flowParseDeclareFunction(node);
            }
            else if (this.match(this.tt._var)) {
                return this.flowParseDeclareVariable(node);
            }
            else if (this.isContextual("module")) {
                if (this.lookahead().type === this.tt.dot) {
                    return this.flowParseDeclareModuleExports(node);
                }
                else {
                    return this.flowParseDeclareModule(node);
                }
            }
            else if (this.isContextual("type")) {
                return this.flowParseDeclareTypeAlias(node);
            }
            else if (this.isContextual("interface")) {
                return this.flowParseDeclareInterface(node);
            }
            else {
                this.unexpected();
            }
        }
        ;
        /*<@235>*/flowParseDeclareVariable(/*<@69>*/node) {
            this.next();
            node.id = this.flowParseTypeAnnotatableIdentifier();
            this.semicolon();
            return this.finishNode(node, "DeclareVariable");
        }
        ;
        /*<@236>*/flowParseDeclareModule(/*<@69>*/node) {
            this.next();
            if (this.match(this.tt.string)) {
                node.id = this.parseExprAtom();
            }
            else {
                node.id = this.parseIdentifier();
            }
            const /*<@69>*/bodyNode = node.body = this.startNode();
            const /*<@119>*/body = bodyNode.body = /*<@361>*/[];
            this.expect(this.tt.braceL);
            while (!this.match(this.tt.braceR)) {
                let /*<@69>*/bodyNode = this.startNode();
                if (this.match(this.tt._import)) {
                    const /*<@65>*/lookahead = this.lookahead();
                    if (lookahead.value !== "type" && lookahead.value !== "typeof") {
                        this.unexpected(null, "Imports within a `declare module` body must always be `import type` or `import typeof`");
                    }
                    this.parseImport(bodyNode);
                }
                else {
                    this.expectContextual("declare", "Only declares and type imports are allowed inside declare module");
                    bodyNode = this.flowParseDeclare(bodyNode, true);
                }
                body.push(bodyNode);
            }
            this.expect(this.tt.braceR);
            this.finishNode(bodyNode, "BlockStatement");
            return this.finishNode(node, "DeclareModule");
        }
        ;
        /*<@237>*/flowParseDeclareModuleExports(/*<@69>*/node) {
            this.expectContextual("module");
            this.expect(this.tt.dot);
            this.expectContextual("exports");
            node.typeAnnotation = this.flowParseTypeAnnotation();
            this.semicolon();
            return this.finishNode(node, "DeclareModuleExports");
        }
        ;
        /*<@238>*/flowParseDeclareTypeAlias(/*<@69>*/node) {
            this.next();
            this.flowParseTypeAlias(node);
            return this.finishNode(node, "DeclareTypeAlias");
        }
        ;
        /*<@239>*/flowParseDeclareInterface(/*<@69>*/node) {
            this.next();
            this.flowParseInterfaceish(node);
            return this.finishNode(node, "DeclareInterface");
        }
        ;
        // Interfaces
        /*<@240>*/flowParseInterfaceish(/*<@69>*/node, /*<@60>*/allowStatic) {
            node.id = this.parseIdentifier();
            if (this.isRelational("<")) {
                node.typeParameters = this.flowParseTypeParameterDeclaration();
            }
            else {
                node.typeParameters = null;
            }
            node.extends = /*<@361>*/[];
            node.mixins = /*<@361>*/[];
            if (this.eat(this.tt._extends)) {
                do {
                    node.extends.push(this.flowParseInterfaceExtends());
                } while (this.eat(this.tt.comma));
            }
            if (this.isContextual("mixins")) {
                this.next();
                do {
                    node.mixins.push(this.flowParseInterfaceExtends());
                } while (this.eat(this.tt.comma));
            }
            node.body = this.flowParseObjectType(/*<@2>*/allowStatic);
        }
        ;
        /*<@241>*/flowParseInterfaceExtends() {
            const /*<@69>*/node = this.startNode();
            node.id = this.flowParseQualifiedTypeIdentifier();
            if (this.isRelational("<")) {
                node.typeParameters = this.flowParseTypeParameterInstantiation();
            }
            else {
                node.typeParameters = null;
            }
            return this.finishNode(node, "InterfaceExtends");
        }
        ;
        /*<@242>*/flowParseInterface(/*<@69>*/node) {
            this.flowParseInterfaceish(node, false);
            return this.finishNode(node, "InterfaceDeclaration");
        }
        ;
        /*<@243>*/flowParseRestrictedIdentifier(/*<@60>*/liberal) {
            if (primitiveTypes.indexOf(this.state./*<@3>*/value) > -1) {
                this.raise(this.state.start, `Cannot overwrite primitive type ${this.state.value}`);
            }
            return this.parseIdentifier(liberal);
        }
        ;
        // Type aliases
        /*<@244>*/flowParseTypeAlias(/*<@69>*/node) {
            node.id = this.flowParseRestrictedIdentifier();
            if (this.isRelational("<")) {
                node.typeParameters = this.flowParseTypeParameterDeclaration();
            }
            else {
                node.typeParameters = null;
            }
            node.right = this.flowParseTypeInitialiser(this.tt.eq);
            this.semicolon();
            return this.finishNode(node, "TypeAlias");
        }
        ;
        // Type annotations
        /*<@245>*/flowParseTypeParameter() {
            const /*<@69>*/node = this.startNode();
            const /*<@111>*/variance = this.flowParseVariance();
            const /*<@69>*/ident = this.flowParseTypeAnnotatableIdentifier();
            node.name = ident.name;
            node.variance = variance;
            node.bound = ident.typeAnnotation;
            if (this.match(this.tt.eq)) {
                this.eat(this.tt.eq);
                node.default = this.flowParseType();
            }
            return this.finishNode(node, "TypeParameter");
        }
        ;
        /*<@246>*/flowParseTypeParameterDeclaration() {
            const /*<@2>*/oldInType = this.state.inType;
            const /*<@69>*/node = this.startNode();
            node.params = /*<@361>*/[];
            this.state.inType = true;
            // istanbul ignore else: this condition is already checked at all call sites
            if (this.isRelational("<") || this.match(this.tt.jsxTagStart)) {
                this.next();
            }
            else {
                this.unexpected();
            }
            do {
                node.params.push(this.flowParseTypeParameter());
                if (!this.isRelational(">")) {
                    this.expect(this.tt.comma);
                }
            } while (!this.isRelational(">"));
            this.expectRelational(">");
            this.state.inType = oldInType;
            return this.finishNode(node, "TypeParameterDeclaration");
        }
        ;
        /*<@247>*/flowParseTypeParameterInstantiation() {
            const /*<@69>*/node = this.startNode();
            const /*<@2>*/oldInType = this.state.inType;
            node.params = /*<@361>*/[];
            this.state.inType = true;
            this.expectRelational("<");
            while (!this.isRelational(">")) {
                node.params.push(this.flowParseType());
                if (!this.isRelational(">")) {
                    this.expect(this.tt.comma);
                }
            }
            this.expectRelational(">");
            this.state.inType = oldInType;
            return this.finishNode(node, "TypeParameterInstantiation");
        }
        ;
        /*<@248>*/flowParseObjectPropertyKey() {
            return (this.match(this.tt.num) || this.match(this.tt.string)) ? this.parseExprAtom() : this.parseIdentifier(true);
        }
        ;
        /*<@249>*/flowParseObjectTypeIndexer(/*<@69>*/node, /*<@2>*/isStatic, /*<@69>*/variance) {
            node.static = isStatic;
            this.expect(this.tt.bracketL);
            if (this.lookahead().type === this.tt.colon) {
                node.id = this.flowParseObjectPropertyKey();
                node.key = this.flowParseTypeInitialiser();
            }
            else {
                node.id = null;
                node.key = this.flowParseType();
            }
            this.expect(this.tt.bracketR);
            node.value = this.flowParseTypeInitialiser();
            node.variance = variance;
            // Finish node first to not include a possible semicolon in the locations
            const /*<@69>*/indexer = this.finishNode(node, "ObjectTypeIndexer");
            this.flowObjectTypeSemicolon();
            return indexer;
        }
        ;
        /*<@250>*/flowParseObjectTypeMethodish(/*<@69>*/node) {
            node.params = /*<@361>*/[];
            node.rest = null;
            node.typeParameters = null;
            if (this.isRelational("<")) {
                node.typeParameters = this.flowParseTypeParameterDeclaration();
            }
            this.expect(this.tt.parenL);
            while (this.match(this.tt.name)) {
                node.params.push(this.flowParseFunctionTypeParam());
                if (!this.match(this.tt.parenR)) {
                    this.expect(this.tt.comma);
                }
            }
            if (this.eat(this.tt.ellipsis)) {
                node.rest = this.flowParseFunctionTypeParam();
            }
            this.expect(this.tt.parenR);
            node.returnType = this.flowParseTypeInitialiser();
            return this.finishNode(node, "FunctionTypeAnnotation");
        }
        ;
        /*<@251>*/flowParseObjectTypeMethod(/*<@5>*/startPos, /*<@35>*/startLoc, /*<@2>*/isStatic, /*<@69>*/key) {
            const /*<@69>*/node = this.startNodeAt(startPos, startLoc);
            node.value = this.flowParseObjectTypeMethodish(this.startNodeAt(startPos, startLoc));
            node.static = isStatic;
            node.key = key;
            node.optional = false;
            this.flowObjectTypeSemicolon();
            return this.finishNode(node, "ObjectTypeProperty");
        }
        ;
        /*<@252>*/flowParseObjectTypeCallProperty(/*<@69>*/node, /*<@2>*/isStatic) {
            const /*<@69>*/valueNode = this.startNode();
            node.static = isStatic;
            node.value = this.flowParseObjectTypeMethodish(valueNode);
            this.flowObjectTypeSemicolon();
            return this.finishNode(node, "ObjectTypeCallProperty");
        }
        ;
        /*<@253>*/flowParseObjectType(/*<@2>*/allowStatic, /*<@60>*/allowExact) {
            const /*<@2>*/oldInType = this.state.inType;
            this.state.inType = true;
            const /*<@69>*/nodeStart = this.startNode();
            let /*<@69>*/node;
            let /*<@69>*/propertyKey;
            let /*<@2>*/isStatic = false;
            nodeStart.callProperties = /*<@361>*/[];
            nodeStart.properties = /*<@361>*/[];
            nodeStart.indexers = /*<@361>*/[];
            let /*<@44>*/endDelim;
            let /*<@2>*/exact;
            if (allowExact && this.match(this.tt.braceBarL)) {
                this.expect(this.tt.braceBarL);
                endDelim = this.tt.braceBarR;
                exact = true;
            }
            else {
                this.expect(this.tt.braceL);
                endDelim = this.tt.braceR;
                exact = false;
            }
            nodeStart.exact = exact;
            while (!this.match(endDelim)) {
                let /*<@2>*/optional = false;
                const /*<@5>*/startPos = this.state.start;
                const /*<@35>*/startLoc = this.state.startLoc;
                node = this.startNode();
                if (allowStatic && this.isContextual("static") && this.lookahead().type !== this.tt.colon) {
                    this.next();
                    isStatic = true;
                }
                const /*<@111>*/variance = this.flowParseVariance();
                if (this.match(this.tt.bracketL)) {
                    nodeStart.indexers.push(this.flowParseObjectTypeIndexer(node, isStatic, /*<@69>*/variance));
                }
                else if (this.match(this.tt.parenL) || this.isRelational("<")) {
                    if (variance) {
                        this.unexpected(variance.start);
                    }
                    nodeStart.callProperties.push(this.flowParseObjectTypeCallProperty(node, isStatic));
                }
                else {
                    propertyKey = this.flowParseObjectPropertyKey();
                    if (this.isRelational("<") || this.match(this.tt.parenL)) {
                        // This is a method property
                        if (variance) {
                            this.unexpected(variance.start);
                        }
                        nodeStart.properties.push(this.flowParseObjectTypeMethod(startPos, startLoc, isStatic, propertyKey));
                    }
                    else {
                        if (this.eat(this.tt.question)) {
                            optional = true;
                        }
                        node.key = propertyKey;
                        node.value = this.flowParseTypeInitialiser();
                        node.optional = optional;
                        node.static = isStatic;
                        node.variance = variance;
                        this.flowObjectTypeSemicolon();
                        nodeStart.properties.push(this.finishNode(node, "ObjectTypeProperty"));
                    }
                }
                isStatic = false;
            }
            this.expect(endDelim);
            const /*<@69>*/out = this.finishNode(nodeStart, "ObjectTypeAnnotation");
            this.state.inType = oldInType;
            return out;
        }
        ;
        /*<@254>*/flowObjectTypeSemicolon() {
            if (!this.eat(this.tt.semi) && !this.eat(this.tt.comma) &&
                !this.match(this.tt.braceR) && !this.match(this.tt.braceBarR)) {
                this.unexpected();
            }
        }
        ;
        /*<@255>*/flowParseQualifiedTypeIdentifier(/*<@22>*/startPos, /*<@35>*/startLoc, /*<@69>*/id) {
            startPos = startPos || this.state.start;
            startLoc = startLoc || this.state.startLoc;
            let /*<@69>*/node = id || this.parseIdentifier();
            while (this.eat(this.tt.dot)) {
                const /*<@69>*/node2 = this.startNodeAt(startPos, startLoc);
                node2.qualification = node;
                node2.id = this.parseIdentifier();
                node = this.finishNode(node2, "QualifiedTypeIdentifier");
            }
            return node;
        }
        ;
        /*<@256>*/flowParseGenericType(/*<@5>*/startPos, /*<@35>*/startLoc, /*<@69>*/id) {
            const /*<@69>*/node = this.startNodeAt(startPos, startLoc);
            node.typeParameters = null;
            node.id = this.flowParseQualifiedTypeIdentifier(startPos, startLoc, id);
            if (this.isRelational("<")) {
                node.typeParameters = this.flowParseTypeParameterInstantiation();
            }
            return this.finishNode(node, "GenericTypeAnnotation");
        }
        ;
        /*<@257>*/flowParseTypeofType() {
            const /*<@69>*/node = this.startNode();
            this.expect(this.tt._typeof);
            node.argument = this.flowParsePrimaryType();
            return this.finishNode(node, "TypeofTypeAnnotation");
        }
        ;
        /*<@258>*/flowParseTupleType() {
            const /*<@69>*/node = this.startNode();
            node.types = /*<@361>*/[];
            this.expect(this.tt.bracketL);
            // We allow trailing commas
            while (this.state.pos < this.input.length && !this.match(this.tt.bracketR)) {
                node.types.push(this.flowParseType());
                if (this.match(this.tt.bracketR))
                    break;
                this.expect(this.tt.comma);
            }
            this.expect(this.tt.bracketR);
            return this.finishNode(node, "TupleTypeAnnotation");
        }
        ;
        /*<@259>*/flowParseFunctionTypeParam() {
            let /*<@111>*/name = null;
            let /*<@2>*/optional = false;
            let /*<@111>*/typeAnnotation = null;
            const /*<@69>*/node = this.startNode();
            const /*<@65>*/lh = this.lookahead();
            if (lh.type === this.tt.colon ||
                lh.type === this.tt.question) {
                name = this.parseIdentifier();
                if (this.eat(this.tt.question)) {
                    optional = true;
                }
                typeAnnotation = this.flowParseTypeInitialiser();
            }
            else {
                typeAnnotation = this.flowParseType();
            }
            node.name = name;
            node.optional = optional;
            node.typeAnnotation = typeAnnotation;
            return this.finishNode(node, "FunctionTypeParam");
        }
        ;
        /*<@260>*/reinterpretTypeAsFunctionTypeParam(/*<@69>*/type) {
            const /*<@69>*/node = this.startNodeAt(type.start, (type.loc));
            node.name = null;
            node.optional = false;
            node.typeAnnotation = type;
            return this.finishNode(node, "FunctionTypeParam");
        }
        ;
        /*<@261>*/flowParseFunctionTypeParams(/*<@119>*/params = /*<@119>*/[]) {
            const /*<@262>*/ret = /*<@262>*/{ params, rest: null };
            while (!this.match(this.tt.parenR) && !this.match(this.tt.ellipsis)) {
                ret.params.push(this.flowParseFunctionTypeParam());
                if (!this.match(this.tt.parenR)) {
                    this.expect(this.tt.comma);
                }
            }
            if (this.eat(this.tt.ellipsis)) {
                ret.rest = this.flowParseFunctionTypeParam();
            }
            return ret;
        }
        ;
        /*<@263>*/flowIdentToTypeAnnotation(/*<@5>*/startPos, /*<@35>*/startLoc, /*<@69>*/node, /*<@69>*/id) {
            switch (id.name) {
                case "any":
                    return this.finishNode(node, "AnyTypeAnnotation");
                case "void":
                    return this.finishNode(node, "VoidTypeAnnotation");
                case "bool":
                case "boolean":
                    return this.finishNode(node, "BooleanTypeAnnotation");
                case "mixed":
                    return this.finishNode(node, "MixedTypeAnnotation");
                case "empty":
                    return this.finishNode(node, "EmptyTypeAnnotation");
                case "number":
                    return this.finishNode(node, "NumberTypeAnnotation");
                case "string":
                    return this.finishNode(node, "StringTypeAnnotation");
                default:
                    return this.flowParseGenericType(startPos, startLoc, id);
            }
        }
        ;
        // The parsing of types roughly parallels the parsing of expressions, and
        // primary types are kind of like primary expressions...they're the
        // primitives with which other types are constructed.
        /*<@264>*/flowParsePrimaryType() {
            const /*<@5>*/startPos = this.state.start;
            const /*<@35>*/startLoc = this.state.startLoc;
            const /*<@69>*/node = this.startNode();
            let /*<@373>*/tmp = void 0;
            let /*<@111>*/type = void 0;
            let /*<@2>*/isGroupedType = false;
            const /*<@2>*/oldNoAnonFunctionType = this.state.noAnonFunctionType;
            switch (this.state.type) {
                case this.tt.name:
                    return this.flowIdentToTypeAnnotation(startPos, startLoc, node, this.parseIdentifier());
                case this.tt.braceL:
                    return this.flowParseObjectType(false, false);
                case this.tt.braceBarL:
                    return this.flowParseObjectType(false, true);
                case this.tt.bracketL:
                    return this.flowParseTupleType();
                case this.tt.relational:
                    if (this.state.value === "<") {
                        node.typeParameters = this.flowParseTypeParameterDeclaration();
                        this.expect(this.tt.parenL);
                        tmp = this.flowParseFunctionTypeParams();
                        node.params = tmp.params;
                        node.rest = tmp.rest;
                        this.expect(this.tt.parenR);
                        this.expect(this.tt.arrow);
                        node.returnType = this.flowParseType();
                        return this.finishNode(node, "FunctionTypeAnnotation");
                    }
                    break;
                case this.tt.parenL:
                    this.next();
                    // Check to see if this is actually a grouped type
                    if (!this.match(this.tt.parenR) && !this.match(this.tt.ellipsis)) {
                        if (this.match(this.tt.name)) {
                            const /*<@44>*/token = this.lookahead().type;
                            isGroupedType = token !== this.tt.question && token !== this.tt.colon;
                        }
                        else {
                            isGroupedType = true;
                        }
                    }
                    if (isGroupedType) {
                        this.state.noAnonFunctionType = false;
                        type = this.flowParseType();
                        this.state.noAnonFunctionType = oldNoAnonFunctionType;
                        // A `,` or a `) =>` means this is an anonymous function type
                        if (this.state.noAnonFunctionType ||
                            !(this.match(this.tt.comma) ||
                                (this.match(this.tt.parenR) && this.lookahead().type === this.tt.arrow))) {
                            this.expect(this.tt.parenR);
                            return type;
                        }
                        else {
                            // Eat a comma if there is one
                            this.eat(this.tt.comma);
                        }
                    }
                    if (type) {
                        tmp = this.flowParseFunctionTypeParams(/*<@119>*/[this.reinterpretTypeAsFunctionTypeParam(type)]);
                    }
                    else {
                        tmp = this.flowParseFunctionTypeParams();
                    }
                    node.params = tmp.params;
                    node.rest = tmp.rest;
                    this.expect(this.tt.parenR);
                    this.expect(this.tt.arrow);
                    node.returnType = this.flowParseType();
                    node.typeParameters = null;
                    return this.finishNode(node, "FunctionTypeAnnotation");
                case this.tt.string:
                    return this.parseLiteral(this.state.value, "StringLiteralTypeAnnotation");
                case this.tt._true:
                case this.tt._false:
                    node.value = this.match(this.tt._true);
                    this.next();
                    return this.finishNode(node, "BooleanLiteralTypeAnnotation");
                case this.tt.plusMin:
                    if (this.state.value === "-") {
                        this.next();
                        if (!this.match(this.tt.num))
                            this.unexpected(null, "Unexpected token, expected number");
                        return this.parseLiteral((-this.state.value), "NumberLiteralTypeAnnotation", node.start, node.loc.start);
                    }
                    this.unexpected();
                case this.tt.num:
                    return this.parseLiteral(this.state.value, "NumberLiteralTypeAnnotation");
                case this.tt._null:
                    node.value = this.match(this.tt._null);
                    this.next();
                    return this.finishNode(node, "NullLiteralTypeAnnotation");
                case this.tt._this:
                    node.value = this.match(this.tt._this);
                    this.next();
                    return this.finishNode(node, "ThisTypeAnnotation");
                case this.tt.star:
                    this.next();
                    return this.finishNode(node, "ExistsTypeAnnotation");
                default:
                    if (this.state.type.keyword === "typeof") {
                        return this.flowParseTypeofType();
                    }
            }
            this.unexpected();
        }
        ;
        /*<@265>*/flowParsePostfixType() {
            const /*<@5>*/startPos = this.state.start, /*<@35>*/startLoc = this.state.startLoc;
            let /*<@111>*/type = this.flowParsePrimaryType();
            while (!this.canInsertSemicolon() && this.match(this.tt.bracketL)) {
                const /*<@69>*/node = this.startNodeAt(startPos, startLoc);
                node.elementType = /*<@69>*/type;
                this.expect(this.tt.bracketL);
                this.expect(this.tt.bracketR);
                type = this.finishNode(node, "ArrayTypeAnnotation");
            }
            return type;
        }
        ;
        /*<@266>*/flowParsePrefixType() {
            const /*<@69>*/node = this.startNode();
            if (this.eat(this.tt.question)) {
                node.typeAnnotation = this.flowParsePrefixType();
                return this.finishNode(node, "NullableTypeAnnotation");
            }
            else {
                return this.flowParsePostfixType();
            }
        }
        ;
        /*<@267>*/flowParseAnonFunctionWithoutParens() {
            const /*<@69>*/param = this.flowParsePrefixType();
            if (!this.state.noAnonFunctionType && this.eat(this.tt.arrow)) {
                const /*<@69>*/node = this.startNodeAt(param.start, param.loc);
                node.params = /*<@119>*/[this.reinterpretTypeAsFunctionTypeParam(param)];
                node.rest = null;
                node.returnType = this.flowParseType();
                node.typeParameters = null;
                return this.finishNode(node, "FunctionTypeAnnotation");
            }
            return param;
        }
        ;
        /*<@268>*/flowParseIntersectionType() {
            const /*<@69>*/node = this.startNode();
            this.eat(this.tt.bitwiseAND);
            const /*<@69>*/type = this.flowParseAnonFunctionWithoutParens();
            node.types = /*<@119>*/[type];
            while (this.eat(this.tt.bitwiseAND)) {
                node.types.push(this.flowParseAnonFunctionWithoutParens());
            }
            return node.types.length === 1 ? type : this.finishNode(node, "IntersectionTypeAnnotation");
        }
        ;
        /*<@269>*/flowParseUnionType() {
            const /*<@69>*/node = this.startNode();
            this.eat(this.tt.bitwiseOR);
            const /*<@69>*/type = this.flowParseIntersectionType();
            node.types = /*<@119>*/[type];
            while (this.eat(this.tt.bitwiseOR)) {
                node.types.push(this.flowParseIntersectionType());
            }
            return node.types.length === 1 ? type : this.finishNode(node, "UnionTypeAnnotation");
        }
        ;
        /*<@270>*/flowParseType() {
            const /*<@2>*/oldInType = this.state.inType;
            this.state.inType = true;
            const /*<@69>*/type = this.flowParseUnionType();
            this.state.inType = oldInType;
            return type;
        }
        ;
        /*<@271>*/flowParseTypeAnnotation() {
            const /*<@69>*/node = this.startNode();
            node.typeAnnotation = this.flowParseTypeInitialiser();
            return this.finishNode(node, "TypeAnnotation");
        }
        ;
        /*<@272>*/flowParseTypeAndPredicateAnnotation() {
            const /*<@69>*/node = this.startNode();
            /*<@113>*/[node./*<@111>*/typeAnnotation, node./*<@111>*/predicate] = this.flowParseTypeAndPredicateInitialiser();
            return this.finishNode(node, "TypeAnnotation");
        }
        ;
        /*<@273>*/flowParseTypeAnnotatableIdentifier() {
            const /*<@69>*/ident = this.flowParseRestrictedIdentifier();
            if (this.match(this.tt.colon)) {
                ident.typeAnnotation = this.flowParseTypeAnnotation();
                this.finishNode(ident, ident.type);
            }
            return ident;
        }
        ;
        /*<@274>*/typeCastToParameter(/*<@69>*/node) {
            node./*<@69>*/expression.typeAnnotation = node.typeAnnotation;
            return this.finishNodeAt(node./*<@69>*/expression, node./*<@69>*/expression.type, node.typeAnnotation.end, node.typeAnnotation.loc.end);
        }
        ;
        /*<@275>*/flowParseVariance() {
            let /*<@111>*/variance = null;
            if (this.match(this.tt.plusMin)) {
                variance = this.startNode();
                if (this.state.value === "+") {
                    variance.kind = "plus";
                }
                else {
                    variance.kind = "minus";
                }
                this.next();
                this.finishNode(variance, "Variance");
            }
            return variance;
        }
        ;
        /*<@276>*/jsxReadToken() {
            let /*<@3>*/out = "";
            let /*<@5>*/chunkStart = this.state.pos;
            for (;;) {
                if (this.state.pos >= this.input.length) {
                    this.raise(this.state.start, "Unterminated JSX contents");
                }
                const /*<@5>*/ch = this.input.charCodeAt(this.state.pos);
                switch (ch) {
                    case 60: // "<"
                    case 123: // "{"
                        if (this.state.pos === this.state.start) {
                            if (ch === 60 && this.state.exprAllowed) {
                                ++this.state.pos;
                                return this.finishToken(this.tt.jsxTagStart);
                            }
                            return this.getTokenFromCode(ch);
                        }
                        out += this.input.slice(chunkStart, this.state.pos);
                        return this.finishToken(this.tt.jsxText, out);
                    case 38: // "&"
                        out += this.input.slice(chunkStart, this.state.pos);
                        out += this.jsxReadEntity();
                        chunkStart = this.state.pos;
                        break;
                    default:
                        if (utilWhitespaceJS.isNewLine(ch)) {
                            out += this.input.slice(chunkStart, this.state.pos);
                            out += this.jsxReadNewLine(true);
                            chunkStart = this.state.pos;
                        }
                        else {
                            ++this.state.pos;
                        }
                }
            }
        }
        ;
        /*<@277>*/jsxReadNewLine(/*<@2>*/normalizeCRLF) {
            const /*<@5>*/ch = this.input.charCodeAt(this.state.pos);
            let /*<@3>*/out;
            ++this.state.pos;
            if (ch === 13 && this.input.charCodeAt(this.state.pos) === 10) {
                ++this.state.pos;
                out = normalizeCRLF ? "\n" : "\r\n";
            }
            else {
                out = String.fromCharCode(ch);
            }
            ++this.state.curLine;
            this.state.lineStart = this.state.pos;
            return out;
        }
        ;
        /*<@278>*/jsxReadString(/*<@5>*/quote) {
            let /*<@3>*/out = "";
            let /*<@5>*/chunkStart = ++this.state.pos;
            for (;;) {
                if (this.state.pos >= this.input.length) {
                    this.raise(this.state.start, "Unterminated string constant");
                }
                const /*<@5>*/ch = this.input.charCodeAt(this.state.pos);
                if (ch === quote)
                    break;
                if (ch === 38) { // "&"
                    out += this.input.slice(chunkStart, this.state.pos);
                    out += this.jsxReadEntity();
                    chunkStart = this.state.pos;
                }
                else if (utilWhitespaceJS.isNewLine(ch)) {
                    out += this.input.slice(chunkStart, this.state.pos);
                    out += this.jsxReadNewLine(false);
                    chunkStart = this.state.pos;
                }
                else {
                    ++this.state.pos;
                }
            }
            out += this.input.slice(chunkStart, this.state.pos++);
            return this.finishToken(this.tt.string, out);
        }
        ;
        /*<@279>*/getJsxXhtmlJS(/*<@3>*/str) {
            switch (str) {
                case "quot":
                    return pluginsJsxXhtmlJS.quot;
                case "amp":
                    return pluginsJsxXhtmlJS.amp;
                case "apos":
                    return pluginsJsxXhtmlJS.apos;
                case "lt":
                    return pluginsJsxXhtmlJS.lt;
                case "gt":
                    return pluginsJsxXhtmlJS.gt;
                case "nbsp":
                    return pluginsJsxXhtmlJS.nbsp;
                case "iexcl":
                    return pluginsJsxXhtmlJS.iexcl;
                case "cent":
                    return pluginsJsxXhtmlJS.cent;
                case "pound":
                    return pluginsJsxXhtmlJS.pound;
                case "curren":
                    return pluginsJsxXhtmlJS.curren;
                case "yen":
                    return pluginsJsxXhtmlJS.yen;
                case "brvbar":
                    return pluginsJsxXhtmlJS.brvbar;
                case "sect":
                    return pluginsJsxXhtmlJS.sect;
                case "uml":
                    return pluginsJsxXhtmlJS.uml;
                case "copy":
                    return pluginsJsxXhtmlJS.copy;
                case "ordf":
                    return pluginsJsxXhtmlJS.ordf;
                case "laquo":
                    return pluginsJsxXhtmlJS.laquo;
                case "not":
                    return pluginsJsxXhtmlJS.not;
                case "shy":
                    return pluginsJsxXhtmlJS.shy;
                case "reg":
                    return pluginsJsxXhtmlJS.reg;
                case "macr":
                    return pluginsJsxXhtmlJS.macr;
                case "deg":
                    return pluginsJsxXhtmlJS.deg;
                case "plusmn":
                    return pluginsJsxXhtmlJS.plusmn;
                case "sup2":
                    return pluginsJsxXhtmlJS.sup2;
                case "sup3":
                    return pluginsJsxXhtmlJS.sup3;
                case "acute":
                    return pluginsJsxXhtmlJS.acute;
                case "micro":
                    return pluginsJsxXhtmlJS.micro;
                case "para":
                    return pluginsJsxXhtmlJS.para;
                case "middot":
                    return pluginsJsxXhtmlJS.middot;
                case "cedil":
                    return pluginsJsxXhtmlJS.cedil;
                case "sup1":
                    return pluginsJsxXhtmlJS.sup1;
                case "ordm":
                    return pluginsJsxXhtmlJS.ordm;
                case "raquo":
                    return pluginsJsxXhtmlJS.raquo;
                case "frac14":
                    return pluginsJsxXhtmlJS.frac14;
                case "frac12":
                    return pluginsJsxXhtmlJS.frac12;
                case "frac34":
                    return pluginsJsxXhtmlJS.frac34;
                case "iquest":
                    return pluginsJsxXhtmlJS.iquest;
                case "Agrave":
                    return pluginsJsxXhtmlJS.Agrave;
                case "Aacute":
                    return pluginsJsxXhtmlJS.Aacute;
                case "Acirc":
                    return pluginsJsxXhtmlJS.Acirc;
                case "Atilde":
                    return pluginsJsxXhtmlJS.Atilde;
                case "Auml":
                    return pluginsJsxXhtmlJS.Auml;
                case "Aring":
                    return pluginsJsxXhtmlJS.Aring;
                case "AElig":
                    return pluginsJsxXhtmlJS.AElig;
                case "Ccedil":
                    return pluginsJsxXhtmlJS.Ccedil;
                case "Egrave":
                    return pluginsJsxXhtmlJS.Egrave;
                case "Eacute":
                    return pluginsJsxXhtmlJS.Eacute;
                case "Ecirc":
                    return pluginsJsxXhtmlJS.Ecirc;
                case "Euml":
                    return pluginsJsxXhtmlJS.Euml;
                case "Igrave":
                    return pluginsJsxXhtmlJS.Igrave;
                case "Iacute":
                    return pluginsJsxXhtmlJS.Iacute;
                case "Icirc":
                    return pluginsJsxXhtmlJS.Icirc;
                case "Iuml":
                    return pluginsJsxXhtmlJS.Iuml;
                case "ETH":
                    return pluginsJsxXhtmlJS.ETH;
                case "Ntilde":
                    return pluginsJsxXhtmlJS.Ntilde;
                case "Ograve":
                    return pluginsJsxXhtmlJS.Ograve;
                case "Oacute":
                    return pluginsJsxXhtmlJS.Oacute;
                case "Ocirc":
                    return pluginsJsxXhtmlJS.Ocirc;
                case "Otilde":
                    return pluginsJsxXhtmlJS.Otilde;
                case "Ouml":
                    return pluginsJsxXhtmlJS.Ouml;
                case "times":
                    return pluginsJsxXhtmlJS.times;
                case "Oslash":
                    return pluginsJsxXhtmlJS.Oslash;
                case "Ugrave":
                    return pluginsJsxXhtmlJS.Ugrave;
                case "Uacute":
                    return pluginsJsxXhtmlJS.Uacute;
                case "Ucirc":
                    return pluginsJsxXhtmlJS.Ucirc;
                case "Uuml":
                    return pluginsJsxXhtmlJS.Uuml;
                case "Yacute":
                    return pluginsJsxXhtmlJS.Yacute;
                case "THORN":
                    return pluginsJsxXhtmlJS.THORN;
                case "szlig":
                    return pluginsJsxXhtmlJS.szlig;
                case "agrave":
                    return pluginsJsxXhtmlJS.agrave;
                case "aacute":
                    return pluginsJsxXhtmlJS.aacute;
                case "acirc":
                    return pluginsJsxXhtmlJS.acirc;
                case "atilde":
                    return pluginsJsxXhtmlJS.atilde;
                case "auml":
                    return pluginsJsxXhtmlJS.auml;
                case "aring":
                    return pluginsJsxXhtmlJS.aring;
                case "aelig":
                    return pluginsJsxXhtmlJS.aelig;
                case "ccedil":
                    return pluginsJsxXhtmlJS.ccedil;
                case "egrave":
                    return pluginsJsxXhtmlJS.egrave;
                case "eacute":
                    return pluginsJsxXhtmlJS.eacute;
                case "ecirc":
                    return pluginsJsxXhtmlJS.ecirc;
                case "euml":
                    return pluginsJsxXhtmlJS.euml;
                case "igrave":
                    return pluginsJsxXhtmlJS.igrave;
                case "iacute":
                    return pluginsJsxXhtmlJS.iacute;
                case "icirc":
                    return pluginsJsxXhtmlJS.icirc;
                case "iuml":
                    return pluginsJsxXhtmlJS.iuml;
                case "eth":
                    return pluginsJsxXhtmlJS.eth;
                case "ntilde":
                    return pluginsJsxXhtmlJS.ntilde;
                case "ograve":
                    return pluginsJsxXhtmlJS.ograve;
                case "oacute":
                    return pluginsJsxXhtmlJS.oacute;
                case "ocirc":
                    return pluginsJsxXhtmlJS.ocirc;
                case "otilde":
                    return pluginsJsxXhtmlJS.otilde;
                case "ouml":
                    return pluginsJsxXhtmlJS.ouml;
                case "divide":
                    return pluginsJsxXhtmlJS.divide;
                case "oslash":
                    return pluginsJsxXhtmlJS.oslash;
                case "ugrave":
                    return pluginsJsxXhtmlJS.ugrave;
                case "uacute":
                    return pluginsJsxXhtmlJS.uacute;
                case "ucirc":
                    return pluginsJsxXhtmlJS.ucirc;
                case "uuml":
                    return pluginsJsxXhtmlJS.uuml;
                case "yacute":
                    return pluginsJsxXhtmlJS.yacute;
                case "thorn":
                    return pluginsJsxXhtmlJS.thorn;
                case "yuml":
                    return pluginsJsxXhtmlJS.yuml;
                case "OElig":
                    return pluginsJsxXhtmlJS.OElig;
                case "oelig":
                    return pluginsJsxXhtmlJS.oelig;
                case "Scaron":
                    return pluginsJsxXhtmlJS.Scaron;
                case "scaron":
                    return pluginsJsxXhtmlJS.scaron;
                case "Yuml":
                    return pluginsJsxXhtmlJS.Yuml;
                case "fnof":
                    return pluginsJsxXhtmlJS.fnof;
                case "circ":
                    return pluginsJsxXhtmlJS.circ;
                case "tilde":
                    return pluginsJsxXhtmlJS.tilde;
                case "Alpha":
                    return pluginsJsxXhtmlJS.Alpha;
                case "Beta":
                    return pluginsJsxXhtmlJS.Beta;
                case "Gamma":
                    return pluginsJsxXhtmlJS.Gamma;
                case "Delta":
                    return pluginsJsxXhtmlJS.Delta;
                case "Epsilon":
                    return pluginsJsxXhtmlJS.Epsilon;
                case "Zeta":
                    return pluginsJsxXhtmlJS.Zeta;
                case "Eta":
                    return pluginsJsxXhtmlJS.Eta;
                case "Theta":
                    return pluginsJsxXhtmlJS.Theta;
                case "Iota":
                    return pluginsJsxXhtmlJS.Iota;
                case "Kappa":
                    return pluginsJsxXhtmlJS.Kappa;
                case "Lambda":
                    return pluginsJsxXhtmlJS.Lambda;
                case "Mu":
                    return pluginsJsxXhtmlJS.Mu;
                case "Nu":
                    return pluginsJsxXhtmlJS.Nu;
                case "Xi":
                    return pluginsJsxXhtmlJS.Xi;
                case "Omicron":
                    return pluginsJsxXhtmlJS.Omicron;
                case "Pi":
                    return pluginsJsxXhtmlJS.Pi;
                case "Rho":
                    return pluginsJsxXhtmlJS.Rho;
                case "Sigma":
                    return pluginsJsxXhtmlJS.Sigma;
                case "Tau":
                    return pluginsJsxXhtmlJS.Tau;
                case "Upsilon":
                    return pluginsJsxXhtmlJS.Upsilon;
                case "Phi":
                    return pluginsJsxXhtmlJS.Phi;
                case "Chi":
                    return pluginsJsxXhtmlJS.Chi;
                case "Psi":
                    return pluginsJsxXhtmlJS.Psi;
                case "Omega":
                    return pluginsJsxXhtmlJS.Omega;
                case "alpha":
                    return pluginsJsxXhtmlJS.alpha;
                case "beta":
                    return pluginsJsxXhtmlJS.beta;
                case "gamma":
                    return pluginsJsxXhtmlJS.gamma;
                case "delta":
                    return pluginsJsxXhtmlJS.delta;
                case "epsilon":
                    return pluginsJsxXhtmlJS.epsilon;
                case "zeta":
                    return pluginsJsxXhtmlJS.zeta;
                case "eta":
                    return pluginsJsxXhtmlJS.eta;
                case "theta":
                    return pluginsJsxXhtmlJS.theta;
                case "iota":
                    return pluginsJsxXhtmlJS.iota;
                case "kappa":
                    return pluginsJsxXhtmlJS.kappa;
                case "lambda":
                    return pluginsJsxXhtmlJS.lambda;
                case "mu":
                    return pluginsJsxXhtmlJS.mu;
                case "nu":
                    return pluginsJsxXhtmlJS.nu;
                case "xi":
                    return pluginsJsxXhtmlJS.xi;
                case "omicron":
                    return pluginsJsxXhtmlJS.omicron;
                case "pi":
                    return pluginsJsxXhtmlJS.pi;
                case "rho":
                    return pluginsJsxXhtmlJS.rho;
                case "sigmaf":
                    return pluginsJsxXhtmlJS.sigmaf;
                case "sigma":
                    return pluginsJsxXhtmlJS.sigma;
                case "tau":
                    return pluginsJsxXhtmlJS.tau;
                case "upsilon":
                    return pluginsJsxXhtmlJS.upsilon;
                case "phi":
                    return pluginsJsxXhtmlJS.phi;
                case "chi":
                    return pluginsJsxXhtmlJS.chi;
                case "psi":
                    return pluginsJsxXhtmlJS.psi;
                case "omega":
                    return pluginsJsxXhtmlJS.omega;
                case "thetasym":
                    return pluginsJsxXhtmlJS.thetasym;
                case "upsih":
                    return pluginsJsxXhtmlJS.upsih;
                case "piv":
                    return pluginsJsxXhtmlJS.piv;
                case "ensp":
                    return pluginsJsxXhtmlJS.ensp;
                case "emsp":
                    return pluginsJsxXhtmlJS.emsp;
                case "thinsp":
                    return pluginsJsxXhtmlJS.thinsp;
                case "zwnj":
                    return pluginsJsxXhtmlJS.zwnj;
                case "zwj":
                    return pluginsJsxXhtmlJS.zwj;
                case "lrm":
                    return pluginsJsxXhtmlJS.lrm;
                case "rlm":
                    return pluginsJsxXhtmlJS.rlm;
                case "ndash":
                    return pluginsJsxXhtmlJS.ndash;
                case "mdash":
                    return pluginsJsxXhtmlJS.mdash;
                case "lsquo":
                    return pluginsJsxXhtmlJS.lsquo;
                case "rsquo":
                    return pluginsJsxXhtmlJS.rsquo;
                case "sbquo":
                    return pluginsJsxXhtmlJS.sbquo;
                case "ldquo":
                    return pluginsJsxXhtmlJS.ldquo;
                case "rdquo":
                    return pluginsJsxXhtmlJS.rdquo;
                case "bdquo":
                    return pluginsJsxXhtmlJS.bdquo;
                case "dagger":
                    return pluginsJsxXhtmlJS.dagger;
                case "Dagger":
                    return pluginsJsxXhtmlJS.Dagger;
                case "bull":
                    return pluginsJsxXhtmlJS.bull;
                case "hellip":
                    return pluginsJsxXhtmlJS.hellip;
                case "permil":
                    return pluginsJsxXhtmlJS.permil;
                case "prime":
                    return pluginsJsxXhtmlJS.prime;
                case "Prime":
                    return pluginsJsxXhtmlJS.Prime;
                case "lsaquo":
                    return pluginsJsxXhtmlJS.lsaquo;
                case "rsaquo":
                    return pluginsJsxXhtmlJS.rsaquo;
                case "oline":
                    return pluginsJsxXhtmlJS.oline;
                case "frasl":
                    return pluginsJsxXhtmlJS.frasl;
                case "euro":
                    return pluginsJsxXhtmlJS.euro;
                case "image":
                    return pluginsJsxXhtmlJS.image;
                case "weierp":
                    return pluginsJsxXhtmlJS.weierp;
                case "real":
                    return pluginsJsxXhtmlJS.real;
                case "trade":
                    return pluginsJsxXhtmlJS.trade;
                case "alefsym":
                    return pluginsJsxXhtmlJS.alefsym;
                case "larr":
                    return pluginsJsxXhtmlJS.larr;
                case "uarr":
                    return pluginsJsxXhtmlJS.uarr;
                case "rarr":
                    return pluginsJsxXhtmlJS.rarr;
                case "darr":
                    return pluginsJsxXhtmlJS.darr;
                case "harr":
                    return pluginsJsxXhtmlJS.harr;
                case "crarr":
                    return pluginsJsxXhtmlJS.crarr;
                case "lArr":
                    return pluginsJsxXhtmlJS.lArr;
                case "uArr":
                    return pluginsJsxXhtmlJS.uArr;
                case "rArr":
                    return pluginsJsxXhtmlJS.rArr;
                case "dArr":
                    return pluginsJsxXhtmlJS.dArr;
                case "hArr":
                    return pluginsJsxXhtmlJS.hArr;
                case "forall":
                    return pluginsJsxXhtmlJS.forall;
                case "part":
                    return pluginsJsxXhtmlJS.part;
                case "exist":
                    return pluginsJsxXhtmlJS.exist;
                case "empty":
                    return pluginsJsxXhtmlJS.empty;
                case "nabla":
                    return pluginsJsxXhtmlJS.nabla;
                case "isin":
                    return pluginsJsxXhtmlJS.isin;
                case "notin":
                    return pluginsJsxXhtmlJS.notin;
                case "ni":
                    return pluginsJsxXhtmlJS.ni;
                case "prod":
                    return pluginsJsxXhtmlJS.prod;
                case "sum":
                    return pluginsJsxXhtmlJS.sum;
                case "minus":
                    return pluginsJsxXhtmlJS.minus;
                case "lowast":
                    return pluginsJsxXhtmlJS.lowast;
                case "radic":
                    return pluginsJsxXhtmlJS.radic;
                case "prop":
                    return pluginsJsxXhtmlJS.prop;
                case "infin":
                    return pluginsJsxXhtmlJS.infin;
                case "ang":
                    return pluginsJsxXhtmlJS.ang;
                case "and":
                    return pluginsJsxXhtmlJS.and;
                case "or":
                    return pluginsJsxXhtmlJS.or;
                case "cap":
                    return pluginsJsxXhtmlJS.cap;
                case "cup":
                    return pluginsJsxXhtmlJS.cup;
                case "number":
                    return pluginsJsxXhtmlJS.number;
                case "there4":
                    return pluginsJsxXhtmlJS.there4;
                case "sim":
                    return pluginsJsxXhtmlJS.sim;
                case "cong":
                    return pluginsJsxXhtmlJS.cong;
                case "asymp":
                    return pluginsJsxXhtmlJS.asymp;
                case "ne":
                    return pluginsJsxXhtmlJS.ne;
                case "equiv":
                    return pluginsJsxXhtmlJS.equiv;
                case "le":
                    return pluginsJsxXhtmlJS.le;
                case "ge":
                    return pluginsJsxXhtmlJS.ge;
                case "sub":
                    return pluginsJsxXhtmlJS.sub;
                case "sup":
                    return pluginsJsxXhtmlJS.sup;
                case "nsub":
                    return pluginsJsxXhtmlJS.nsub;
                case "sube":
                    return pluginsJsxXhtmlJS.sube;
                case "supe":
                    return pluginsJsxXhtmlJS.supe;
                case "oplus":
                    return pluginsJsxXhtmlJS.oplus;
                case "otimes":
                    return pluginsJsxXhtmlJS.otimes;
                case "perp":
                    return pluginsJsxXhtmlJS.perp;
                case "sdot":
                    return pluginsJsxXhtmlJS.sdot;
                case "lceil":
                    return pluginsJsxXhtmlJS.lceil;
                case "rceil":
                    return pluginsJsxXhtmlJS.rceil;
                case "lfloor":
                    return pluginsJsxXhtmlJS.lfloor;
                case "rfloor":
                    return pluginsJsxXhtmlJS.rfloor;
                case "lang":
                    return pluginsJsxXhtmlJS.lang;
                case "rang":
                    return pluginsJsxXhtmlJS.rang;
                case "loz":
                    return pluginsJsxXhtmlJS.loz;
                case "spades":
                    return pluginsJsxXhtmlJS.spades;
                case "clubs":
                    return pluginsJsxXhtmlJS.clubs;
                case "hearts":
                    return pluginsJsxXhtmlJS.hearts;
                case "diams":
                    return pluginsJsxXhtmlJS.diams;
            }
        }
        /*<@280>*/jsxReadEntity() {
            let /*<@3>*/str = "";
            let /*<@5>*/count = 0;
            let /*<@26>*/entity = void 0;
            let /*<@3>*/ch = this.input[this.state.pos];
            const /*<@5>*/startPos = ++this.state.pos;
            while (this.state.pos < this.input.length && count++ < 10) {
                ch = this.input[this.state.pos++];
                if (ch === ";") {
                    if (str[0] === "#") {
                        if (str[1] === "x") {
                            str = str.substr(2);
                            if (HEX_NUMBER.test(str))
                                entity = String.fromCodePoint(parseInt(str, 16));
                        }
                        else {
                            str = str.substr(1);
                            if (DECIMAL_NUMBER.test(str))
                                entity = String.fromCodePoint(parseInt(str, 10));
                        }
                    }
                    else {
                        entity = this.getJsxXhtmlJS(str);
                    }
                    break;
                }
                str += ch;
            }
            if (!entity) {
                this.state.pos = startPos;
                return "&";
            }
            return entity;
        }
        ;
        // Read a JSX identifier (valid tag or attribute name).
        //
        // Optimized version since JSX identifiers can"t contain
        // escape characters and so can be read as single slice.
        // Also assumes that first character was already checked
        // by isIdentifierStart in readToken.
        /*<@281>*/jsxReadWord() {
            let /*<@5>*/ch;
            const /*<@5>*/start = this.state.pos;
            do {
                ch = this.input.charCodeAt(++this.state.pos);
            } while (utilIdentifierJS.isIdentifierChar(ch) || ch === 45); // "-"
            return this.finishToken(this.tt.jsxName, this.input.slice(start, this.state.pos));
        }
        ;
        /*<@282>*/jsxParseIdentifier() {
            const /*<@69>*/node = this.startNode();
            if (this.match(this.tt.jsxName)) {
                node.name = (this.state./*<@69>*/value);
            }
            else if (this.state.type.keyword) {
                node.name = this.state.type.keyword;
            }
            else {
                this.unexpected();
            }
            this.next();
            return this.finishNode(node, "JSXIdentifier");
        }
        ;
        // Parse namespaced identifier.
        /*<@283>*/jsxParseNamespacedName() {
            const /*<@5>*/startPos = this.state.start;
            const /*<@35>*/startLoc = this.state.startLoc;
            const /*<@69>*/name = this.jsxParseIdentifier();
            if (!this.eat(this.tt.colon))
                return name;
            const /*<@69>*/node = this.startNodeAt(startPos, startLoc);
            node.namespace = name;
            node.name = this.jsxParseIdentifier();
            return this.finishNode(node, "JSXNamespacedName");
        }
        ;
        // Parses element name in any form - namespaced, member
        // or single identifier.
        /*<@284>*/jsxParseElementName() {
            const /*<@5>*/startPos = this.state.start;
            const /*<@35>*/startLoc = this.state.startLoc;
            let /*<@69>*/node = this.jsxParseNamespacedName();
            while (this.eat(this.tt.dot)) {
                const /*<@69>*/newNode = this.startNodeAt(startPos, startLoc);
                newNode.object = node;
                newNode.property = this.jsxParseIdentifier();
                node = this.finishNode(newNode, "JSXMemberExpression");
            }
            return node;
        }
        ;
        // Parses any type of JSX attribute value.
        /*<@285>*/jsxParseAttributeValue() {
            let /*<@69>*/node;
            switch (this.state.type) {
                case this.tt.braceL:
                    node = this.jsxParseExpressionContainer();
                    if (node./*<@69>*/expression.type === "JSXEmptyExpression") {
                        this.raise(node.start, "JSX attributes must only be assigned a non-empty expression");
                    }
                    else {
                        return node;
                    }
                case this.tt.jsxTagStart:
                case this.tt.string:
                    node = this.parseExprAtom();
                    node.extra = null;
                    return node;
                default:
                    this.raise(this.state.start, "JSX value should be either an expression or a quoted JSX text");
            }
        }
        ;
        // JSXEmptyExpression is unique type since it doesn't actually parse anything,
        // and so it should start at the end of last read token (left brace) and finish
        // at the beginning of the next one (right brace).
        /*<@286>*/jsxParseEmptyExpression() {
            const /*<@69>*/node = this.startNodeAt(this.state.lastTokEnd, this.state.lastTokEndLoc);
            return this.finishNodeAt(node, "JSXEmptyExpression", this.state.start, this.state.startLoc);
        }
        ;
        // Parse JSX spread child
        /*<@287>*/jsxParseSpreadChild() {
            const /*<@69>*/node = this.startNode();
            this.expect(this.tt.braceL);
            this.expect(this.tt.ellipsis);
            node.expression = this.parseExpression();
            this.expect(this.tt.braceR);
            return this.finishNode(node, "JSXSpreadChild");
        }
        ;
        // Parses JSX expression enclosed into curly brackets.
        /*<@288>*/jsxParseExpressionContainer() {
            const /*<@69>*/node = this.startNode();
            this.next();
            if (this.match(this.tt.braceR)) {
                node.expression = this.jsxParseEmptyExpression();
            }
            else {
                node.expression = this.parseExpression();
            }
            this.expect(this.tt.braceR);
            return this.finishNode(node, "JSXExpressionContainer");
        }
        ;
        // Parses following JSX attribute name-value pair.
        /*<@289>*/jsxParseAttribute() {
            const /*<@69>*/node = this.startNode();
            if (this.eat(this.tt.braceL)) {
                this.expect(this.tt.ellipsis);
                node.argument = this.parseMaybeAssign();
                this.expect(this.tt.braceR);
                return this.finishNode(node, "JSXSpreadAttribute");
            }
            node.name = this.jsxParseNamespacedName();
            node.value = (this.eat(this.tt.eq) ? this.jsxParseAttributeValue() : null);
            return this.finishNode(node, "JSXAttribute");
        }
        ;
        // Parses JSX opening tag starting after "<".
        /*<@290>*/jsxParseOpeningElementAt(/*<@5>*/startPos, /*<@35>*/startLoc) {
            const /*<@69>*/node = this.startNodeAt(startPos, startLoc);
            node.attributes = /*<@361>*/[];
            node.name = this.jsxParseElementName();
            while (!this.match(this.tt.slash) && !this.match(this.tt.jsxTagEnd)) {
                node.attributes.push(this.jsxParseAttribute());
            }
            node.selfClosing = this.eat(this.tt.slash);
            this.expect(this.tt.jsxTagEnd);
            return this.finishNode(node, "JSXOpeningElement");
        }
        ;
        // Parses JSX closing tag starting after "</".
        /*<@291>*/jsxParseClosingElementAt(/*<@5>*/startPos, /*<@35>*/startLoc) {
            const /*<@69>*/node = this.startNodeAt(startPos, startLoc);
            node.name = this.jsxParseElementName();
            this.expect(this.tt.jsxTagEnd);
            return this.finishNode(node, "JSXClosingElement");
        }
        ;
        // Parses entire JSX element, including it"s opening tag
        // (starting after "<"), attributes, contents and closing tag.
        /*<@292>*/jsxParseElementAt(/*<@5>*/startPos, /*<@35>*/startLoc) {
            const /*<@69>*/node = this.startNodeAt(startPos, startLoc);
            const /*<@361>*/children = /*<@361>*/[];
            const /*<@69>*/openingElement = this.jsxParseOpeningElementAt(startPos, startLoc);
            let /*<@111>*/closingElement = null;
            if (!openingElement.selfClosing) {
                contents: for (;;) {
                    switch (this.state.type) {
                        case this.tt.jsxTagStart:
                            startPos = this.state.start;
                            startLoc = this.state.startLoc;
                            this.next();
                            if (this.eat(this.tt.slash)) {
                                closingElement = this.jsxParseClosingElementAt(startPos, startLoc);
                                break contents;
                            }
                            children.push(this.jsxParseElementAt(startPos, startLoc));
                            break;
                        case this.tt.jsxText:
                            children.push(this.parseExprAtom());
                            break;
                        case this.tt.braceL:
                            if (this.lookahead().type === this.tt.ellipsis) {
                                children.push(this.jsxParseSpreadChild());
                            }
                            else {
                                children.push(this.jsxParseExpressionContainer());
                            }
                            break;
                        // istanbul ignore next - should never han
                        default:
                            this.unexpected();
                    }
                }
                if (getQualifiedJSXName(closingElement./*<@69>*/name) !== getQualifiedJSXName(openingElement./*<@69>*/name)) {
                    this.raise(closingElement.start, "Expected corresponding JSX closing tag for <" + getQualifiedJSXName(openingElement./*<@69>*/name) + ">");
                }
            }
            node.openingElement = openingElement;
            node.closingElement = closingElement;
            node.children = /*<@119>*/children;
            if (this.match(this.tt.relational) && this.state.value === "<") {
                this.raise(this.state.start, "Adjacent JSX elements must be wrad in an enclosing tag");
            }
            return this.finishNode(node, "JSXElement");
        }
        ;
        // Parses entire JSX element from current position.
        /*<@293>*/jsxParseElement() {
            const /*<@5>*/startPos = this.state.start;
            const /*<@35>*/startLoc = this.state.startLoc;
            this.next();
            return this.jsxParseElementAt(startPos, startLoc);
        }
        ;
    }
    Parser.plugins = {};
    let /*<@72>*/parserIndexJS = Parser;
    // parser/expression.js
    const /*<@6>*/parserExpressionJS = /*<@6>*/{};
    // parser/statement.js
    const /*<@6>*/parserStatementJS = /*<@6>*/{};
    // parser/util.js
    const /*<@6>*/parserUtilJS = /*<@6>*/{};
    // plugins/estree.js
    function /*<@374>*/isSimpleProperty(/*<@69>*/node) {
        return node &&
            node.type === "Property" &&
            node.kind === "init" &&
            node.method === false;
    }
    function /*<@375>*/pluginsEstreeJS(/*<@71>*/instance) {
        instance.extends("checkDeclaration", function /*<@376>*/(/*<@94>*/inner) {
            return function /*<@377>*/(/*<@69>*/node) {
                if (isSimpleProperty(node)) {
                    this.checkDeclaration(node.value);
                }
                else {
                    inner.call(this, node);
                }
            };
        });
        instance.extends("checkGetterSetterParamCount", function /*<@378>*/() {
            return function /*<@379>*/(/*<@69>*/prop) {
                const /*<@5>*/paramCount = prop.kind === "get" ? 0 : 1;
                if (prop./*<@69>*/value.params.length !== paramCount) {
                    const /*<@22>*/start = prop.start;
                    if (prop.kind === "get") {
                        this.raise(start, "getter should have no params");
                    }
                    else {
                        this.raise(start, "setter should have exactly one param");
                    }
                }
            };
        });
        instance.extends("checkLVal", function /*<@380>*/(/*<@94>*/inner) {
            return function /*<@381>*/(/*<@69>*/expr, /*<@2>*/isBinding, /*<@6>*/checkClashes, /*<@26>*/contextDescription) {
                switch (expr.type) {
                    case "ObjectPattern":
                        expr.properties.forEach(/*<@382>*/(/*<@69>*/prop) => {
                            this.checkLVal(prop.type === "Property" ? prop.value : prop, isBinding, checkClashes, "object destructuring pattern");
                        });
                        break;
                    default:
                        inner.call(this, expr, isBinding, checkClashes, contextDescription);
                }
            };
        });
        instance.extends("checkPropClash", function /*<@383>*/() {
            return function /*<@384>*/(/*<@69>*/prop, /*<@6>*/propHash) {
                if (prop.computed || !isSimpleProperty(prop))
                    return;
                const /*<@69>*/key = prop.key;
                // It is either an Identifier or a String/NumericLiteral
                const /*<@297>*/name = key.type === "Identifier" ? key.name : String(key.value);
                if (name === "__proto__") {
                    if (propHash.proto)
                        this.raise(key.start, "Redefinition of __proto__ property");
                    propHash.proto = true;
                }
            };
        });
        instance.extends("isStrictBody", function /*<@385>*/() {
            return function /*<@386>*/(/*<@69>*/node, /*<@2>*/isExpression) {
                if (!isExpression && node./*<@69>*/body./*<@119>*/body.length > 0) {
                    for (const /*<@69>*/directive of node./*<@69>*/body./*<@119>*/body) {
                        if (directive.type === "ExpressionStatement" && directive./*<@69>*/expression.type === "Literal") {
                            if ((directive./*<@69>*/expression./*<@3>*/value) === "use strict")
                                return true;
                        }
                        else {
                            // Break for the first non literal expression
                            break;
                        }
                    }
                }
                return false;
            };
        });
        instance.extends("isValidDirective", function /*<@387>*/() {
            return function /*<@388>*/(/*<@69>*/stmt) {
                return stmt.type === "ExpressionStatement" &&
                    stmt./*<@69>*/expression.type === "Literal" &&
                    typeof stmt./*<@69>*/expression.value === "string" &&
                    (!stmt./*<@69>*/expression.extra || !stmt./*<@69>*/expression.extra.parenthesized);
            };
        });
        instance.extends("parseBlockBody", function /*<@389>*/(/*<@94>*/inner) {
            return function /*<@390>*/(/*<@69>*/node, /*<@60>*/allowDirectives, /*<@60>*/topLevel, /*<@44>*/end) {
                let /*<@71>*/thisobj = (/*<@71>*/this);
                inner.call(thisobj, node, allowDirectives, topLevel, end);
                node.directives.reverse().forEach(/*<@391>*/(/*<@69>*/directive) => {
                    node./*<@119>*/body.unshift(this.directiveToStmt(directive));
                });
                delete node.directives;
            };
        });
        instance.extends("parseClassMethod", function /*<@392>*/(/*<@94>*/inner) {
            return function /*<@393>*/(/*<@69>*/classBody, /*<@69>*/method, /*<@60>*/isGenerator, /*<@60>*/isAsync) {
                let /*<@71>*/thisobj = (/*<@71>*/this);
                inner.call(thisobj, classBody, method, isGenerator, isAsync);
                const /*<@119>*/body = (classBody./*<@119>*/body);
                body[body.length - 1].type = "MethodDefinition";
            };
        });
        instance.extends("parseExprAtom", function /*<@394>*/(/*<@94>*/inner) {
            return function /*<@395>*/(/*<@92>*/refShorthandDefaultPos) {
                let /*<@71>*/thisobj = (/*<@71>*/this);
                switch (thisobj.state.type) {
                    case tokenizerTypesJS.types.regexp:
                        return thisobj.estreeParseRegExpLiteral(thisobj.state./*<@226>*/value);
                    case tokenizerTypesJS.types.num:
                    case tokenizerTypesJS.types.string:
                        return thisobj.estreeParseLiteral(thisobj.state.value);
                    case tokenizerTypesJS.types._null:
                        return thisobj.estreeParseLiteral(null);
                    case tokenizerTypesJS.types._true:
                        return thisobj.estreeParseLiteral(true);
                    case tokenizerTypesJS.types._false:
                        return thisobj.estreeParseLiteral(false);
                    default:
                        return inner.call(thisobj, refShorthandDefaultPos);
                }
            };
        });
        instance.extends("parseLiteral", function /*<@396>*/(/*<@94>*/inner) {
            return function /*<@397>*/(/*<@6>*/value, /*<@26>*/type, /*<@22>*/startPos, /*<@35>*/startLoc) {
                const /*<@69>*/node = inner.call(value, type, startPos, startLoc);
                node.raw = node.extra./*<@103>*/raw;
                delete node.extra;
                return node;
            };
        });
        instance.extends("parseMethod", function /*<@398>*/(/*<@94>*/inner) {
            return function /*<@399>*/(/*<@69>*/node, /*<@60>*/isGenerator, /*<@60>*/isAsync) {
                let /*<@71>*/thisobj = (/*<@71>*/this);
                let /*<@69>*/funcNode = thisobj.startNode();
                funcNode.kind = node.kind; // provide kind, so inner method correctly sets state
                funcNode = inner.call(thisobj, funcNode, isGenerator, isAsync);
                delete funcNode.kind;
                node.value = thisobj.finishNode(funcNode, "FunctionExpression");
                return node;
            };
        });
        instance.extends("parseObjectMethod", function /*<@400>*/(/*<@94>*/inner) {
            return function /*<@401>*/(/*<@69>*/prop, /*<@2>*/isGenerator, /*<@2>*/isAsync, /*<@2>*/isPattern) {
                const /*<@69>*/node = inner.call(this, prop, isGenerator, isAsync, isPattern);
                if (node) {
                    if (node.kind === "method")
                        node.kind = "init";
                    node.type = "Property";
                }
                return node;
            };
        });
        instance.extends("parseObjectProperty", function /*<@402>*/(/*<@94>*/inner) {
            return function /*<@403>*/(/*<@69>*/prop, /*<@5>*/startPos, /*<@35>*/startLoc, /*<@2>*/isPattern, /*<@6>*/refShorthandDefaultPos) {
                const /*<@69>*/node = inner.call(this, prop, startPos, startLoc, isPattern, refShorthandDefaultPos);
                if (node) {
                    node.kind = "init";
                    node.type = "Property";
                }
                return node;
            };
        });
        instance.extends("toAssignable", function /*<@404>*/(/*<@94>*/inner) {
            return function /*<@405>*/(/*<@69>*/node, /*<@2>*/isBinding, /*<@26>*/contextDescription) {
                let /*<@71>*/thisobj = (/*<@71>*/this);
                if (isSimpleProperty(node)) {
                    thisobj.toAssignable((node./*<@69>*/value), isBinding, contextDescription);
                    return node;
                }
                else if (node.type === "ObjectExpression") {
                    node.type = "ObjectPattern";
                    for (const /*<@69>*/prop of (node.properties)) {
                        if (prop.kind === "get" || prop.kind === "set") {
                            thisobj.raise(prop.key.start, "Object pattern can't contain getter or setter");
                        }
                        else if (prop.method) {
                            thisobj.raise(prop.key.start, "Object pattern can't contain methods");
                        }
                        else {
                            thisobj.toAssignable(prop, isBinding, "object destructuring pattern");
                        }
                    }
                    return node;
                }
                return inner.call(this, node, isBinding, contextDescription);
            };
        });
    }
    // plugins/flow.js
    function /*<@406>*/pluginsFlowJS(/*<@71>*/instance) {
        instance.extends("parseFunctionBody", function /*<@407>*/(/*<@94>*/inner) {
            return function /*<@408>*/(/*<@69>*/node, /*<@2>*/allowExpression) {
                let /*<@71>*/thisObj = (/*<@71>*/this);
                if (thisObj.match(thisObj.tt.colon) && !allowExpression) {
                    // if allowExpression is true then we're parsing an arrow function and if
                    // there's a return type then it's been handled elsewhere
                    node.returnType = thisObj.flowParseTypeAndPredicateAnnotation();
                }
                return inner.call(thisObj, node, allowExpression);
            };
        });
        // interfaces
        instance.extends("parseStatement", function /*<@409>*/(/*<@94>*/inner) {
            return function /*<@410>*/(/*<@69>*/declaration, /*<@2>*/topLevel) {
                let /*<@71>*/thisObj = (/*<@71>*/this);
                // strict mode handling of `interface` since it's a reserved word
                if (thisObj.state.strict && thisObj.match(thisObj.tt.name) && thisObj.state.value === "interface") {
                    const /*<@69>*/node = thisObj.startNode();
                    thisObj.next();
                    return thisObj.flowParseInterface(node);
                }
                else {
                    return inner.call(thisObj, declaration, topLevel);
                }
            };
        });
        // declares, interfaces and type aliases
        instance.extends("parseExpressionStatement", function /*<@411>*/(/*<@94>*/inner) {
            return function /*<@412>*/(/*<@69>*/node, /*<@69>*/expr) {
                let /*<@71>*/thisObj = (/*<@71>*/this);
                if (expr.type === "Identifier") {
                    if (expr.name === "declare") {
                        if (thisObj.match(thisObj.tt._class) || thisObj.match(thisObj.tt.name) || thisObj.match(thisObj.tt._function) || thisObj.match(this.tt._var)) {
                            return thisObj.flowParseDeclare(node);
                        }
                    }
                    else if (thisObj.match(thisObj.tt.name)) {
                        if (expr.name === "interface") {
                            return thisObj.flowParseInterface(node);
                        }
                        else if (expr.name === "type") {
                            return thisObj.flowParseTypeAlias(node);
                        }
                    }
                }
                return inner.call(thisObj, node, expr);
            };
        });
        // export type
        instance.extends("shouldParseExportDeclaration", function /*<@413>*/(/*<@94>*/inner) {
            return function /*<@414>*/() {
                let /*<@71>*/thisObj = (/*<@71>*/this);
                return thisObj.isContextual("type")
                    || thisObj.isContextual("interface")
                    || inner.call(thisObj);
            };
        });
        instance.extends("parseConditional", function /*<@415>*/(/*<@94>*/inner) {
            return function /*<@416>*/(/*<@69>*/expr, /*<@2>*/noIn, /*<@5>*/startPos, /*<@35>*/startLoc, /*<@6>*/refNeedsArrowPos) {
                // only do the expensive clone if there is a question mark
                // and if we come from inside parens
                let /*<@71>*/thisObj = (/*<@71>*/this);
                if (refNeedsArrowPos && thisObj.match(this.tt.question)) {
                    const /*<@65>*/state = thisObj.state.clone();
                    try {
                        return inner.call(thisObj, expr, noIn, startPos, startLoc);
                    }
                    catch (err) {
                        if (err instanceof SyntaxError) {
                            thisObj.state = state;
                            refNeedsArrowPos.start = thisObj.state.start;
                            return expr;
                        }
                        else {
                            // istanbul ignore next: no such error is expected
                            throw err;
                        }
                    }
                }
                return inner.call(this, expr, noIn, startPos, startLoc);
            };
        });
        instance.extends("parseParenItem", function /*<@417>*/(/*<@94>*/inner) {
            return function /*<@418>*/(/*<@69>*/node, /*<@5>*/startPos, /*<@35>*/startLoc) {
                let /*<@71>*/thisObj = (/*<@71>*/this);
                node = inner.call(thisObj, node, startPos, startLoc);
                if (thisObj.eat(thisObj.tt.question)) {
                    node.optional = true;
                }
                if (thisObj.match(thisObj.tt.colon)) {
                    const /*<@69>*/typeCastNode = thisObj.startNodeAt(startPos, startLoc);
                    typeCastNode.expression = node;
                    typeCastNode.typeAnnotation = thisObj.flowParseTypeAnnotation();
                    return thisObj.finishNode(typeCastNode, "TypeCastExpression");
                }
                return node;
            };
        });
        instance.extends("parseExport", function /*<@419>*/(/*<@94>*/inner) {
            return function /*<@420>*/(/*<@69>*/node) {
                node = inner.call(this, node);
                if (node.type === "ExportNamedDeclaration") {
                    node.exportKind = node.exportKind || "value";
                }
                return node;
            };
        });
        instance.extends("parseExportDeclaration", function /*<@421>*/(/*<@94>*/inner) {
            return function /*<@422>*/(/*<@69>*/node) {
                let /*<@71>*/thisObj = (/*<@71>*/this);
                if (thisObj.isContextual("type")) {
                    node.exportKind = "type";
                    const /*<@69>*/declarationNode = thisObj.startNode();
                    thisObj.next();
                    if (thisObj.match(thisObj.tt.braceL)) {
                        // export type { foo, bar };
                        node.specifiers = thisObj.parseExportSpecifiers();
                        thisObj.parseExportFrom(node);
                        return null;
                    }
                    else {
                        // export type Foo = Bar;
                        return thisObj.flowParseTypeAlias(declarationNode);
                    }
                }
                else if (thisObj.isContextual("interface")) {
                    node.exportKind = "type";
                    const /*<@69>*/declarationNode = thisObj.startNode();
                    thisObj.next();
                    return thisObj.flowParseInterface(declarationNode);
                }
                else {
                    return inner.call(thisObj, node);
                }
            };
        });
        instance.extends("parseClassId", function /*<@423>*/(/*<@94>*/inner) {
            return function /*<@424>*/(/*<@69>*/node) {
                let /*<@71>*/thisObj = (/*<@71>*/this);
                inner.apply(thisObj, arguments);
                if (thisObj.isRelational("<")) {
                    node.typeParameters = thisObj.flowParseTypeParameterDeclaration();
                }
            };
        });
        // don't consider `void` to be a keyword as then it'll use the void token type
        // and set startExpr
        instance.extends("isKeyword", function /*<@425>*/(/*<@94>*/inner) {
            return function /*<@426>*/(/*<@3>*/name) {
                let /*<@71>*/thisObj = (/*<@71>*/this);
                if (thisObj.state.inType && name === "void") {
                    return false;
                }
                else {
                    return inner.call(thisObj, name);
                }
            };
        });
        // ensure that inside flow types, we bypass the jsx parser plugin
        instance.extends("readToken", function /*<@427>*/(/*<@94>*/inner) {
            return function /*<@428>*/(/*<@5>*/code) {
                let /*<@71>*/thisObj = (/*<@71>*/this);
                if (thisObj.state.inType && (code === 62 || code === 60)) {
                    return thisObj.finishOp(thisObj.tt.relational, 1);
                }
                else {
                    return inner.call(thisObj, code);
                }
            };
        });
        // don't lex any token as a jsx one inside a flow type
        instance.extends("jsx_readToken", function /*<@429>*/(/*<@94>*/inner) {
            return function /*<@430>*/() {
                let /*<@71>*/thisObj = (/*<@71>*/this);
                if (!thisObj.state.inType)
                    return inner.call(thisObj);
            };
        });
        instance.extends("toAssignable", function /*<@431>*/(/*<@94>*/inner) {
            return function /*<@432>*/(/*<@69>*/node, /*<@2>*/isBinding, /*<@3>*/contextDescription) {
                let /*<@71>*/thisObj = (/*<@71>*/this);
                if (node.type === "TypeCastExpression") {
                    return inner.call(thisObj, thisObj.typeCastToParameter(node), isBinding, contextDescription);
                }
                else {
                    return inner.call(thisObj, node, isBinding, contextDescription);
                }
            };
        });
        // turn type casts that we found in function parameter head into type annotated params
        instance.extends("toAssignableList", function /*<@433>*/(/*<@94>*/inner) {
            return function /*<@434>*/(/*<@119>*/exprList, /*<@2>*/isBinding, /*<@3>*/contextDescription) {
                let /*<@71>*/thisObj = (/*<@71>*/this);
                for (let /*<@5>*/i = 0; i < exprList.length; i++) {
                    const /*<@69>*/expr = exprList[i];
                    if (expr && expr.type === "TypeCastExpression") {
                        exprList[i] = thisObj.typeCastToParameter(expr);
                    }
                }
                return inner.call(thisObj, exprList, isBinding, contextDescription);
            };
        });
        // this is a list of nodes, from something like a call expression, we need to filter the
        // type casts that we've found that are illegal in this context
        instance.extends("toReferencedList", function /*<@435>*/() {
            return function /*<@436>*/(/*<@119>*/exprList) {
                for (let /*<@5>*/i = 0; i < exprList.length; i++) {
                    const /*<@69>*/expr = exprList[i];
                    if (expr && expr._exprListItem && expr.type === "TypeCastExpression") {
                        this.raise(expr.start, "Unexpected type cast");
                    }
                }
                return exprList;
            };
        });
        // parse an item inside a expression list eg. `(NODE, NODE)` where NODE represents
        // the position where this function is called
        instance.extends("parseExprListItem", function /*<@437>*/(/*<@94>*/inner) {
            return function /*<@438>*/(/*<@2>*/allowEmpty, /*<@6>*/refShorthandDefaultPos, /*<@92>*/refNeedsArrowPos) {
                let /*<@71>*/thisObj = (/*<@71>*/this);
                const /*<@69>*/container = thisObj.startNode();
                const /*<@69>*/node = inner.call(thisObj, allowEmpty, refShorthandDefaultPos, refNeedsArrowPos);
                if (thisObj.match(thisObj.tt.colon)) {
                    container._exprListItem = true;
                    container.expression = node;
                    container.typeAnnotation = thisObj.flowParseTypeAnnotation();
                    return thisObj.finishNode(container, "TypeCastExpression");
                }
                else {
                    return node;
                }
            };
        });
        instance.extends("checkLVal", function /*<@439>*/(/*<@94>*/inner) {
            return function /*<@440>*/(/*<@69>*/node, /*<@2>*/isBinding, /*<@6>*/checkClashes, /*<@26>*/contextDescription) {
                if (node.type !== "TypeCastExpression") {
                    return inner.apply(this, /*<@361>*/[node, isBinding, checkClashes, contextDescription]);
                }
            };
        });
        // parse class property type annotations
        instance.extends("parseClassProperty", function /*<@441>*/(/*<@94>*/inner) {
            return function /*<@442>*/(/*<@69>*/node) {
                let /*<@71>*/thisObj = (/*<@71>*/this);
                if (thisObj.match(thisObj.tt.colon)) {
                    node.typeAnnotation = thisObj.flowParseTypeAnnotation();
                }
                return inner.call(thisObj, node);
            };
        });
        // determine whether or not we're currently in the position where a class method would appear
        instance.extends("isClassMethod", function /*<@443>*/(/*<@94>*/inner) {
            return function /*<@444>*/() {
                let /*<@71>*/thisObj = (/*<@71>*/this);
                return thisObj.isRelational("<") || inner.call(thisObj);
            };
        });
        // determine whether or not we're currently in the position where a class property would appear
        instance.extends("isClassProperty", function /*<@445>*/(/*<@94>*/inner) {
            return function /*<@446>*/() {
                let /*<@71>*/thisObj = (/*<@71>*/this);
                return thisObj.match(thisObj.tt.colon) || inner.call(this);
            };
        });
        // parse type parameters for class methods
        instance.extends("parseClassMethod", function /*<@447>*/(/*<@94>*/inner) {
            return function /*<@448>*/(/*<@69>*/classBody, /*<@69>*/method, /*<@2>*/isGenerator, /*<@2>*/isAsync) {
                let /*<@71>*/thisObj = (/*<@71>*/this);
                if (method.variance) {
                    thisObj.unexpected(method.variance.start);
                }
                delete method.variance;
                if (thisObj.isRelational("<")) {
                    method.typeParameters = thisObj.flowParseTypeParameterDeclaration();
                }
                inner.call(thisObj, classBody, method, isGenerator, isAsync);
            };
        });
        // parse a the super class type parameters and implements
        instance.extends("parseClassSuper", function /*<@449>*/(/*<@94>*/inner) {
            return function /*<@450>*/(/*<@69>*/node, /*<@2>*/isStatement) {
                let /*<@71>*/thisObj = (/*<@71>*/this);
                inner.call(thisObj, node, isStatement);
                if (node.superClass && thisObj.isRelational("<")) {
                    node.superTypeParameters = thisObj.flowParseTypeParameterInstantiation();
                }
                if (thisObj.isContextual("implements")) {
                    thisObj.next();
                    const /*<@119>*/implemented = node.implements = /*<@361>*/[];
                    do {
                        const /*<@69>*/node = thisObj.startNode();
                        node.id = thisObj.parseIdentifier();
                        if (thisObj.isRelational("<")) {
                            node.typeParameters = thisObj.flowParseTypeParameterInstantiation();
                        }
                        else {
                            node.typeParameters = null;
                        }
                        implemented.push(thisObj.finishNode(node, "ClassImplements"));
                    } while (thisObj.eat(thisObj.tt.comma));
                }
            };
        });
        instance.extends("parsePropertyName", function /*<@451>*/(/*<@94>*/inner) {
            return function /*<@452>*/(/*<@69>*/node) {
                let /*<@71>*/thisObj = (/*<@71>*/this);
                const /*<@111>*/variance = thisObj.flowParseVariance();
                const /*<@69>*/key = inner.call(thisObj, node);
                node.variance = variance;
                return key;
            };
        });
        // parse type parameters for object method shorthand
        instance.extends("parseObjPropValue", function /*<@453>*/(/*<@94>*/inner) {
            return function /*<@454>*/(/*<@69>*/prop) {
                let /*<@71>*/thisObj = (/*<@71>*/this);
                if (prop.variance) {
                    thisObj.unexpected(prop.variance.start);
                }
                delete prop.variance;
                let /*<@111>*/typeParameters = void 0;
                // method shorthand
                if (thisObj.isRelational("<")) {
                    typeParameters = thisObj.flowParseTypeParameterDeclaration();
                    if (!thisObj.match(thisObj.tt.parenL))
                        thisObj.unexpected();
                }
                inner.apply(thisObj, arguments);
                // add typeParameters if we found them
                if (typeParameters) {
                    (prop./*<@69>*/value || prop).typeParameters = typeParameters;
                }
            };
        });
        instance.extends("parseAssignableListItemTypes", function /*<@455>*/() {
            return function /*<@456>*/(/*<@69>*/param) {
                let /*<@71>*/thisObj = (/*<@71>*/this);
                if (thisObj.eat(thisObj.tt.question)) {
                    param.optional = true;
                }
                if (thisObj.match(thisObj.tt.colon)) {
                    param.typeAnnotation = thisObj.flowParseTypeAnnotation();
                }
                thisObj.finishNode(param, param.type);
                return param;
            };
        });
        instance.extends("parseMaybeDefault", function /*<@457>*/(/*<@94>*/inner) {
            return function /*<@458>*/(/*<@22>*/startPos, /*<@35>*/startLoc, /*<@69>*/left) {
                const /*<@69>*/node = inner.apply(this, /*<@361>*/[startPos, startLoc, left]);
                if (node.type === "AssignmentPattern" && node.typeAnnotation && node.right./*<@5>*/start < node.typeAnnotation./*<@5>*/start) {
                    this.raise(node.typeAnnotation.start, "Type annotations must come before default assignments, e.g. instead of `age = 25: int` use `age: int = 25`");
                }
                return node;
            };
        });
        // parse typeof and type imports
        instance.extends("parseImportSpecifiers", function /*<@459>*/(/*<@94>*/inner) {
            return function /*<@460>*/(/*<@69>*/node) {
                let /*<@71>*/thisObj = (/*<@71>*/this);
                node.importKind = "value";
                let /*<@26>*/kind = null;
                if (thisObj.match(thisObj.tt._typeof)) {
                    kind = "typeof";
                }
                else if (thisObj.isContextual("type")) {
                    kind = "type";
                }
                if (kind) {
                    const /*<@65>*/lh = thisObj.lookahead();
                    if ((lh.type === thisObj.tt.name && lh.value !== "from") || lh.type === thisObj.tt.braceL || lh.type === thisObj.tt.star) {
                        this.next();
                        node.importKind = kind;
                    }
                }
                inner.call(this, node);
            };
        });
        // parse import-type/typeof shorthand
        instance.extends("parseImportSpecifier", function /*<@461>*/() {
            return function /*<@462>*/(/*<@69>*/node) {
                let /*<@71>*/thisObj = (/*<@71>*/this);
                const /*<@69>*/specifier = thisObj.startNode();
                const /*<@5>*/firstIdentLoc = thisObj.state.start;
                const /*<@69>*/firstIdent = thisObj.parseIdentifier(true);
                let /*<@26>*/specifierTypeKind = null;
                if (firstIdent.name === "type") {
                    specifierTypeKind = "type";
                }
                else if (firstIdent.name === "typeof") {
                    specifierTypeKind = "typeof";
                }
                let /*<@2>*/isBinding = false;
                if (thisObj.isContextual("as")) {
                    const /*<@69>*/as_ident = thisObj.parseIdentifier(true);
                    if (specifierTypeKind !== null && !thisObj.match(thisObj.tt.name) && !thisObj.state./*<@44>*/type.keyword) {
                        // `import {type as ,` or `import {type as }`
                        specifier.imported = as_ident;
                        specifier.importKind = specifierTypeKind;
                        specifier.local = as_ident.__clone();
                    }
                    else {
                        // `import {type as foo`
                        specifier.imported = firstIdent;
                        specifier.importKind = null;
                        specifier.local = thisObj.parseIdentifier();
                    }
                }
                else if (specifierTypeKind !== null && (thisObj.match(thisObj.tt.name) || this.state.type.keyword)) {
                    // `import {type foo`
                    specifier.imported = thisObj.parseIdentifier(true);
                    specifier.importKind = specifierTypeKind;
                    if (thisObj.eatContextual("as")) {
                        specifier.local = thisObj.parseIdentifier();
                    }
                    else {
                        isBinding = true;
                        specifier.local = specifier.imported.__clone();
                    }
                }
                else {
                    isBinding = true;
                    specifier.imported = firstIdent;
                    specifier.importKind = null;
                    specifier.local = specifier.imported.__clone();
                }
                if ((node.importKind === "type" || node.importKind === "typeof") &&
                    (specifier.importKind === "type" || specifier.importKind === "typeof")) {
                    thisObj.raise(firstIdentLoc, "`The `type` and `typeof` keywords on named imports can only be used on regular `import` statements. It cannot be used with `import type` or `import typeof` statements`");
                }
                if (isBinding)
                    thisObj.checkReservedWord(specifier.local./*<@3>*/name, specifier./*<@5>*/start, true, true);
                thisObj.checkLVal(specifier.local, true, undefined, "import specifier");
                node.specifiers.push(thisObj.finishNode(specifier, "ImportSpecifier"));
            };
        });
        // parse function type parameters - function foo<T>() {}
        instance.extends("parseFunctionParams", function /*<@463>*/(/*<@94>*/inner) {
            return function /*<@464>*/(/*<@69>*/node) {
                let /*<@71>*/thisObj = (/*<@71>*/this);
                if (thisObj.isRelational("<")) {
                    node.typeParameters = thisObj.flowParseTypeParameterDeclaration();
                }
                inner.call(thisObj, node);
            };
        });
        // parse flow type annotations on variable declarator heads - let foo: string = bar
        instance.extends("parseVarHead", function /*<@465>*/(/*<@94>*/inner) {
            return function /*<@466>*/(/*<@69>*/decl) {
                let /*<@71>*/thisObj = (/*<@71>*/this);
                inner.call(thisObj, decl);
                if (thisObj.match(thisObj.tt.colon)) {
                    decl./*<@69>*/id.typeAnnotation = thisObj.flowParseTypeAnnotation();
                    this.finishNode(decl.id, decl./*<@69>*/id.type);
                }
            };
        });
        // parse the return type of an async arrow function - let foo = (async (): int => {});
        instance.extends("parseAsyncArrowFromCallExpression", function /*<@467>*/(/*<@94>*/inner) {
            return function /*<@468>*/(/*<@69>*/node, /*<@94>*/call) {
                let /*<@71>*/thisObj = (/*<@71>*/this);
                if (thisObj.match(thisObj.tt.colon)) {
                    const /*<@2>*/oldNoAnonFunctionType = thisObj.state.noAnonFunctionType;
                    thisObj.state.noAnonFunctionType = true;
                    node.returnType = thisObj.flowParseTypeAnnotation();
                    thisObj.state.noAnonFunctionType = oldNoAnonFunctionType;
                }
                return inner.call(thisObj, node, call);
            };
        });
        // todo description
        instance.extends("shouldParseAsyncArrow", function /*<@469>*/(/*<@94>*/inner) {
            return function /*<@470>*/() {
                let /*<@71>*/thisObj = (/*<@71>*/this);
                return thisObj.match(thisObj.tt.colon) || inner.call(thisObj);
            };
        });
        // We need to support type parameter declarations for arrow functions. This
        // is tricky. There are three situations we need to handle
        //
        // 1. This is either JSX or an arrow function. We'll try JSX first. If that
        //    fails, we'll try an arrow function. If that fails, we'll throw the JSX
        //    error.
        // 2. This is an arrow function. We'll parse the type parameter declaration,
        //    parse the rest, make sure the rest is an arrow function, and go from
        //    there
        // 3. This is neither. Just call the inner function
        instance.extends("parseMaybeAssign", function /*<@471>*/(/*<@94>*/inner) {
            return function /*<@472>*/(/*<@60>*/noIn, /*<@92>*/refShorthandDefaultPos, /*<@94>*/afterLeftParse, /*<@92>*/refNeedsArrowPos) {
                let /*<@71>*/thisObj = (/*<@71>*/this);
                let /*<@473>*/jsxError = null;
                if (thisObj.tt.jsxTagStart && thisObj.match(thisObj.tt.jsxTagStart)) {
                    const /*<@65>*/state = thisObj.state.clone();
                    try {
                        return inner.apply(thisObj, /*<@361>*/[noIn, refShorthandDefaultPos, afterLeftParse, refNeedsArrowPos]);
                    }
                    catch (err) {
                        if (err instanceof SyntaxError) {
                            thisObj.state = state;
                            jsxError = err;
                        }
                        else {
                            // istanbul ignore next: no such error is expected
                            throw err;
                        }
                    }
                }
                if (jsxError != null || thisObj.isRelational("<")) {
                    // Need to push something onto the context to stop
                    // the JSX plugin from messing with the tokens
                    thisObj.state.context.push(tokenizerContextJS.types.parenExpression);
                    let /*<@111>*/arrowExpression = void 0;
                    let /*<@111>*/typeParameters = void 0;
                    try {
                        typeParameters = thisObj.flowParseTypeParameterDeclaration();
                        arrowExpression = inner.apply(thisObj, /*<@361>*/[noIn, refShorthandDefaultPos, afterLeftParse, refNeedsArrowPos]);
                        arrowExpression.typeParameters = typeParameters;
                        thisObj.resetStartLocationFromNode(arrowExpression, typeParameters);
                    }
                    catch (err) {
                        thisObj.state.context.pop();
                        throw jsxError || err;
                    }
                    thisObj.state.context.pop();
                    if (arrowExpression.type === "ArrowFunctionExpression") {
                        return arrowExpression;
                    }
                    else if (jsxError != null) {
                        throw jsxError;
                    }
                    else {
                        thisObj.raise(typeParameters.start, "Expected an arrow function after this type parameter declaration");
                    }
                }
                return inner.apply(this, /*<@361>*/[noIn, refShorthandDefaultPos, afterLeftParse, refNeedsArrowPos]);
            };
        });
        // handle return types for arrow functions
        instance.extends("parseArrow", function /*<@474>*/(/*<@94>*/inner) {
            return function /*<@475>*/(/*<@69>*/node) {
                let /*<@71>*/thisObj = (/*<@71>*/this);
                if (this.match(thisObj.tt.colon)) {
                    const /*<@65>*/state = thisObj.state.clone();
                    try {
                        const /*<@2>*/oldNoAnonFunctionType = thisObj.state.noAnonFunctionType;
                        thisObj.state.noAnonFunctionType = true;
                        const /*<@69>*/returnType = thisObj.flowParseTypeAndPredicateAnnotation();
                        thisObj.state.noAnonFunctionType = oldNoAnonFunctionType;
                        if (thisObj.canInsertSemicolon())
                            thisObj.unexpected();
                        if (!thisObj.match(thisObj.tt.arrow))
                            thisObj.unexpected();
                        // assign after it is clear it is an arrow
                        node.returnType = returnType;
                    }
                    catch (err) {
                        if (err instanceof SyntaxError) {
                            thisObj.state = state;
                        }
                        else {
                            // istanbul ignore next: no such error is expected
                            throw err;
                        }
                    }
                }
                return inner.call(thisObj, node);
            };
        });
        instance.extends("shouldParseArrow", function /*<@476>*/(/*<@94>*/inner) {
            return function /*<@477>*/() {
                let /*<@71>*/thisObj = (/*<@71>*/this);
                return this.match(thisObj.tt.colon) || inner.call(thisObj);
            };
        });
    }
    // plugins/jsx/xhtml.js
    const /*<@478>*/pluginsJsxXhtmlJS = /*<@478>*/{
        quot: "\u0022",
        amp: "&",
        apos: "\u0027",
        lt: "<",
        gt: ">",
        nbsp: "\u00A0",
        iexcl: "\u00A1",
        cent: "\u00A2",
        pound: "\u00A3",
        curren: "\u00A4",
        yen: "\u00A5",
        brvbar: "\u00A6",
        sect: "\u00A7",
        uml: "\u00A8",
        copy: "\u00A9",
        ordf: "\u00AA",
        laquo: "\u00AB",
        not: "\u00AC",
        shy: "\u00AD",
        reg: "\u00AE",
        macr: "\u00AF",
        deg: "\u00B0",
        plusmn: "\u00B1",
        sup2: "\u00B2",
        sup3: "\u00B3",
        acute: "\u00B4",
        micro: "\u00B5",
        para: "\u00B6",
        middot: "\u00B7",
        cedil: "\u00B8",
        sup1: "\u00B9",
        ordm: "\u00BA",
        raquo: "\u00BB",
        frac14: "\u00BC",
        frac12: "\u00BD",
        frac34: "\u00BE",
        iquest: "\u00BF",
        Agrave: "\u00C0",
        Aacute: "\u00C1",
        Acirc: "\u00C2",
        Atilde: "\u00C3",
        Auml: "\u00C4",
        Aring: "\u00C5",
        AElig: "\u00C6",
        Ccedil: "\u00C7",
        Egrave: "\u00C8",
        Eacute: "\u00C9",
        Ecirc: "\u00CA",
        Euml: "\u00CB",
        Igrave: "\u00CC",
        Iacute: "\u00CD",
        Icirc: "\u00CE",
        Iuml: "\u00CF",
        ETH: "\u00D0",
        Ntilde: "\u00D1",
        Ograve: "\u00D2",
        Oacute: "\u00D3",
        Ocirc: "\u00D4",
        Otilde: "\u00D5",
        Ouml: "\u00D6",
        times: "\u00D7",
        Oslash: "\u00D8",
        Ugrave: "\u00D9",
        Uacute: "\u00DA",
        Ucirc: "\u00DB",
        Uuml: "\u00DC",
        Yacute: "\u00DD",
        THORN: "\u00DE",
        szlig: "\u00DF",
        agrave: "\u00E0",
        aacute: "\u00E1",
        acirc: "\u00E2",
        atilde: "\u00E3",
        auml: "\u00E4",
        aring: "\u00E5",
        aelig: "\u00E6",
        ccedil: "\u00E7",
        egrave: "\u00E8",
        eacute: "\u00E9",
        ecirc: "\u00EA",
        euml: "\u00EB",
        igrave: "\u00EC",
        iacute: "\u00ED",
        icirc: "\u00EE",
        iuml: "\u00EF",
        eth: "\u00F0",
        ntilde: "\u00F1",
        ograve: "\u00F2",
        oacute: "\u00F3",
        ocirc: "\u00F4",
        otilde: "\u00F5",
        ouml: "\u00F6",
        divide: "\u00F7",
        oslash: "\u00F8",
        ugrave: "\u00F9",
        uacute: "\u00FA",
        ucirc: "\u00FB",
        uuml: "\u00FC",
        yacute: "\u00FD",
        thorn: "\u00FE",
        yuml: "\u00FF",
        OElig: "\u0152",
        oelig: "\u0153",
        Scaron: "\u0160",
        scaron: "\u0161",
        Yuml: "\u0178",
        fnof: "\u0192",
        circ: "\u02C6",
        tilde: "\u02DC",
        Alpha: "\u0391",
        Beta: "\u0392",
        Gamma: "\u0393",
        Delta: "\u0394",
        Epsilon: "\u0395",
        Zeta: "\u0396",
        Eta: "\u0397",
        Theta: "\u0398",
        Iota: "\u0399",
        Kappa: "\u039A",
        Lambda: "\u039B",
        Mu: "\u039C",
        Nu: "\u039D",
        Xi: "\u039E",
        Omicron: "\u039F",
        Pi: "\u03A0",
        Rho: "\u03A1",
        Sigma: "\u03A3",
        Tau: "\u03A4",
        Upsilon: "\u03A5",
        Phi: "\u03A6",
        Chi: "\u03A7",
        Psi: "\u03A8",
        Omega: "\u03A9",
        alpha: "\u03B1",
        beta: "\u03B2",
        gamma: "\u03B3",
        delta: "\u03B4",
        epsilon: "\u03B5",
        zeta: "\u03B6",
        eta: "\u03B7",
        theta: "\u03B8",
        iota: "\u03B9",
        kappa: "\u03BA",
        lambda: "\u03BB",
        mu: "\u03BC",
        nu: "\u03BD",
        xi: "\u03BE",
        omicron: "\u03BF",
        pi: "\u03C0",
        rho: "\u03C1",
        sigmaf: "\u03C2",
        sigma: "\u03C3",
        tau: "\u03C4",
        upsilon: "\u03C5",
        phi: "\u03C6",
        chi: "\u03C7",
        psi: "\u03C8",
        omega: "\u03C9",
        thetasym: "\u03D1",
        upsih: "\u03D2",
        piv: "\u03D6",
        ensp: "\u2002",
        emsp: "\u2003",
        thinsp: "\u2009",
        zwnj: "\u200C",
        zwj: "\u200D",
        lrm: "\u200E",
        rlm: "\u200F",
        ndash: "\u2013",
        mdash: "\u2014",
        lsquo: "\u2018",
        rsquo: "\u2019",
        sbquo: "\u201A",
        ldquo: "\u201C",
        rdquo: "\u201D",
        bdquo: "\u201E",
        dagger: "\u2020",
        Dagger: "\u2021",
        bull: "\u2022",
        hellip: "\u2026",
        permil: "\u2030",
        prime: "\u2032",
        Prime: "\u2033",
        lsaquo: "\u2039",
        rsaquo: "\u203A",
        oline: "\u203E",
        frasl: "\u2044",
        euro: "\u20AC",
        image: "\u2111",
        weierp: "\u2118",
        real: "\u211C",
        trade: "\u2122",
        alefsym: "\u2135",
        larr: "\u2190",
        uarr: "\u2191",
        rarr: "\u2192",
        darr: "\u2193",
        harr: "\u2194",
        crarr: "\u21B5",
        lArr: "\u21D0",
        uArr: "\u21D1",
        rArr: "\u21D2",
        dArr: "\u21D3",
        hArr: "\u21D4",
        forall: "\u2200",
        part: "\u2202",
        exist: "\u2203",
        empty: "\u2205",
        nabla: "\u2207",
        isin: "\u2208",
        notin: "\u2209",
        ni: "\u220B",
        prod: "\u220F",
        sum: "\u2211",
        minus: "\u2212",
        lowast: "\u2217",
        radic: "\u221A",
        prop: "\u221D",
        infin: "\u221E",
        ang: "\u2220",
        and: "\u2227",
        or: "\u2228",
        cap: "\u2229",
        cup: "\u222A",
        "number": "\u222B",
        there4: "\u2234",
        sim: "\u223C",
        cong: "\u2245",
        asymp: "\u2248",
        ne: "\u2260",
        equiv: "\u2261",
        le: "\u2264",
        ge: "\u2265",
        sub: "\u2282",
        sup: "\u2283",
        nsub: "\u2284",
        sube: "\u2286",
        supe: "\u2287",
        oplus: "\u2295",
        otimes: "\u2297",
        perp: "\u22A5",
        sdot: "\u22C5",
        lceil: "\u2308",
        rceil: "\u2309",
        lfloor: "\u230A",
        rfloor: "\u230B",
        lang: "\u2329",
        rang: "\u232A",
        loz: "\u25CA",
        spades: "\u2660",
        clubs: "\u2663",
        hearts: "\u2665",
        diams: "\u2666"
    };
    tokenizerContextJS.types.j_oTag = new TokContext("<tag", false);
    tokenizerContextJS.types.j_cTag = new TokContext("</tag", false);
    tokenizerContextJS.types.j_expr = new TokContext("<tag>...</tag>", true, true);
    tokenizerTypesJS.types.jsxName = new TokenType("jsxName", new TokenConfig());
    tokenizerTypesJS.types.jsxText = new TokenType("jsxText", new TokenConfig(undefined, true));
    tokenizerTypesJS.types.jsxTagStart = new TokenType("jsxTagStart", new TokenConfig(undefined, false, true));
    tokenizerTypesJS.types.jsxTagEnd = new TokenType("jsxTagEnd", new TokenConfig());
    tokenizerTypesJS.types.jsxTagStart.updateContext = function /*<@479>*/() {
        let /*<@63>*/thisObj = (/*<@63>*/this);
        thisObj.state.context.push(tokenizerContextJS.types./*<@58>*/j_expr); // treat as beginning of JSX expression
        thisObj.state.context.push(tokenizerContextJS.types./*<@58>*/j_oTag); // start opening tag context
        thisObj.state.exprAllowed = false;
    };
    tokenizerTypesJS.types.jsxTagEnd.updateContext = function /*<@480>*/(/*<@48>*/prevType) {
        let /*<@63>*/thisObj = (/*<@63>*/this);
        const /*<@61>*/out = thisObj.state.context.pop();
        if (out === tokenizerContextJS.types.j_oTag && prevType === tokenizerTypesJS.types.slash || out === tokenizerContextJS.types.j_cTag) {
            thisObj.state.context.pop();
            thisObj.state.exprAllowed = thisObj.curContext() === tokenizerContextJS.types.j_expr;
        }
        else {
            thisObj.state.exprAllowed = true;
        }
    };
    // Reads inline JSX contents token.
    // Transforms JSX element name to string.
    function /*<@481>*/getQualifiedJSXName(/*<@69>*/object) {
        if (object.type === "JSXIdentifier") {
            return object./*<@3>*/name;
        }
        if (object.type === "JSXNamespacedName") {
            return object.namespace.name + ":" + object./*<@69>*/name.name;
        }
        if (object.type === "JSXMemberExpression") {
            return getQualifiedJSXName(object./*<@69>*/object) + "." + getQualifiedJSXName(object.property);
        }
    }
    // Parse next token as JSX identifier
    //export default function(instance) {
    function /*<@482>*/pluginsJsxIndexJS(/*<@71>*/instance) {
        instance.extends("parseExprAtom", function /*<@483>*/(/*<@94>*/inner) {
            return function /*<@484>*/(/*<@6>*/refShortHandDefaultPos) {
                let /*<@71>*/thisObj = (/*<@71>*/this);
                if (thisObj.match(thisObj.tt.jsxText)) {
                    const /*<@69>*/node = thisObj.parseLiteral(thisObj.state.value, "JSXText");
                    // https://github.com/babel/babel/issues/2078
                    node.extra = null;
                    return node;
                }
                else if (thisObj.match(tokenizerTypesJS.types.jsxTagStart)) {
                    return thisObj.jsxParseElement();
                }
                else {
                    return inner.call(thisObj, refShortHandDefaultPos);
                }
            };
        });
        instance.extends("readToken", function /*<@485>*/(/*<@94>*/inner) {
            return function /*<@486>*/(/*<@5>*/code) {
                let /*<@71>*/thisObj = (/*<@71>*/this);
                if (thisObj.state.inPropertyName)
                    return inner.call(thisObj, code);
                const /*<@58>*/context = thisObj.curContext();
                if (context === tokenizerContextJS.types.j_expr) {
                    return thisObj.jsxReadToken();
                }
                if (context === tokenizerContextJS.types.j_oTag || context === tokenizerContextJS.types.j_cTag) {
                    if (utilIdentifierJS.isIdentifierStart(code)) {
                        return thisObj.jsxReadWord();
                    }
                    if (code === 62) {
                        ++thisObj.state.pos;
                        return thisObj.finishToken(thisObj.tt.jsxTagEnd);
                    }
                    if ((code === 34 || code === 39) && context === tokenizerContextJS.types.j_oTag) {
                        return thisObj.jsxReadString(code);
                    }
                }
                if (code === 60 && this.state.exprAllowed) {
                    ++this.state.pos;
                    return this.finishToken(this.tt.jsxTagStart);
                }
                return inner.call(this, code);
            };
        });
        instance.extends("updateContext", function /*<@487>*/(/*<@94>*/inner) {
            return function /*<@488>*/(/*<@44>*/prevType) {
                let /*<@71>*/thisObj = (/*<@71>*/this);
                const tc = tokenizerContextJS.types;
                if (thisObj.match(thisObj.tt.braceL)) {
                    const /*<@58>*/curContext = thisObj.curContext();
                    if (curContext === tc.j_oTag) {
                        thisObj.state.context.push(tc.braceExpression);
                    }
                    else if (curContext === tc.j_expr) {
                        thisObj.state.context.push(tc.templateQuasi);
                    }
                    else {
                        inner.call(thisObj, prevType);
                    }
                    thisObj.state.exprAllowed = true;
                }
                else if (thisObj.match(thisObj.tt.slash) && prevType === thisObj.tt.jsxTagStart) {
                    thisObj.state.context.length -= 2; // do not consider JSX expr -> JSX open tag -> ... anymore
                    thisObj.state.context.push(tc./*<@58>*/j_cTag); // reconsider as closing tag context
                    thisObj.state.exprAllowed = false;
                }
                else {
                    return inner.call(this, prevType);
                }
            };
        });
    }
    class /*<@490>*/Benchmark {
        constructor(/*<@5>*/verbose = 0) {
            let /*<@491>*/sources = /*<@491>*/[];
            const /*<@491>*/files = /*<@491>*/[
                /*<@361>*/["./Babylon/resource/air-blob.js", {}],
                /*<@361>*/["./Babylon/resource/basic-blob.js", {}],
                /*<@361>*/["./Babylon/resource/inspector-blob.js", {}],
                /*<@361>*/["./Babylon/resource/babylon-blob.js", /*<@493>*/{ sourceType: "module" }]
            ];
            for (let /*<@361>*/[file, options] of files) {
                function /*<@494>*/appendSource(/*<@3>*/s) {
                    sources.push(/*<@361>*/[/*<@3>*/file, s, options]);
                }
                let s;
                appendSource(read(/*<@3>*/file));
            }
            this.sources = sources;
        }
        /*<@492>*/runIteration() {
            const /*<@72>*/Parser = parserIndexJS;
            const { /*<@6>*/plugins } = parserIndexJS;
            const { types: tokTypes } = tokenizerTypesJS;
            const /*<@375>*/estreePlugin = pluginsEstreeJS;
            const /*<@406>*/flowPlugin = pluginsFlowJS;
            const /*<@482>*/jsxPlugin = pluginsJsxIndexJS;
            plugins.estree = estreePlugin;
            plugins.flow = flowPlugin;
            plugins.jsx = jsxPlugin;
            function /*<@495>*/parse(/*<@3>*/input, options) {
                return new Parser(options, input).parse();
            }
            function /*<@496>*/parseExpression(/*<@3>*/input, options) {
                const /*<@71>*/parser = new Parser(options, input);
                if (parser.options.strictMode) {
                    parser.state.strict = true;
                }
                return parser.getExpression();
            }
            for (let /*<@361>*/[/*<@3>*/fileName, /*<@3>*/source, options] of this.sources) {
                parse(source, options);
            }
        }
    }
    let /*<@1>*/worst4;
    let /*<@1>*/average;
    let /*<@1>*/firstIteration;
    let /*<@1>*/total;
    function /*<@498>*/summation(/*<@499>*/values) {
        assert(values instanceof Array);
        let /*<@5>*/sum = 0;
        for (let /*<@103>*/x of values)
            sum = sum + /*<@1>*/x;
        return sum;
    }
    function /*<@500>*/toScore(/*<@103>*/timeValue) {
        return /*<@1>*/timeValue;
    }
    function /*<@501>*/mean(/*<@499>*/values) {
        assert(values instanceof Array);
        let /*<@1>*/sum = 0;
        for (let /*<@103>*/x of values)
            sum = sum + /*<@1>*/x;
        return sum / values.length;
    }
    function /*<@502>*/assert(/*<@2>*/condition) {
        if (!condition) {
            throw new Error("assert false");
        }
    }
    function /*<@503>*/processResults(/*<@499>*/results) {
        function /*<@504>*/copyArray(/*<@499>*/a) {
            let /*<@361>*/result = /*<@361>*/[];
            for (let /*<@103>*/x of a)
                result.push(x);
            return result;
        }
        results = copyArray(results);
        firstIteration = toScore(results[0]);
        total = summation(results);
        // results = results.slice(1);
        results.sort(/*<@505>*/(/*<@103>*/a, /*<@103>*/b) => a < b ? 1 : -1);
        for (let /*<@5>*/i = 0; i + 1 < results.length; ++i)
            assert(results[i] >= results[i + 1]);
        let /*<@499>*/worstCase = /*<@499>*/[];
        for (let /*<@5>*/i = 0; i < 4; ++i)
            worstCase.push(results[i]);
        worst4 = toScore(mean(worstCase));
        average = toScore(mean(results));
    }
    function /*<@506>*/printScore() {
        // print("First: " + firstIteration);
        // print("worst4: " + worst4);
        print("average: " + average);
        // print("total: " + total);
    }
    function /*<@507>*/main() {
        let /*<@489>*/__benchmark = new Benchmark(60);
        let /*<@361>*/results = /*<@361>*/[];
        for (let /*<@5>*/i = 0; i < 120; i++) {
            let /*<@1>*/start = performance.now();
            __benchmark.runIteration();
            let /*<@1>*/end = performance.now();
            results.push(end - start);
        }
        processResults(results);
        printScore();
    }
    main();
})(babylon || (babylon = {}));
