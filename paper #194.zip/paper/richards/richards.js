/*<@type>{
    "header": {
        "version": "3.0.1",
        "filename": "richards.js",
        "sound": 1
    },
    "types": [
        "any",
        "number",
        "boolean",
        "string",
        "void",
        "int",
        "object",
        {
            "index": 7,
            "cname": "Scheduler",
            "fields": {
                "queueCount": -5,
                "holdCount": -5,
                "blocks": -28,
                "list": -9,
                "currentTcb": -9,
                "currentId": -5
            },
            "methods": [
                8,
                29,
                30,
                31,
                32,
                33,
                34,
                35,
                36,
                37,
                38,
                39
            ]
        },
        {
            "index": 8,
            "fname": "constructor",
            "ret": 7
        },
        {
            "index": 9,
            "cname": "TaskControlBlock",
            "fields": {
                "link": -9,
                "id": -5,
                "priority": -5,
                "queue": -11,
                "task": -16,
                "state": 5
            },
            "methods": [
                10,
                19,
                20,
                21,
                22,
                23,
                24,
                25,
                26,
                27
            ]
        },
        {
            "index": 10,
            "fname": "constructor",
            "params": {
                "link": 9,
                "id": 5,
                "priority": 5,
                "queue": 11,
                "task": 16
            },
            "ret": 9
        },
        {
            "index": 11,
            "cname": "Packet",
            "fields": {
                "link": -11,
                "id": -5,
                "kind": -5,
                "a1": -5,
                "a2": -13
            },
            "methods": [
                12,
                14,
                15
            ]
        },
        {
            "index": 12,
            "fname": "constructor",
            "params": {
                "link": 11,
                "id": 5,
                "kind": 5
            },
            "ret": 11
        },
        {
            "index": 13,
            "aname": "",
            "element": 5,
            "mode": "normal"
        },
        {
            "index": 14,
            "fname": "addTo",
            "params": {
                "queue": 11
            },
            "ret": 11
        },
        {
            "index": 15,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 16,
            "cname": "Task",
            "methods": [
                17,
                18
            ]
        },
        {
            "index": 17,
            "fname": "constructor",
            "ret": 16
        },
        {
            "index": 18,
            "fname": "run",
            "params": {
                "packet": 11
            },
            "ret": 9
        },
        {
            "index": 19,
            "fname": "setRunning"
        },
        {
            "index": 20,
            "fname": "markAsNotHeld"
        },
        {
            "index": 21,
            "fname": "markAsHeld"
        },
        {
            "index": 22,
            "fname": "isHeldOrSuspended",
            "ret": 2
        },
        {
            "index": 23,
            "fname": "markAsSuspended"
        },
        {
            "index": 24,
            "fname": "markAsRunnable",
            "private": 1
        },
        {
            "index": 25,
            "fname": "run",
            "ret": 9
        },
        {
            "index": 26,
            "fname": "checkPriorityAdd",
            "params": {
                "task": 9,
                "packet": 11
            },
            "ret": 9
        },
        {
            "index": 27,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 28,
            "aname": "",
            "element": 9,
            "mode": "normal"
        },
        {
            "index": 29,
            "fname": "addIdleTask",
            "params": {
                "id": 5,
                "priority": 5,
                "queue": 11,
                "count": 5
            }
        },
        {
            "index": 30,
            "fname": "addWorkerTask",
            "params": {
                "id": 5,
                "priority": 5,
                "queue": 11
            }
        },
        {
            "index": 31,
            "fname": "addHandlerTask",
            "params": {
                "id": 5,
                "priority": 5,
                "queue": 11
            }
        },
        {
            "index": 32,
            "fname": "addDeviceTask",
            "params": {
                "id": 5,
                "priority": 5,
                "queue": 11
            }
        },
        {
            "index": 33,
            "fname": "addRunningTask",
            "private": 1,
            "params": {
                "id": 5,
                "priority": 5,
                "queue": 11,
                "task": 16
            }
        },
        {
            "index": 34,
            "fname": "addTask",
            "private": 1,
            "params": {
                "id": 5,
                "priority": 5,
                "queue": 11,
                "task": 16
            }
        },
        {
            "index": 35,
            "fname": "schedule"
        },
        {
            "index": 36,
            "fname": "release",
            "params": {
                "id": 5
            },
            "ret": 9
        },
        {
            "index": 37,
            "fname": "holdCurrent",
            "ret": 9
        },
        {
            "index": 38,
            "fname": "suspendCurrent",
            "ret": 9
        },
        {
            "index": 39,
            "fname": "queue",
            "params": {
                "packet": 11
            },
            "ret": 9
        },
        {
            "index": 40,
            "aname": "",
            "element": 9,
            "mode": "holey"
        },
        {
            "index": 41,
            "cname": "IdleTask",
            "supers": {
                "Task": 17
            },
            "fields": {
                "scheduler": -7,
                "v1": -5,
                "count": -5
            },
            "methods": [
                42,
                43,
                44
            ]
        },
        {
            "index": 42,
            "fname": "constructor",
            "params": {
                "scheduler": 7,
                "v1": 5,
                "count": 5
            },
            "ret": 41,
            "hobj": 1
        },
        {
            "index": 43,
            "fname": "run",
            "params": {
                "packet": 11
            },
            "ret": 9
        },
        {
            "index": 44,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 45,
            "cname": "DeviceTask",
            "supers": {
                "Task": 17
            },
            "fields": {
                "scheduler": -7,
                "v1": -11
            },
            "methods": [
                46,
                47,
                48
            ]
        },
        {
            "index": 46,
            "fname": "constructor",
            "params": {
                "scheduler": 7
            },
            "ret": 45,
            "hobj": 1
        },
        {
            "index": 47,
            "fname": "run",
            "params": {
                "packet": 11
            },
            "ret": 9
        },
        {
            "index": 48,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 49,
            "cname": "WorkerTask",
            "supers": {
                "Task": 17
            },
            "fields": {
                "scheduler": -7,
                "v1": -5,
                "v2": -5
            },
            "methods": [
                50,
                51,
                52
            ]
        },
        {
            "index": 50,
            "fname": "constructor",
            "params": {
                "scheduler": 7,
                "v1": 5,
                "v2": 5
            },
            "ret": 49,
            "hobj": 1
        },
        {
            "index": 51,
            "fname": "run",
            "params": {
                "packet": 11
            },
            "ret": 9
        },
        {
            "index": 52,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 53,
            "cname": "HandlerTask",
            "supers": {
                "Task": 17
            },
            "fields": {
                "scheduler": -7,
                "v1": -11,
                "v2": -11
            },
            "methods": [
                54,
                55,
                56
            ]
        },
        {
            "index": 54,
            "fname": "constructor",
            "params": {
                "scheduler": 7
            },
            "ret": 53,
            "hobj": 1
        },
        {
            "index": 55,
            "fname": "run",
            "params": {
                "packet": 11
            },
            "ret": 9
        },
        {
            "index": 56,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 57,
            "fname": "runRichards"
        },
        {
            "index": 58,
            "fname": "static now",
            "ret": 1
        },
        {
            "index": 59,
            "fname": "summation",
            "params": {
                "values": 61
            },
            "ret": 5
        },
        {
            "index": 60,
            "bname": "Object"
        },
        {
            "index": 61,
            "aname": "",
            "element": 60,
            "mode": "normal"
        },
        {
            "index": 62,
            "fname": "toScore",
            "params": {
                "timeValue": 60
            },
            "ret": 1
        },
        {
            "index": 63,
            "fname": "mean",
            "params": {
                "values": 61
            },
            "ret": 1
        },
        {
            "index": 64,
            "fname": "assert",
            "params": {
                "condition": 2
            }
        },
        {
            "index": 65,
            "fname": "processResults",
            "params": {
                "results": 61
            }
        },
        {
            "index": 66,
            "fname": "copyArray",
            "params": {
                "a": 61
            },
            "ret": 61
        },
        {
            "index": 67,
            "aname": "",
            "element": 0,
            "mode": "normal"
        },
        {
            "index": 68,
            "fname": "",
            "params": {
                "a": 60,
                "b": 60
            },
            "ret": 5
        },
        {
            "index": 69,
            "fname": "printScore"
        },
        {
            "index": 70,
            "cname": "Benchmark",
            "methods": [
                71,
                72
            ]
        },
        {
            "index": 71,
            "fname": "constructor",
            "ret": 70
        },
        {
            "index": 72,
            "fname": "runIteration"
        },
        {
            "index": 73,
            "fname": "main"
        }
    ]
}*/
"use strict";
// Copyright 2006-2008 the V8 project authors. All rights reserved.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above
//       copyright notice, this list of conditions and the following
//       disclaimer in the documentation and/or other materials provided
//       with the distribution.
//     * Neither the name of Google Inc. nor the names of its
//       contributors may be used to endorse or promote products derived
//       from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
var rd;
(function (rd) {
    const /*<@5>*/COUNT = 1000;
    /**
     * These two constants specify how many times a packet is queued and
     * how many times a task is put on hold in a correct run of richards.
     * They don't have any meaning a such but are characteristic of a
     * correct run so if the actual queue or hold count is different from
     * the expected there must be a bug in the implementation.
     **/
    const /*<@5>*/EXPECTED_QUEUE_COUNT = 2322;
    const /*<@5>*/EXPECTED_HOLD_COUNT = 928;
    const /*<@5>*/NULL_ID = -1;
    const /*<@5>*/ID_IDLE = 0;
    const /*<@5>*/ID_WORKER = 1;
    const /*<@5>*/ID_HANDLER_A = 2;
    const /*<@5>*/ID_HANDLER_B = 3;
    const /*<@5>*/ID_DEVICE_A = 4;
    const /*<@5>*/ID_DEVICE_B = 5;
    const /*<@5>*/NUMBER_OF_IDS = 6;
    const /*<@5>*/KIND_DEVICE = 0;
    const /*<@5>*/KIND_WORK = 1;
    class /*<@8>*/Scheduler {
        /**
         * A scheduler can be used to schedule a set of tasks based on their relative
         * priorities.  Scheduling is done by maintaining a list of task control blocks
         * which holds tasks and the data queue they are processing.
         * @constructor
         */
        constructor() {
            this.queueCount = 0;
            this.holdCount = 0;
            this.blocks = new /*<@40>*/Array(NUMBER_OF_IDS);
            this.list = null;
            this.currentTcb = null;
            this.currentId = NULL_ID;
        }
        /**
         * Add an idle task to this scheduler.
         * @param {int} id the identity of the task
         * @param {int} priority the task's priority
         * @param {Packet} queue the queue of work to be processed by the task
         * @param {int} count the number of times to schedule the task
         */
        /*<@29>*/addIdleTask(/*<@5>*/id, /*<@5>*/priority, /*<@11>*/queue, /*<@5>*/count) {
            this.addRunningTask(id, priority, queue, new IdleTask(this, 1, count));
        }
        ;
        /**
         * Add a work task to this scheduler.
         * @param {int} id the identity of the task
         * @param {int} priority the task's priority
         * @param {Packet} queue the queue of work to be processed by the task
         */
        /*<@30>*/addWorkerTask(/*<@5>*/id, /*<@5>*/priority, /*<@11>*/queue) {
            this.addTask(id, priority, queue, new WorkerTask(this, ID_HANDLER_A, 0));
        }
        ;
        /**
         * Add a handler task to this scheduler.
         * @param {int} id the identity of the task
         * @param {int} priority the task's priority
         * @param {Packet} queue the queue of work to be processed by the task
         */
        /*<@31>*/addHandlerTask(/*<@5>*/id, /*<@5>*/priority, /*<@11>*/queue) {
            this.addTask(id, priority, queue, new HandlerTask(this));
        }
        ;
        /**
         * Add a handler task to this scheduler.
         * @param {int} id the identity of the task
         * @param {int} priority the task's priority
         * @param {Packet} queue the queue of work to be processed by the task
         */
        /*<@32>*/addDeviceTask(/*<@5>*/id, /*<@5>*/priority, /*<@11>*/queue) {
            this.addTask(id, priority, queue, new DeviceTask(this));
        }
        ;
        /**
         * Add the specified task and mark it as running.
         * @param {int} id the identity of the task
         * @param {int} priority the task's priority
         * @param {Packet} queue the queue of work to be processed by the task
         * @param {Task} task the task to add
         */
        /*<@33>*/addRunningTask(/*<@5>*/id, /*<@5>*/priority, /*<@11>*/queue, /*<@16>*/task) {
            this.addTask(id, priority, queue, task);
            this.currentTcb.setRunning();
        }
        ;
        /**
         * Add the specified task to this scheduler.
         * @param {int} id the identity of the task
         * @param {int} priority the task's priority
         * @param {Packet} queue the queue of work to be processed by the task
         * @param {Task} task the task to add
         */
        /*<@34>*/addTask(/*<@5>*/id, /*<@5>*/priority, /*<@11>*/queue, /*<@16>*/task) {
            this.currentTcb = new TaskControlBlock(this.list, id, priority, queue, task);
            this.list = this.currentTcb;
            this.blocks[id] = this.currentTcb;
        }
        ;
        /**
         * Execute the tasks managed by this scheduler.
         */
        /*<@35>*/schedule() {
            this.currentTcb = this.list;
            while (this.currentTcb != null) {
                if (this.currentTcb.isHeldOrSuspended()) {
                    this.currentTcb = this.currentTcb.link;
                }
                else {
                    this.currentId = this.currentTcb.id;
                    this.currentTcb = this.currentTcb.run();
                }
            }
        }
        ;
        /**
         * Release a task that is currently blocked and return the next block to run.
         * @param {int} id the id of the task to suspend
         */
        /*<@36>*/release(/*<@5>*/id) {
            var /*<@9>*/tcb = this.blocks[id];
            if (tcb == null)
                return tcb;
            tcb.markAsNotHeld();
            if (tcb.priority > this.currentTcb.priority) {
                return tcb;
            }
            else {
                return this.currentTcb;
            }
        }
        ;
        /**
         * Block the currently executing task and return the next task control block
         * to run.  The blocked task will not be made runnable until it is explicitly
         * released, even if new work is added to it.
         */
        /*<@37>*/holdCurrent() {
            this.holdCount++;
            this.currentTcb.markAsHeld();
            return this.currentTcb.link;
        }
        ;
        /**
         * Suspend the currently executing task and return the next task control block
         * to run.  If new work is added to the suspended task it will be made runnable.
         */
        /*<@38>*/suspendCurrent() {
            this.currentTcb.markAsSuspended();
            return this.currentTcb;
        }
        ;
        /**
         * Add the specified packet to the end of the worklist used by the task
         * associated with the packet and make the task runnable if it is currently
         * suspended.
         * @param {Packet} packet the packet to add
         */
        /*<@39>*/queue(/*<@11>*/packet) {
            var /*<@9>*/t = this.blocks[packet.id];
            if (t == null)
                return t;
            this.queueCount++;
            packet.link = null;
            packet.id = this.currentId;
            return t.checkPriorityAdd(this.currentTcb, packet);
        }
        ;
    }
    /**
     * The task is running and is currently scheduled.
     */
    const /*<@5>*/STATE_RUNNING = 0;
    /**
     * The task has packets left to process.
     */
    const /*<@5>*/STATE_RUNNABLE = 1;
    /**
     * The task is not currently running.  The task is not blocked as such and may
    * be started by the scheduler.
     */
    const /*<@5>*/STATE_SUSPENDED = 2;
    /**
     * The task is blocked and cannot be run until it is explicitly released.
     */
    const /*<@5>*/STATE_HELD = 4;
    const /*<@5>*/STATE_SUSPENDED_RUNNABLE = STATE_SUSPENDED | STATE_RUNNABLE;
    const /*<@1>*/STATE_NOT_HELD = ~STATE_HELD;
    class /*<@10>*/TaskControlBlock {
        /**
         * A task control block manages a task and the queue of work packages associated
         * with it.
         * @param {TaskControlBlock} link the preceding block in the linked block list
         * @param {int} id the id of this block
         * @param {int} priority the priority of this block
         * @param {Packet} queue the queue of packages to be processed by the task
         * @param {Task} task the task
         * @constructor
         */
        constructor(/*<@9>*/link, /*<@5>*/id, /*<@5>*/priority, /*<@11>*/queue, /*<@16>*/task) {
            this.link = link;
            this.id = id;
            this.priority = priority;
            this.queue = queue;
            this.task = task;
            if (queue == null) {
                this.state = STATE_SUSPENDED;
            }
            else {
                this.state = STATE_SUSPENDED_RUNNABLE;
            }
        }
        /*<@19>*/setRunning() {
            this.state = STATE_RUNNING;
        }
        ;
        /*<@20>*/markAsNotHeld() {
            this.state = (this.state & STATE_NOT_HELD);
        }
        ;
        /*<@21>*/markAsHeld() {
            this.state = this.state | STATE_HELD;
        }
        ;
        /*<@22>*/isHeldOrSuspended() {
            return (this.state & STATE_HELD) != 0 || (this.state == STATE_SUSPENDED);
        }
        ;
        /*<@23>*/markAsSuspended() {
            this.state = this.state | STATE_SUSPENDED;
        }
        ;
        /*<@24>*/markAsRunnable() {
            this.state = this.state | STATE_RUNNABLE;
        }
        ;
        /**
         * Runs this task, if it is ready to be run, and returns the next task to run.
         */
        /*<@25>*/run() {
            var /*<@11>*/packet;
            if (this.state == STATE_SUSPENDED_RUNNABLE) {
                packet = this.queue;
                this.queue = packet.link;
                if (this.queue == null) {
                    this.state = STATE_RUNNING;
                }
                else {
                    this.state = STATE_RUNNABLE;
                }
            }
            else {
                packet = null;
            }
            return this.task.run(packet);
        }
        ;
        /**
         * Adds a packet to the worklist of this block's task, marks this as runnable if
         * necessary, and returns the next runnable object to run (the one
         * with the highest priority).
         */
        /*<@26>*/checkPriorityAdd(/*<@9>*/task, /*<@11>*/packet) {
            if (this.queue == null) {
                this.queue = packet;
                this.markAsRunnable();
                if (this.priority > task.priority)
                    return this;
            }
            else {
                this.queue = packet.addTo(this.queue);
            }
            return task;
        }
        ;
        /*<@27>*/toString() {
            return "tcb { " + this.task + "@" + this.state + " }";
        }
        ;
    }
    class /*<@17>*/Task {
        /*<@18>*/run(/*<@11>*/packet) { return undefined; }
    }
    class /*<@42>*/IdleTask extends Task {
        /**
         * An idle task doesn't do any work itself but cycles control between the two
         * device tasks.
         * @param {Scheduler} scheduler the scheduler that manages this task
         * @param {int} v1 a seed value that controls how the device tasks are scheduled
         * @param {int} count the number of times this task should be scheduled
         * @constructor
         */
        constructor(/*<@7>*/scheduler, /*<@5>*/v1, /*<@5>*/count) {
            super();
            this.scheduler = scheduler;
            this.v1 = v1;
            this.count = count;
        }
        /*<@43>*/run(/*<@11>*/packet) {
            this.count--;
            if (this.count == 0)
                return this.scheduler.holdCurrent();
            if ((this.v1 & 1) == 0) {
                this.v1 = this.v1 >> 1;
                return this.scheduler.release(ID_DEVICE_A);
            }
            else {
                this.v1 = (this.v1 >> 1) ^ 0xD008;
                return this.scheduler.release(ID_DEVICE_B);
            }
        }
        /*<@44>*/toString() {
            return "IdleTask";
        }
        ;
    }
    class /*<@46>*/DeviceTask extends Task {
        /**
         * A task that suspends itself after each time it has been run to simulate
         * waiting for data from an external device.
         * @param {Scheduler} scheduler the scheduler that manages this task
         * @constructor
         */
        constructor(/*<@7>*/scheduler) {
            super();
            this.scheduler = scheduler;
            this.v1 = null;
        }
        /*<@47>*/run(/*<@11>*/packet) {
            if (packet == null) {
                if (this.v1 == null)
                    return this.scheduler.suspendCurrent();
                var /*<@11>*/v = this.v1;
                this.v1 = null;
                return this.scheduler.queue(v);
            }
            else {
                this.v1 = packet;
                return this.scheduler.holdCurrent();
            }
        }
        /*<@48>*/toString() {
            return "DeviceTask";
        }
    }
    class /*<@50>*/WorkerTask extends Task {
        /**
         * A task that manipulates work packets.
         * @param {Scheduler} scheduler the scheduler that manages this task
         * @param {int} v1 a seed used to specify how work packets are manipulated
         * @param {int} v2 another seed used to specify how work packets are manipulated
         * @constructor
         */
        constructor(/*<@7>*/scheduler, /*<@5>*/v1, /*<@5>*/v2) {
            super();
            this.scheduler = scheduler;
            this.v1 = v1;
            this.v2 = v2;
        }
        /*<@51>*/run(/*<@11>*/packet) {
            if (packet == null) {
                return this.scheduler.suspendCurrent();
            }
            else {
                if (this.v1 == ID_HANDLER_A) {
                    this.v1 = ID_HANDLER_B;
                }
                else {
                    this.v1 = ID_HANDLER_A;
                }
                packet.id = this.v1;
                packet.a1 = 0;
                for (var /*<@5>*/i = 0; i < DATA_SIZE; i++) {
                    this.v2++;
                    if (this.v2 > 26)
                        this.v2 = 1;
                    packet.a2[i] = this.v2;
                }
                return this.scheduler.queue(packet);
            }
        }
        /*<@52>*/toString() {
            return "WorkerTask";
        }
    }
    class /*<@54>*/HandlerTask extends Task {
        /**
         * A task that manipulates work packets and then suspends itself.
         * @param {Scheduler} scheduler the scheduler that manages this task
         * @constructor
         */
        constructor(/*<@7>*/scheduler) {
            super();
            this.scheduler = scheduler;
            this.v1 = null;
            this.v2 = null;
        }
        /*<@55>*/run(/*<@11>*/packet) {
            if (packet != null) {
                if (packet.kind == KIND_WORK) {
                    this.v1 = packet.addTo(this.v1);
                }
                else {
                    this.v2 = packet.addTo(this.v2);
                }
            }
            if (this.v1 != null) {
                var /*<@5>*/count = this.v1.a1;
                var /*<@11>*/v;
                if (count < DATA_SIZE) {
                    if (this.v2 != null) {
                        v = this.v2;
                        this.v2 = this.v2.link;
                        v.a1 = this.v1.a2[count];
                        this.v1.a1 = count + 1;
                        return this.scheduler.queue(v);
                    }
                }
                else {
                    v = this.v1;
                    this.v1 = this.v1.link;
                    return this.scheduler.queue(v);
                }
            }
            return this.scheduler.suspendCurrent();
        }
        /*<@56>*/toString() {
            return "HandlerTask";
        }
    }
    /* --- *
     * P a c k e t
     * --- */
    const /*<@5>*/DATA_SIZE = 4;
    class /*<@12>*/Packet {
        /**
         * A simple package of data that is manipulated by the tasks.  The exact layout
         * of the payload data carried by a packet is not importaint, and neither is the
         * nature of the work performed on packets by the tasks.
         *
         * Besides carrying data, packets form linked lists and are hence used both as
         * data and worklists.
         * @param {Packet} link the tail of the linked list of packets
         * @param {int} id an ID for this packet
         * @param {int} kind the type of this packet
         * @constructor
         */
        constructor(/*<@11>*/link, /*<@5>*/id, /*<@5>*/kind) {
            this.link = link;
            this.id = id;
            this.kind = kind;
            this.a1 = 0;
            this.a2 = new /*<@13>*/Array(DATA_SIZE);
        }
        /**
         * Add this packet to the end of a worklist, and return the worklist.
         * @param {Packet} queue the worklist to add this packet to
         */
        /*<@14>*/addTo(/*<@11>*/queue) {
            this.link = null;
            if (queue == null)
                return this;
            var /*<@11>*/peek, /*<@11>*/next = queue;
            while ((peek = next.link) != null)
                next = peek;
            next.link = this;
            return queue;
        }
        ;
        /*<@15>*/toString() {
            return "Packet";
        }
        ;
    }
    /**
     * The Richards benchmark simulates the task dispatcher of an
     * operating system.
     **/
    function /*<@57>*/runRichards() {
        var /*<@7>*/scheduler = new Scheduler();
        scheduler.addIdleTask(ID_IDLE, 0, null, COUNT);
        var /*<@11>*/queue = new Packet(null, ID_WORKER, KIND_WORK);
        queue = new Packet(queue, ID_WORKER, KIND_WORK);
        scheduler.addWorkerTask(ID_WORKER, 1000, queue);
        queue = new Packet(null, ID_DEVICE_A, KIND_DEVICE);
        queue = new Packet(queue, ID_DEVICE_A, KIND_DEVICE);
        queue = new Packet(queue, ID_DEVICE_A, KIND_DEVICE);
        scheduler.addHandlerTask(ID_HANDLER_A, 2000, queue);
        queue = new Packet(null, ID_DEVICE_B, KIND_DEVICE);
        queue = new Packet(queue, ID_DEVICE_B, KIND_DEVICE);
        queue = new Packet(queue, ID_DEVICE_B, KIND_DEVICE);
        scheduler.addHandlerTask(ID_HANDLER_B, 3000, queue);
        scheduler.addDeviceTask(ID_DEVICE_A, 4000, null);
        scheduler.addDeviceTask(ID_DEVICE_B, 5000, null);
        scheduler.schedule();
        if (scheduler.queueCount != EXPECTED_QUEUE_COUNT ||
            scheduler.holdCount != EXPECTED_HOLD_COUNT) {
            var /*<@3>*/msg = "Error during execution: queueCount = " + scheduler.queueCount +
                ", holdCount = " + scheduler.holdCount + ".";
            throw new Error(msg);
        }
    }
    rd.runRichards = runRichards;
})(rd || (rd = {}));
let /*<@1>*/worst4;
let /*<@1>*/average;
let /*<@1>*/firstIteration;
let /*<@1>*/total;
function /*<@59>*/summation(/*<@61>*/values) {
    assert(values instanceof Array);
    let /*<@5>*/sum = 0;
    for (let /*<@60>*/x of values)
        sum = sum + /*<@1>*/x;
    return sum;
}
function /*<@62>*/toScore(/*<@60>*/timeValue) {
    return /*<@1>*/timeValue;
}
function /*<@63>*/mean(/*<@61>*/values) {
    assert(values instanceof Array);
    let /*<@1>*/sum = 0;
    for (let /*<@60>*/x of values)
        sum = sum + /*<@1>*/x;
    return sum / values.length;
}
function /*<@64>*/assert(/*<@2>*/condition) {
    if (!condition) {
        throw new Error("assert false");
    }
}
function /*<@65>*/processResults(/*<@61>*/results) {
    function /*<@66>*/copyArray(/*<@61>*/a) {
        let /*<@67>*/result = /*<@67>*/[];
        for (let /*<@60>*/x of a)
            result.push(x);
        return result;
    }
    results = copyArray(results);
    firstIteration = toScore(results[0]);
    total = summation(results);
    // results = results.slice(1);
    results.sort(/*<@68>*/(/*<@60>*/a, /*<@60>*/b) => a < b ? 1 : -1);
    for (let /*<@5>*/i = 0; i + 1 < results.length; ++i)
        assert(results[i] >= results[i + 1]);
    let /*<@61>*/worstCase = /*<@61>*/[];
    for (let /*<@5>*/i = 0; i < 4; ++i)
        worstCase.push(results[i]);
    worst4 = toScore(mean(worstCase));
    average = toScore(mean(results));
}
function /*<@69>*/printScore() {
    // print("First: " + firstIteration);
    // print("worst4: " + worst4);
    print("average: " + average);
    // print("total: " + total);
}
class /*<@71>*/Benchmark {
    /*<@72>*/runIteration() {
        rd.runRichards();
    }
}
function /*<@73>*/main() {
    let /*<@70>*/__benchmark = new Benchmark();
    let /*<@67>*/results = /*<@67>*/[];
    for (let /*<@5>*/i = 0; i < 120; i++) {
        let /*<@1>*/start = performance.now();
        __benchmark.runIteration();
        let /*<@1>*/end = performance.now();
        results.push(end - start);
    }
    processResults(results);
    printScore();
}
main();
