/*<@type>{
    "header": {
        "version": "3.0.1",
        "filename": "wsl.js",
        "sound": 1
    },
    "types": [
        "any",
        "number",
        "boolean",
        "string",
        "void",
        "int",
        "object",
        {
            "index": 7,
            "cname": "Node",
            "fields": {
                "_origin": -42,
                "_addressSpace": -3,
                "ePtr": 43,
                "_name": -3,
                "program": 71,
                "hasBecome": 2,
                "_target": -7,
                "_type": -85,
                "_isPtr": -2,
                "_isLiteral": -2,
                "implementation": 0
            },
            "sfields": {
                "const visit": 736
            },
            "methods": [
                8,
                211,
                212,
                213,
                214,
                215,
                216,
                217,
                218,
                219,
                739,
                740,
                741,
                742,
                743,
                744,
                745,
                746,
                747,
                748,
                749,
                750,
                751,
                752,
                753,
                754,
                755,
                756,
                758,
                759,
                760,
                761
            ]
        },
        {
            "index": 8,
            "fname": "constructor",
            "ret": 7
        },
        {
            "index": 9,
            "cname": "LexerToken",
            "fields": {
                "_lexer": -11,
                "_index": -5,
                "_kind": -3,
                "_text": -3
            },
            "methods": [
                10,
                31,
                32,
                33,
                34,
                35,
                36,
                37,
                38,
                39
            ]
        },
        {
            "index": 10,
            "fname": "constructor",
            "params": {
                "lexer": 11,
                "index": 5,
                "kind": 3,
                "text": 3
            },
            "ret": 9
        },
        {
            "index": 11,
            "cname": "Lexer",
            "fields": {
                "_origin": -3,
                "_originKind": -3,
                "_lineNumberOffset": -5,
                "_text": -3,
                "_index": -5,
                "_stack": -13
            },
            "sfields": {
                "const _textIsIdentifierImpl": 22,
                "const textIsIdentifier": 23
            },
            "methods": [
                12,
                14,
                15,
                16,
                17,
                18,
                19,
                21,
                24,
                25,
                26,
                27,
                28,
                30
            ]
        },
        {
            "index": 12,
            "fname": "constructor",
            "params": {
                "origin": 3,
                "originKind": 3,
                "lineNumberOffset": 5,
                "text": 3
            },
            "ret": 11
        },
        {
            "index": 13,
            "aname": "",
            "element": 9,
            "mode": "normal"
        },
        {
            "index": 14,
            "fname": "get origin",
            "ret": 3
        },
        {
            "index": 15,
            "fname": "get lineNumber",
            "ret": 5
        },
        {
            "index": 16,
            "fname": "get originString",
            "ret": 3
        },
        {
            "index": 17,
            "fname": "get originKind",
            "ret": 3
        },
        {
            "index": 18,
            "fname": "lineNumberForIndex",
            "params": {
                "index": 5
            },
            "ret": 5
        },
        {
            "index": 19,
            "fname": "get state",
            "ret": 20
        },
        {
            "index": 20,
            "oname": "",
            "fields": {
                "index": -5,
                "stack": -13
            }
        },
        {
            "index": 21,
            "fname": "set state",
            "params": {
                "value": 20
            }
        },
        {
            "index": 22,
            "fname": "static _textIsIdentifierImpl",
            "params": {
                "text": 3
            },
            "ret": 2
        },
        {
            "index": 23,
            "fname": "static textIsIdentifier",
            "params": {
                "text": 3
            },
            "ret": 2
        },
        {
            "index": 24,
            "fname": "next",
            "ret": 9
        },
        {
            "index": 25,
            "fname": "push",
            "params": {
                "token": 9
            }
        },
        {
            "index": 26,
            "fname": "peek",
            "ret": 9
        },
        {
            "index": 27,
            "fname": "fail",
            "params": {
                "error": 3
            }
        },
        {
            "index": 28,
            "fname": "backtrackingScope",
            "params": {
                "callback": 0
            },
            "ret": 29
        },
        {
            "index": 29,
            "uname": "",
            "types": [
                4,
                7
            ]
        },
        {
            "index": 30,
            "fname": "testScope",
            "params": {
                "callback": 0
            },
            "ret": 2
        },
        {
            "index": 31,
            "fname": "get lexer",
            "ret": 11
        },
        {
            "index": 32,
            "fname": "get kind",
            "ret": 3
        },
        {
            "index": 33,
            "fname": "get text",
            "ret": 3
        },
        {
            "index": 34,
            "fname": "get origin",
            "ret": 3
        },
        {
            "index": 35,
            "fname": "get originKind",
            "ret": 3
        },
        {
            "index": 36,
            "fname": "get index",
            "ret": 5
        },
        {
            "index": 37,
            "fname": "get lineNumber",
            "ret": 5
        },
        {
            "index": 38,
            "fname": "get originString",
            "ret": 3
        },
        {
            "index": 39,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 40,
            "cname": "ExternalOrigin",
            "fields": {
                "originString": -3,
                "originKind": -3
            },
            "methods": [
                41
            ]
        },
        {
            "index": 41,
            "fname": "constructor",
            "params": {
                "originString": 3,
                "originKind": 3
            },
            "ret": 40
        },
        {
            "index": 42,
            "uname": "",
            "types": [
                9,
                40
            ]
        },
        {
            "index": 43,
            "cname": "EPtr",
            "fields": {
                "_buffer": -45,
                "_offset": -5
            },
            "sfields": {
                "const box": 61
            },
            "methods": [
                44,
                62,
                63,
                64,
                65,
                66,
                67,
                68,
                69,
                70
            ]
        },
        {
            "index": 44,
            "fname": "constructor",
            "params": {
                "buffer": 45,
                "offset": 5
            },
            "ret": 43
        },
        {
            "index": 45,
            "cname": "EBuffer",
            "fields": {
                "_index": -5,
                "_array": -53
            },
            "sfields": {
                "const setCanAllocateEBuffers": 54,
                "const disallowAllocation": 55,
                "const allowAllocation": 56
            },
            "methods": [
                46,
                57,
                58,
                59,
                60
            ]
        },
        {
            "index": 46,
            "fname": "constructor",
            "params": {
                "size": 5
            },
            "ret": 45
        },
        {
            "index": 47,
            "cname": "EArrayRef",
            "fields": {
                "_ptr": -43,
                "_length": -5
            },
            "methods": [
                48,
                49,
                50,
                51
            ]
        },
        {
            "index": 48,
            "fname": "constructor",
            "params": {
                "ptr": 43,
                "length": 5
            },
            "ret": 47
        },
        {
            "index": 49,
            "fname": "get ptr",
            "ret": 43
        },
        {
            "index": 50,
            "fname": "get length",
            "ret": 5
        },
        {
            "index": 51,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 52,
            "uname": "",
            "types": [
                1,
                2,
                7,
                43,
                47
            ]
        },
        {
            "index": 53,
            "aname": "",
            "element": 52,
            "mode": "normal"
        },
        {
            "index": 54,
            "fname": "static setCanAllocateEBuffers",
            "params": {
                "value": 2,
                "callback": 0
            },
            "ret": 43
        },
        {
            "index": 55,
            "fname": "static disallowAllocation",
            "params": {
                "callback": 0
            },
            "ret": 43
        },
        {
            "index": 56,
            "fname": "static allowAllocation",
            "params": {
                "callback": 0
            },
            "ret": 43
        },
        {
            "index": 57,
            "fname": "get",
            "params": {
                "index": 5
            },
            "ret": 52
        },
        {
            "index": 58,
            "fname": "set",
            "params": {
                "index": 5,
                "value": 52
            }
        },
        {
            "index": 59,
            "fname": "get index",
            "ret": 5
        },
        {
            "index": 60,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 61,
            "fname": "static box",
            "params": {
                "value": 52
            },
            "ret": 43
        },
        {
            "index": 62,
            "fname": "box",
            "params": {
                "value": 52
            },
            "ret": 43
        },
        {
            "index": 63,
            "fname": "get buffer",
            "ret": 45
        },
        {
            "index": 64,
            "fname": "get offset",
            "ret": 5
        },
        {
            "index": 65,
            "fname": "plus",
            "params": {
                "offset": 5
            },
            "ret": 43
        },
        {
            "index": 66,
            "fname": "loadValue",
            "ret": 52
        },
        {
            "index": 67,
            "fname": "get",
            "params": {
                "offset": 5
            },
            "ret": 52
        },
        {
            "index": 68,
            "fname": "set",
            "params": {
                "offset": 5,
                "value": 52
            }
        },
        {
            "index": 69,
            "fname": "copyFrom",
            "params": {
                "other": 43,
                "size": 5
            }
        },
        {
            "index": 70,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 71,
            "cname": "Program",
            "supers": {
                "Node": 8
            },
            "fields": {
                "intrinsics": 73,
                "_funcInstantiator": -200,
                "_functions": -77,
                "_topLevelStatements": -101,
                "_types": -77,
                "_protocols": -77,
                "_globalNameContext": 75
            },
            "methods": [
                72,
                203,
                204,
                205,
                206,
                207,
                208,
                209,
                210
            ]
        },
        {
            "index": 72,
            "fname": "constructor",
            "ret": 71,
            "hobj": 1
        },
        {
            "index": 73,
            "cname": "Intrinsics",
            "fields": {
                "bool": 85,
                "int32": 85,
                "uint32": 85,
                "uint8": 85,
                "float": 85,
                "double": 85,
                "void": 85,
                "_map": -77
            },
            "methods": [
                74,
                198
            ]
        },
        {
            "index": 74,
            "fname": "constructor",
            "params": {
                "nameContext": 75
            },
            "ret": 73
        },
        {
            "index": 75,
            "cname": "NameContext",
            "fields": {
                "_map": -77,
                "_set": -78,
                "_currentStatement": -7,
                "_delegate": -75,
                "_intrinsics": -73,
                "_program": -71
            },
            "sfields": {
                "const underlyingThings": 83
            },
            "methods": [
                76,
                79,
                80,
                81,
                84,
                191,
                192,
                193,
                194,
                195,
                196,
                197
            ]
        },
        {
            "index": 76,
            "fname": "constructor",
            "params": {
                "delegate": 75
            },
            "ret": 75
        },
        {
            "index": 77,
            "bname": "Map"
        },
        {
            "index": 78,
            "bname": "Set"
        },
        {
            "index": 79,
            "fname": "add",
            "params": {
                "thing": 7
            }
        },
        {
            "index": 80,
            "fname": "get",
            "params": {
                "kind": 6,
                "name": 3
            },
            "ret": 0
        },
        {
            "index": 81,
            "fname": "underlyingThings",
            "params": {
                "kind": 6,
                "name": 3
            },
            "ret": 82
        },
        {
            "index": 82,
            "bname": "Generator"
        },
        {
            "index": 83,
            "fname": "static underlyingThings",
            "params": {
                "thing": 0
            },
            "ret": 82
        },
        {
            "index": 84,
            "fname": "resolveFuncOverload",
            "params": {
                "name": 3,
                "typeArguments": 136,
                "argumentTypes": 136,
                "returnType": 85,
                "allowEntryPoint": 2
            },
            "ret": 0
        },
        {
            "index": 85,
            "cname": "Type",
            "supers": {
                "Node": 8
            },
            "fields": {
                "canRepresent": 0,
                "createLiteral": 0,
                "successorValue": 0,
                "valuesEqual": 0,
                "formatValueFromIntLiteral": 0,
                "formatValueFromUintLiteral": 0,
                "allValues": -0,
                "instantiate": -0,
                "formatValueFromFloatLiteral": 0,
                "formatValueFromDoubleLiteral": 0,
                "populateDefaultValue": -0,
                "_elementType": -85,
                "_isPrimitive": 2,
                "_isInt": 2,
                "_isNumber": 2,
                "_isSigned": 2,
                "_isFloating": 2,
                "_size": 5,
                "_isArrayRef": -2,
                "defaultValue": 1
            },
            "methods": [
                86,
                87,
                88,
                89,
                90,
                91,
                92,
                93,
                94,
                95,
                96,
                97,
                98,
                99,
                100,
                102,
                103,
                104,
                105,
                106,
                186,
                187,
                189,
                190
            ]
        },
        {
            "index": 86,
            "fname": "constructor",
            "ret": 85
        },
        {
            "index": 87,
            "fname": "get elementType",
            "ret": 85
        },
        {
            "index": 88,
            "fname": "get isPrimitive",
            "ret": 2
        },
        {
            "index": 89,
            "fname": "set isPrimitive",
            "params": {
                "value": 2
            }
        },
        {
            "index": 90,
            "fname": "get isInt",
            "ret": 2
        },
        {
            "index": 91,
            "fname": "set isInt",
            "params": {
                "val": 2
            }
        },
        {
            "index": 92,
            "fname": "get isNumber",
            "ret": 2
        },
        {
            "index": 93,
            "fname": "set isNumber",
            "params": {
                "val": 2
            }
        },
        {
            "index": 94,
            "fname": "get isSigned",
            "ret": 2
        },
        {
            "index": 95,
            "fname": "set isSigned",
            "params": {
                "val": 2
            }
        },
        {
            "index": 96,
            "fname": "get isFloating",
            "ret": 2
        },
        {
            "index": 97,
            "fname": "set isFloating",
            "params": {
                "val": 2
            }
        },
        {
            "index": 98,
            "fname": "get size",
            "ret": 5
        },
        {
            "index": 99,
            "fname": "set size",
            "params": {
                "val": 5
            }
        },
        {
            "index": 100,
            "fname": "get typeParameters",
            "ret": 101
        },
        {
            "index": 101,
            "aname": "",
            "element": 7,
            "mode": "normal"
        },
        {
            "index": 102,
            "fname": "get kind",
            "ret": 86
        },
        {
            "index": 103,
            "fname": "get isArray",
            "ret": 2
        },
        {
            "index": 104,
            "fname": "get isArrayRef",
            "ret": 2
        },
        {
            "index": 105,
            "fname": "get isRef",
            "ret": 2
        },
        {
            "index": 106,
            "fname": "inherits",
            "params": {
                "protocol": 107
            },
            "ret": 0
        },
        {
            "index": 107,
            "cname": "ProtocolRef",
            "supers": {
                "Protocol": 178
            },
            "fields": {
                "protocolDecl": -109
            },
            "methods": [
                108,
                183,
                184,
                185
            ]
        },
        {
            "index": 108,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "name": 3
            },
            "ret": 107,
            "hobj": 1
        },
        {
            "index": 109,
            "cname": "ProtocolDecl",
            "supers": {
                "Protocol": 178
            },
            "fields": {
                "extends": -111,
                "_signatures": -145,
                "_signatureMap": -77,
                "_typeVariable": -146
            },
            "methods": [
                110,
                168,
                169,
                170,
                171,
                172,
                173,
                176,
                181,
                182
            ]
        },
        {
            "index": 110,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "name": 3
            },
            "ret": 109,
            "hobj": 1
        },
        {
            "index": 111,
            "aname": "",
            "element": 107,
            "mode": "normal"
        },
        {
            "index": 112,
            "cname": "ProtocolFuncDecl",
            "supers": {
                "Func": 115
            },
            "fields": {
                "protocolDecl": 109,
                "possibleOverloads": 143
            },
            "methods": [
                113,
                144
            ]
        },
        {
            "index": 113,
            "fname": "constructor",
            "ret": 112
        },
        {
            "index": 114,
            "cname": "Func",
            "supers": {
                "Node": 8
            },
            "fields": {
                "_origin": 42,
                "_typeParameters": 101,
                "_parameters": 130,
                "uninstantiatedReturnType": 85,
                "_name": 3,
                "_returnType": 85,
                "_isCast": 2,
                "_shaderType": 3,
                "implementation": 0,
                "inlined": 2,
                "isRestricted": 2
            },
            "methods": [
                115,
                131,
                132,
                133,
                134,
                135,
                137,
                138,
                139,
                140,
                141,
                142
            ]
        },
        {
            "index": 115,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "name": 3,
                "returnType": 85,
                "typeParameters": 101,
                "parameters": 130,
                "isCast": 2,
                "shaderType": 3
            },
            "ret": 114,
            "hobj": 1
        },
        {
            "index": 116,
            "cname": "FuncParameter",
            "supers": {
                "Value": 121
            },
            "methods": [
                117,
                118,
                119
            ]
        },
        {
            "index": 117,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "name": 3,
                "type": 85
            },
            "ret": 116,
            "hobj": 1
        },
        {
            "index": 118,
            "fname": "get varIsLValue",
            "ret": 2
        },
        {
            "index": 119,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 120,
            "cname": "Value",
            "supers": {
                "Node": 8
            },
            "fields": {
                "_name": -3
            },
            "methods": [
                121,
                123,
                124,
                125,
                126,
                127,
                128,
                129
            ]
        },
        {
            "index": 121,
            "fname": "constructor",
            "ret": 120
        },
        {
            "index": 122,
            "bname": "Object"
        },
        {
            "index": 123,
            "fname": "get kind",
            "ret": 121
        },
        {
            "index": 124,
            "fname": "get isConstexpr",
            "ret": 2
        },
        {
            "index": 125,
            "fname": "get isLValue",
            "ret": 2
        },
        {
            "index": 126,
            "fname": "get notLValueReason",
            "ret": 3
        },
        {
            "index": 127,
            "fname": "get varIsLValue",
            "ret": 2
        },
        {
            "index": 128,
            "fname": "get notLValueReasonString",
            "ret": 3
        },
        {
            "index": 129,
            "fname": "become",
            "params": {
                "otherValue": 120
            }
        },
        {
            "index": 130,
            "aname": "",
            "element": 116,
            "mode": "normal"
        },
        {
            "index": 131,
            "fname": "get returnType",
            "ret": 85
        },
        {
            "index": 132,
            "fname": "get typeParameters",
            "ret": 101
        },
        {
            "index": 133,
            "fname": "get typeParametersForCallResolution",
            "ret": 101
        },
        {
            "index": 134,
            "fname": "get parameters",
            "ret": 130
        },
        {
            "index": 135,
            "fname": "get parameterTypes",
            "ret": 136
        },
        {
            "index": 136,
            "aname": "",
            "element": 85,
            "mode": "normal"
        },
        {
            "index": 137,
            "fname": "get isCast",
            "ret": 2
        },
        {
            "index": 138,
            "fname": "get shaderType",
            "ret": 3
        },
        {
            "index": 139,
            "fname": "get returnTypeForOverloadResolution",
            "ret": 85
        },
        {
            "index": 140,
            "fname": "get kind",
            "ret": 115
        },
        {
            "index": 141,
            "fname": "toDeclString",
            "ret": 3
        },
        {
            "index": 142,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 143,
            "aname": "",
            "element": 114,
            "mode": "normal"
        },
        {
            "index": 144,
            "fname": "get typeParametersForCallResolution",
            "ret": 101
        },
        {
            "index": 145,
            "aname": "",
            "element": 112,
            "mode": "normal"
        },
        {
            "index": 146,
            "cname": "TypeVariable",
            "supers": {
                "Type": 86
            },
            "fields": {
                "_name": -3,
                "_protocol": -107
            },
            "methods": [
                147,
                148,
                149,
                150,
                151,
                152,
                164,
                165,
                166,
                167
            ]
        },
        {
            "index": 147,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "name": 3,
                "protocol": 107
            },
            "ret": 146,
            "hobj": 1
        },
        {
            "index": 148,
            "fname": "get protocol",
            "ret": 107
        },
        {
            "index": 149,
            "fname": "get isPrimitive",
            "ret": 2
        },
        {
            "index": 150,
            "fname": "get isUnifiable",
            "ret": 2
        },
        {
            "index": 151,
            "fname": "inherits",
            "params": {
                "protocol": 107
            },
            "ret": 0
        },
        {
            "index": 152,
            "fname": "typeVariableUnify",
            "params": {
                "unificationContext": 153,
                "other": 146
            },
            "ret": 2
        },
        {
            "index": 153,
            "cname": "UnificationContext",
            "fields": {
                "_typeParameters": -78,
                "_nextMap": -77,
                "_extraNodes": -78
            },
            "methods": [
                154,
                155,
                156,
                157,
                158,
                159,
                160,
                161,
                162,
                163
            ]
        },
        {
            "index": 154,
            "fname": "constructor",
            "params": {
                "typeParameters": 101
            },
            "ret": 153
        },
        {
            "index": 155,
            "fname": "union",
            "params": {
                "a": 7,
                "b": 7
            }
        },
        {
            "index": 156,
            "fname": "find",
            "params": {
                "node": 7
            },
            "ret": 7
        },
        {
            "index": 157,
            "fname": "addExtraNode",
            "params": {
                "node": 7
            }
        },
        {
            "index": 158,
            "fname": "get nodes",
            "ret": 78
        },
        {
            "index": 159,
            "fname": "typeParameters",
            "ret": 78
        },
        {
            "index": 160,
            "fname": "typeArguments",
            "ret": 82
        },
        {
            "index": 161,
            "fname": "verify",
            "ret": 0
        },
        {
            "index": 162,
            "fname": "get conversionCost",
            "ret": 5
        },
        {
            "index": 163,
            "fname": "commit"
        },
        {
            "index": 164,
            "fname": "unifyImpl",
            "params": {
                "unificationContext": 153,
                "other": 146
            },
            "ret": 2
        },
        {
            "index": 165,
            "fname": "verifyAsArgument",
            "params": {
                "unificationContext": 153
            },
            "ret": 0
        },
        {
            "index": 166,
            "fname": "verifyAsParameter",
            "params": {
                "unificationContext": 153
            },
            "ret": 0
        },
        {
            "index": 167,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 168,
            "fname": "addExtends",
            "params": {
                "protocol": 107
            }
        },
        {
            "index": 169,
            "fname": "add",
            "params": {
                "signature": 112
            }
        },
        {
            "index": 170,
            "fname": "get signatures",
            "ret": 145
        },
        {
            "index": 171,
            "fname": "signaturesByName",
            "params": {
                "name": 3
            },
            "ret": 143
        },
        {
            "index": 172,
            "fname": "get typeVariable",
            "ret": 146
        },
        {
            "index": 173,
            "fname": "signaturesByNameWithTypeVariable",
            "params": {
                "name": 3,
                "typeVariable": 7
            },
            "ret": 175
        },
        {
            "index": 174,
            "uname": "",
            "types": [
                3,
                7,
                43
            ]
        },
        {
            "index": 175,
            "aname": "",
            "element": 174,
            "mode": "normal"
        },
        {
            "index": 176,
            "fname": "inherits",
            "params": {
                "otherProtocol": 177
            },
            "ret": 0
        },
        {
            "index": 177,
            "cname": "Protocol",
            "supers": {
                "Node": 8
            },
            "fields": {
                "_name": -3
            },
            "methods": [
                178,
                179,
                180
            ]
        },
        {
            "index": 178,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "name": 3
            },
            "ret": 177,
            "hobj": 1
        },
        {
            "index": 179,
            "fname": "get kind",
            "ret": 178
        },
        {
            "index": 180,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 181,
            "fname": "hasHeir",
            "params": {
                "type": 85
            },
            "ret": 0
        },
        {
            "index": 182,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 183,
            "fname": "inherits",
            "params": {
                "other": 177
            },
            "ret": 0
        },
        {
            "index": 184,
            "fname": "hasHeir",
            "params": {
                "type": 85
            },
            "ret": 0
        },
        {
            "index": 185,
            "fname": "get isPrimitive",
            "ret": 2
        },
        {
            "index": 186,
            "fname": "get instantiatedType",
            "ret": 85
        },
        {
            "index": 187,
            "fname": "argumentForAndOverload",
            "params": {
                "origin": 42,
                "value": 188
            },
            "ret": 7
        },
        {
            "index": 188,
            "uname": "",
            "types": [
                1,
                7,
                43
            ]
        },
        {
            "index": 189,
            "fname": "argumentTypeForAndOverload",
            "params": {
                "origin": 42,
                "type": 85
            },
            "ret": 85
        },
        {
            "index": 190,
            "fname": "returnTypeFromAndOverload",
            "params": {
                "origin": 42
            },
            "ret": 85
        },
        {
            "index": 191,
            "fname": "get currentStatement",
            "ret": 7
        },
        {
            "index": 192,
            "fname": "doStatement",
            "params": {
                "statement": 7,
                "callback": 0
            }
        },
        {
            "index": 193,
            "fname": "recognizeIntrinsics"
        },
        {
            "index": 194,
            "fname": "get intrinsics",
            "ret": 73
        },
        {
            "index": 195,
            "fname": "get program",
            "ret": 71
        },
        {
            "index": 196,
            "fname": "set program",
            "params": {
                "value": 71
            }
        },
        {
            "index": 197,
            "fname": "[Symbol.iterator]",
            "ret": 82
        },
        {
            "index": 198,
            "fname": "add",
            "params": {
                "thing": 199
            }
        },
        {
            "index": 199,
            "uname": "",
            "types": [
                85,
                114
            ]
        },
        {
            "index": 200,
            "cname": "FuncInstantiator",
            "fields": {
                "_program": -71,
                "_instances": -77
            },
            "methods": [
                201,
                202
            ]
        },
        {
            "index": 201,
            "fname": "constructor",
            "params": {
                "program": 71
            },
            "ret": 200
        },
        {
            "index": 202,
            "fname": "getUnique",
            "params": {
                "func": 114,
                "typeArguments": 101
            },
            "ret": 114
        },
        {
            "index": 203,
            "fname": "get topLevelStatements",
            "ret": 101
        },
        {
            "index": 204,
            "fname": "get functions",
            "ret": 77
        },
        {
            "index": 205,
            "fname": "get types",
            "ret": 77
        },
        {
            "index": 206,
            "fname": "get protocols",
            "ret": 77
        },
        {
            "index": 207,
            "fname": "get funcInstantiator",
            "ret": 200
        },
        {
            "index": 208,
            "fname": "get globalNameContext",
            "ret": 75
        },
        {
            "index": 209,
            "fname": "add",
            "params": {
                "statement": 7
            }
        },
        {
            "index": 210,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 211,
            "fname": "get name",
            "ret": 3
        },
        {
            "index": 212,
            "fname": "set name",
            "params": {
                "name": 3
            }
        },
        {
            "index": 213,
            "fname": "verifyAsArgument",
            "params": {
                "unificationContext": 153
            },
            "ret": 0
        },
        {
            "index": 214,
            "fname": "get type",
            "ret": 85
        },
        {
            "index": 215,
            "fname": "set type",
            "params": {
                "val": 85
            }
        },
        {
            "index": 216,
            "fname": "get addressSpace",
            "ret": 3
        },
        {
            "index": 217,
            "fname": "set addressSpace",
            "params": {
                "val": 3
            }
        },
        {
            "index": 218,
            "fname": "verifyAsParameter",
            "params": {
                "unificationContext": 153
            },
            "ret": 0
        },
        {
            "index": 219,
            "fname": "visit",
            "params": {
                "visitor": 735
            },
            "ret": 174
        },
        {
            "index": 220,
            "cname": "Visitor",
            "fields": {
                "returnValue": 7
            },
            "methods": [
                221,
                222,
                223,
                224,
                225,
                226,
                637,
                638,
                639,
                640,
                641,
                642,
                643,
                644,
                645,
                646,
                647,
                648,
                649,
                650,
                651,
                652,
                653,
                654,
                656,
                657,
                658,
                659,
                660,
                661,
                662,
                663,
                664,
                665,
                666,
                667,
                668,
                669,
                670,
                671,
                672,
                673,
                674,
                675,
                676,
                677,
                678,
                679,
                680,
                681,
                682,
                683,
                684,
                685,
                686,
                687,
                688,
                689,
                690,
                691
            ]
        },
        {
            "index": 221,
            "fname": "constructor",
            "ret": 220
        },
        {
            "index": 222,
            "fname": "visitProgram",
            "params": {
                "node": 71
            }
        },
        {
            "index": 223,
            "fname": "visitFunc",
            "params": {
                "node": 114
            }
        },
        {
            "index": 224,
            "fname": "visitProtocolFuncDecl",
            "params": {
                "node": 112
            }
        },
        {
            "index": 225,
            "fname": "visitFuncParameter",
            "params": {
                "node": 116
            }
        },
        {
            "index": 226,
            "fname": "visitFuncDef",
            "params": {
                "node": 227
            }
        },
        {
            "index": 227,
            "cname": "FuncDef",
            "supers": {
                "Func": 115
            },
            "fields": {
                "returnEPtr": 43,
                "_body": 7,
                "isRestricted": 2
            },
            "methods": [
                228,
                229,
                230,
                636
            ]
        },
        {
            "index": 228,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "name": 3,
                "returnType": 85,
                "typeParameters": 101,
                "parameters": 130,
                "body": 7,
                "isCast": 2,
                "shaderType": 3
            },
            "ret": 227,
            "hobj": 1
        },
        {
            "index": 229,
            "fname": "get body",
            "ret": 7
        },
        {
            "index": 230,
            "fname": "rewrite",
            "params": {
                "rewriter": 231
            }
        },
        {
            "index": 231,
            "cname": "Rewriter",
            "fields": {
                "_mapping": -77
            },
            "methods": [
                232,
                233,
                234,
                235,
                236,
                241,
                248,
                274,
                279,
                295,
                296,
                297,
                314,
                315,
                316,
                324,
                325,
                331,
                337,
                343,
                344,
                356,
                357,
                358,
                366,
                372,
                384,
                391,
                404,
                410,
                428,
                434,
                465,
                474,
                484,
                489,
                490,
                495,
                496,
                501,
                505,
                509,
                513,
                527,
                541,
                547,
                551,
                562,
                563,
                564,
                572,
                578,
                585,
                592,
                598,
                604,
                612,
                626,
                627,
                628
            ]
        },
        {
            "index": 232,
            "fname": "constructor",
            "ret": 231
        },
        {
            "index": 233,
            "fname": "_mapNode",
            "params": {
                "oldItem": 7,
                "newItem": 7
            },
            "ret": 7
        },
        {
            "index": 234,
            "fname": "_getMapping",
            "params": {
                "oldItem": 7
            },
            "ret": 7
        },
        {
            "index": 235,
            "fname": "visitFuncDef",
            "params": {
                "node": 227
            },
            "ret": 227
        },
        {
            "index": 236,
            "fname": "visitNativeFunc",
            "params": {
                "node": 237
            },
            "ret": 237
        },
        {
            "index": 237,
            "cname": "NativeFunc",
            "supers": {
                "Func": 115
            },
            "fields": {
                "instantiateImplementation": 0,
                "visitImplementationData": 0,
                "didLayoutStructsInImplementationData": 0,
                "isRestricted": 2
            },
            "methods": [
                238,
                239,
                240
            ]
        },
        {
            "index": 238,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "name": 3,
                "returnType": 85,
                "typeParameters": 101,
                "parameters": 130,
                "isCast": 2,
                "shaderType": 3
            },
            "ret": 237,
            "hobj": 1
        },
        {
            "index": 239,
            "fname": "get isNative",
            "ret": 2
        },
        {
            "index": 240,
            "fname": "toDeclString",
            "ret": 3,
            "hobj": 1
        },
        {
            "index": 241,
            "fname": "visitNativeFuncInstance",
            "params": {
                "node": 242
            },
            "ret": 242
        },
        {
            "index": 242,
            "cname": "NativeFuncInstance",
            "supers": {
                "Func": 115
            },
            "fields": {
                "_func": 237,
                "_implementationData": 0
            },
            "methods": [
                243,
                244,
                245,
                246,
                247
            ]
        },
        {
            "index": 243,
            "fname": "constructor",
            "params": {
                "func": 237,
                "returnType": 85,
                "parameters": 130,
                "isCast": 2,
                "shaderType": 3,
                "implementationData": 0
            },
            "ret": 242,
            "hobj": 1
        },
        {
            "index": 244,
            "fname": "get func",
            "ret": 237
        },
        {
            "index": 245,
            "fname": "get isNative",
            "ret": 2
        },
        {
            "index": 246,
            "fname": "get implementationData",
            "ret": 0
        },
        {
            "index": 247,
            "fname": "toDeclString",
            "ret": 3,
            "hobj": 1
        },
        {
            "index": 248,
            "fname": "visitNativeType",
            "params": {
                "node": 249
            },
            "ret": 7
        },
        {
            "index": 249,
            "cname": "NativeType",
            "supers": {
                "Type": 86
            },
            "fields": {
                "_origin": -42,
                "_name": -3,
                "_typeParameters": -262,
                "_isNumber": -2,
                "_isInt": -2,
                "_isFloating": -2,
                "_isPrimitive": -2
            },
            "methods": [
                250,
                263,
                264,
                265,
                266,
                267,
                268,
                269,
                270,
                271,
                272,
                273
            ]
        },
        {
            "index": 250,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "name": 3,
                "typeParameters": 262
            },
            "ret": 249,
            "hobj": 1
        },
        {
            "index": 251,
            "cname": "ConstexprTypeParameter",
            "supers": {
                "Value": 121
            },
            "fields": {
                "_name": -3
            },
            "methods": [
                252,
                253,
                254,
                255,
                256,
                257,
                258,
                259,
                260
            ]
        },
        {
            "index": 252,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "name": 3,
                "type": 85
            },
            "ret": 251,
            "hobj": 1
        },
        {
            "index": 253,
            "fname": "get isConstexpr",
            "ret": 2
        },
        {
            "index": 254,
            "fname": "get isUnifiable",
            "ret": 2
        },
        {
            "index": 255,
            "fname": "get varIsLValue",
            "ret": 2
        },
        {
            "index": 256,
            "fname": "typeVariableUnify",
            "params": {
                "unificationContext": 153,
                "other": 120
            },
            "ret": 2
        },
        {
            "index": 257,
            "fname": "unifyImpl",
            "params": {
                "unificationContext": 153,
                "other": 120
            },
            "ret": 2
        },
        {
            "index": 258,
            "fname": "verifyAsArgument",
            "params": {
                "unificationContext": 153
            },
            "ret": 0
        },
        {
            "index": 259,
            "fname": "verifyAsParameter",
            "params": {
                "unificationContext": 153
            },
            "ret": 0
        },
        {
            "index": 260,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 261,
            "uname": "",
            "types": [
                146,
                251
            ]
        },
        {
            "index": 262,
            "aname": "",
            "element": 261,
            "mode": "normal"
        },
        {
            "index": 263,
            "fname": "get typeParameters",
            "ret": 262
        },
        {
            "index": 264,
            "fname": "get isNative",
            "ret": 2
        },
        {
            "index": 265,
            "fname": "get isNumber",
            "ret": 2
        },
        {
            "index": 266,
            "fname": "set isNumber",
            "params": {
                "value": 2
            }
        },
        {
            "index": 267,
            "fname": "get isInt",
            "ret": 2
        },
        {
            "index": 268,
            "fname": "set isInt",
            "params": {
                "value": 2
            }
        },
        {
            "index": 269,
            "fname": "get isFloating",
            "ret": 2
        },
        {
            "index": 270,
            "fname": "set isFloating",
            "params": {
                "value": 2
            }
        },
        {
            "index": 271,
            "fname": "get isPrimitive",
            "ret": 2
        },
        {
            "index": 272,
            "fname": "set isPrimitive",
            "params": {
                "value": 2
            }
        },
        {
            "index": 273,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 274,
            "fname": "visitTypeDef",
            "params": {
                "node": 275
            },
            "ret": 275
        },
        {
            "index": 275,
            "cname": "TypeDef",
            "supers": {
                "Type": 86
            },
            "fields": {
                "_name": -3,
                "_typeParameters": -101
            },
            "methods": [
                276,
                277,
                278
            ]
        },
        {
            "index": 276,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "name": 3,
                "typeParameters": 101,
                "type": 85
            },
            "ret": 275,
            "hobj": 1
        },
        {
            "index": 277,
            "fname": "get typeParameters",
            "ret": 101
        },
        {
            "index": 278,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 279,
            "fname": "visitStructType",
            "params": {
                "node": 280
            },
            "ret": 7
        },
        {
            "index": 280,
            "cname": "StructType",
            "supers": {
                "Type": 86
            },
            "fields": {
                "_name": -3,
                "_typeParameters": -101,
                "_fields": -77
            },
            "methods": [
                281,
                282,
                283,
                287,
                288,
                290,
                291,
                292,
                293,
                294
            ]
        },
        {
            "index": 281,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "name": 3,
                "typeParameters": 101
            },
            "ret": 280,
            "hobj": 1
        },
        {
            "index": 282,
            "fname": "_instantiate",
            "params": {
                "typeArguments": 101
            },
            "ret": 280
        },
        {
            "index": 283,
            "fname": "add",
            "params": {
                "field": 284
            }
        },
        {
            "index": 284,
            "cname": "Field",
            "supers": {
                "Node": 8
            },
            "fields": {
                "_name": -3,
                "offset": 5,
                "struct": 280
            },
            "methods": [
                285,
                286
            ]
        },
        {
            "index": 285,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "name": 3,
                "type": 85
            },
            "ret": 284,
            "hobj": 1
        },
        {
            "index": 286,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 287,
            "fname": "get typeParameters",
            "ret": 101
        },
        {
            "index": 288,
            "fname": "get fieldNames",
            "ret": 289
        },
        {
            "index": 289,
            "bname": "IterableIterator"
        },
        {
            "index": 290,
            "fname": "fieldByName",
            "params": {
                "name": 3
            },
            "ret": 284
        },
        {
            "index": 291,
            "fname": "get fields",
            "ret": 289
        },
        {
            "index": 292,
            "fname": "get fieldMap",
            "ret": 77
        },
        {
            "index": 293,
            "fname": "get isPrimitive",
            "ret": 2
        },
        {
            "index": 294,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 295,
            "fname": "visitConstexprTypeParameter",
            "params": {
                "node": 251
            },
            "ret": 7
        },
        {
            "index": 296,
            "fname": "visitProtocolDecl",
            "params": {
                "node": 109
            },
            "ret": 109
        },
        {
            "index": 297,
            "fname": "visitEnumType",
            "params": {
                "node": 298
            },
            "ret": 298
        },
        {
            "index": 298,
            "cname": "EnumType",
            "supers": {
                "Type": 86
            },
            "fields": {
                "_name": -3,
                "_baseType": -85,
                "_members": -77
            },
            "methods": [
                299,
                300,
                306,
                307,
                308,
                309,
                310,
                311,
                312,
                313
            ]
        },
        {
            "index": 299,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "name": 3,
                "baseType": 85
            },
            "ret": 298,
            "hobj": 1
        },
        {
            "index": 300,
            "fname": "add",
            "params": {
                "member": 301
            }
        },
        {
            "index": 301,
            "cname": "EnumMember",
            "supers": {
                "Node": 8
            },
            "fields": {
                "value": -303,
                "_name": -3,
                "enumType": 298
            },
            "methods": [
                302,
                305
            ]
        },
        {
            "index": 302,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "name": 3,
                "value": 303
            },
            "ret": 301,
            "hobj": 1
        },
        {
            "index": 303,
            "cname": "Expression",
            "supers": {
                "Value": 121
            },
            "methods": [
                304
            ]
        },
        {
            "index": 304,
            "fname": "constructor",
            "params": {
                "origin": 42
            },
            "ret": 303,
            "hobj": 1
        },
        {
            "index": 305,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 306,
            "fname": "get baseType",
            "ret": 85
        },
        {
            "index": 307,
            "fname": "get memberNames",
            "ret": 289
        },
        {
            "index": 308,
            "fname": "memberByName",
            "params": {
                "name": 3
            },
            "ret": 301
        },
        {
            "index": 309,
            "fname": "get members",
            "ret": 289
        },
        {
            "index": 310,
            "fname": "get memberMap",
            "ret": 77
        },
        {
            "index": 311,
            "fname": "get isPrimitive",
            "ret": 2
        },
        {
            "index": 312,
            "fname": "get size",
            "ret": 5
        },
        {
            "index": 313,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 314,
            "fname": "visitTypeVariable",
            "params": {
                "node": 146
            },
            "ret": 7
        },
        {
            "index": 315,
            "fname": "visitProtocolFuncDecl",
            "params": {
                "node": 112
            },
            "ret": 112
        },
        {
            "index": 316,
            "fname": "visitNativeTypeInstance",
            "params": {
                "node": 317
            },
            "ret": 317
        },
        {
            "index": 317,
            "cname": "NativeTypeInstance",
            "supers": {
                "Type": 86
            },
            "fields": {
                "_typeArguments": -136
            },
            "methods": [
                318,
                319,
                320,
                321,
                322,
                323
            ]
        },
        {
            "index": 318,
            "fname": "constructor",
            "params": {
                "type": 85,
                "typeArguments": 136
            },
            "ret": 317,
            "hobj": 1
        },
        {
            "index": 319,
            "fname": "get typeArguments",
            "ret": 136
        },
        {
            "index": 320,
            "fname": "get isPrimitive",
            "ret": 2
        },
        {
            "index": 321,
            "fname": "get isNative",
            "ret": 2
        },
        {
            "index": 322,
            "fname": "unifyImpl",
            "params": {
                "unificationContext": 153,
                "other": 317
            },
            "ret": 2
        },
        {
            "index": 323,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 324,
            "fname": "visitFuncParameter",
            "params": {
                "node": 116
            },
            "ret": 7
        },
        {
            "index": 325,
            "fname": "visitVariableDecl",
            "params": {
                "node": 326
            },
            "ret": 7
        },
        {
            "index": 326,
            "cname": "VariableDecl",
            "supers": {
                "Value": 121
            },
            "fields": {
                "_initializer": -7,
                "_name": -3
            },
            "methods": [
                327,
                328,
                329,
                330
            ]
        },
        {
            "index": 327,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "name": 3,
                "type": 85,
                "initializer": 303
            },
            "ret": 326,
            "hobj": 1
        },
        {
            "index": 328,
            "fname": "get initializer",
            "ret": 7
        },
        {
            "index": 329,
            "fname": "get varIsLValue",
            "ret": 2
        },
        {
            "index": 330,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 331,
            "fname": "visitBlock",
            "params": {
                "node": 332
            },
            "ret": 332
        },
        {
            "index": 332,
            "cname": "Block",
            "supers": {
                "Node": 8
            },
            "fields": {
                "_statements": -101,
                "__origin": -3
            },
            "methods": [
                333,
                334,
                335,
                336
            ]
        },
        {
            "index": 333,
            "fname": "constructor",
            "params": {
                "origin": 3
            },
            "ret": 332,
            "hobj": 1
        },
        {
            "index": 334,
            "fname": "add",
            "params": {
                "statement": 7
            }
        },
        {
            "index": 335,
            "fname": "get statements",
            "ret": 101
        },
        {
            "index": 336,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 337,
            "fname": "visitCommaExpression",
            "params": {
                "node": 338
            },
            "ret": 338
        },
        {
            "index": 338,
            "cname": "CommaExpression",
            "supers": {
                "Expression": 304
            },
            "fields": {
                "_list": -340
            },
            "methods": [
                339,
                341,
                342
            ]
        },
        {
            "index": 339,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "list": 340
            },
            "ret": 338,
            "hobj": 1
        },
        {
            "index": 340,
            "aname": "",
            "element": 303,
            "mode": "normal"
        },
        {
            "index": 341,
            "fname": "get list",
            "ret": 340
        },
        {
            "index": 342,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 343,
            "fname": "visitProtocolRef",
            "params": {
                "node": 107
            },
            "ret": 107
        },
        {
            "index": 344,
            "fname": "visitTypeRef",
            "params": {
                "node": 345
            },
            "ret": 174
        },
        {
            "index": 345,
            "cname": "TypeRef",
            "supers": {
                "Type": 86
            },
            "fields": {
                "_name": -3,
                "_typeArguments": -101
            },
            "sfields": {
                "const wrap": 347,
                "const instantiate": 348
            },
            "methods": [
                346,
                349,
                350,
                351,
                352,
                353,
                354,
                355
            ]
        },
        {
            "index": 346,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "name": 3,
                "typeArguments": 101
            },
            "ret": 345,
            "hobj": 1
        },
        {
            "index": 347,
            "fname": "static wrap",
            "params": {
                "type": 85
            },
            "ret": 345
        },
        {
            "index": 348,
            "fname": "static instantiate",
            "params": {
                "type": 85,
                "typeArguments": 101
            },
            "ret": 345
        },
        {
            "index": 349,
            "fname": "get typeArguments",
            "ret": 101
        },
        {
            "index": 350,
            "fname": "get unifyNode",
            "ret": 7
        },
        {
            "index": 351,
            "fname": "get size",
            "ret": 5
        },
        {
            "index": 352,
            "fname": "get isPrimitive",
            "ret": 2
        },
        {
            "index": 353,
            "fname": "setTypeAndArguments",
            "params": {
                "type": 85,
                "typeArguments": 101
            }
        },
        {
            "index": 354,
            "fname": "unifyImpl",
            "params": {
                "unificationContext": 153,
                "other": 345
            },
            "ret": 2
        },
        {
            "index": 355,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 356,
            "fname": "visitField",
            "params": {
                "node": 284
            },
            "ret": 284
        },
        {
            "index": 357,
            "fname": "visitEnumMember",
            "params": {
                "node": 301
            },
            "ret": 301
        },
        {
            "index": 358,
            "fname": "visitEnumLiteral",
            "params": {
                "node": 359
            },
            "ret": 359
        },
        {
            "index": 359,
            "cname": "EnumLiteral",
            "supers": {
                "Expression": 304
            },
            "fields": {
                "_member": -301
            },
            "methods": [
                360,
                361,
                362,
                363,
                364,
                365
            ]
        },
        {
            "index": 360,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "member": 301
            },
            "ret": 359,
            "hobj": 1
        },
        {
            "index": 361,
            "fname": "get member",
            "ret": 301
        },
        {
            "index": 362,
            "fname": "get isConstexpr",
            "ret": 2
        },
        {
            "index": 363,
            "fname": "unifyImpl",
            "params": {
                "unificationContext": 153,
                "other": 359
            },
            "ret": 2
        },
        {
            "index": 364,
            "fname": "get valueForSelectedType",
            "ret": 1
        },
        {
            "index": 365,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 366,
            "fname": "visitReferenceType",
            "params": {
                "node": 367
            },
            "ret": 367
        },
        {
            "index": 367,
            "cname": "ReferenceType",
            "supers": {
                "Type": 86
            },
            "methods": [
                368,
                369,
                370,
                371
            ]
        },
        {
            "index": 368,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "addressSpace": 3,
                "elementType": 85
            },
            "ret": 367,
            "hobj": 1
        },
        {
            "index": 369,
            "fname": "get elementType",
            "ret": 85
        },
        {
            "index": 370,
            "fname": "get addressSpace",
            "ret": 3
        },
        {
            "index": 371,
            "fname": "get size",
            "ret": 5
        },
        {
            "index": 372,
            "fname": "visitPtrType",
            "params": {
                "node": 373
            },
            "ret": 367
        },
        {
            "index": 373,
            "cname": "PtrType",
            "supers": {
                "ReferenceType": 368
            },
            "methods": [
                374,
                375,
                376,
                381,
                382,
                383
            ]
        },
        {
            "index": 374,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "addressSpace": 3,
                "elementType": 85
            },
            "ret": 373,
            "hobj": 1
        },
        {
            "index": 375,
            "fname": "unifyImpl",
            "params": {
                "unificationContext": 153,
                "other": 85
            },
            "ret": 2
        },
        {
            "index": 376,
            "fname": "argumentForAndOverload",
            "params": {
                "origin": 42,
                "value": 188
            },
            "ret": 377
        },
        {
            "index": 377,
            "cname": "MakeArrayRefExpression",
            "supers": {
                "Expression": 304
            },
            "fields": {
                "numElements": 303,
                "_lValue": -120
            },
            "methods": [
                378,
                379,
                380
            ]
        },
        {
            "index": 378,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "lValue": 120
            },
            "ret": 377,
            "hobj": 1
        },
        {
            "index": 379,
            "fname": "get lValue",
            "ret": 120
        },
        {
            "index": 380,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 381,
            "fname": "argumentTypeForAndOverload",
            "params": {
                "origin": 42,
                "type": 85
            },
            "ret": 373
        },
        {
            "index": 382,
            "fname": "returnTypeFromAndOverload",
            "params": {
                "origin": 42
            },
            "ret": 85
        },
        {
            "index": 383,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 384,
            "fname": "visitArrayRefType",
            "params": {
                "node": 385
            },
            "ret": 367
        },
        {
            "index": 385,
            "cname": "ArrayRefType",
            "supers": {
                "ReferenceType": 368
            },
            "methods": [
                386,
                387,
                388,
                389,
                390
            ]
        },
        {
            "index": 386,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "addressSpace": 3,
                "elementType": 85
            },
            "ret": 385,
            "hobj": 1
        },
        {
            "index": 387,
            "fname": "unifyImpl",
            "params": {
                "unificationContext": 153,
                "other": 85
            },
            "ret": 2
        },
        {
            "index": 388,
            "fname": "argumentForAndOverload",
            "params": {
                "origin": 42,
                "value": 188
            },
            "ret": 7
        },
        {
            "index": 389,
            "fname": "argumentTypeForAndOverload",
            "params": {
                "origin": 42
            },
            "ret": 385
        },
        {
            "index": 390,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 391,
            "fname": "visitArrayType",
            "params": {
                "node": 392
            },
            "ret": 392
        },
        {
            "index": 392,
            "cname": "ArrayType",
            "supers": {
                "Type": 86
            },
            "fields": {
                "_elementType": -85,
                "_numElements": -303
            },
            "methods": [
                393,
                394,
                395,
                396,
                397,
                398,
                399,
                400,
                401,
                402,
                403
            ]
        },
        {
            "index": 393,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "elementType": 85,
                "numElements": 303
            },
            "ret": 392,
            "hobj": 1
        },
        {
            "index": 394,
            "fname": "get elementType",
            "ret": 85
        },
        {
            "index": 395,
            "fname": "get numElements",
            "ret": 303
        },
        {
            "index": 396,
            "fname": "get isPrimitive",
            "ret": 2
        },
        {
            "index": 397,
            "fname": "get isArray",
            "ret": 2
        },
        {
            "index": 398,
            "fname": "get numElementsValue",
            "ret": 1
        },
        {
            "index": 399,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 400,
            "fname": "get size",
            "ret": 1
        },
        {
            "index": 401,
            "fname": "unifyImpl",
            "params": {
                "unificationContext": 153,
                "other": 392
            },
            "ret": 2
        },
        {
            "index": 402,
            "fname": "argumentForAndOverload",
            "params": {
                "origin": 42,
                "value": 188
            },
            "ret": 377
        },
        {
            "index": 403,
            "fname": "argumentTypeForAndOverload",
            "params": {
                "origin": 42
            },
            "ret": 367
        },
        {
            "index": 404,
            "fname": "visitAssignment",
            "params": {
                "node": 405
            },
            "ret": 405
        },
        {
            "index": 405,
            "cname": "Assignment",
            "supers": {
                "Expression": 304
            },
            "fields": {
                "_lhs": -120,
                "_rhs": -7
            },
            "methods": [
                406,
                407,
                408,
                409
            ]
        },
        {
            "index": 406,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "lhs": 120,
                "rhs": 7,
                "type": 85
            },
            "ret": 405,
            "hobj": 1
        },
        {
            "index": 407,
            "fname": "get lhs",
            "ret": 120
        },
        {
            "index": 408,
            "fname": "get rhs",
            "ret": 7
        },
        {
            "index": 409,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 410,
            "fname": "visitReadModifyWriteExpression",
            "params": {
                "node": 411
            },
            "ret": 411
        },
        {
            "index": 411,
            "cname": "ReadModifyWriteExpression",
            "supers": {
                "Expression": 304
            },
            "fields": {
                "oldValueVar": -413,
                "newValueVar": -413,
                "newValueExp": -303,
                "resultExp": -303,
                "_lValue": -303
            },
            "methods": [
                412,
                416,
                417,
                426,
                427
            ]
        },
        {
            "index": 412,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "lValue": 303,
                "type": 85
            },
            "ret": 411,
            "hobj": 1
        },
        {
            "index": 413,
            "cname": "AnonymousVariable",
            "supers": {
                "Value": 121
            },
            "fields": {
                "index": -5
            },
            "methods": [
                414,
                415
            ]
        },
        {
            "index": 414,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "type": 85
            },
            "ret": 413,
            "hobj": 1
        },
        {
            "index": 415,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 416,
            "fname": "get lValue",
            "ret": 303
        },
        {
            "index": 417,
            "fname": "oldValueRef",
            "ret": 418
        },
        {
            "index": 418,
            "cname": "VariableRef",
            "supers": {
                "Expression": 304
            },
            "fields": {
                "variable": -120,
                "_name": -3
            },
            "sfields": {
                "const wrap": 421
            },
            "methods": [
                419,
                420,
                422,
                423,
                424,
                425
            ]
        },
        {
            "index": 419,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "name": 3
            },
            "ret": 418,
            "hobj": 1
        },
        {
            "index": 420,
            "fname": "get addressSpace",
            "ret": 3
        },
        {
            "index": 421,
            "fname": "static wrap",
            "params": {
                "variable": 120
            },
            "ret": 418
        },
        {
            "index": 422,
            "fname": "get isConstexpr",
            "ret": 2
        },
        {
            "index": 423,
            "fname": "get unifyNode",
            "ret": 7
        },
        {
            "index": 424,
            "fname": "get isLValue",
            "ret": 2
        },
        {
            "index": 425,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 426,
            "fname": "newValueRef",
            "ret": 418
        },
        {
            "index": 427,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 428,
            "fname": "visitDereferenceExpression",
            "params": {
                "node": 429
            },
            "ret": 429
        },
        {
            "index": 429,
            "cname": "DereferenceExpression",
            "supers": {
                "Expression": 304
            },
            "fields": {
                "_ptr": -7
            },
            "methods": [
                430,
                431,
                432,
                433
            ]
        },
        {
            "index": 430,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "ptr": 7,
                "type": 85,
                "addressSpace": 3
            },
            "ret": 429,
            "hobj": 1
        },
        {
            "index": 431,
            "fname": "get ptr",
            "ret": 7
        },
        {
            "index": 432,
            "fname": "get isLValue",
            "ret": 2
        },
        {
            "index": 433,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 434,
            "fname": "_handlePropertyAccessExpression",
            "params": {
                "result": 435,
                "node": 435
            }
        },
        {
            "index": 435,
            "cname": "PropertyAccessExpression",
            "supers": {
                "Expression": 304
            },
            "fields": {
                "base": -303,
                "baseType": 85,
                "_isLValue": -2,
                "_notLValueReason": -3,
                "resultTypeForGet": 85,
                "resultTypeForAnd": 85,
                "callForAnd": 437,
                "callForGet": 437,
                "callForSet": 437,
                "possibleGetOverloads": 101,
                "possibleSetOverloads": 101,
                "possibleAndOverloads": 101,
                "errorForSet": 449
            },
            "methods": [
                436,
                452,
                453,
                454,
                455,
                456,
                457,
                458,
                459,
                460,
                462,
                463,
                464
            ]
        },
        {
            "index": 436,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "base": 303
            },
            "ret": 435,
            "hobj": 1
        },
        {
            "index": 437,
            "cname": "CallExpression",
            "supers": {
                "Expression": 304
            },
            "fields": {
                "_returnType": -85,
                "_name": -3,
                "_typeArguments": -101,
                "_argumentList": -101,
                "func": -114,
                "_isCast": -2,
                "argumentTypes": 136,
                "actualTypeArguments": 136,
                "instantiatedActualTypeArguments": 136,
                "possibleOverloads": 143,
                "resultType": 85,
                "nativeFuncInstance": 242,
                "resultEPtr": 43
            },
            "sfields": {
                "const resolve": 443
            },
            "methods": [
                438,
                439,
                440,
                441,
                442,
                444,
                445,
                446,
                447,
                448
            ]
        },
        {
            "index": 438,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "name": 3,
                "typeArguments": 101,
                "argumentList": 101
            },
            "ret": 437,
            "hobj": 1
        },
        {
            "index": 439,
            "fname": "get typeArguments",
            "ret": 101
        },
        {
            "index": 440,
            "fname": "get argumentList",
            "ret": 101
        },
        {
            "index": 441,
            "fname": "get isCast",
            "ret": 2
        },
        {
            "index": 442,
            "fname": "get returnType",
            "ret": 85
        },
        {
            "index": 443,
            "fname": "static resolve",
            "params": {
                "origin": 42,
                "possibleOverloads": 143,
                "typeParametersInScope": 101,
                "name": 3,
                "typeArguments": 136,
                "argumentList": 101,
                "argumentTypes": 136,
                "returnType": 345
            },
            "ret": 0
        },
        {
            "index": 444,
            "fname": "resolve",
            "params": {
                "possibleOverloads": 143,
                "typeParametersInScope": 101,
                "typeArguments": 136
            },
            "ret": 85
        },
        {
            "index": 445,
            "fname": "resolveToOverload",
            "params": {
                "overload": 0
            },
            "ret": 85
        },
        {
            "index": 446,
            "fname": "becomeCast",
            "params": {
                "returnType": 85
            }
        },
        {
            "index": 447,
            "fname": "setCastData",
            "params": {
                "returnType": 85
            }
        },
        {
            "index": 448,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 449,
            "cname": "WTypeError",
            "supers": {
                "Error": 451
            },
            "fields": {
                "typeErrorMessage": 3,
                "originString": 3
            },
            "methods": [
                450
            ]
        },
        {
            "index": 450,
            "fname": "constructor",
            "params": {
                "originString": 3,
                "message": 3
            },
            "ret": 449,
            "hobj": 1
        },
        {
            "index": 451,
            "bname": "Error"
        },
        {
            "index": 452,
            "fname": "get getFuncName",
            "ret": 3
        },
        {
            "index": 453,
            "fname": "get andFuncName",
            "ret": 3
        },
        {
            "index": 454,
            "fname": "get setFuncName",
            "ret": 3
        },
        {
            "index": 455,
            "fname": "get resultType",
            "ret": 85
        },
        {
            "index": 456,
            "fname": "get isLValue",
            "ret": 2
        },
        {
            "index": 457,
            "fname": "set isLValue",
            "params": {
                "value": 2
            }
        },
        {
            "index": 458,
            "fname": "get notLValueReason",
            "ret": 3
        },
        {
            "index": 459,
            "fname": "set notLValueReason",
            "params": {
                "value": 3
            }
        },
        {
            "index": 460,
            "fname": "rewriteAfterCloning",
            "ret": 461
        },
        {
            "index": 461,
            "uname": "",
            "types": [
                338,
                429,
                437
            ]
        },
        {
            "index": 462,
            "fname": "updateCalls"
        },
        {
            "index": 463,
            "fname": "emitGet",
            "params": {
                "base": 303
            },
            "ret": 461
        },
        {
            "index": 464,
            "fname": "emitSet",
            "params": {
                "base": 303,
                "value": 188
            },
            "ret": 437
        },
        {
            "index": 465,
            "fname": "visitDotExpression",
            "params": {
                "node": 466
            },
            "ret": 7
        },
        {
            "index": 466,
            "cname": "DotExpression",
            "supers": {
                "PropertyAccessExpression": 436
            },
            "fields": {
                "_fieldName": -3
            },
            "methods": [
                467,
                468,
                469,
                470,
                471,
                472,
                473
            ]
        },
        {
            "index": 467,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "struct": 303,
                "fieldName": 3
            },
            "ret": 466,
            "hobj": 1
        },
        {
            "index": 468,
            "fname": "get struct",
            "ret": 303
        },
        {
            "index": 469,
            "fname": "get fieldName",
            "ret": 3
        },
        {
            "index": 470,
            "fname": "get getFuncName",
            "ret": 3
        },
        {
            "index": 471,
            "fname": "get andFuncName",
            "ret": 3
        },
        {
            "index": 472,
            "fname": "get setFuncName",
            "ret": 3
        },
        {
            "index": 473,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 474,
            "fname": "visitIndexExpression",
            "params": {
                "node": 475
            },
            "ret": 7
        },
        {
            "index": 475,
            "cname": "IndexExpression",
            "supers": {
                "PropertyAccessExpression": 436
            },
            "fields": {
                "_index": -303
            },
            "methods": [
                476,
                477,
                478,
                479,
                480,
                481,
                482,
                483
            ]
        },
        {
            "index": 476,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "array": 303,
                "index": 303
            },
            "ret": 475,
            "hobj": 1
        },
        {
            "index": 477,
            "fname": "get array",
            "ret": 303
        },
        {
            "index": 478,
            "fname": "get index",
            "ret": 303
        },
        {
            "index": 479,
            "fname": "get getFuncName",
            "ret": 3
        },
        {
            "index": 480,
            "fname": "get andFuncName",
            "ret": 3
        },
        {
            "index": 481,
            "fname": "get setFuncName",
            "ret": 3
        },
        {
            "index": 482,
            "fname": "updateCalls",
            "hobj": 1
        },
        {
            "index": 483,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 484,
            "fname": "visitMakePtrExpression",
            "params": {
                "node": 485
            },
            "ret": 485
        },
        {
            "index": 485,
            "cname": "MakePtrExpression",
            "supers": {
                "Expression": 304
            },
            "fields": {
                "_lValue": -7
            },
            "methods": [
                486,
                487,
                488
            ]
        },
        {
            "index": 486,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "lValue": 7
            },
            "ret": 485,
            "hobj": 1
        },
        {
            "index": 487,
            "fname": "get lValue",
            "ret": 7
        },
        {
            "index": 488,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 489,
            "fname": "visitMakeArrayRefExpression",
            "params": {
                "node": 377
            },
            "ret": 377
        },
        {
            "index": 490,
            "fname": "visitConvertPtrToArrayRefExpression",
            "params": {
                "node": 491
            },
            "ret": 491
        },
        {
            "index": 491,
            "cname": "ConvertPtrToArrayRefExpression",
            "supers": {
                "Expression": 304
            },
            "fields": {
                "_lValue": -7
            },
            "methods": [
                492,
                493,
                494
            ]
        },
        {
            "index": 492,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "lValue": 7
            },
            "ret": 491,
            "hobj": 1
        },
        {
            "index": 493,
            "fname": "get lValue",
            "ret": 7
        },
        {
            "index": 494,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 495,
            "fname": "visitVariableRef",
            "params": {
                "node": 418
            },
            "ret": 7
        },
        {
            "index": 496,
            "fname": "visitReturn",
            "params": {
                "node": 497
            },
            "ret": 497
        },
        {
            "index": 497,
            "cname": "Return",
            "supers": {
                "Node": 8
            },
            "fields": {
                "func": 114,
                "_value": -120
            },
            "methods": [
                498,
                499,
                500
            ]
        },
        {
            "index": 498,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "value": 120
            },
            "ret": 497,
            "hobj": 1
        },
        {
            "index": 499,
            "fname": "get value",
            "ret": 120
        },
        {
            "index": 500,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 501,
            "fname": "visitContinue",
            "params": {
                "node": 502
            },
            "ret": 502
        },
        {
            "index": 502,
            "cname": "Continue",
            "supers": {
                "Node": 8
            },
            "methods": [
                503,
                504
            ]
        },
        {
            "index": 503,
            "fname": "constructor",
            "params": {
                "origin": 42
            },
            "ret": 502,
            "hobj": 1
        },
        {
            "index": 504,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 505,
            "fname": "visitBreak",
            "params": {
                "node": 506
            },
            "ret": 506
        },
        {
            "index": 506,
            "cname": "Break",
            "supers": {
                "Node": 8
            },
            "methods": [
                507,
                508
            ]
        },
        {
            "index": 507,
            "fname": "constructor",
            "params": {
                "origin": 42
            },
            "ret": 506,
            "hobj": 1
        },
        {
            "index": 508,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 509,
            "fname": "visitTrapStatement",
            "params": {
                "node": 510
            },
            "ret": 510
        },
        {
            "index": 510,
            "cname": "TrapStatement",
            "supers": {
                "Node": 8
            },
            "methods": [
                511,
                512
            ]
        },
        {
            "index": 511,
            "fname": "constructor",
            "params": {
                "origin": 42
            },
            "ret": 510,
            "hobj": 1
        },
        {
            "index": 512,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 513,
            "fname": "visitGenericLiteral",
            "params": {
                "node": 514
            },
            "ret": 523
        },
        {
            "index": 514,
            "cname": "GenericLiteral",
            "supers": {
                "Expression": 304
            },
            "fields": {
                "_value": -1,
                "literalClassName": -3,
                "preferredTypeName": -3
            },
            "sfields": {
                "const withType": 516
            },
            "methods": [
                515,
                517,
                518,
                519,
                520,
                521,
                522
            ]
        },
        {
            "index": 515,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "value": 1
            },
            "ret": 514,
            "hobj": 1
        },
        {
            "index": 516,
            "fname": "static withType",
            "params": {
                "origin": 42,
                "value": 1,
                "type": 85
            }
        },
        {
            "index": 517,
            "fname": "get value",
            "ret": 1
        },
        {
            "index": 518,
            "fname": "get valueForSelectedType",
            "ret": 1
        },
        {
            "index": 519,
            "fname": "get isConstexpr",
            "ret": 2
        },
        {
            "index": 520,
            "fname": "negConstexpr",
            "params": {
                "origin": 42
            },
            "ret": 514
        },
        {
            "index": 521,
            "fname": "unifyImpl",
            "params": {
                "unificationContext": 153,
                "other": 7
            },
            "ret": 2
        },
        {
            "index": 522,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 523,
            "cname": "IntLiteral",
            "supers": {
                "GenericLiteral": 515
            },
            "sfields": {
                "const withType": 525
            },
            "methods": [
                524,
                526
            ]
        },
        {
            "index": 524,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "value": 1
            },
            "ret": 523,
            "hobj": 1
        },
        {
            "index": 525,
            "fname": "static withType",
            "params": {
                "origin": 42,
                "value": 1,
                "type": 85
            },
            "ret": 523
        },
        {
            "index": 526,
            "fname": "negConstexpr",
            "params": {
                "origin": 42
            },
            "ret": 523
        },
        {
            "index": 527,
            "fname": "visitGenericLiteralType",
            "params": {
                "node": 528
            },
            "ret": 528
        },
        {
            "index": 528,
            "cname": "GenericLiteralType",
            "supers": {
                "Type": 86
            },
            "fields": {
                "_value": -1,
                "preferredType": -345,
                "preferredTypeName": -3
            },
            "methods": [
                529,
                530,
                531,
                532,
                533,
                534,
                535,
                536,
                537,
                538,
                539,
                540
            ]
        },
        {
            "index": 529,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "value": 1,
                "name": 3
            },
            "ret": 528,
            "hobj": 1
        },
        {
            "index": 530,
            "fname": "get value",
            "ret": 1
        },
        {
            "index": 531,
            "fname": "get isPrimitive",
            "ret": 2
        },
        {
            "index": 532,
            "fname": "get isUnifiable",
            "ret": 2
        },
        {
            "index": 533,
            "fname": "typeVariableUnify",
            "params": {
                "unificationContext": 153,
                "other": 85
            },
            "ret": 2
        },
        {
            "index": 534,
            "fname": "unifyImpl",
            "params": {
                "unificationContext": 153,
                "other": 85
            },
            "ret": 2
        },
        {
            "index": 535,
            "fname": "prepareToVerify",
            "params": {
                "unificationContext": 153
            },
            "ret": 0
        },
        {
            "index": 536,
            "fname": "verifyAsArgument",
            "params": {
                "unificationContext": 153
            },
            "ret": 0
        },
        {
            "index": 537,
            "fname": "verifyAsParameter",
            "params": {
                "unificationContext": 153
            },
            "ret": 0
        },
        {
            "index": 538,
            "fname": "conversionCost",
            "params": {
                "unificationContext": 153
            },
            "ret": 5
        },
        {
            "index": 539,
            "fname": "commitUnification",
            "params": {
                "unificationContext": 153
            }
        },
        {
            "index": 540,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 541,
            "fname": "visitBoolLiteral",
            "params": {
                "node": 542
            },
            "ret": 542
        },
        {
            "index": 542,
            "cname": "BoolLiteral",
            "supers": {
                "Expression": 304
            },
            "fields": {
                "_value": -2
            },
            "methods": [
                543,
                544,
                545,
                546
            ]
        },
        {
            "index": 543,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "value": 2
            },
            "ret": 542,
            "hobj": 1
        },
        {
            "index": 544,
            "fname": "get value",
            "ret": 2
        },
        {
            "index": 545,
            "fname": "get isConstexpr",
            "ret": 2
        },
        {
            "index": 546,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 547,
            "fname": "visitNullLiteral",
            "params": {
                "node": 548
            },
            "ret": 548
        },
        {
            "index": 548,
            "cname": "NullLiteral",
            "supers": {
                "Expression": 304
            },
            "methods": [
                549,
                550
            ]
        },
        {
            "index": 549,
            "fname": "constructor",
            "params": {
                "origin": 42
            },
            "ret": 548,
            "hobj": 1
        },
        {
            "index": 550,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 551,
            "fname": "visitNullType",
            "params": {
                "node": 552
            },
            "ret": 552
        },
        {
            "index": 552,
            "cname": "NullType",
            "supers": {
                "Type": 86
            },
            "methods": [
                553,
                554,
                555,
                556,
                557,
                558,
                559,
                560,
                561
            ]
        },
        {
            "index": 553,
            "fname": "constructor",
            "params": {
                "origin": 42
            },
            "ret": 552,
            "hobj": 1
        },
        {
            "index": 554,
            "fname": "get isPrimitive",
            "ret": 2
        },
        {
            "index": 555,
            "fname": "get isUnifiable",
            "ret": 2
        },
        {
            "index": 556,
            "fname": "typeVariableUnify",
            "params": {
                "unificationContext": 153,
                "other": 85
            },
            "ret": 2
        },
        {
            "index": 557,
            "fname": "unifyImpl",
            "params": {
                "unificationContext": 153,
                "other": 85
            },
            "ret": 2
        },
        {
            "index": 558,
            "fname": "verifyAsArgument",
            "params": {
                "unificationContext": 153
            },
            "ret": 0
        },
        {
            "index": 559,
            "fname": "verifyAsParameter",
            "params": {
                "unificationContext": 153
            },
            "ret": 0
        },
        {
            "index": 560,
            "fname": "commitUnification",
            "params": {
                "unificationContext": 153
            }
        },
        {
            "index": 561,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 562,
            "fname": "processDerivedCallData",
            "params": {
                "node": 437,
                "result": 437
            },
            "ret": 437
        },
        {
            "index": 563,
            "fname": "visitCallExpression",
            "params": {
                "node": 437
            },
            "ret": 7
        },
        {
            "index": 564,
            "fname": "visitFunctionLikeBlock",
            "params": {
                "node": 565
            },
            "ret": 565
        },
        {
            "index": 565,
            "cname": "FunctionLikeBlock",
            "supers": {
                "Value": 121
            },
            "fields": {
                "returnEPtr": 43,
                "resultType": 85,
                "_returnType": -85,
                "_argumentList": -101,
                "_parameters": -130,
                "_body": -7,
                "isCast": 2
            },
            "methods": [
                566,
                567,
                568,
                569,
                570,
                571
            ]
        },
        {
            "index": 566,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "returnType": 85,
                "argumentList": 101,
                "parameters": 130,
                "body": 7
            },
            "ret": 565,
            "hobj": 1
        },
        {
            "index": 567,
            "fname": "get returnType",
            "ret": 85
        },
        {
            "index": 568,
            "fname": "get argumentList",
            "ret": 101
        },
        {
            "index": 569,
            "fname": "get parameters",
            "ret": 130
        },
        {
            "index": 570,
            "fname": "get body",
            "ret": 7
        },
        {
            "index": 571,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 572,
            "fname": "visitLogicalNot",
            "params": {
                "node": 573
            },
            "ret": 573
        },
        {
            "index": 573,
            "cname": "LogicalNot",
            "supers": {
                "Expression": 304
            },
            "fields": {
                "_operand": -575
            },
            "methods": [
                574,
                576,
                577
            ]
        },
        {
            "index": 574,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "operand": 437
            },
            "ret": 573,
            "hobj": 1
        },
        {
            "index": 575,
            "uname": "",
            "types": [
                437,
                565
            ]
        },
        {
            "index": 576,
            "fname": "get operand",
            "ret": 575
        },
        {
            "index": 577,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 578,
            "fname": "visitLogicalExpression",
            "params": {
                "node": 579
            },
            "ret": 579
        },
        {
            "index": 579,
            "cname": "LogicalExpression",
            "supers": {
                "Expression": 304
            },
            "fields": {
                "_text": -3,
                "_left": -575,
                "_right": -575
            },
            "methods": [
                580,
                581,
                582,
                583,
                584
            ]
        },
        {
            "index": 580,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "text": 3,
                "left": 437,
                "right": 437
            },
            "ret": 579,
            "hobj": 1
        },
        {
            "index": 581,
            "fname": "get text",
            "ret": 3
        },
        {
            "index": 582,
            "fname": "get left",
            "ret": 575
        },
        {
            "index": 583,
            "fname": "get right",
            "ret": 575
        },
        {
            "index": 584,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 585,
            "fname": "visitIfStatement",
            "params": {
                "node": 586
            },
            "ret": 586
        },
        {
            "index": 586,
            "cname": "IfStatement",
            "supers": {
                "Node": 8
            },
            "fields": {
                "_conditional": -575,
                "_body": -7,
                "_elseBody": -7
            },
            "methods": [
                587,
                588,
                589,
                590,
                591
            ]
        },
        {
            "index": 587,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "conditional": 437,
                "body": 7,
                "elseBody": 7
            },
            "ret": 586,
            "hobj": 1
        },
        {
            "index": 588,
            "fname": "get conditional",
            "ret": 575
        },
        {
            "index": 589,
            "fname": "get body",
            "ret": 7
        },
        {
            "index": 590,
            "fname": "get elseBody",
            "ret": 7
        },
        {
            "index": 591,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 592,
            "fname": "visitWhileLoop",
            "params": {
                "node": 593
            },
            "ret": 593
        },
        {
            "index": 593,
            "cname": "WhileLoop",
            "supers": {
                "Node": 8
            },
            "fields": {
                "_conditional": -575,
                "_body": -7
            },
            "methods": [
                594,
                595,
                596,
                597
            ]
        },
        {
            "index": 594,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "conditional": 437,
                "body": 7
            },
            "ret": 593,
            "hobj": 1
        },
        {
            "index": 595,
            "fname": "get conditional",
            "ret": 575
        },
        {
            "index": 596,
            "fname": "get body",
            "ret": 7
        },
        {
            "index": 597,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 598,
            "fname": "visitDoWhileLoop",
            "params": {
                "node": 599
            },
            "ret": 599
        },
        {
            "index": 599,
            "cname": "DoWhileLoop",
            "supers": {
                "Node": 8
            },
            "fields": {
                "_body": -7,
                "_conditional": -575
            },
            "methods": [
                600,
                601,
                602,
                603
            ]
        },
        {
            "index": 600,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "body": 7,
                "conditional": 437
            },
            "ret": 599,
            "hobj": 1
        },
        {
            "index": 601,
            "fname": "get body",
            "ret": 7
        },
        {
            "index": 602,
            "fname": "get conditional",
            "ret": 575
        },
        {
            "index": 603,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 604,
            "fname": "visitForLoop",
            "params": {
                "node": 605
            },
            "ret": 605
        },
        {
            "index": 605,
            "cname": "ForLoop",
            "supers": {
                "Node": 8
            },
            "fields": {
                "_initialization": -303,
                "_condition": -575,
                "_increment": -303,
                "_body": -7
            },
            "methods": [
                606,
                607,
                608,
                609,
                610,
                611
            ]
        },
        {
            "index": 606,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "initialization": 303,
                "condition": 437,
                "increment": 303,
                "body": 7
            },
            "ret": 605,
            "hobj": 1
        },
        {
            "index": 607,
            "fname": "get initialization",
            "ret": 303
        },
        {
            "index": 608,
            "fname": "get condition",
            "ret": 575
        },
        {
            "index": 609,
            "fname": "get increment",
            "ret": 303
        },
        {
            "index": 610,
            "fname": "get body",
            "ret": 7
        },
        {
            "index": 611,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 612,
            "fname": "visitSwitchStatement",
            "params": {
                "node": 613
            },
            "ret": 613
        },
        {
            "index": 613,
            "cname": "SwitchStatement",
            "supers": {
                "Node": 8
            },
            "fields": {
                "_switchCases": -621,
                "_value": -120
            },
            "methods": [
                614,
                622,
                623,
                624,
                625
            ]
        },
        {
            "index": 614,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "value": 120
            },
            "ret": 613,
            "hobj": 1
        },
        {
            "index": 615,
            "cname": "SwitchCase",
            "supers": {
                "Node": 8
            },
            "fields": {
                "_value": -120,
                "_body": -332
            },
            "methods": [
                616,
                617,
                618,
                619,
                620
            ]
        },
        {
            "index": 616,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "value": 120,
                "body": 332
            },
            "ret": 615,
            "hobj": 1
        },
        {
            "index": 617,
            "fname": "get isDefault",
            "ret": 2
        },
        {
            "index": 618,
            "fname": "get value",
            "ret": 120
        },
        {
            "index": 619,
            "fname": "get body",
            "ret": 332
        },
        {
            "index": 620,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 621,
            "aname": "",
            "element": 615,
            "mode": "normal"
        },
        {
            "index": 622,
            "fname": "get value",
            "ret": 120
        },
        {
            "index": 623,
            "fname": "add",
            "params": {
                "switchCase": 615
            }
        },
        {
            "index": 624,
            "fname": "get switchCases",
            "ret": 621
        },
        {
            "index": 625,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 626,
            "fname": "visitSwitchCase",
            "params": {
                "node": 615
            },
            "ret": 615
        },
        {
            "index": 627,
            "fname": "visitAnonymousVariable",
            "params": {
                "node": 413
            },
            "ret": 413
        },
        {
            "index": 628,
            "fname": "visitIdentityExpression",
            "params": {
                "node": 7
            },
            "ret": 629
        },
        {
            "index": 629,
            "cname": "IdentityExpression",
            "supers": {
                "Expression": 304
            },
            "methods": [
                630,
                631,
                632,
                633,
                634,
                635
            ]
        },
        {
            "index": 630,
            "fname": "constructor",
            "params": {
                "target": 7
            },
            "ret": 629,
            "hobj": 1
        },
        {
            "index": 631,
            "fname": "get unifyNode",
            "ret": 7
        },
        {
            "index": 632,
            "fname": "get isConstexpr",
            "ret": 2
        },
        {
            "index": 633,
            "fname": "get isLValue",
            "ret": 2
        },
        {
            "index": 634,
            "fname": "get addressSpace",
            "ret": 3
        },
        {
            "index": 635,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 636,
            "fname": "toString",
            "ret": 3,
            "hobj": 1
        },
        {
            "index": 637,
            "fname": "visitNativeFunc",
            "params": {
                "node": 237
            }
        },
        {
            "index": 638,
            "fname": "visitNativeFuncInstance",
            "params": {
                "node": 242
            }
        },
        {
            "index": 639,
            "fname": "visitBlock",
            "params": {
                "node": 332
            }
        },
        {
            "index": 640,
            "fname": "visitCommaExpression",
            "params": {
                "node": 338
            }
        },
        {
            "index": 641,
            "fname": "visitProtocolRef",
            "params": {
                "node": 107
            }
        },
        {
            "index": 642,
            "fname": "visitProtocolDecl",
            "params": {
                "node": 109
            }
        },
        {
            "index": 643,
            "fname": "visitTypeRef",
            "params": {
                "node": 345
            }
        },
        {
            "index": 644,
            "fname": "visitNativeType",
            "params": {
                "node": 249
            }
        },
        {
            "index": 645,
            "fname": "visitNativeTypeInstance",
            "params": {
                "node": 317
            }
        },
        {
            "index": 646,
            "fname": "visitTypeDef",
            "params": {
                "node": 275
            }
        },
        {
            "index": 647,
            "fname": "visitStructType",
            "params": {
                "node": 280
            }
        },
        {
            "index": 648,
            "fname": "visitTypeVariable",
            "params": {
                "node": 146
            }
        },
        {
            "index": 649,
            "fname": "visitConstexprTypeParameter",
            "params": {
                "node": 251
            }
        },
        {
            "index": 650,
            "fname": "visitField",
            "params": {
                "node": 284
            }
        },
        {
            "index": 651,
            "fname": "visitEnumType",
            "params": {
                "node": 298
            }
        },
        {
            "index": 652,
            "fname": "visitEnumMember",
            "params": {
                "node": 301
            }
        },
        {
            "index": 653,
            "fname": "visitEnumLiteral",
            "params": {
                "node": 359
            }
        },
        {
            "index": 654,
            "fname": "visitElementalType",
            "params": {
                "node": 655
            }
        },
        {
            "index": 655,
            "uname": "",
            "types": [
                367,
                392
            ]
        },
        {
            "index": 656,
            "fname": "visitReferenceType",
            "params": {
                "node": 367
            }
        },
        {
            "index": 657,
            "fname": "visitPtrType",
            "params": {
                "node": 373
            }
        },
        {
            "index": 658,
            "fname": "visitArrayRefType",
            "params": {
                "node": 385
            }
        },
        {
            "index": 659,
            "fname": "visitArrayType",
            "params": {
                "node": 392
            }
        },
        {
            "index": 660,
            "fname": "visitVariableDecl",
            "params": {
                "node": 326
            }
        },
        {
            "index": 661,
            "fname": "visitAssignment",
            "params": {
                "node": 405
            }
        },
        {
            "index": 662,
            "fname": "visitReadModifyWriteExpression",
            "params": {
                "node": 411
            }
        },
        {
            "index": 663,
            "fname": "visitDereferenceExpression",
            "params": {
                "node": 429
            }
        },
        {
            "index": 664,
            "fname": "_handlePropertyAccessExpression",
            "params": {
                "node": 435
            }
        },
        {
            "index": 665,
            "fname": "visitDotExpression",
            "params": {
                "node": 466
            }
        },
        {
            "index": 666,
            "fname": "visitIndexExpression",
            "params": {
                "node": 475
            }
        },
        {
            "index": 667,
            "fname": "visitMakePtrExpression",
            "params": {
                "node": 485
            }
        },
        {
            "index": 668,
            "fname": "visitMakeArrayRefExpression",
            "params": {
                "node": 377
            }
        },
        {
            "index": 669,
            "fname": "visitConvertPtrToArrayRefExpression",
            "params": {
                "node": 491
            }
        },
        {
            "index": 670,
            "fname": "visitVariableRef",
            "params": {
                "node": 418
            }
        },
        {
            "index": 671,
            "fname": "visitIfStatement",
            "params": {
                "node": 586
            }
        },
        {
            "index": 672,
            "fname": "visitWhileLoop",
            "params": {
                "node": 593
            }
        },
        {
            "index": 673,
            "fname": "visitDoWhileLoop",
            "params": {
                "node": 599
            }
        },
        {
            "index": 674,
            "fname": "visitForLoop",
            "params": {
                "node": 605
            }
        },
        {
            "index": 675,
            "fname": "visitSwitchStatement",
            "params": {
                "node": 613
            }
        },
        {
            "index": 676,
            "fname": "visitSwitchCase",
            "params": {
                "node": 615
            }
        },
        {
            "index": 677,
            "fname": "visitReturn",
            "params": {
                "node": 497
            }
        },
        {
            "index": 678,
            "fname": "visitContinue",
            "params": {
                "node": 502
            }
        },
        {
            "index": 679,
            "fname": "visitBreak",
            "params": {
                "node": 506
            }
        },
        {
            "index": 680,
            "fname": "visitTrapStatement",
            "params": {
                "node": 510
            }
        },
        {
            "index": 681,
            "fname": "visitGenericLiteral",
            "params": {
                "node": 514
            }
        },
        {
            "index": 682,
            "fname": "visitGenericLiteralType",
            "params": {
                "node": 528
            }
        },
        {
            "index": 683,
            "fname": "visitNullLiteral",
            "params": {
                "node": 548
            }
        },
        {
            "index": 684,
            "fname": "visitBoolLiteral",
            "params": {
                "node": 542
            }
        },
        {
            "index": 685,
            "fname": "visitNullType",
            "params": {
                "node": 552
            }
        },
        {
            "index": 686,
            "fname": "visitCallExpression",
            "params": {
                "node": 437
            }
        },
        {
            "index": 687,
            "fname": "visitLogicalNot",
            "params": {
                "node": 573
            }
        },
        {
            "index": 688,
            "fname": "visitLogicalExpression",
            "params": {
                "node": 579
            }
        },
        {
            "index": 689,
            "fname": "visitFunctionLikeBlock",
            "params": {
                "node": 565
            }
        },
        {
            "index": 690,
            "fname": "visitAnonymousVariable",
            "params": {
                "node": 413
            }
        },
        {
            "index": 691,
            "fname": "visitIdentityExpression",
            "params": {
                "node": 7
            }
        },
        {
            "index": 692,
            "cname": "Instantiate",
            "fields": {
                "substitution": -694,
                "instantiateImmediates": -702
            },
            "methods": [
                693,
                709,
                710
            ]
        },
        {
            "index": 693,
            "fname": "constructor",
            "params": {
                "substitution": 694,
                "instantiateImmediates": 702
            },
            "ret": 692
        },
        {
            "index": 694,
            "cname": "InstantiationSubstitution",
            "supers": {
                "Substitution": 698
            },
            "fields": {
                "thisInstantiator": -200
            },
            "methods": [
                695,
                696
            ]
        },
        {
            "index": 695,
            "fname": "constructor",
            "params": {
                "thisInstantiator": 200,
                "typeParameters": 101,
                "typeArguments": 101
            },
            "ret": 694,
            "hobj": 1
        },
        {
            "index": 696,
            "fname": "visitCallExpression",
            "params": {
                "node": 437
            },
            "ret": 437,
            "hobj": 1
        },
        {
            "index": 697,
            "cname": "Substitution",
            "supers": {
                "Rewriter": 232
            },
            "fields": {
                "_map": -77
            },
            "methods": [
                698,
                699,
                700,
                701
            ]
        },
        {
            "index": 698,
            "fname": "constructor",
            "params": {
                "parameters": 101,
                "argumentList": 101
            },
            "ret": 697,
            "hobj": 1
        },
        {
            "index": 699,
            "fname": "get map",
            "ret": 77
        },
        {
            "index": 700,
            "fname": "visitTypeRef",
            "params": {
                "node": 345
            },
            "ret": 174,
            "hobj": 1
        },
        {
            "index": 701,
            "fname": "visitVariableRef",
            "params": {
                "node": 418
            },
            "ret": 7,
            "hobj": 1
        },
        {
            "index": 702,
            "cname": "InstantiationInstantiateImmediates",
            "supers": {
                "InstantiateImmediates": 706
            },
            "methods": [
                703,
                704
            ]
        },
        {
            "index": 703,
            "fname": "constructor",
            "ret": 702
        },
        {
            "index": 704,
            "fname": "visitCallExpression",
            "params": {
                "node": 437
            },
            "ret": 437
        },
        {
            "index": 705,
            "cname": "InstantiateImmediates",
            "supers": {
                "Rewriter": 232
            },
            "methods": [
                706,
                707,
                708
            ]
        },
        {
            "index": 706,
            "fname": "constructor",
            "ret": 705
        },
        {
            "index": 707,
            "fname": "visitTypeRef",
            "params": {
                "node": 345
            },
            "ret": 174,
            "hobj": 1
        },
        {
            "index": 708,
            "fname": "visitReferenceType",
            "params": {
                "node": 367
            },
            "ret": 367
        },
        {
            "index": 709,
            "fname": "visitFuncDef",
            "params": {
                "func": 227
            },
            "ret": 227
        },
        {
            "index": 710,
            "fname": "visitNativeFunc",
            "params": {
                "func": 237
            },
            "ret": 242
        },
        {
            "index": 711,
            "cname": "RValueFinder",
            "fields": {
                "resolver_": -713
            },
            "methods": [
                712,
                724,
                725,
                726,
                727,
                728,
                729,
                730
            ]
        },
        {
            "index": 712,
            "fname": "constructor",
            "params": {
                "resolver": 713
            },
            "ret": 711
        },
        {
            "index": 713,
            "cname": "PropertyResolver",
            "supers": {
                "Visitor": 221
            },
            "methods": [
                714,
                715,
                716,
                717,
                718,
                719,
                720,
                721,
                722,
                723
            ]
        },
        {
            "index": 714,
            "fname": "constructor",
            "ret": 713
        },
        {
            "index": 715,
            "fname": "_visitRValuesWithinLValue",
            "params": {
                "node": 7
            }
        },
        {
            "index": 716,
            "fname": "_visitPropertyAccess",
            "params": {
                "node": 435
            }
        },
        {
            "index": 717,
            "fname": "visitDotExpression",
            "params": {
                "node": 466
            }
        },
        {
            "index": 718,
            "fname": "visitIndexExpression",
            "params": {
                "node": 475
            }
        },
        {
            "index": 719,
            "fname": "_handleReadModifyWrite",
            "params": {
                "node": 411
            }
        },
        {
            "index": 720,
            "fname": "visitReadModifyWriteExpression",
            "params": {
                "node": 411
            }
        },
        {
            "index": 721,
            "fname": "visitAssignment",
            "params": {
                "node": 405
            }
        },
        {
            "index": 722,
            "fname": "visitMakePtrExpression",
            "params": {
                "node": 377
            },
            "hobj": 1
        },
        {
            "index": 723,
            "fname": "visitMakeArrayRefExpression",
            "params": {
                "node": 377
            },
            "hobj": 1
        },
        {
            "index": 724,
            "fname": "visit",
            "params": {
                "node": 7
            }
        },
        {
            "index": 725,
            "fname": "visitDotExpression",
            "params": {
                "node": 466
            }
        },
        {
            "index": 726,
            "fname": "visitIndexExpression",
            "params": {
                "node": 475
            }
        },
        {
            "index": 727,
            "fname": "visitVariableRef",
            "params": {
                "node": 418
            }
        },
        {
            "index": 728,
            "fname": "visitDereferenceExpression",
            "params": {
                "node": 429
            }
        },
        {
            "index": 729,
            "fname": "visitIdentityExpression",
            "params": {
                "node": 7
            }
        },
        {
            "index": 730,
            "fname": "visitMakeArrayRefExpression",
            "params": {
                "node": 377
            }
        },
        {
            "index": 731,
            "cname": "TypeParameterRewriter",
            "methods": [
                732,
                733,
                734
            ]
        },
        {
            "index": 732,
            "fname": "constructor",
            "ret": 731
        },
        {
            "index": 733,
            "fname": "visitConstexprTypeParameter",
            "params": {
                "node": 251
            },
            "ret": 251
        },
        {
            "index": 734,
            "fname": "visitTypeVariable",
            "params": {
                "node": 146
            },
            "ret": 146
        },
        {
            "index": 735,
            "uname": "",
            "types": [
                220,
                231,
                692,
                711,
                731
            ]
        },
        {
            "index": 736,
            "fname": "static visit",
            "params": {
                "node": 737,
                "visitor": 738
            },
            "ret": 174
        },
        {
            "index": 737,
            "uname": "",
            "types": [
                3,
                7
            ]
        },
        {
            "index": 738,
            "uname": "",
            "types": [
                220,
                231
            ]
        },
        {
            "index": 739,
            "fname": "unify",
            "params": {
                "unificationContext": 153,
                "other": 7
            },
            "ret": 2
        },
        {
            "index": 740,
            "fname": "unifyImpl",
            "params": {
                "unificationContext": 153,
                "other": 7
            },
            "ret": 2
        },
        {
            "index": 741,
            "fname": "typeVariableUnify",
            "params": {
                "unificationContext": 153,
                "other": 7
            },
            "ret": 2
        },
        {
            "index": 742,
            "fname": "_typeVariableUnifyImpl",
            "params": {
                "unificationContext": 153,
                "other": 7
            },
            "ret": 2
        },
        {
            "index": 743,
            "fname": "prepareToVerify",
            "params": {
                "unificationContext": 153
            },
            "ret": 0
        },
        {
            "index": 744,
            "fname": "commitUnification",
            "params": {
                "unificationContext": 153
            }
        },
        {
            "index": 745,
            "fname": "get target",
            "ret": 7
        },
        {
            "index": 746,
            "fname": "get unifyNode",
            "ret": 7
        },
        {
            "index": 747,
            "fname": "get isConstexpr",
            "ret": 2
        },
        {
            "index": 748,
            "fname": "get isLValue",
            "ret": 2
        },
        {
            "index": 749,
            "fname": "get isUnifiable",
            "ret": 2
        },
        {
            "index": 750,
            "fname": "get isLiteral",
            "ret": 2
        },
        {
            "index": 751,
            "fname": "get isNative",
            "ret": 2
        },
        {
            "index": 752,
            "fname": "get origin",
            "ret": 42
        },
        {
            "index": 753,
            "fname": "get isPtr",
            "ret": 2
        },
        {
            "index": 754,
            "fname": "get kind",
            "ret": 6
        },
        {
            "index": 755,
            "fname": "conversionCost",
            "params": {
                "unificationContext": 153
            },
            "ret": 5
        },
        {
            "index": 756,
            "fname": "equals",
            "params": {
                "other": 7
            },
            "ret": 757
        },
        {
            "index": 757,
            "uname": "",
            "types": [
                2,
                153
            ]
        },
        {
            "index": 758,
            "fname": "equalsWithCommit",
            "params": {
                "other": 7
            },
            "ret": 757
        },
        {
            "index": 759,
            "fname": "commit",
            "ret": 7
        },
        {
            "index": 760,
            "fname": "substitute",
            "params": {
                "parameters": 101,
                "argumentList": 101
            },
            "ret": 7
        },
        {
            "index": 761,
            "fname": "substituteToUnification",
            "params": {
                "parameters": 101,
                "unificationContext": 153
            },
            "ret": 7
        },
        {
            "index": 762,
            "oname": "OverLoadSuccess",
            "fields": {
                "failure": -4,
                "func": -114,
                "unificationContext": -153,
                "typeArguments": -101
            }
        },
        {
            "index": 763,
            "oname": "OverLoadFailure",
            "fields": {
                "failures": -769,
                "func": -4
            }
        },
        {
            "index": 764,
            "cname": "OverloadResolutionFailure",
            "fields": {
                "_func": -114,
                "_reason": -3
            },
            "methods": [
                765,
                766,
                767,
                768
            ]
        },
        {
            "index": 765,
            "fname": "constructor",
            "params": {
                "func": 114,
                "reason": 3
            },
            "ret": 764
        },
        {
            "index": 766,
            "fname": "get func",
            "ret": 114
        },
        {
            "index": 767,
            "fname": "get reason",
            "ret": 3
        },
        {
            "index": 768,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 769,
            "aname": "",
            "element": 764,
            "mode": "normal"
        },
        {
            "index": 770,
            "oname": "InferTypesFail",
            "fields": {
                "failure": -764,
                "func": -4
            }
        },
        {
            "index": 771,
            "oname": "CallResolve",
            "fields": {
                "call": -437,
                "resultType": -85
            }
        },
        {
            "index": 772,
            "oname": "FuncInstantiatorInstances",
            "fields": {
                "func": -114,
                "typeArguments": -101
            }
        },
        {
            "index": 773,
            "oname": "ImplementationDataType",
            "fields": {
                "type": -85,
                "fieldName": -3,
                "offset": -5,
                "structSize": -5,
                "fieldSize": -5
            }
        },
        {
            "index": 774,
            "oname": "",
            "fields": {
                "type": -4,
                "fieldName": -3,
                "offset": -5,
                "structSize": -5,
                "fieldSize": -5
            }
        },
        {
            "index": 775,
            "oname": "VerityResultType",
            "fields": {
                "result": -2,
                "reason": -3
            }
        },
        {
            "index": 776,
            "iname": "RegExpType",
            "fields": {
                "prototype": 778,
                "rightContext": 3,
                "leftContext": 3,
                "$1": 3,
                "$2": 3,
                "$3": 3,
                "$4": 3,
                "$5": 3,
                "$6": 3,
                "$7": 3,
                "$8": 3,
                "$9": 3,
                "lastMatch": 3
            },
            "methods": [
                777
            ]
        },
        {
            "index": 777,
            "fname": "constructor",
            "params": {
                "pattern": 779
            },
            "ret": 778
        },
        {
            "index": 778,
            "bname": "RegExp"
        },
        {
            "index": 779,
            "uname": "",
            "types": [
                3,
                778
            ]
        },
        {
            "index": 780,
            "uname": "",
            "types": [
                7,
                43
            ]
        },
        {
            "index": 781,
            "aname": "",
            "element": 780,
            "mode": "normal"
        },
        {
            "index": 782,
            "fname": "",
            "params": {
                "type": 7
            },
            "ret": 7
        },
        {
            "index": 783,
            "oname": "",
            "fields": {
                "value": -1,
                "name": -122
            }
        },
        {
            "index": 784,
            "aname": "",
            "element": 0,
            "mode": "normal"
        },
        {
            "index": 785,
            "oname": "",
            "fields": {
                "result": -2,
                "reason": -4
            }
        },
        {
            "index": 786,
            "fname": "ReferencePopulate",
            "params": {
                "buffer": 45,
                "offset": 1
            }
        },
        {
            "index": 787,
            "fname": "",
            "params": {
                "parameter": 7
            },
            "ret": 174
        },
        {
            "index": 788,
            "fname": "",
            "params": {
                "parameter": 7
            },
            "ret": 174
        },
        {
            "index": 789,
            "fname": "",
            "params": {
                "argument": 7
            },
            "ret": 174
        },
        {
            "index": 790,
            "fname": "",
            "params": {
                "expression": 7
            },
            "ret": 174
        },
        {
            "index": 791,
            "fname": "",
            "params": {
                "typeArgument": 7
            },
            "ret": 174
        },
        {
            "index": 792,
            "fname": "",
            "params": {
                "actualTypeArguments": 136
            },
            "ret": 136
        },
        {
            "index": 793,
            "fname": "",
            "params": {
                "actualTypeArgument": 7
            },
            "ret": 174
        },
        {
            "index": 794,
            "fname": "",
            "params": {
                "argumentType": 85
            },
            "ret": 174
        },
        {
            "index": 795,
            "fname": "",
            "params": {
                "typeArgument": 7
            },
            "ret": 174
        },
        {
            "index": 796,
            "fname": "",
            "params": {
                "argument": 7
            },
            "ret": 174
        },
        {
            "index": 797,
            "fname": "",
            "params": {
                "argument": 7
            },
            "ret": 174
        },
        {
            "index": 798,
            "fname": "",
            "params": {
                "parameter": 7
            },
            "ret": 174
        },
        {
            "index": 799,
            "fname": "",
            "params": {
                "actualTypeArguments": 136
            }
        },
        {
            "index": 800,
            "cname": "DoubleLiteral",
            "supers": {
                "GenericLiteral": 515
            },
            "sfields": {
                "const withType": 802
            },
            "methods": [
                801,
                803
            ]
        },
        {
            "index": 801,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "value": 1
            },
            "ret": 800,
            "hobj": 1
        },
        {
            "index": 802,
            "fname": "static withType",
            "params": {
                "origin": 42,
                "value": 1,
                "type": 85
            },
            "ret": 800
        },
        {
            "index": 803,
            "fname": "negConstexpr",
            "params": {
                "origin": 42
            },
            "ret": 523
        },
        {
            "index": 804,
            "cname": "FloatLiteral",
            "supers": {
                "GenericLiteral": 515
            },
            "sfields": {
                "const withType": 806
            },
            "methods": [
                805,
                807
            ]
        },
        {
            "index": 805,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "value": 1
            },
            "ret": 804,
            "hobj": 1
        },
        {
            "index": 806,
            "fname": "static withType",
            "params": {
                "origin": 42,
                "value": 1,
                "type": 85
            },
            "ret": 804
        },
        {
            "index": 807,
            "fname": "negConstexpr",
            "params": {
                "origin": 42
            },
            "ret": 523
        },
        {
            "index": 808,
            "cname": "UintLiteral",
            "supers": {
                "GenericLiteral": 515
            },
            "sfields": {
                "const withType": 810
            },
            "methods": [
                809,
                811
            ]
        },
        {
            "index": 809,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "value": 1
            },
            "ret": 808,
            "hobj": 1
        },
        {
            "index": 810,
            "fname": "static withType",
            "params": {
                "origin": 42,
                "value": 1,
                "type": 85
            },
            "ret": 808
        },
        {
            "index": 811,
            "fname": "negConstexpr",
            "params": {
                "origin": 42
            },
            "ret": 808
        },
        {
            "index": 812,
            "fname": "",
            "ret": 813
        },
        {
            "index": 813,
            "uname": "",
            "types": [
                775,
                785
            ]
        },
        {
            "index": 814,
            "cname": "DoubleLiteralType",
            "supers": {
                "GenericLiteralType": 529
            },
            "methods": [
                815,
                816
            ]
        },
        {
            "index": 815,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "value": 1
            },
            "ret": 814,
            "hobj": 1
        },
        {
            "index": 816,
            "fname": "verifyAsArgument",
            "params": {
                "unificationContext": 153
            },
            "ret": 0
        },
        {
            "index": 817,
            "cname": "FloatLiteralType",
            "supers": {
                "GenericLiteralType": 529
            },
            "methods": [
                818,
                819
            ]
        },
        {
            "index": 818,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "value": 1
            },
            "ret": 817,
            "hobj": 1
        },
        {
            "index": 819,
            "fname": "verifyAsArgument",
            "params": {
                "unificationContext": 153
            },
            "ret": 0
        },
        {
            "index": 820,
            "cname": "IntLiteralType",
            "supers": {
                "GenericLiteralType": 529
            },
            "methods": [
                821,
                822
            ]
        },
        {
            "index": 821,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "value": 1
            },
            "ret": 820,
            "hobj": 1
        },
        {
            "index": 822,
            "fname": "verifyAsArgument",
            "params": {
                "unificationContext": 153
            },
            "ret": 0
        },
        {
            "index": 823,
            "cname": "UintLiteralType",
            "supers": {
                "GenericLiteralType": 529
            },
            "methods": [
                824,
                825
            ]
        },
        {
            "index": 824,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "value": 1
            },
            "ret": 823,
            "hobj": 1
        },
        {
            "index": 825,
            "fname": "verifyAsArgument",
            "params": {
                "unificationContext": 153
            },
            "ret": 0
        },
        {
            "index": 826,
            "aname": "",
            "element": 3,
            "mode": "normal"
        },
        {
            "index": 827,
            "fname": "isAddressSpace",
            "params": {
                "addressSpace": 3
            },
            "ret": 2
        },
        {
            "index": 828,
            "fname": "validateAddressSpace",
            "params": {
                "addressSpace": 3
            }
        },
        {
            "index": 829,
            "fname": "ArrayTypePopulate",
            "params": {
                "buffer": 45,
                "offset": 5
            }
        },
        {
            "index": 830,
            "cname": "AutoWrapper",
            "supers": {
                "Rewriter": 232
            },
            "methods": [
                831,
                832,
                833,
                834,
                835,
                836,
                837,
                838,
                839,
                840,
                841
            ]
        },
        {
            "index": 831,
            "fname": "constructor",
            "ret": 830
        },
        {
            "index": 832,
            "fname": "visitVariableRef",
            "params": {
                "node": 418
            },
            "ret": 418
        },
        {
            "index": 833,
            "fname": "visitTypeRef",
            "params": {
                "node": 345
            },
            "ret": 345
        },
        {
            "index": 834,
            "fname": "visitConstexprTypeParameter",
            "params": {
                "node": 251
            },
            "ret": 418
        },
        {
            "index": 835,
            "fname": "visitFuncParameter",
            "params": {
                "node": 116
            },
            "ret": 418
        },
        {
            "index": 836,
            "fname": "visitVariableDecl",
            "params": {
                "node": 326
            },
            "ret": 418
        },
        {
            "index": 837,
            "fname": "visitStructType",
            "params": {
                "node": 280
            },
            "ret": 345
        },
        {
            "index": 838,
            "fname": "visitNativeType",
            "params": {
                "node": 249
            },
            "ret": 345
        },
        {
            "index": 839,
            "fname": "visitTypeVariable",
            "params": {
                "node": 146
            },
            "ret": 345
        },
        {
            "index": 840,
            "fname": "visitGenericLiteralType",
            "params": {
                "node": 528
            },
            "ret": 528
        },
        {
            "index": 841,
            "fname": "visitNullType",
            "params": {
                "node": 552
            },
            "ret": 552
        },
        {
            "index": 842,
            "fname": "",
            "params": {
                "argument": 85
            },
            "ret": 174
        },
        {
            "index": 843,
            "fname": "",
            "params": {
                "typeArgument": 7
            },
            "ret": 174
        },
        {
            "index": 844,
            "fname": "callFunction",
            "params": {
                "program": 71,
                "name": 3,
                "typeArguments": 136,
                "argumentList": 852
            },
            "ret": 845
        },
        {
            "index": 845,
            "cname": "TypedValue",
            "fields": {
                "_type": -85,
                "_ePtr": -43
            },
            "sfields": {
                "const box": 849
            },
            "methods": [
                846,
                847,
                848,
                850,
                851
            ]
        },
        {
            "index": 846,
            "fname": "constructor",
            "params": {
                "type": 85,
                "ePtr": 43
            },
            "ret": 845
        },
        {
            "index": 847,
            "fname": "get type",
            "ret": 85
        },
        {
            "index": 848,
            "fname": "get ePtr",
            "ret": 43
        },
        {
            "index": 849,
            "fname": "static box",
            "params": {
                "type": 85,
                "value": 52
            },
            "ret": 845
        },
        {
            "index": 850,
            "fname": "get value",
            "ret": 52
        },
        {
            "index": 851,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 852,
            "aname": "",
            "element": 845,
            "mode": "normal"
        },
        {
            "index": 853,
            "fname": "",
            "params": {
                "argument": 845
            },
            "ret": 85
        },
        {
            "index": 854,
            "uname": "",
            "types": [
                114,
                769
            ]
        },
        {
            "index": 855,
            "fname": "check",
            "params": {
                "program": 71
            }
        },
        {
            "index": 856,
            "fname": "checkLiteralTypes",
            "params": {
                "program": 71
            }
        },
        {
            "index": 857,
            "fname": "checkLoops",
            "params": {
                "program": 71
            }
        },
        {
            "index": 858,
            "fname": "checkRecursiveTypes",
            "params": {
                "program": 71
            }
        },
        {
            "index": 859,
            "fname": "checkRecursion",
            "params": {
                "program": 71
            }
        },
        {
            "index": 860,
            "fname": "checkReturns",
            "params": {
                "program": 71
            }
        },
        {
            "index": 861,
            "fname": "checkUnreachableCode",
            "params": {
                "program": 71
            }
        },
        {
            "index": 862,
            "fname": "checkExpressionWrapped",
            "params": {
                "node": 7
            }
        },
        {
            "index": 863,
            "fname": "checkProgramWrapped",
            "params": {
                "node": 7
            }
        },
        {
            "index": 864,
            "cname": "Checker",
            "supers": {
                "Visitor": 221
            },
            "fields": {
                "_program": -71,
                "_currentStatement": -7,
                "_vertexEntryPoints": -78,
                "_fragmentEntryPoints": -78
            },
            "methods": [
                865,
                866,
                867,
                868,
                869,
                870,
                871,
                872,
                873,
                874,
                875,
                876,
                877,
                878,
                879,
                880,
                882,
                883,
                884,
                885,
                886,
                887,
                888,
                889,
                890,
                891,
                892,
                893,
                894,
                895,
                896,
                897,
                898,
                899,
                900,
                901,
                902,
                903,
                904,
                905
            ]
        },
        {
            "index": 865,
            "fname": "constructor",
            "params": {
                "program": 71
            },
            "ret": 864,
            "hobj": 1
        },
        {
            "index": 866,
            "fname": "doStatement",
            "params": {
                "statement": 7
            }
        },
        {
            "index": 867,
            "fname": "visitProgram",
            "params": {
                "node": 71
            }
        },
        {
            "index": 868,
            "fname": "_checkShaderType",
            "params": {
                "node": 114
            }
        },
        {
            "index": 869,
            "fname": "_checkOperatorOverload",
            "params": {
                "func": 114,
                "resolveFuncs": 0
            }
        },
        {
            "index": 870,
            "fname": "visitFuncDef",
            "params": {
                "node": 227
            }
        },
        {
            "index": 871,
            "fname": "visitNativeFunc",
            "params": {
                "node": 237
            }
        },
        {
            "index": 872,
            "fname": "visitProtocolDecl",
            "params": {
                "node": 109
            }
        },
        {
            "index": 873,
            "fname": "visitEnumType",
            "params": {
                "node": 298
            }
        },
        {
            "index": 874,
            "fname": "_checkTypeArguments",
            "params": {
                "origin": 42,
                "typeParameters": 101,
                "typeArguments": 101
            }
        },
        {
            "index": 875,
            "fname": "visitTypeRef",
            "params": {
                "node": 345
            }
        },
        {
            "index": 876,
            "fname": "visitArrayType",
            "params": {
                "node": 392
            }
        },
        {
            "index": 877,
            "fname": "visitVariableDecl",
            "params": {
                "node": 326
            }
        },
        {
            "index": 878,
            "fname": "visitAssignment",
            "params": {
                "node": 405
            },
            "ret": 85
        },
        {
            "index": 879,
            "fname": "visitIdentityExpression",
            "params": {
                "node": 7
            },
            "ret": 174
        },
        {
            "index": 880,
            "fname": "visitReadModifyWriteExpression",
            "params": {
                "node": 411
            },
            "ret": 881
        },
        {
            "index": 881,
            "uname": "",
            "types": [
                3,
                7,
                43,
                449
            ]
        },
        {
            "index": 882,
            "fname": "visitAnonymousVariable",
            "params": {
                "node": 413
            }
        },
        {
            "index": 883,
            "fname": "visitDereferenceExpression",
            "params": {
                "node": 429
            },
            "ret": 85
        },
        {
            "index": 884,
            "fname": "visitMakePtrExpression",
            "params": {
                "node": 485
            },
            "ret": 373
        },
        {
            "index": 885,
            "fname": "visitMakeArrayRefExpression",
            "params": {
                "node": 377
            },
            "ret": 385
        },
        {
            "index": 886,
            "fname": "visitConvertToArrayRefExpression",
            "params": {
                "node": 491
            }
        },
        {
            "index": 887,
            "fname": "_finishVisitingPropertyAccess",
            "params": {
                "node": 435,
                "baseType": 85,
                "extraArgs": 101,
                "extraArgTypes": 136
            },
            "ret": 85
        },
        {
            "index": 888,
            "fname": "visitDotExpression",
            "params": {
                "node": 466
            },
            "ret": 85
        },
        {
            "index": 889,
            "fname": "visitIndexExpression",
            "params": {
                "node": 475
            },
            "ret": 85
        },
        {
            "index": 890,
            "fname": "visitVariableRef",
            "params": {
                "node": 418
            },
            "ret": 85
        },
        {
            "index": 891,
            "fname": "visitReturn",
            "params": {
                "node": 497
            }
        },
        {
            "index": 892,
            "fname": "visitGenericLiteral",
            "params": {
                "node": 514
            },
            "ret": 85
        },
        {
            "index": 893,
            "fname": "visitNullLiteral",
            "params": {
                "node": 548
            },
            "ret": 85
        },
        {
            "index": 894,
            "fname": "visitBoolLiteral",
            "params": {
                "node": 542
            },
            "ret": 85
        },
        {
            "index": 895,
            "fname": "visitEnumLiteral",
            "params": {
                "node": 359
            },
            "ret": 298
        },
        {
            "index": 896,
            "fname": "_requireBool",
            "params": {
                "expression": 303
            }
        },
        {
            "index": 897,
            "fname": "visitLogicalNot",
            "params": {
                "node": 573
            },
            "ret": 85
        },
        {
            "index": 898,
            "fname": "visitLogicalExpression",
            "params": {
                "node": 579
            },
            "ret": 85
        },
        {
            "index": 899,
            "fname": "visitIfStatement",
            "params": {
                "node": 586
            }
        },
        {
            "index": 900,
            "fname": "visitWhileLoop",
            "params": {
                "node": 593
            }
        },
        {
            "index": 901,
            "fname": "visitDoWhileLoop",
            "params": {
                "node": 599
            }
        },
        {
            "index": 902,
            "fname": "visitForLoop",
            "params": {
                "node": 605
            }
        },
        {
            "index": 903,
            "fname": "visitSwitchStatement",
            "params": {
                "node": 613
            }
        },
        {
            "index": 904,
            "fname": "visitCommaExpression",
            "params": {
                "node": 338
            },
            "ret": 7
        },
        {
            "index": 905,
            "fname": "visitCallExpression",
            "params": {
                "node": 437
            },
            "ret": 85
        },
        {
            "index": 906,
            "cname": "TypeVariableTracker",
            "supers": {
                "Visitor": 221
            },
            "fields": {
                "_set": -78
            },
            "methods": [
                907,
                908,
                909,
                910,
                911
            ]
        },
        {
            "index": 907,
            "fname": "constructor",
            "ret": 906,
            "hobj": 1
        },
        {
            "index": 908,
            "fname": "get set",
            "ret": 78
        },
        {
            "index": 909,
            "fname": "_consider",
            "params": {
                "thing": 7
            }
        },
        {
            "index": 910,
            "fname": "visitTypeRef",
            "params": {
                "node": 345
            }
        },
        {
            "index": 911,
            "fname": "visitVariableRef",
            "params": {
                "node": 418
            }
        },
        {
            "index": 912,
            "fname": "",
            "params": {
                "kind": 3
            }
        },
        {
            "index": 913,
            "fname": "",
            "params": {
                "kind": 3
            }
        },
        {
            "index": 914,
            "fname": "",
            "params": {
                "kind": 3
            }
        },
        {
            "index": 915,
            "fname": "",
            "params": {
                "name": 3
            },
            "ret": 143
        },
        {
            "index": 916,
            "fname": "",
            "params": {
                "name": 3
            },
            "ret": 143
        },
        {
            "index": 917,
            "aname": "",
            "element": 301,
            "mode": "normal"
        },
        {
            "index": 918,
            "uname": "",
            "types": [
                359,
                514
            ]
        },
        {
            "index": 919,
            "fname": "",
            "params": {
                "typeArgument": 7
            },
            "ret": 174
        },
        {
            "index": 920,
            "aname": "",
            "element": 345,
            "mode": "normal"
        },
        {
            "index": 921,
            "fname": "",
            "params": {
                "argument": 7
            },
            "ret": 174
        },
        {
            "index": 922,
            "fname": "cloneProgram",
            "params": {
                "program": 71
            },
            "ret": 71
        },
        {
            "index": 923,
            "cname": "StatementCloner",
            "supers": {
                "Rewriter": 232
            },
            "methods": [
                924,
                925,
                926,
                927,
                928,
                929,
                930,
                931,
                932,
                933,
                934,
                935,
                939
            ]
        },
        {
            "index": 924,
            "fname": "constructor",
            "ret": 923
        },
        {
            "index": 925,
            "fname": "visitFuncDef",
            "params": {
                "node": 227
            },
            "ret": 227
        },
        {
            "index": 926,
            "fname": "visitNativeFunc",
            "params": {
                "node": 237
            },
            "ret": 237
        },
        {
            "index": 927,
            "fname": "visitNativeType",
            "params": {
                "node": 249
            },
            "ret": 249
        },
        {
            "index": 928,
            "fname": "visitTypeDef",
            "params": {
                "node": 275
            },
            "ret": 275
        },
        {
            "index": 929,
            "fname": "visitStructType",
            "params": {
                "node": 280
            },
            "ret": 280
        },
        {
            "index": 930,
            "fname": "visitConstexprTypeParameter",
            "params": {
                "node": 251
            },
            "ret": 251
        },
        {
            "index": 931,
            "fname": "visitProtocolDecl",
            "params": {
                "node": 109
            },
            "ret": 109
        },
        {
            "index": 932,
            "fname": "visitTypeVariable",
            "params": {
                "node": 146
            },
            "ret": 146
        },
        {
            "index": 933,
            "fname": "visitProtocolRef",
            "params": {
                "node": 107
            },
            "ret": 107
        },
        {
            "index": 934,
            "fname": "visitBoolLiteral",
            "params": {
                "node": 542
            },
            "ret": 542
        },
        {
            "index": 935,
            "fname": "visitTypeOrVariableRef",
            "params": {
                "node": 936
            },
            "ret": 936
        },
        {
            "index": 936,
            "cname": "TypeOrVariableRef",
            "supers": {
                "Node": 8
            },
            "methods": [
                937,
                938
            ]
        },
        {
            "index": 937,
            "fname": "constructor",
            "params": {
                "origin": 42,
                "name": 3
            },
            "ret": 936,
            "hobj": 1
        },
        {
            "index": 938,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 939,
            "fname": "visitEnumType",
            "params": {
                "node": 298
            },
            "ret": 298
        },
        {
            "index": 940,
            "cname": "ConstexprFolder",
            "supers": {
                "Visitor": 221
            },
            "methods": [
                941,
                942,
                943
            ]
        },
        {
            "index": 941,
            "fname": "constructor",
            "ret": 940
        },
        {
            "index": 942,
            "fname": "visitCallExpression",
            "params": {
                "node": 437
            },
            "hobj": 1
        },
        {
            "index": 943,
            "fname": "visitTypeOrVariableRef",
            "params": {
                "node": 936
            }
        },
        {
            "index": 944,
            "cname": "EBufferBuilder",
            "supers": {
                "Visitor": 221
            },
            "fields": {
                "_program": -71
            },
            "methods": [
                945,
                946,
                947,
                948,
                949,
                950,
                951,
                952,
                953,
                954,
                955,
                956,
                957,
                958,
                959,
                960,
                961,
                962
            ]
        },
        {
            "index": 945,
            "fname": "constructor",
            "params": {
                "program": 71
            },
            "ret": 944,
            "hobj": 1
        },
        {
            "index": 946,
            "fname": "_createEPtr",
            "params": {
                "type": 85
            },
            "ret": 43
        },
        {
            "index": 947,
            "fname": "_createEPtrForNode",
            "params": {
                "node": 7
            }
        },
        {
            "index": 948,
            "fname": "visitFuncParameter",
            "params": {
                "node": 116
            }
        },
        {
            "index": 949,
            "fname": "visitVariableDecl",
            "params": {
                "node": 326
            }
        },
        {
            "index": 950,
            "fname": "visitFuncDef",
            "params": {
                "node": 227
            },
            "hobj": 1
        },
        {
            "index": 951,
            "fname": "visitFunctionLikeBlock",
            "params": {
                "node": 565
            },
            "hobj": 1
        },
        {
            "index": 952,
            "fname": "visitCallExpression",
            "params": {
                "node": 437
            },
            "hobj": 1
        },
        {
            "index": 953,
            "fname": "visitMakePtrExpression",
            "params": {
                "node": 485
            },
            "hobj": 1
        },
        {
            "index": 954,
            "fname": "visitGenericLiteral",
            "params": {
                "node": 514
            }
        },
        {
            "index": 955,
            "fname": "visitNullLiteral",
            "params": {
                "node": 548
            }
        },
        {
            "index": 956,
            "fname": "visitBoolLiteral",
            "params": {
                "node": 542
            }
        },
        {
            "index": 957,
            "fname": "visitEnumLiteral",
            "params": {
                "node": 359
            }
        },
        {
            "index": 958,
            "fname": "visitLogicalNot",
            "params": {
                "node": 573
            },
            "hobj": 1
        },
        {
            "index": 959,
            "fname": "visitLogicalExpression",
            "params": {
                "node": 579
            },
            "hobj": 1
        },
        {
            "index": 960,
            "fname": "visitAnonymousVariable",
            "params": {
                "node": 413
            }
        },
        {
            "index": 961,
            "fname": "visitMakeArrayRefExpression",
            "params": {
                "node": 377
            },
            "hobj": 1
        },
        {
            "index": 962,
            "fname": "visitConvertPtrToArrayRefExpression",
            "params": {
                "node": 491
            },
            "hobj": 1
        },
        {
            "index": 963,
            "fname": "EnumTypePopulate",
            "params": {
                "buffer": 45,
                "offset": 5
            }
        },
        {
            "index": 964,
            "fname": "",
            "ret": 82
        },
        {
            "index": 965,
            "oname": "",
            "fields": {
                "value": -1,
                "name": -0
            }
        },
        {
            "index": 966,
            "fname": "",
            "params": {
                "a": 1,
                "b": 1
            },
            "ret": 2
        },
        {
            "index": 967,
            "bname": "Symbol"
        },
        {
            "index": 968,
            "cname": "Evaluator",
            "supers": {
                "Visitor": 221
            },
            "fields": {
                "_program": -71
            },
            "methods": [
                969,
                970,
                971,
                972,
                973,
                974,
                975,
                976,
                977,
                978,
                979,
                980,
                981,
                982,
                983,
                984,
                985,
                986,
                987,
                988,
                989,
                990,
                991,
                992,
                993,
                994,
                995,
                996,
                997,
                998,
                999
            ]
        },
        {
            "index": 969,
            "fname": "constructor",
            "params": {
                "program": 71
            },
            "ret": 968,
            "hobj": 1
        },
        {
            "index": 970,
            "fname": "_snapshot",
            "params": {
                "type": 85,
                "dstPtr": 43,
                "srcPtr": 43
            },
            "ret": 43
        },
        {
            "index": 971,
            "fname": "runFunc",
            "params": {
                "func": 227
            },
            "ret": 43
        },
        {
            "index": 972,
            "fname": "_runBody",
            "params": {
                "type": 85,
                "ptr": 43,
                "block": 7
            },
            "ret": 43
        },
        {
            "index": 973,
            "fname": "visitFunctionLikeBlock",
            "params": {
                "node": 565
            },
            "ret": 43
        },
        {
            "index": 974,
            "fname": "visitReturn",
            "params": {
                "node": 497
            }
        },
        {
            "index": 975,
            "fname": "visitVariableDecl",
            "params": {
                "node": 326
            }
        },
        {
            "index": 976,
            "fname": "visitAssignment",
            "params": {
                "node": 405
            },
            "ret": 43
        },
        {
            "index": 977,
            "fname": "visitIdentityExpression",
            "params": {
                "node": 7
            },
            "ret": 174
        },
        {
            "index": 978,
            "fname": "visitDereferenceExpression",
            "params": {
                "node": 429
            },
            "ret": 7
        },
        {
            "index": 979,
            "fname": "visitMakePtrExpression",
            "params": {
                "node": 485
            },
            "ret": 43
        },
        {
            "index": 980,
            "fname": "visitMakeArrayRefExpression",
            "params": {
                "node": 377
            },
            "ret": 43
        },
        {
            "index": 981,
            "fname": "visitConvertPtrToArrayRefExpression",
            "params": {
                "node": 491
            },
            "ret": 43
        },
        {
            "index": 982,
            "fname": "visitCommaExpression",
            "params": {
                "node": 338
            },
            "ret": 7
        },
        {
            "index": 983,
            "fname": "visitVariableRef",
            "params": {
                "node": 418
            },
            "ret": 43
        },
        {
            "index": 984,
            "fname": "visitGenericLiteral",
            "params": {
                "node": 514
            },
            "ret": 43
        },
        {
            "index": 985,
            "fname": "visitNullLiteral",
            "params": {
                "node": 548
            },
            "ret": 43
        },
        {
            "index": 986,
            "fname": "visitBoolLiteral",
            "params": {
                "node": 542
            },
            "ret": 43
        },
        {
            "index": 987,
            "fname": "visitEnumLiteral",
            "params": {
                "node": 359
            },
            "ret": 43
        },
        {
            "index": 988,
            "fname": "visitLogicalNot",
            "params": {
                "node": 573
            },
            "ret": 43
        },
        {
            "index": 989,
            "fname": "visitLogicalExpression",
            "params": {
                "node": 579
            },
            "ret": 43
        },
        {
            "index": 990,
            "fname": "visitIfStatement",
            "params": {
                "node": 586
            },
            "ret": 174
        },
        {
            "index": 991,
            "fname": "visitWhileLoop",
            "params": {
                "node": 593
            }
        },
        {
            "index": 992,
            "fname": "visitDoWhileLoop",
            "params": {
                "node": 599
            }
        },
        {
            "index": 993,
            "fname": "visitForLoop",
            "params": {
                "node": 605
            }
        },
        {
            "index": 994,
            "fname": "visitSwitchStatement",
            "params": {
                "node": 613
            }
        },
        {
            "index": 995,
            "fname": "visitBreak",
            "params": {
                "node": 506
            }
        },
        {
            "index": 996,
            "fname": "visitContinue",
            "params": {
                "node": 502
            }
        },
        {
            "index": 997,
            "fname": "visitTrapStatement",
            "params": {
                "node": 510
            }
        },
        {
            "index": 998,
            "fname": "visitAnonymousVariable",
            "params": {
                "node": 413
            }
        },
        {
            "index": 999,
            "fname": "visitCallExpression",
            "params": {
                "node": 437
            },
            "ret": 43
        },
        {
            "index": 1000,
            "fname": "",
            "ret": 43
        },
        {
            "index": 1001,
            "fname": "",
            "params": {
                "predicate": 0
            },
            "ret": 2
        },
        {
            "index": 1002,
            "fname": "",
            "params": {
                "switchCase": 615
            },
            "ret": 2
        },
        {
            "index": 1003,
            "uname": "",
            "types": [
                359,
                523
            ]
        },
        {
            "index": 1004,
            "fname": "",
            "params": {
                "switchCase": 615
            },
            "ret": 2
        },
        {
            "index": 1005,
            "fname": "",
            "ret": 43
        },
        {
            "index": 1006,
            "fname": "",
            "ret": 43
        },
        {
            "index": 1007,
            "fname": "",
            "params": {
                "thunk": 1008
            },
            "ret": 0
        },
        {
            "index": 1008,
            "bname": "Function"
        },
        {
            "index": 1009,
            "cname": "ExpressionFinder",
            "supers": {
                "Visitor": 221
            },
            "fields": {
                "_callback": -0
            },
            "methods": [
                1010,
                1011,
                1012,
                1013,
                1014,
                1015,
                1016,
                1017,
                1018,
                1019,
                1020,
                1021,
                1022,
                1023
            ]
        },
        {
            "index": 1010,
            "fname": "constructor",
            "params": {
                "callback": 0
            },
            "ret": 1009,
            "hobj": 1
        },
        {
            "index": 1011,
            "fname": "visitFunc",
            "params": {
                "node": 114
            }
        },
        {
            "index": 1012,
            "fname": "visitFuncParameter",
            "params": {
                "node": 116
            }
        },
        {
            "index": 1013,
            "fname": "visitConstexprTypeParameter",
            "params": {
                "node": 251
            }
        },
        {
            "index": 1014,
            "fname": "visitAssignment",
            "params": {
                "node": 405
            }
        },
        {
            "index": 1015,
            "fname": "visitReadModifyWriteExpression",
            "params": {
                "node": 411
            }
        },
        {
            "index": 1016,
            "fname": "visitIdentityExpression",
            "params": {
                "node": 7
            }
        },
        {
            "index": 1017,
            "fname": "visitCallExpression",
            "params": {
                "node": 437
            }
        },
        {
            "index": 1018,
            "fname": "visitReturn",
            "params": {
                "node": 497
            }
        },
        {
            "index": 1019,
            "fname": "visitWhileLoop",
            "params": {
                "node": 593
            }
        },
        {
            "index": 1020,
            "fname": "visitDoWhileLoop",
            "params": {
                "node": 599
            }
        },
        {
            "index": 1021,
            "fname": "visitIfStatement",
            "params": {
                "node": 586
            }
        },
        {
            "index": 1022,
            "fname": "visitForLoop",
            "params": {
                "node": 605
            }
        },
        {
            "index": 1023,
            "fname": "visitVariableDecl",
            "params": {
                "node": 326
            }
        },
        {
            "index": 1024,
            "fname": "findHighZombies",
            "params": {
                "program": 71
            }
        },
        {
            "index": 1025,
            "fname": "flattenProtocolExtends",
            "params": {
                "program": 71
            }
        },
        {
            "index": 1026,
            "cname": "VisitingSet",
            "fields": {
                "_set": -78
            },
            "methods": [
                1027,
                1028
            ]
        },
        {
            "index": 1027,
            "fname": "constructor",
            "params": {
                "items": 101
            },
            "ret": 1026
        },
        {
            "index": 1028,
            "fname": "doVisit",
            "params": {
                "item": 7,
                "callback": 0
            },
            "ret": 29
        },
        {
            "index": 1029,
            "fname": "flatten",
            "params": {
                "protocol": 109
            }
        },
        {
            "index": 1030,
            "fname": "",
            "ret": 0
        },
        {
            "index": 1031,
            "aname": "",
            "element": 146,
            "mode": "normal"
        },
        {
            "index": 1032,
            "fname": "foldConstexprs",
            "params": {
                "program": 71
            }
        },
        {
            "index": 1033,
            "fname": "",
            "params": {
                "parameter": 116
            },
            "ret": 85
        },
        {
            "index": 1034,
            "fname": "",
            "params": {
                "parameter": 116
            },
            "ret": 174
        },
        {
            "index": 1035,
            "cname": "FindTypeVariable",
            "supers": {
                "Visitor": 221
            },
            "fields": {
                "func": -114,
                "typeArguments": -101
            },
            "methods": [
                1036,
                1037,
                1038
            ]
        },
        {
            "index": 1036,
            "fname": "constructor",
            "params": {
                "func": 114,
                "typeArguments": 101
            },
            "ret": 1035,
            "hobj": 1
        },
        {
            "index": 1037,
            "fname": "visitTypeRef",
            "params": {
                "node": 345
            }
        },
        {
            "index": 1038,
            "fname": "visitTypeVariable",
            "params": {
                "node": 146
            }
        },
        {
            "index": 1039,
            "fname": "",
            "params": {
                "parameter": 116
            },
            "ret": 174
        },
        {
            "index": 1040,
            "fname": "",
            "params": {
                "parameter": 116
            },
            "ret": 174
        },
        {
            "index": 1041,
            "fname": "",
            "params": {
                "parameter": 116
            },
            "ret": 174
        },
        {
            "index": 1042,
            "cname": "HighZombieFinder",
            "supers": {
                "Visitor": 221
            },
            "methods": [
                1043,
                1044,
                1045,
                1046,
                1047
            ]
        },
        {
            "index": 1043,
            "fname": "constructor",
            "ret": 1042
        },
        {
            "index": 1044,
            "fname": "_found",
            "params": {
                "node": 7
            }
        },
        {
            "index": 1045,
            "fname": "visitDotExpression",
            "params": {
                "node": 466
            }
        },
        {
            "index": 1046,
            "fname": "visitIndexExpression",
            "params": {
                "node": 475
            }
        },
        {
            "index": 1047,
            "fname": "visitCallExpression",
            "params": {
                "node": 437
            },
            "hobj": 1
        },
        {
            "index": 1048,
            "fname": "inferTypesForCall",
            "params": {
                "func": 114,
                "typeArguments": 101,
                "argumentTypes": 136,
                "returnType": 85
            },
            "ret": 0
        },
        {
            "index": 1049,
            "fname": "inline",
            "params": {
                "program": 71
            }
        },
        {
            "index": 1050,
            "fname": "_inlineFunction",
            "params": {
                "program": 71,
                "func": 114,
                "visiting": 1026
            }
        },
        {
            "index": 1051,
            "fname": "resolveInlinedFunction",
            "params": {
                "program": 71,
                "name": 3,
                "typeArguments": 136,
                "argumentTypes": 136,
                "allowEntryPoint": 2
            },
            "ret": 854
        },
        {
            "index": 1052,
            "cname": "Inliner",
            "supers": {
                "Rewriter": 232
            },
            "fields": {
                "_program": -71,
                "_visiting": -1026
            },
            "methods": [
                1053,
                1054
            ]
        },
        {
            "index": 1053,
            "fname": "constructor",
            "params": {
                "program": 71,
                "func": 114,
                "visiting": 1026
            },
            "ret": 1052,
            "hobj": 1
        },
        {
            "index": 1054,
            "fname": "visitCallExpression",
            "params": {
                "node": 437
            },
            "ret": 7,
            "hobj": 1
        },
        {
            "index": 1055,
            "fname": "",
            "ret": 565
        },
        {
            "index": 1056,
            "fname": "",
            "params": {
                "argument": 7
            },
            "ret": 174
        },
        {
            "index": 1057,
            "fname": "",
            "params": {
                "type": 199
            }
        },
        {
            "index": 1058,
            "fname": ""
        },
        {
            "index": 1059,
            "fname": "isBitwiseEquivalent",
            "params": {
                "left": 1,
                "right": 1
            },
            "ret": 2
        },
        {
            "index": 1060,
            "bname": "Float64Array"
        },
        {
            "index": 1061,
            "bname": "Int32Array"
        },
        {
            "index": 1062,
            "fname": "",
            "params": {
                "type": 85
            }
        },
        {
            "index": 1063,
            "fname": "",
            "params": {
                "value": 1
            },
            "ret": 2
        },
        {
            "index": 1064,
            "fname": "",
            "params": {
                "origin": 42,
                "value": 1
            },
            "ret": 523
        },
        {
            "index": 1065,
            "fname": "",
            "params": {
                "value": 1
            },
            "ret": 1
        },
        {
            "index": 1066,
            "fname": "",
            "params": {
                "a": 1,
                "b": 1
            },
            "ret": 2
        },
        {
            "index": 1067,
            "fname": "",
            "params": {
                "buffer": 45,
                "offset": 1
            }
        },
        {
            "index": 1068,
            "fname": "",
            "params": {
                "value": 1
            },
            "ret": 1
        },
        {
            "index": 1069,
            "fname": "",
            "params": {
                "value": 1
            },
            "ret": 1
        },
        {
            "index": 1070,
            "fname": "",
            "ret": 82
        },
        {
            "index": 1071,
            "oname": "",
            "fields": {
                "value": -5,
                "name": -5
            }
        },
        {
            "index": 1072,
            "fname": "",
            "params": {
                "type": 85
            }
        },
        {
            "index": 1073,
            "fname": "",
            "params": {
                "value": 1
            },
            "ret": 2
        },
        {
            "index": 1074,
            "fname": "",
            "params": {
                "origin": 42,
                "value": 1
            },
            "ret": 523
        },
        {
            "index": 1075,
            "fname": "",
            "params": {
                "value": 1
            },
            "ret": 1
        },
        {
            "index": 1076,
            "fname": "",
            "params": {
                "a": 1,
                "b": 1
            },
            "ret": 2
        },
        {
            "index": 1077,
            "fname": "",
            "params": {
                "buffer": 45,
                "offset": 1
            }
        },
        {
            "index": 1078,
            "fname": "",
            "params": {
                "value": 1
            },
            "ret": 1
        },
        {
            "index": 1079,
            "fname": "",
            "params": {
                "value": 1
            },
            "ret": 1
        },
        {
            "index": 1080,
            "fname": "",
            "ret": 82
        },
        {
            "index": 1081,
            "fname": "",
            "params": {
                "type": 85
            }
        },
        {
            "index": 1082,
            "fname": "",
            "params": {
                "value": 1
            },
            "ret": 2
        },
        {
            "index": 1083,
            "fname": "",
            "params": {
                "origin": 42,
                "value": 1
            },
            "ret": 523
        },
        {
            "index": 1084,
            "fname": "",
            "params": {
                "value": 1
            },
            "ret": 1
        },
        {
            "index": 1085,
            "fname": "",
            "params": {
                "a": 1,
                "b": 1
            },
            "ret": 2
        },
        {
            "index": 1086,
            "fname": "",
            "params": {
                "buffer": 45,
                "offset": 1
            }
        },
        {
            "index": 1087,
            "fname": "",
            "params": {
                "value": 1
            },
            "ret": 1
        },
        {
            "index": 1088,
            "fname": "",
            "params": {
                "value": 1
            },
            "ret": 1
        },
        {
            "index": 1089,
            "fname": "",
            "ret": 82
        },
        {
            "index": 1090,
            "fname": "",
            "params": {
                "type": 85
            }
        },
        {
            "index": 1091,
            "fname": "",
            "params": {
                "value": 1
            },
            "ret": 2
        },
        {
            "index": 1092,
            "fname": "",
            "params": {
                "buffer": 45,
                "offset": 1
            }
        },
        {
            "index": 1093,
            "fname": "",
            "params": {
                "value": 1
            },
            "ret": 1
        },
        {
            "index": 1094,
            "fname": "",
            "params": {
                "value": 1
            },
            "ret": 1
        },
        {
            "index": 1095,
            "fname": "",
            "params": {
                "value": 1
            },
            "ret": 1
        },
        {
            "index": 1096,
            "fname": "",
            "params": {
                "value": 1
            },
            "ret": 1
        },
        {
            "index": 1097,
            "fname": "",
            "params": {
                "type": 85
            }
        },
        {
            "index": 1098,
            "fname": "",
            "params": {
                "value": 1
            },
            "ret": 2
        },
        {
            "index": 1099,
            "fname": "",
            "params": {
                "buffer": 45,
                "offset": 1
            }
        },
        {
            "index": 1100,
            "fname": "",
            "params": {
                "value": 1
            },
            "ret": 1
        },
        {
            "index": 1101,
            "fname": "",
            "params": {
                "value": 1
            },
            "ret": 1
        },
        {
            "index": 1102,
            "fname": "",
            "params": {
                "value": 1
            },
            "ret": 1
        },
        {
            "index": 1103,
            "fname": "",
            "params": {
                "value": 1
            },
            "ret": 1
        },
        {
            "index": 1104,
            "fname": "",
            "params": {
                "type": 199
            }
        },
        {
            "index": 1105,
            "fname": "",
            "params": {
                "buffer": 45,
                "offset": 1
            }
        },
        {
            "index": 1106,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1107,
            "fname": "",
            "params": {
                "[value]": 781
            },
            "ret": 43
        },
        {
            "index": 1108,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1109,
            "fname": "",
            "params": {
                "[value]": 781
            },
            "ret": 43
        },
        {
            "index": 1110,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1111,
            "fname": "",
            "params": {
                "[value]": 781
            },
            "ret": 43
        },
        {
            "index": 1112,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1113,
            "fname": "",
            "params": {
                "[value]": 781
            },
            "ret": 43
        },
        {
            "index": 1114,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1115,
            "fname": "",
            "params": {
                "[value]": 781
            },
            "ret": 43
        },
        {
            "index": 1116,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1117,
            "fname": "",
            "params": {
                "[value]": 781
            },
            "ret": 43
        },
        {
            "index": 1118,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1119,
            "fname": "",
            "params": {
                "[value]": 781
            },
            "ret": 43
        },
        {
            "index": 1120,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1121,
            "fname": "",
            "params": {
                "[value]": 781
            },
            "ret": 43
        },
        {
            "index": 1122,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1123,
            "fname": "",
            "params": {
                "[value]": 781
            },
            "ret": 43
        },
        {
            "index": 1124,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1125,
            "fname": "",
            "params": {
                "[value]": 781
            },
            "ret": 43
        },
        {
            "index": 1126,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1127,
            "fname": "",
            "params": {
                "[value]": 781
            },
            "ret": 43
        },
        {
            "index": 1128,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1129,
            "fname": "",
            "params": {
                "[value]": 781
            },
            "ret": 43
        },
        {
            "index": 1130,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1131,
            "fname": "",
            "params": {
                "[value]": 781
            },
            "ret": 43
        },
        {
            "index": 1132,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1133,
            "fname": "",
            "params": {
                "[value]": 781
            },
            "ret": 43
        },
        {
            "index": 1134,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1135,
            "fname": "",
            "params": {
                "[value]": 781
            },
            "ret": 43
        },
        {
            "index": 1136,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1137,
            "fname": "",
            "params": {
                "[value]": 781
            },
            "ret": 43
        },
        {
            "index": 1138,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1139,
            "fname": "",
            "params": {
                "[value]": 781
            },
            "ret": 43
        },
        {
            "index": 1140,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1141,
            "fname": "",
            "params": {
                "[value]": 781
            },
            "ret": 43
        },
        {
            "index": 1142,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1143,
            "fname": "",
            "params": {
                "[value]": 781
            },
            "ret": 43
        },
        {
            "index": 1144,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1145,
            "fname": "",
            "params": {
                "[value]": 781
            },
            "ret": 43
        },
        {
            "index": 1146,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1147,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1148,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1149,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1150,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1151,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1152,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1153,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1154,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1155,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1156,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1157,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1158,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1159,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1160,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1161,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1162,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1163,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1164,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1165,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1166,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1167,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1168,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1169,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1170,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1171,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1172,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1173,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1174,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1175,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1176,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1177,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1178,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1179,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1180,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1181,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1182,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1183,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1184,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1185,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1186,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1187,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1188,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1189,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1190,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1191,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1192,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1193,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1194,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1195,
            "fname": "",
            "params": {
                "[value]": 781
            },
            "ret": 43
        },
        {
            "index": 1196,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1197,
            "fname": "",
            "params": {
                "[value]": 781
            },
            "ret": 43
        },
        {
            "index": 1198,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1199,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1200,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1201,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1202,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1203,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1204,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1205,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1206,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1207,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1208,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1209,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1210,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1211,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1212,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1213,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1214,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1215,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1216,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1217,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1218,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1219,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1220,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1221,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1222,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1223,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1224,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1225,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1226,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1227,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1228,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1229,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1230,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1231,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1232,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1233,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1234,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1235,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1236,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1237,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1238,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1239,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1240,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1241,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1242,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1243,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1244,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1245,
            "fname": "",
            "params": {
                "[ref, index]": 781,
                "node": 7
            },
            "ret": 43
        },
        {
            "index": 1246,
            "fname": "",
            "params": {
                "func": 114
            }
        },
        {
            "index": 1247,
            "fname": "",
            "params": {
                "[ref]": 781,
                "node": 7
            },
            "ret": 43
        },
        {
            "index": 1248,
            "cname": "LateChecker",
            "supers": {
                "Visitor": 221
            },
            "methods": [
                1249,
                1250,
                1251,
                1252
            ]
        },
        {
            "index": 1249,
            "fname": "constructor",
            "ret": 1248
        },
        {
            "index": 1250,
            "fname": "visitReferenceType",
            "params": {
                "node": 367
            }
        },
        {
            "index": 1251,
            "fname": "_checkShaderType",
            "params": {
                "node": 114
            }
        },
        {
            "index": 1252,
            "fname": "visitFuncDef",
            "params": {
                "node": 227
            },
            "hobj": 1
        },
        {
            "index": 1253,
            "fname": "",
            "params": {
                "type": 85
            }
        },
        {
            "index": 1254,
            "fname": "",
            "params": {
                "kind": 3
            },
            "ret": 9
        },
        {
            "index": 1255,
            "cname": "LiteralTypeChecker",
            "supers": {
                "Visitor": 221
            },
            "methods": [
                1256,
                1257,
                1258
            ]
        },
        {
            "index": 1256,
            "fname": "constructor",
            "ret": 1255
        },
        {
            "index": 1257,
            "fname": "visitNullType",
            "params": {
                "node": 552
            }
        },
        {
            "index": 1258,
            "fname": "visitGenericLiteralType",
            "params": {
                "node": 528
            }
        },
        {
            "index": 1259,
            "cname": "LoopChecker",
            "supers": {
                "Visitor": 221
            },
            "fields": {
                "_loopDepth": -1,
                "_switchDepth": -1
            },
            "methods": [
                1260,
                1261,
                1262,
                1263,
                1264,
                1265,
                1266,
                1267
            ]
        },
        {
            "index": 1260,
            "fname": "constructor",
            "ret": 1259,
            "hobj": 1
        },
        {
            "index": 1261,
            "fname": "visitFuncDef",
            "params": {
                "node": 227
            },
            "hobj": 1
        },
        {
            "index": 1262,
            "fname": "visitWhileLoop",
            "params": {
                "node": 593
            }
        },
        {
            "index": 1263,
            "fname": "visitDoWhileLoop",
            "params": {
                "node": 599
            }
        },
        {
            "index": 1264,
            "fname": "visitForLoop",
            "params": {
                "node": 605
            }
        },
        {
            "index": 1265,
            "fname": "visitSwitchStatement",
            "params": {
                "node": 613
            }
        },
        {
            "index": 1266,
            "fname": "visitBreak",
            "params": {
                "node": 506
            },
            "hobj": 1
        },
        {
            "index": 1267,
            "fname": "visitContinue",
            "params": {
                "node": 502
            },
            "hobj": 1
        },
        {
            "index": 1268,
            "fname": "isWildcardKind",
            "params": {
                "kind": 6
            },
            "ret": 2
        },
        {
            "index": 1269,
            "oname": "FuncArray",
            "fields": {
                "kind": -0,
                "array": -143
            }
        },
        {
            "index": 1270,
            "oname": "",
            "fields": {
                "kind": -115,
                "array": -143
            }
        },
        {
            "index": 1271,
            "oname": "",
            "fields": {
                "failures": -784,
                "func": -4
            }
        },
        {
            "index": 1272,
            "cname": "NameFinder",
            "supers": {
                "Visitor": 221
            },
            "fields": {
                "_set": -78,
                "_worklist": -826
            },
            "methods": [
                1273,
                1274,
                1275,
                1276,
                1277,
                1278,
                1279,
                1280,
                1281,
                1282,
                1283,
                1284
            ]
        },
        {
            "index": 1273,
            "fname": "constructor",
            "ret": 1272,
            "hobj": 1
        },
        {
            "index": 1274,
            "fname": "get set",
            "ret": 78
        },
        {
            "index": 1275,
            "fname": "get worklist",
            "ret": 826
        },
        {
            "index": 1276,
            "fname": "add",
            "params": {
                "name": 3
            }
        },
        {
            "index": 1277,
            "fname": "visitProtocolRef",
            "params": {
                "node": 107
            },
            "hobj": 1
        },
        {
            "index": 1278,
            "fname": "visitTypeRef",
            "params": {
                "node": 345
            },
            "hobj": 1
        },
        {
            "index": 1279,
            "fname": "visitVariableRef",
            "params": {
                "node": 418
            },
            "hobj": 1
        },
        {
            "index": 1280,
            "fname": "visitTypeOrVariableRef",
            "params": {
                "node": 936
            }
        },
        {
            "index": 1281,
            "fname": "_handlePropertyAccess",
            "params": {
                "node": 435
            }
        },
        {
            "index": 1282,
            "fname": "visitDotExpression",
            "params": {
                "node": 466
            },
            "hobj": 1
        },
        {
            "index": 1283,
            "fname": "visitIndexExpression",
            "params": {
                "node": 475
            },
            "hobj": 1
        },
        {
            "index": 1284,
            "fname": "visitCallExpression",
            "params": {
                "node": 437
            },
            "hobj": 1
        },
        {
            "index": 1285,
            "cname": "NameResolver",
            "supers": {
                "Visitor": 221
            },
            "fields": {
                "_nameContext": -75
            },
            "methods": [
                1286,
                1287,
                1288,
                1289,
                1290,
                1291,
                1292,
                1293,
                1294,
                1295,
                1296,
                1297,
                1298,
                1299,
                1300,
                1301,
                1302,
                1303,
                1304,
                1305,
                1306,
                1307,
                1308,
                1309,
                1310
            ]
        },
        {
            "index": 1286,
            "fname": "constructor",
            "params": {
                "nameContext": 75
            },
            "ret": 1285,
            "hobj": 1
        },
        {
            "index": 1287,
            "fname": "doStatement",
            "params": {
                "statement": 7
            }
        },
        {
            "index": 1288,
            "fname": "_visitTypeParametersAndBuildNameContext",
            "params": {
                "node": 114
            },
            "ret": 75
        },
        {
            "index": 1289,
            "fname": "visitFunc",
            "params": {
                "node": 114
            }
        },
        {
            "index": 1290,
            "fname": "visitFuncDef",
            "params": {
                "node": 227
            }
        },
        {
            "index": 1291,
            "fname": "visitBlock",
            "params": {
                "node": 332
            }
        },
        {
            "index": 1292,
            "fname": "visitIfStatement",
            "params": {
                "node": 586
            }
        },
        {
            "index": 1293,
            "fname": "visitWhileLoop",
            "params": {
                "node": 593
            }
        },
        {
            "index": 1294,
            "fname": "visitDoWhileLoop",
            "params": {
                "node": 599
            }
        },
        {
            "index": 1295,
            "fname": "visitForLoop",
            "params": {
                "node": 605
            }
        },
        {
            "index": 1296,
            "fname": "visitProtocolDecl",
            "params": {
                "node": 109
            }
        },
        {
            "index": 1297,
            "fname": "visitProtocolRef",
            "params": {
                "node": 107
            }
        },
        {
            "index": 1298,
            "fname": "visitProtocolFuncDecl",
            "params": {
                "node": 112
            }
        },
        {
            "index": 1299,
            "fname": "visitTypeDef",
            "params": {
                "node": 275
            }
        },
        {
            "index": 1300,
            "fname": "visitStructType",
            "params": {
                "node": 280
            }
        },
        {
            "index": 1301,
            "fname": "_resolveTypeArguments",
            "params": {
                "typeArguments": 101
            }
        },
        {
            "index": 1302,
            "fname": "visitTypeRef",
            "params": {
                "node": 345
            }
        },
        {
            "index": 1303,
            "fname": "visitReferenceType",
            "params": {
                "node": 367
            }
        },
        {
            "index": 1304,
            "fname": "visitVariableDecl",
            "params": {
                "node": 326
            }
        },
        {
            "index": 1305,
            "fname": "visitVariableRef",
            "params": {
                "node": 418
            }
        },
        {
            "index": 1306,
            "fname": "visitReturn",
            "params": {
                "node": 497
            },
            "hobj": 1
        },
        {
            "index": 1307,
            "fname": "_handlePropertyAccess",
            "params": {
                "node": 435
            }
        },
        {
            "index": 1308,
            "fname": "visitDotExpression",
            "params": {
                "node": 466
            },
            "hobj": 1
        },
        {
            "index": 1309,
            "fname": "visitIndexExpression",
            "params": {
                "node": 475
            },
            "hobj": 1
        },
        {
            "index": 1310,
            "fname": "visitCallExpression",
            "params": {
                "node": 437
            },
            "hobj": 1
        },
        {
            "index": 1311,
            "fname": "",
            "ret": 174
        },
        {
            "index": 1312,
            "aname": "",
            "element": 120,
            "mode": "normal"
        },
        {
            "index": 1313,
            "fname": "",
            "params": {
                "substitution": 694
            },
            "ret": 0
        },
        {
            "index": 1314,
            "fname": "",
            "params": {
                "implementationData": 0,
                "visitor": 220
            },
            "ret": 0
        },
        {
            "index": 1315,
            "fname": "",
            "params": {
                "implementationData": 0
            },
            "ret": 0
        },
        {
            "index": 1316,
            "fname": "NativeTypeInstantiate",
            "params": {
                "typeArguments": 136
            },
            "ret": 0
        },
        {
            "index": 1317,
            "cname": "NormalUsePropertyResolver",
            "supers": {
                "Rewriter": 232
            },
            "methods": [
                1318,
                1319,
                1320
            ]
        },
        {
            "index": 1318,
            "fname": "constructor",
            "ret": 1317
        },
        {
            "index": 1319,
            "fname": "visitDotExpression",
            "params": {
                "node": 466
            },
            "ret": 7,
            "hobj": 1
        },
        {
            "index": 1320,
            "fname": "visitIndexExpression",
            "params": {
                "node": 475
            },
            "ret": 7,
            "hobj": 1
        },
        {
            "index": 1321,
            "fname": "isOriginKind",
            "params": {
                "originKind": 3
            },
            "ret": 2
        },
        {
            "index": 1322,
            "cname": "Parse",
            "fields": {
                "program": -71,
                "origin": -3,
                "originKind": -3,
                "lineNumberOffset": -5,
                "text": -3,
                "lexer": -11,
                "addressSpaceConsumed": 2
            },
            "sfields": {
                "static instance": -1322,
                "const genericConsume": 1324,
                "const consume": 1325,
                "const consumeKind": 1326,
                "const assertNext": 1327,
                "const genericTest": 1328,
                "const test": 1329,
                "const testKind": 1330,
                "const tryConsume": 1331,
                "const tryConsumeKind": 1332,
                "const parseProtocolRef": 1333,
                "const consumeEndOfTypeArgs": 1334,
                "const parseTypeParameters": 1335,
                "const parseTerm": 1336,
                "const parseConstexpr": 1337,
                "const parseTypeArguments": 1338,
                "const getAddressSpace": 1339,
                "const parseType": 1340,
                "const parseTypeDef": 1341,
                "const genericParseLeft": 1342,
                "const parseLeftOperatorCall": 1343,
                "const parseCallExpression": 1344,
                "const isCallExpression": 1345,
                "const emitIncrement": 1346,
                "const finishParsingPostIncrement": 1347,
                "const parseSuffixOperator": 1348,
                "const parsePossibleSuffix": 1349,
                "const finishParsingPreIncrement": 1350,
                "const parsePreIncrement": 1351,
                "const parsePossiblePrefix": 1352,
                "const parsePossibleProduct": 1353,
                "const parsePossibleSum": 1354,
                "const parsePossibleShift": 1355,
                "const parsePossibleRelationalInequality": 1356,
                "const parsePossibleRelationalEquality": 1357,
                "const parsePossibleBitwiseAnd": 1358,
                "const parsePossibleBitwiseXor": 1359,
                "const parsePossibleBitwiseOr": 1360,
                "const parseLeftLogicalExpression": 1361,
                "const parsePossibleLogicalAnd": 1362,
                "const parsePossibleLogicalOr": 1363,
                "const parsePossibleTernaryConditional": 1364,
                "const parsePossibleAssignment": 1365,
                "const parseAssignment": 1366,
                "const parsePostIncrement": 1367,
                "const parseEffectfulExpression": 1368,
                "const genericParseCommaExpression": 1369,
                "const parseCommaExpression": 1370,
                "const parseExpression": 1371,
                "const parseEffectfulStatement": 1372,
                "const parseReturn": 1373,
                "const parseBreak": 1374,
                "const parseContinue": 1375,
                "const parseIfStatement": 1376,
                "const parseWhile": 1377,
                "const parseFor": 1378,
                "const parseDo": 1379,
                "const parseVariableDecls": 1380,
                "const parseSwitchCase": 1381,
                "const parseSwitchStatement": 1382,
                "const parseStatement": 1383,
                "const parseBlockBody": 1384,
                "const parseBlock": 1385,
                "const parseParameter": 1386,
                "const parseParameters": 1387,
                "const parseFuncName": 1388,
                "const parseFuncDecl": 1389,
                "const parseProtocolFuncDecl": 1390,
                "const parseFuncDef": 1391,
                "const parseProtocolDecl": 1392,
                "const parseField": 1393,
                "const parseStructType": 1394,
                "const parseNativeFunc": 1395,
                "const parseNative": 1396,
                "const parseRestrictedFuncDef": 1398,
                "const parseEnumMember": 1399,
                "const parseEnumType": 1400
            },
            "methods": [
                1323
            ]
        },
        {
            "index": 1323,
            "fname": "constructor",
            "params": {
                "program": 71,
                "origin": 3,
                "originKind": 3,
                "lineNumberOffset": 5,
                "text": 3
            },
            "ret": 1322
        },
        {
            "index": 1324,
            "fname": "static genericConsume",
            "params": {
                "callback": 0,
                "explanation": 826
            },
            "ret": 9
        },
        {
            "index": 1325,
            "fname": "static consume",
            "params": {
                "texts": 826
            },
            "ret": 9
        },
        {
            "index": 1326,
            "fname": "static consumeKind",
            "params": {
                "kind": 3
            },
            "ret": 9
        },
        {
            "index": 1327,
            "fname": "static assertNext",
            "params": {
                "texts": 826
            }
        },
        {
            "index": 1328,
            "fname": "static genericTest",
            "params": {
                "callback": 0
            },
            "ret": 9
        },
        {
            "index": 1329,
            "fname": "static test",
            "params": {
                "texts": 826
            },
            "ret": 9
        },
        {
            "index": 1330,
            "fname": "static testKind",
            "params": {
                "kind": 3
            },
            "ret": 9
        },
        {
            "index": 1331,
            "fname": "static tryConsume",
            "params": {
                "texts": 826
            },
            "ret": 9
        },
        {
            "index": 1332,
            "fname": "static tryConsumeKind",
            "params": {
                "kind": 3
            },
            "ret": 9
        },
        {
            "index": 1333,
            "fname": "static parseProtocolRef",
            "ret": 107
        },
        {
            "index": 1334,
            "fname": "static consumeEndOfTypeArgs"
        },
        {
            "index": 1335,
            "fname": "static parseTypeParameters",
            "ret": 262
        },
        {
            "index": 1336,
            "fname": "static parseTerm",
            "ret": 303
        },
        {
            "index": 1337,
            "fname": "static parseConstexpr",
            "ret": 303
        },
        {
            "index": 1338,
            "fname": "static parseTypeArguments",
            "ret": 101
        },
        {
            "index": 1339,
            "fname": "static getAddressSpace",
            "params": {
                "addressSpace": 3
            },
            "ret": 3
        },
        {
            "index": 1340,
            "fname": "static parseType",
            "ret": 85
        },
        {
            "index": 1341,
            "fname": "static parseTypeDef",
            "ret": 275
        },
        {
            "index": 1342,
            "fname": "static genericParseLeft",
            "params": {
                "texts": 826,
                "nextParser": 0,
                "constructor": 0
            },
            "ret": 303
        },
        {
            "index": 1343,
            "fname": "static parseLeftOperatorCall",
            "params": {
                "texts": 826,
                "nextParser": 0
            },
            "ret": 303
        },
        {
            "index": 1344,
            "fname": "static parseCallExpression",
            "ret": 437
        },
        {
            "index": 1345,
            "fname": "static isCallExpression",
            "ret": 2
        },
        {
            "index": 1346,
            "fname": "static emitIncrement",
            "params": {
                "token": 9,
                "old": 7,
                "extraArg": 7
            },
            "ret": 437
        },
        {
            "index": 1347,
            "fname": "static finishParsingPostIncrement",
            "params": {
                "token": 9,
                "left": 303
            },
            "ret": 411
        },
        {
            "index": 1348,
            "fname": "static parseSuffixOperator",
            "params": {
                "left": 303,
                "acceptableOperators": 826
            },
            "ret": 303
        },
        {
            "index": 1349,
            "fname": "static parsePossibleSuffix",
            "ret": 303
        },
        {
            "index": 1350,
            "fname": "static finishParsingPreIncrement",
            "params": {
                "token": 9,
                "left": 303,
                "extraArg": 7
            },
            "ret": 411
        },
        {
            "index": 1351,
            "fname": "static parsePreIncrement",
            "ret": 411
        },
        {
            "index": 1352,
            "fname": "static parsePossiblePrefix",
            "ret": 303
        },
        {
            "index": 1353,
            "fname": "static parsePossibleProduct",
            "ret": 303
        },
        {
            "index": 1354,
            "fname": "static parsePossibleSum",
            "ret": 303
        },
        {
            "index": 1355,
            "fname": "static parsePossibleShift",
            "ret": 303
        },
        {
            "index": 1356,
            "fname": "static parsePossibleRelationalInequality",
            "ret": 303
        },
        {
            "index": 1357,
            "fname": "static parsePossibleRelationalEquality",
            "ret": 303
        },
        {
            "index": 1358,
            "fname": "static parsePossibleBitwiseAnd",
            "ret": 303
        },
        {
            "index": 1359,
            "fname": "static parsePossibleBitwiseXor",
            "ret": 303
        },
        {
            "index": 1360,
            "fname": "static parsePossibleBitwiseOr",
            "ret": 303
        },
        {
            "index": 1361,
            "fname": "static parseLeftLogicalExpression",
            "params": {
                "texts": 826,
                "nextParser": 0
            },
            "ret": 303
        },
        {
            "index": 1362,
            "fname": "static parsePossibleLogicalAnd",
            "ret": 303
        },
        {
            "index": 1363,
            "fname": "static parsePossibleLogicalOr",
            "ret": 303
        },
        {
            "index": 1364,
            "fname": "static parsePossibleTernaryConditional",
            "ret": 303
        },
        {
            "index": 1365,
            "fname": "static parsePossibleAssignment",
            "params": {
                "mode": 3
            },
            "ret": 303
        },
        {
            "index": 1366,
            "fname": "static parseAssignment",
            "ret": 303
        },
        {
            "index": 1367,
            "fname": "static parsePostIncrement",
            "ret": 411
        },
        {
            "index": 1368,
            "fname": "static parseEffectfulExpression",
            "ret": 303
        },
        {
            "index": 1369,
            "fname": "static genericParseCommaExpression",
            "params": {
                "finalExpressionParser": 0
            },
            "ret": 303
        },
        {
            "index": 1370,
            "fname": "static parseCommaExpression",
            "ret": 303
        },
        {
            "index": 1371,
            "fname": "static parseExpression",
            "ret": 303
        },
        {
            "index": 1372,
            "fname": "static parseEffectfulStatement",
            "ret": 303
        },
        {
            "index": 1373,
            "fname": "static parseReturn",
            "ret": 497
        },
        {
            "index": 1374,
            "fname": "static parseBreak",
            "ret": 506
        },
        {
            "index": 1375,
            "fname": "static parseContinue",
            "ret": 502
        },
        {
            "index": 1376,
            "fname": "static parseIfStatement",
            "ret": 586
        },
        {
            "index": 1377,
            "fname": "static parseWhile",
            "ret": 593
        },
        {
            "index": 1378,
            "fname": "static parseFor",
            "ret": 605
        },
        {
            "index": 1379,
            "fname": "static parseDo",
            "ret": 599
        },
        {
            "index": 1380,
            "fname": "static parseVariableDecls",
            "ret": 338
        },
        {
            "index": 1381,
            "fname": "static parseSwitchCase",
            "ret": 615
        },
        {
            "index": 1382,
            "fname": "static parseSwitchStatement",
            "ret": 613
        },
        {
            "index": 1383,
            "fname": "static parseStatement",
            "ret": 7
        },
        {
            "index": 1384,
            "fname": "static parseBlockBody",
            "params": {
                "terminators": 826
            },
            "ret": 332
        },
        {
            "index": 1385,
            "fname": "static parseBlock",
            "ret": 332
        },
        {
            "index": 1386,
            "fname": "static parseParameter",
            "ret": 116
        },
        {
            "index": 1387,
            "fname": "static parseParameters",
            "ret": 130
        },
        {
            "index": 1388,
            "fname": "static parseFuncName",
            "ret": 3
        },
        {
            "index": 1389,
            "fname": "static parseFuncDecl",
            "ret": 114
        },
        {
            "index": 1390,
            "fname": "static parseProtocolFuncDecl",
            "ret": 112
        },
        {
            "index": 1391,
            "fname": "static parseFuncDef",
            "ret": 227
        },
        {
            "index": 1392,
            "fname": "static parseProtocolDecl",
            "ret": 109
        },
        {
            "index": 1393,
            "fname": "static parseField",
            "ret": 284
        },
        {
            "index": 1394,
            "fname": "static parseStructType",
            "ret": 280
        },
        {
            "index": 1395,
            "fname": "static parseNativeFunc",
            "ret": 237
        },
        {
            "index": 1396,
            "fname": "static parseNative",
            "ret": 1397
        },
        {
            "index": 1397,
            "uname": "",
            "types": [
                237,
                249
            ]
        },
        {
            "index": 1398,
            "fname": "static parseRestrictedFuncDef",
            "ret": 114
        },
        {
            "index": 1399,
            "fname": "static parseEnumMember",
            "ret": 301
        },
        {
            "index": 1400,
            "fname": "static parseEnumType",
            "ret": 298
        },
        {
            "index": 1401,
            "fname": "",
            "params": {
                "token": 9
            },
            "ret": 2
        },
        {
            "index": 1402,
            "fname": "",
            "params": {
                "token": 9
            },
            "ret": 2
        },
        {
            "index": 1403,
            "fname": "",
            "params": {
                "token": 9
            },
            "ret": 2
        },
        {
            "index": 1404,
            "fname": "",
            "params": {
                "token": 9
            },
            "ret": 2
        },
        {
            "index": 1405,
            "fname": "",
            "ret": 251
        },
        {
            "index": 1406,
            "fname": "",
            "ret": 936
        },
        {
            "index": 1407,
            "fname": "",
            "ret": 303
        },
        {
            "index": 1408,
            "fname": "",
            "params": {
                "token": 9,
                "left": 303,
                "right": 303
            },
            "ret": 437
        },
        {
            "index": 1409,
            "fname": ""
        },
        {
            "index": 1410,
            "fname": "",
            "params": {
                "token": 9,
                "left": 303,
                "right": 303
            },
            "ret": 303
        },
        {
            "index": 1411,
            "fname": "",
            "params": {
                "token": 9,
                "left": 303,
                "right": 303
            },
            "ret": 579
        },
        {
            "index": 1412,
            "fname": "",
            "ret": 303
        },
        {
            "index": 1413,
            "fname": "parse",
            "params": {
                "program": 71,
                "origin": 3,
                "originKind": 3,
                "lineNumberOffset": 5,
                "text": 3
            }
        },
        {
            "index": 1414,
            "fname": "",
            "params": {
                "origin": 3,
                "lineNumberOffset": 5,
                "text": 3
            },
            "ret": 71
        },
        {
            "index": 1415,
            "fname": "",
            "ret": 1414
        },
        {
            "index": 1416,
            "fname": "programWithUnnecessaryThingsRemoved",
            "params": {
                "program": 71
            },
            "ret": 71
        },
        {
            "index": 1417,
            "uname": "",
            "types": [
                377,
                485
            ]
        },
        {
            "index": 1418,
            "fname": "",
            "params": {
                "signature": 114
            },
            "ret": 174
        },
        {
            "index": 1419,
            "cname": "RecursionChecker",
            "supers": {
                "Visitor": 221
            },
            "fields": {
                "_visiting": -1026
            },
            "methods": [
                1420,
                1421,
                1422
            ]
        },
        {
            "index": 1420,
            "fname": "constructor",
            "params": {
                "program": 71
            },
            "ret": 1419,
            "hobj": 1
        },
        {
            "index": 1421,
            "fname": "visitFuncDef",
            "params": {
                "node": 227
            }
        },
        {
            "index": 1422,
            "fname": "visitCallExpression",
            "params": {
                "node": 437
            }
        },
        {
            "index": 1423,
            "fname": ""
        },
        {
            "index": 1424,
            "cname": "RecursiveTypeChecker",
            "supers": {
                "Visitor": 221
            },
            "fields": {
                "_visiting": -1026
            },
            "methods": [
                1425,
                1426,
                1427,
                1428,
                1429,
                1430
            ]
        },
        {
            "index": 1425,
            "fname": "constructor",
            "ret": 1424,
            "hobj": 1
        },
        {
            "index": 1426,
            "fname": "visitFuncDef",
            "params": {
                "node": 227
            }
        },
        {
            "index": 1427,
            "fname": "visitNativeFunc",
            "params": {
                "node": 237
            }
        },
        {
            "index": 1428,
            "fname": "visitStructType",
            "params": {
                "node": 280
            }
        },
        {
            "index": 1429,
            "fname": "visitReferenceType",
            "params": {
                "node": 367
            }
        },
        {
            "index": 1430,
            "fname": "visitTypeRef",
            "params": {
                "node": 345
            },
            "hobj": 1
        },
        {
            "index": 1431,
            "fname": ""
        },
        {
            "index": 1432,
            "fname": "createNameResolver",
            "params": {
                "program": 71
            },
            "ret": 1285
        },
        {
            "index": 1433,
            "fname": "resolveNamesInTypes",
            "params": {
                "program": 71,
                "nameResolver": 1285
            }
        },
        {
            "index": 1434,
            "fname": "resolveNamesInProtocols",
            "params": {
                "program": 71,
                "nameResolver": 1285
            }
        },
        {
            "index": 1435,
            "fname": "resolveNamesInFunctions",
            "params": {
                "program": 71,
                "nameResolver": 1285
            }
        },
        {
            "index": 1436,
            "fname": "resolveOverloadImpl",
            "params": {
                "functions": 143,
                "typeArguments": 101,
                "argumentTypes": 136,
                "returnType": 85,
                "allowEntryPoint": 2
            },
            "ret": 0
        },
        {
            "index": 1437,
            "fname": "",
            "params": {
                "result": 1,
                "overload": 0
            },
            "ret": 1
        },
        {
            "index": 1438,
            "fname": "",
            "params": {
                "overload": 0
            },
            "ret": 2
        },
        {
            "index": 1439,
            "fname": "",
            "params": {
                "result": 2,
                "overload": 0
            },
            "ret": 2
        },
        {
            "index": 1440,
            "fname": "",
            "params": {
                "overload": 0
            },
            "ret": 2
        },
        {
            "index": 1441,
            "fname": "",
            "params": {
                "overload": 0
            },
            "ret": 764
        },
        {
            "index": 1442,
            "fname": "resolveProperties",
            "params": {
                "program": 71
            }
        },
        {
            "index": 1443,
            "fname": "resolveTypeDefsInTypes",
            "params": {
                "program": 71
            }
        },
        {
            "index": 1444,
            "cname": "TypeDefResolver",
            "supers": {
                "Visitor": 221
            },
            "fields": {
                "_visiting": -1026
            },
            "methods": [
                1445,
                1446
            ]
        },
        {
            "index": 1445,
            "fname": "constructor",
            "ret": 1444,
            "hobj": 1
        },
        {
            "index": 1446,
            "fname": "visitTypeRef",
            "params": {
                "node": 345
            }
        },
        {
            "index": 1447,
            "fname": "resolveTypeDefsInProtocols",
            "params": {
                "program": 71
            }
        },
        {
            "index": 1448,
            "fname": "resolveTypeDefsInFunctions",
            "params": {
                "program": 71
            }
        },
        {
            "index": 1449,
            "cname": "ReturnChecker",
            "supers": {
                "Visitor": 221
            },
            "fields": {
                "_program": -71,
                "returnStyle": -1451
            },
            "methods": [
                1450,
                1452,
                1453,
                1454,
                1455,
                1456,
                1457,
                1458,
                1459,
                1460,
                1461,
                1462,
                1463,
                1464
            ]
        },
        {
            "index": 1450,
            "fname": "constructor",
            "params": {
                "program": 71
            },
            "ret": 1449,
            "hobj": 1
        },
        {
            "index": 1451,
            "oname": "",
            "fields": {
                "DefinitelyReturns": -3,
                "DefinitelyDoesntReturn": -3,
                "HasntReturnedYet": -3
            }
        },
        {
            "index": 1452,
            "fname": "_mergeReturnStyle",
            "params": {
                "a": 3,
                "b": 3
            },
            "ret": 3
        },
        {
            "index": 1453,
            "fname": "visitFuncDef",
            "params": {
                "node": 227
            }
        },
        {
            "index": 1454,
            "fname": "visitBlock",
            "params": {
                "node": 332
            },
            "ret": 3
        },
        {
            "index": 1455,
            "fname": "visitIfStatement",
            "params": {
                "node": 586
            },
            "ret": 3
        },
        {
            "index": 1456,
            "fname": "_isBoolCastFromLiteralTrue",
            "params": {
                "node": 575
            },
            "ret": 2
        },
        {
            "index": 1457,
            "fname": "visitWhileLoop",
            "params": {
                "node": 593
            },
            "ret": 3
        },
        {
            "index": 1458,
            "fname": "visitDoWhileLoop",
            "params": {
                "node": 599
            },
            "ret": 3
        },
        {
            "index": 1459,
            "fname": "visitForLoop",
            "params": {
                "node": 605
            },
            "ret": 3
        },
        {
            "index": 1460,
            "fname": "visitSwitchStatement",
            "params": {
                "node": 613
            },
            "ret": 3
        },
        {
            "index": 1461,
            "fname": "visitReturn",
            "params": {
                "node": 497
            },
            "ret": 3
        },
        {
            "index": 1462,
            "fname": "visitTrapStatement",
            "params": {
                "node": 510
            },
            "ret": 3
        },
        {
            "index": 1463,
            "fname": "visitBreak",
            "params": {
                "node": 506
            },
            "ret": 3
        },
        {
            "index": 1464,
            "fname": "visitContinue",
            "params": {
                "node": 502
            },
            "ret": 3
        },
        {
            "index": 1465,
            "cname": "ReturnException",
            "fields": {
                "_value": -120
            },
            "methods": [
                1466,
                1467
            ]
        },
        {
            "index": 1466,
            "fname": "constructor",
            "params": {
                "value": 120
            },
            "ret": 1465
        },
        {
            "index": 1467,
            "fname": "get value",
            "ret": 120
        },
        {
            "index": 1468,
            "fname": "intToString",
            "params": {
                "x": 5
            },
            "ret": 3
        },
        {
            "index": 1469,
            "fname": "_generateSwizzle",
            "params": {
                "maxDepth": 5,
                "maxItems": 5,
                "array": 826
            },
            "ret": 3
        },
        {
            "index": 1470,
            "fname": "",
            "params": {
                "typeParameter": 7
            },
            "ret": 174
        },
        {
            "index": 1471,
            "fname": "",
            "params": {
                "parameter": 116
            },
            "ret": 174
        },
        {
            "index": 1472,
            "fname": "",
            "params": {
                "typeParameter": 7
            },
            "ret": 174
        },
        {
            "index": 1473,
            "fname": "",
            "params": {
                "parameter": 116
            },
            "ret": 174
        },
        {
            "index": 1474,
            "fname": "",
            "params": {
                "typeParameter": 261
            },
            "ret": 174
        },
        {
            "index": 1475,
            "fname": "",
            "params": {
                "typeParameter": 7
            },
            "ret": 174
        },
        {
            "index": 1476,
            "fname": "",
            "params": {
                "typeParameter": 7
            },
            "ret": 174
        },
        {
            "index": 1477,
            "cname": "StructLayoutBuilder",
            "supers": {
                "Visitor": 221
            },
            "fields": {
                "_offset": -5
            },
            "methods": [
                1478,
                1479,
                1480,
                1481,
                1482,
                1483,
                1484,
                1485
            ]
        },
        {
            "index": 1478,
            "fname": "constructor",
            "ret": 1477,
            "hobj": 1
        },
        {
            "index": 1479,
            "fname": "visitReferenceType",
            "params": {
                "node": 367
            }
        },
        {
            "index": 1480,
            "fname": "visitStructType",
            "params": {
                "node": 280
            },
            "hobj": 1
        },
        {
            "index": 1481,
            "fname": "get offset",
            "ret": 5
        },
        {
            "index": 1482,
            "fname": "visitField",
            "params": {
                "node": 284
            },
            "hobj": 1
        },
        {
            "index": 1483,
            "fname": "visitNativeFuncInstance",
            "params": {
                "node": 242
            },
            "hobj": 1
        },
        {
            "index": 1484,
            "fname": "visitTypeRef",
            "params": {
                "node": 345
            },
            "hobj": 1
        },
        {
            "index": 1485,
            "fname": "visitCallExpression",
            "params": {
                "node": 437
            }
        },
        {
            "index": 1486,
            "fname": "",
            "params": {
                "actualTypeArguments": 101
            }
        },
        {
            "index": 1487,
            "fname": "StructTypePopulate",
            "params": {
                "buffer": 45,
                "offset": 5
            }
        },
        {
            "index": 1488,
            "fname": "synthesizeEnumFunctions",
            "params": {
                "program": 71
            }
        },
        {
            "index": 1489,
            "fname": "",
            "params": {
                "[left, right]": 781
            },
            "ret": 43
        },
        {
            "index": 1490,
            "fname": "",
            "params": {
                "[value]": 781
            },
            "ret": 43
        },
        {
            "index": 1491,
            "fname": "",
            "params": {
                "[value]": 781
            },
            "ret": 43
        },
        {
            "index": 1492,
            "fname": "",
            "params": {
                "[value]": 781
            },
            "ret": 43
        },
        {
            "index": 1493,
            "fname": "createTypeParameters",
            "params": {
                "type": 85
            },
            "ret": 101
        },
        {
            "index": 1494,
            "fname": "",
            "params": {
                "typeParameter": 7
            },
            "ret": 7
        },
        {
            "index": 1495,
            "fname": "createTypeArguments",
            "params": {
                "typeParameters": 101
            },
            "ret": 175
        },
        {
            "index": 1496,
            "fname": "",
            "params": {
                "typeParameter": 7
            },
            "ret": 174
        },
        {
            "index": 1497,
            "fname": "setupImplementationData",
            "params": {
                "nativeFunc": 237,
                "implementation": 0,
                "type": 85,
                "field": 284
            }
        },
        {
            "index": 1498,
            "aname": "",
            "element": 43,
            "mode": "normal"
        },
        {
            "index": 1499,
            "fname": "",
            "params": {
                "substitution": 697
            },
            "ret": 0
        },
        {
            "index": 1500,
            "fname": "",
            "params": {
                "typeParameter": 7
            },
            "ret": 7
        },
        {
            "index": 1501,
            "oname": "",
            "fields": {
                "type": -85,
                "fieldName": -3,
                "offset": -1,
                "structSize": -1,
                "fieldSize": -1
            }
        },
        {
            "index": 1502,
            "fname": "",
            "params": {
                "implementationData": 0,
                "visitor": 220
            }
        },
        {
            "index": 1503,
            "fname": "",
            "params": {
                "implementationData": 0
            }
        },
        {
            "index": 1504,
            "fname": "",
            "params": {
                "argumentList": 1498,
                "node": 7
            },
            "ret": 43
        },
        {
            "index": 1505,
            "fname": "createFieldType",
            "params": {
                "type": 85,
                "typeParameters": 101,
                "field": 284
            },
            "ret": 85
        },
        {
            "index": 1506,
            "fname": "createTypeRef",
            "params": {
                "type": 85,
                "typeParameters": 101
            },
            "ret": 345
        },
        {
            "index": 1507,
            "fname": "synthesizeStructAccessors",
            "params": {
                "program": 71
            }
        },
        {
            "index": 1508,
            "fname": "",
            "params": {
                "[base]": 1498,
                "offset": 5,
                "structSize": 5,
                "fieldSize": 5
            },
            "ret": 43
        },
        {
            "index": 1509,
            "fname": "",
            "params": {
                "[base, value]": 1498,
                "offset": 5,
                "structSize": 5,
                "fieldSize": 5
            },
            "ret": 43
        },
        {
            "index": 1510,
            "fname": "setupAnder",
            "params": {
                "addressSpace": 3
            }
        },
        {
            "index": 1511,
            "fname": "",
            "params": {
                "[base]": 1498,
                "offset": 5,
                "structSize": 5,
                "fieldSize": 5
            },
            "ret": 43
        },
        {
            "index": 1512,
            "fname": ""
        },
        {
            "index": 1513,
            "fname": "TypeRefPopulate",
            "params": {
                "buffer": 45,
                "offset": 5
            },
            "ret": 0
        },
        {
            "index": 1514,
            "cname": "UnreachableCodeChecker",
            "supers": {
                "Visitor": 221
            },
            "fields": {
                "_returnChecker": -1449
            },
            "methods": [
                1515,
                1516
            ]
        },
        {
            "index": 1515,
            "fname": "constructor",
            "params": {
                "program": 71
            },
            "ret": 1514,
            "hobj": 1
        },
        {
            "index": 1516,
            "fname": "visitBlock",
            "params": {
                "node": 332
            },
            "hobj": 1
        },
        {
            "index": 1517,
            "cname": "WSyntaxError",
            "supers": {
                "Error": 451
            },
            "fields": {
                "originString": 3,
                "syntaxErrorMessage": 3
            },
            "methods": [
                1518
            ]
        },
        {
            "index": 1518,
            "fname": "constructor",
            "params": {
                "originString": 3,
                "message": 3
            },
            "ret": 1517,
            "hobj": 1
        },
        {
            "index": 1519,
            "cname": "WTrapError",
            "supers": {
                "Error": 451
            },
            "fields": {
                "originString": 3,
                "syntaxErrorMessage": 3
            },
            "methods": [
                1520
            ]
        },
        {
            "index": 1520,
            "fname": "constructor",
            "params": {
                "originString": 3,
                "message": 3
            },
            "ret": 1519,
            "hobj": 1
        },
        {
            "index": 1521,
            "cname": "WrapChecker",
            "supers": {
                "Visitor": 221
            },
            "fields": {
                "_startNode": -7
            },
            "methods": [
                1522,
                1523,
                1524,
                1525,
                1526,
                1527,
                1528,
                1529,
                1530,
                1531
            ]
        },
        {
            "index": 1522,
            "fname": "constructor",
            "params": {
                "node": 7
            },
            "ret": 1521,
            "hobj": 1
        },
        {
            "index": 1523,
            "fname": "visitVariableRef",
            "params": {
                "node": 418
            }
        },
        {
            "index": 1524,
            "fname": "visitTypeRef",
            "params": {
                "node": 345
            }
        },
        {
            "index": 1525,
            "fname": "_foundUnwrapped",
            "params": {
                "node": 7
            }
        },
        {
            "index": 1526,
            "fname": "visitConstexprTypeParameter",
            "params": {
                "node": 251
            }
        },
        {
            "index": 1527,
            "fname": "visitFuncParameter",
            "params": {
                "node": 116
            }
        },
        {
            "index": 1528,
            "fname": "visitVariableDecl",
            "params": {
                "node": 326
            }
        },
        {
            "index": 1529,
            "fname": "visitStructType",
            "params": {
                "node": 280
            }
        },
        {
            "index": 1530,
            "fname": "visitNativeType",
            "params": {
                "node": 249
            }
        },
        {
            "index": 1531,
            "fname": "visitTypeVariable",
            "params": {
                "node": 146
            }
        },
        {
            "index": 1532,
            "fname": "originString",
            "params": {
                "node": 7
            },
            "ret": 3
        },
        {
            "index": 1533,
            "fname": "doPrep",
            "params": {
                "code": 3
            },
            "ret": 71
        },
        {
            "index": 1534,
            "fname": "doLex",
            "params": {
                "code": 3
            },
            "ret": 784
        },
        {
            "index": 1535,
            "fname": "makeInt",
            "params": {
                "program": 71,
                "value": 1
            },
            "ret": 845
        },
        {
            "index": 1536,
            "fname": "makeUint",
            "params": {
                "program": 71,
                "value": 1
            },
            "ret": 845
        },
        {
            "index": 1537,
            "fname": "makeUint8",
            "params": {
                "program": 71,
                "value": 1
            },
            "ret": 845
        },
        {
            "index": 1538,
            "fname": "makeBool",
            "params": {
                "program": 71,
                "value": 2
            },
            "ret": 845
        },
        {
            "index": 1539,
            "fname": "makeFloat",
            "params": {
                "program": 71,
                "value": 7
            },
            "ret": 845
        },
        {
            "index": 1540,
            "fname": "makeDouble",
            "params": {
                "program": 71,
                "value": 7
            },
            "ret": 845
        },
        {
            "index": 1541,
            "fname": "makeEnum",
            "params": {
                "program": 71,
                "enumName": 3,
                "value": 3
            },
            "ret": 845
        },
        {
            "index": 1542,
            "fname": "checkNumber",
            "params": {
                "program": 71,
                "result": 845,
                "expected": 1
            }
        },
        {
            "index": 1543,
            "uname": "",
            "types": [
                249,
                528
            ]
        },
        {
            "index": 1544,
            "fname": "checkInt",
            "params": {
                "program": 71,
                "result": 845,
                "expected": 1
            }
        },
        {
            "index": 1545,
            "fname": "checkEnum",
            "params": {
                "program": 71,
                "result": 845,
                "expected": 1
            }
        },
        {
            "index": 1546,
            "fname": "checkUint",
            "params": {
                "program": 71,
                "result": 845,
                "expected": 1
            }
        },
        {
            "index": 1547,
            "fname": "checkUint8",
            "params": {
                "program": 71,
                "result": 845,
                "expected": 1
            }
        },
        {
            "index": 1548,
            "fname": "checkBool",
            "params": {
                "program": 71,
                "result": 845,
                "expected": 2
            }
        },
        {
            "index": 1549,
            "fname": "checkFloat",
            "params": {
                "program": 71,
                "result": 845,
                "expected": 1
            }
        },
        {
            "index": 1550,
            "fname": "checkDouble",
            "params": {
                "program": 71,
                "result": 845,
                "expected": 1
            }
        },
        {
            "index": 1551,
            "fname": "checkLexerToken",
            "params": {
                "result": 9,
                "expectedIndex": 1,
                "expectedKind": 3,
                "expectedText": 3
            }
        },
        {
            "index": 1552,
            "fname": "checkFail",
            "params": {
                "callback": 0,
                "predicate": 0
            }
        },
        {
            "index": 1553,
            "fname": ""
        },
        {
            "index": 1554,
            "fname": ""
        },
        {
            "index": 1555,
            "fname": ""
        },
        {
            "index": 1556,
            "fname": ""
        },
        {
            "index": 1557,
            "fname": ""
        },
        {
            "index": 1558,
            "fname": ""
        },
        {
            "index": 1559,
            "fname": ""
        },
        {
            "index": 1560,
            "fname": ""
        },
        {
            "index": 1561,
            "fname": ""
        },
        {
            "index": 1562,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1563,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1564,
            "fname": ""
        },
        {
            "index": 1565,
            "fname": ""
        },
        {
            "index": 1566,
            "fname": ""
        },
        {
            "index": 1567,
            "fname": ""
        },
        {
            "index": 1568,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1569,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1570,
            "fname": ""
        },
        {
            "index": 1571,
            "fname": ""
        },
        {
            "index": 1572,
            "fname": ""
        },
        {
            "index": 1573,
            "fname": ""
        },
        {
            "index": 1574,
            "fname": ""
        },
        {
            "index": 1575,
            "fname": ""
        },
        {
            "index": 1576,
            "fname": ""
        },
        {
            "index": 1577,
            "fname": ""
        },
        {
            "index": 1578,
            "fname": ""
        },
        {
            "index": 1579,
            "fname": ""
        },
        {
            "index": 1580,
            "fname": ""
        },
        {
            "index": 1581,
            "fname": ""
        },
        {
            "index": 1582,
            "fname": ""
        },
        {
            "index": 1583,
            "fname": ""
        },
        {
            "index": 1584,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1585,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1586,
            "fname": ""
        },
        {
            "index": 1587,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1588,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1589,
            "fname": ""
        },
        {
            "index": 1590,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1591,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1592,
            "fname": ""
        },
        {
            "index": 1593,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1594,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1595,
            "fname": ""
        },
        {
            "index": 1596,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1597,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1598,
            "fname": ""
        },
        {
            "index": 1599,
            "fname": ""
        },
        {
            "index": 1600,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1601,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1602,
            "fname": ""
        },
        {
            "index": 1603,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1604,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1605,
            "fname": ""
        },
        {
            "index": 1606,
            "fname": ""
        },
        {
            "index": 1607,
            "fname": ""
        },
        {
            "index": 1608,
            "fname": ""
        },
        {
            "index": 1609,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1610,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1611,
            "fname": ""
        },
        {
            "index": 1612,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1613,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1614,
            "fname": ""
        },
        {
            "index": 1615,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1616,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1617,
            "fname": ""
        },
        {
            "index": 1618,
            "fname": ""
        },
        {
            "index": 1619,
            "fname": "",
            "ret": 845
        },
        {
            "index": 1620,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1621,
            "fname": ""
        },
        {
            "index": 1622,
            "fname": "",
            "ret": 845
        },
        {
            "index": 1623,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1624,
            "fname": ""
        },
        {
            "index": 1625,
            "fname": "",
            "ret": 845
        },
        {
            "index": 1626,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1627,
            "fname": ""
        },
        {
            "index": 1628,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1629,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1630,
            "fname": ""
        },
        {
            "index": 1631,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1632,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1633,
            "fname": ""
        },
        {
            "index": 1634,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1635,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1636,
            "fname": ""
        },
        {
            "index": 1637,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1638,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1639,
            "fname": ""
        },
        {
            "index": 1640,
            "fname": ""
        },
        {
            "index": 1641,
            "fname": "",
            "ret": 845
        },
        {
            "index": 1642,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1643,
            "fname": ""
        },
        {
            "index": 1644,
            "fname": "",
            "ret": 845
        },
        {
            "index": 1645,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1646,
            "fname": ""
        },
        {
            "index": 1647,
            "fname": "",
            "ret": 845
        },
        {
            "index": 1648,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1649,
            "fname": ""
        },
        {
            "index": 1650,
            "fname": "",
            "ret": 845
        },
        {
            "index": 1651,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1652,
            "fname": ""
        },
        {
            "index": 1653,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1654,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1655,
            "fname": ""
        },
        {
            "index": 1656,
            "fname": ""
        },
        {
            "index": 1657,
            "fname": ""
        },
        {
            "index": 1658,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1659,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1660,
            "fname": ""
        },
        {
            "index": 1661,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1662,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1663,
            "fname": ""
        },
        {
            "index": 1664,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1665,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1666,
            "fname": ""
        },
        {
            "index": 1667,
            "fname": ""
        },
        {
            "index": 1668,
            "fname": ""
        },
        {
            "index": 1669,
            "fname": ""
        },
        {
            "index": 1670,
            "fname": ""
        },
        {
            "index": 1671,
            "fname": ""
        },
        {
            "index": 1672,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1673,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1674,
            "fname": ""
        },
        {
            "index": 1675,
            "fname": ""
        },
        {
            "index": 1676,
            "fname": ""
        },
        {
            "index": 1677,
            "fname": ""
        },
        {
            "index": 1678,
            "fname": ""
        },
        {
            "index": 1679,
            "fname": ""
        },
        {
            "index": 1680,
            "fname": ""
        },
        {
            "index": 1681,
            "fname": ""
        },
        {
            "index": 1682,
            "fname": ""
        },
        {
            "index": 1683,
            "fname": ""
        },
        {
            "index": 1684,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1685,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1686,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1687,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1688,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1689,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1690,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1691,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1692,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1693,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1694,
            "fname": ""
        },
        {
            "index": 1695,
            "fname": ""
        },
        {
            "index": 1696,
            "fname": ""
        },
        {
            "index": 1697,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1698,
            "fname": ""
        },
        {
            "index": 1699,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1700,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1701,
            "fname": ""
        },
        {
            "index": 1702,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1703,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1704,
            "fname": ""
        },
        {
            "index": 1705,
            "fname": ""
        },
        {
            "index": 1706,
            "fname": ""
        },
        {
            "index": 1707,
            "fname": ""
        },
        {
            "index": 1708,
            "fname": ""
        },
        {
            "index": 1709,
            "fname": ""
        },
        {
            "index": 1710,
            "fname": ""
        },
        {
            "index": 1711,
            "fname": ""
        },
        {
            "index": 1712,
            "fname": ""
        },
        {
            "index": 1713,
            "fname": ""
        },
        {
            "index": 1714,
            "fname": ""
        },
        {
            "index": 1715,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1716,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1717,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1718,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1719,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1720,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1721,
            "fname": ""
        },
        {
            "index": 1722,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1723,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1724,
            "fname": ""
        },
        {
            "index": 1725,
            "fname": ""
        },
        {
            "index": 1726,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1727,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1728,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1729,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1730,
            "fname": ""
        },
        {
            "index": 1731,
            "fname": ""
        },
        {
            "index": 1732,
            "fname": ""
        },
        {
            "index": 1733,
            "fname": ""
        },
        {
            "index": 1734,
            "fname": ""
        },
        {
            "index": 1735,
            "fname": ""
        },
        {
            "index": 1736,
            "fname": ""
        },
        {
            "index": 1737,
            "fname": ""
        },
        {
            "index": 1738,
            "fname": ""
        },
        {
            "index": 1739,
            "fname": ""
        },
        {
            "index": 1740,
            "fname": ""
        },
        {
            "index": 1741,
            "fname": ""
        },
        {
            "index": 1742,
            "fname": ""
        },
        {
            "index": 1743,
            "fname": ""
        },
        {
            "index": 1744,
            "fname": ""
        },
        {
            "index": 1745,
            "fname": ""
        },
        {
            "index": 1746,
            "fname": ""
        },
        {
            "index": 1747,
            "fname": ""
        },
        {
            "index": 1748,
            "fname": ""
        },
        {
            "index": 1749,
            "fname": ""
        },
        {
            "index": 1750,
            "fname": ""
        },
        {
            "index": 1751,
            "fname": ""
        },
        {
            "index": 1752,
            "fname": ""
        },
        {
            "index": 1753,
            "fname": ""
        },
        {
            "index": 1754,
            "fname": ""
        },
        {
            "index": 1755,
            "fname": ""
        },
        {
            "index": 1756,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1757,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1758,
            "fname": ""
        },
        {
            "index": 1759,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1760,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1761,
            "fname": ""
        },
        {
            "index": 1762,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1763,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1764,
            "fname": ""
        },
        {
            "index": 1765,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1766,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1767,
            "fname": ""
        },
        {
            "index": 1768,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1769,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1770,
            "fname": ""
        },
        {
            "index": 1771,
            "fname": ""
        },
        {
            "index": 1772,
            "fname": ""
        },
        {
            "index": 1773,
            "fname": ""
        },
        {
            "index": 1774,
            "fname": ""
        },
        {
            "index": 1775,
            "fname": ""
        },
        {
            "index": 1776,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1777,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1778,
            "fname": ""
        },
        {
            "index": 1779,
            "fname": ""
        },
        {
            "index": 1780,
            "fname": ""
        },
        {
            "index": 1781,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1782,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1783,
            "fname": ""
        },
        {
            "index": 1784,
            "fname": ""
        },
        {
            "index": 1785,
            "fname": ""
        },
        {
            "index": 1786,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1787,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1788,
            "fname": ""
        },
        {
            "index": 1789,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1790,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1791,
            "fname": ""
        },
        {
            "index": 1792,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1793,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1794,
            "fname": ""
        },
        {
            "index": 1795,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1796,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1797,
            "fname": ""
        },
        {
            "index": 1798,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1799,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1800,
            "fname": ""
        },
        {
            "index": 1801,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1802,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1803,
            "fname": ""
        },
        {
            "index": 1804,
            "fname": ""
        },
        {
            "index": 1805,
            "fname": ""
        },
        {
            "index": 1806,
            "fname": ""
        },
        {
            "index": 1807,
            "fname": ""
        },
        {
            "index": 1808,
            "fname": ""
        },
        {
            "index": 1809,
            "fname": ""
        },
        {
            "index": 1810,
            "fname": ""
        },
        {
            "index": 1811,
            "fname": ""
        },
        {
            "index": 1812,
            "fname": ""
        },
        {
            "index": 1813,
            "fname": ""
        },
        {
            "index": 1814,
            "fname": ""
        },
        {
            "index": 1815,
            "fname": ""
        },
        {
            "index": 1816,
            "fname": ""
        },
        {
            "index": 1817,
            "fname": ""
        },
        {
            "index": 1818,
            "fname": ""
        },
        {
            "index": 1819,
            "fname": ""
        },
        {
            "index": 1820,
            "fname": ""
        },
        {
            "index": 1821,
            "fname": ""
        },
        {
            "index": 1822,
            "fname": ""
        },
        {
            "index": 1823,
            "fname": ""
        },
        {
            "index": 1824,
            "fname": ""
        },
        {
            "index": 1825,
            "fname": ""
        },
        {
            "index": 1826,
            "fname": ""
        },
        {
            "index": 1827,
            "fname": ""
        },
        {
            "index": 1828,
            "fname": ""
        },
        {
            "index": 1829,
            "fname": ""
        },
        {
            "index": 1830,
            "fname": ""
        },
        {
            "index": 1831,
            "fname": ""
        },
        {
            "index": 1832,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1833,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1834,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1835,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1836,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1837,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1838,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1839,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1840,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1841,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1842,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1843,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1844,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1845,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1846,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1847,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1848,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1849,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1850,
            "fname": ""
        },
        {
            "index": 1851,
            "fname": ""
        },
        {
            "index": 1852,
            "fname": ""
        },
        {
            "index": 1853,
            "fname": ""
        },
        {
            "index": 1854,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1855,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1856,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1857,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1858,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1859,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1860,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1861,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1862,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1863,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1864,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1865,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1866,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1867,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1868,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1869,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1870,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1871,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1872,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1873,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1874,
            "fname": ""
        },
        {
            "index": 1875,
            "fname": ""
        },
        {
            "index": 1876,
            "fname": ""
        },
        {
            "index": 1877,
            "fname": ""
        },
        {
            "index": 1878,
            "fname": ""
        },
        {
            "index": 1879,
            "fname": ""
        },
        {
            "index": 1880,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1881,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1882,
            "fname": ""
        },
        {
            "index": 1883,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1884,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1885,
            "fname": ""
        },
        {
            "index": 1886,
            "fname": ""
        },
        {
            "index": 1887,
            "fname": ""
        },
        {
            "index": 1888,
            "fname": ""
        },
        {
            "index": 1889,
            "fname": "",
            "ret": 845
        },
        {
            "index": 1890,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1891,
            "fname": "",
            "ret": 845
        },
        {
            "index": 1892,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1893,
            "fname": "",
            "ret": 845
        },
        {
            "index": 1894,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1895,
            "fname": ""
        },
        {
            "index": 1896,
            "fname": ""
        },
        {
            "index": 1897,
            "fname": ""
        },
        {
            "index": 1898,
            "fname": ""
        },
        {
            "index": 1899,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1900,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1901,
            "fname": ""
        },
        {
            "index": 1902,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1903,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1904,
            "fname": ""
        },
        {
            "index": 1905,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1906,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1907,
            "fname": ""
        },
        {
            "index": 1908,
            "fname": ""
        },
        {
            "index": 1909,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1910,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1911,
            "fname": ""
        },
        {
            "index": 1912,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1913,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1914,
            "fname": ""
        },
        {
            "index": 1915,
            "fname": ""
        },
        {
            "index": 1916,
            "fname": ""
        },
        {
            "index": 1917,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1918,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1919,
            "fname": ""
        },
        {
            "index": 1920,
            "fname": ""
        },
        {
            "index": 1921,
            "fname": ""
        },
        {
            "index": 1922,
            "fname": ""
        },
        {
            "index": 1923,
            "fname": ""
        },
        {
            "index": 1924,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1925,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1926,
            "fname": ""
        },
        {
            "index": 1927,
            "fname": ""
        },
        {
            "index": 1928,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1929,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1930,
            "fname": ""
        },
        {
            "index": 1931,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1932,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1933,
            "fname": ""
        },
        {
            "index": 1934,
            "fname": ""
        },
        {
            "index": 1935,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1936,
            "fname": ""
        },
        {
            "index": 1937,
            "fname": ""
        },
        {
            "index": 1938,
            "fname": ""
        },
        {
            "index": 1939,
            "fname": ""
        },
        {
            "index": 1940,
            "fname": ""
        },
        {
            "index": 1941,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1942,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1943,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1944,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1945,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1946,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1947,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1948,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1949,
            "fname": ""
        },
        {
            "index": 1950,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1951,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1952,
            "fname": ""
        },
        {
            "index": 1953,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1954,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1955,
            "fname": ""
        },
        {
            "index": 1956,
            "fname": ""
        },
        {
            "index": 1957,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1958,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1959,
            "fname": ""
        },
        {
            "index": 1960,
            "fname": ""
        },
        {
            "index": 1961,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1962,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1963,
            "fname": ""
        },
        {
            "index": 1964,
            "fname": ""
        },
        {
            "index": 1965,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1966,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1967,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1968,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1969,
            "fname": ""
        },
        {
            "index": 1970,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1971,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1972,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1973,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1974,
            "fname": ""
        },
        {
            "index": 1975,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1976,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1977,
            "fname": ""
        },
        {
            "index": 1978,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1979,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1980,
            "fname": ""
        },
        {
            "index": 1981,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1982,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1983,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1984,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1985,
            "fname": ""
        },
        {
            "index": 1986,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1987,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1988,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1989,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1990,
            "fname": ""
        },
        {
            "index": 1991,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1992,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1993,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1994,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1995,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1996,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 1997,
            "fname": ""
        },
        {
            "index": 1998,
            "fname": "",
            "ret": 71
        },
        {
            "index": 1999,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2000,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2001,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2002,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2003,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2004,
            "fname": ""
        },
        {
            "index": 2005,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2006,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2007,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2008,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2009,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2010,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2011,
            "fname": ""
        },
        {
            "index": 2012,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2013,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2014,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2015,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2016,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2017,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2018,
            "fname": ""
        },
        {
            "index": 2019,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2020,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2021,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2022,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2023,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2024,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2025,
            "fname": ""
        },
        {
            "index": 2026,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2027,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2028,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2029,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2030,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2031,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2032,
            "fname": ""
        },
        {
            "index": 2033,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2034,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2035,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2036,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2037,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2038,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2039,
            "fname": ""
        },
        {
            "index": 2040,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2041,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2042,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2043,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2044,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2045,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2046,
            "fname": ""
        },
        {
            "index": 2047,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2048,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2049,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2050,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2051,
            "fname": ""
        },
        {
            "index": 2052,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2053,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2054,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2055,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2056,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2057,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2058,
            "fname": ""
        },
        {
            "index": 2059,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2060,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2061,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2062,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2063,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2064,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2065,
            "fname": ""
        },
        {
            "index": 2066,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2067,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2068,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2069,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2070,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2071,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2072,
            "fname": ""
        },
        {
            "index": 2073,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2074,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2075,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2076,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2077,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2078,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2079,
            "fname": ""
        },
        {
            "index": 2080,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2081,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2082,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2083,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2084,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2085,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2086,
            "fname": ""
        },
        {
            "index": 2087,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2088,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2089,
            "fname": ""
        },
        {
            "index": 2090,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2091,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2092,
            "fname": ""
        },
        {
            "index": 2093,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2094,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2095,
            "fname": ""
        },
        {
            "index": 2096,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2097,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2098,
            "fname": ""
        },
        {
            "index": 2099,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2100,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2101,
            "fname": ""
        },
        {
            "index": 2102,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2103,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2104,
            "fname": ""
        },
        {
            "index": 2105,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2106,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2107,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2108,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2109,
            "fname": ""
        },
        {
            "index": 2110,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2111,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2112,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2113,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2114,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2115,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2116,
            "fname": ""
        },
        {
            "index": 2117,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2118,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2119,
            "fname": ""
        },
        {
            "index": 2120,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2121,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2122,
            "fname": ""
        },
        {
            "index": 2123,
            "fname": ""
        },
        {
            "index": 2124,
            "fname": ""
        },
        {
            "index": 2125,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2126,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2127,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2128,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2129,
            "fname": ""
        },
        {
            "index": 2130,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2131,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2132,
            "fname": ""
        },
        {
            "index": 2133,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2134,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2135,
            "fname": ""
        },
        {
            "index": 2136,
            "fname": ""
        },
        {
            "index": 2137,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2138,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2139,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2140,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2141,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2142,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2143,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2144,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2145,
            "fname": ""
        },
        {
            "index": 2146,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2147,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2148,
            "fname": ""
        },
        {
            "index": 2149,
            "fname": ""
        },
        {
            "index": 2150,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2151,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2152,
            "fname": ""
        },
        {
            "index": 2153,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2154,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2155,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2156,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2157,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2158,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2159,
            "fname": ""
        },
        {
            "index": 2160,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2161,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2162,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2163,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2164,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2165,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2166,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2167,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2168,
            "fname": ""
        },
        {
            "index": 2169,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2170,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2171,
            "fname": ""
        },
        {
            "index": 2172,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2173,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2174,
            "fname": ""
        },
        {
            "index": 2175,
            "fname": ""
        },
        {
            "index": 2176,
            "fname": ""
        },
        {
            "index": 2177,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2178,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2179,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2180,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2181,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2182,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2183,
            "fname": ""
        },
        {
            "index": 2184,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2185,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2186,
            "fname": ""
        },
        {
            "index": 2187,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2188,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2189,
            "fname": ""
        },
        {
            "index": 2190,
            "fname": ""
        },
        {
            "index": 2191,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2192,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2193,
            "fname": ""
        },
        {
            "index": 2194,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2195,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2196,
            "fname": ""
        },
        {
            "index": 2197,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2198,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2199,
            "fname": ""
        },
        {
            "index": 2200,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2201,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2202,
            "fname": ""
        },
        {
            "index": 2203,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2204,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2205,
            "fname": ""
        },
        {
            "index": 2206,
            "fname": ""
        },
        {
            "index": 2207,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2208,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2209,
            "fname": ""
        },
        {
            "index": 2210,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2211,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2212,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2213,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2214,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2215,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2216,
            "fname": ""
        },
        {
            "index": 2217,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2218,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2219,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2220,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2221,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2222,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2223,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2224,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2225,
            "fname": ""
        },
        {
            "index": 2226,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2227,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2228,
            "fname": ""
        },
        {
            "index": 2229,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2230,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2231,
            "fname": ""
        },
        {
            "index": 2232,
            "fname": ""
        },
        {
            "index": 2233,
            "fname": ""
        },
        {
            "index": 2234,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2235,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2236,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2237,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2238,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2239,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2240,
            "fname": ""
        },
        {
            "index": 2241,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2242,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2243,
            "fname": ""
        },
        {
            "index": 2244,
            "fname": "",
            "ret": 71
        },
        {
            "index": 2245,
            "fname": "",
            "params": {
                "e": 451
            },
            "ret": 2
        },
        {
            "index": 2246,
            "fname": ""
        },
        {
            "index": 2247,
            "fname": ""
        },
        {
            "index": 2248,
            "fname": "doTest"
        },
        {
            "index": 2249,
            "cname": "Benchmark",
            "methods": [
                2250,
                2251,
                2252
            ]
        },
        {
            "index": 2250,
            "fname": "constructor",
            "ret": 2249
        },
        {
            "index": 2251,
            "fname": "buildStdlib"
        },
        {
            "index": 2252,
            "fname": "run"
        },
        {
            "index": 2253,
            "fname": "static now",
            "ret": 1
        },
        {
            "index": 2254,
            "fname": "toScore",
            "params": {
                "timeValue": 1
            },
            "ret": 1
        },
        {
            "index": 2255,
            "fname": "assert",
            "params": {
                "condition": 2
            }
        },
        {
            "index": 2256,
            "fname": "processResults",
            "params": {
                "results": 2257
            }
        },
        {
            "index": 2257,
            "aname": "",
            "element": 1,
            "mode": "normal"
        },
        {
            "index": 2258,
            "fname": "printScore"
        },
        {
            "index": 2259,
            "fname": "main"
        }
    ]
}*/
"use strict";
const DefaultImplementationData = /*<@774>*/{ type: undefined, fieldName: "", offset: -1, structSize: -1, fieldSize: -1 };
class /*<@8>*/Node {
    get /*<@211>*/name() { return this._name; }
    set /*<@212>*/name(/*<@3>*/name) { this._name = name; }
    /*<@213>*/verifyAsArgument(/*<@153>*/unificationContext) {
        throw new Error("no verifyAsArgument");
    }
    get /*<@214>*/type() { return this._type; }
    set /*<@215>*/type(/*<@85>*/val) { this._type = val; }
    get /*<@216>*/addressSpace() {
        return this._addressSpace;
    }
    set /*<@217>*/addressSpace(/*<@3>*/val) { this._addressSpace = val; }
    /*<@218>*/verifyAsParameter(/*<@153>*/unificationContext) {
        throw new Error("no verifyAsparameter!");
    }
    /*<@219>*/visit(/*<@735>*/visitor) {
        let visitFunc;
        if (this.hasBecome) {
            visitFunc = visitor["visitIdentityExpression"];
        }
        else {
            let /*<@3>*/name = this.constructor.name;
            if (name == "IntLiteral" || name == "UintLiteral" || name == "FloatLiteral" || name == "DoubleLiteral") {
                name = "GenericLiteral";
            }
            else if (name == "IntLiteralType" || name == "UintLiteralType" || name == "FloatLiteralType" || name == "DoubleLiteralType") {
                name = "GenericLiteralType";
            }
            visitFunc = visitor["visit" + name];
        }
        if (!visitFunc)
            throw new Error("No visit function for " + this.constructor.name + " in " + visitor.constructor.name);
        let /*<@7>*/returnValue = visitFunc.call(visitor, this);
        if ("returnValue" in visitor)
            returnValue = visitor./*<@7>*/returnValue;
        return returnValue;
    }
    static /*<@736>*/visit(/*<@737>*/node, /*<@738>*/visitor) {
        if (node instanceof Node)
            return node.visit(visitor);
        return node;
    }
    /*<@739>*/unify(/*<@153>*/unificationContext, /*<@7>*/other) {
        if (!other)
            throw new Error("Null other");
        let /*<@7>*/unifyThis = this.unifyNode;
        let /*<@7>*/unifyOther = other.unifyNode;
        if (unifyThis == unifyOther)
            return true;
        if (unifyOther.typeVariableUnify(unificationContext, unifyThis))
            return true;
        return unifyThis.unifyImpl(unificationContext, unifyOther);
    }
    /*<@740>*/unifyImpl(/*<@153>*/unificationContext, /*<@7>*/other) {
        if (other.typeVariableUnify(unificationContext, this))
            return true;
        return this == other;
    }
    /*<@741>*/typeVariableUnify(/*<@153>*/unificationContext, /*<@7>*/other) {
        return false;
    }
    /*<@742>*/_typeVariableUnifyImpl(/*<@153>*/unificationContext, /*<@7>*/other) {
        let /*<@7>*/realThis = unificationContext.find(this);
        if (realThis != this)
            return realThis.unify(unificationContext, other);
        unificationContext.union(this, other);
        return true;
    }
    // Most type variables don't care about this.
    /*<@743>*/prepareToVerify(/*<@153>*/unificationContext) { return undefined; }
    /*<@744>*/commitUnification(/*<@153>*/unificationContext) { }
    get /*<@745>*/target() {
        return this._target;
    }
    get /*<@746>*/unifyNode() {
        if (this.hasBecome)
            return this.target.unifyNode;
        return this;
    }
    get /*<@747>*/isConstexpr() { return false; }
    get /*<@748>*/isLValue() { return false; }
    get /*<@749>*/isUnifiable() { return false; }
    get /*<@750>*/isLiteral() { return this._isLiteral == true; }
    get /*<@751>*/isNative() { return false; }
    get /*<@752>*/origin() { return this._origin; }
    get /*<@753>*/isPtr() { return this._isPtr === true; }
    get /*<@754>*/kind() { return Node; }
    /*<@755>*/conversionCost(/*<@153>*/unificationContext) { return 0; }
    /*<@756>*/equals(/*<@7>*/other) {
        let /*<@153>*/unificationContext = new UnificationContext();
        if (this.unify(unificationContext, other) && unificationContext.verify().result)
            return unificationContext;
        return false;
    }
    /*<@758>*/equalsWithCommit(/*<@7>*/other) {
        let /*<@757>*/unificationContext = this.equals(other);
        if (!unificationContext)
            return false;
        unificationContext.commit();
        return unificationContext;
    }
    /*<@759>*/commit() {
        let /*<@153>*/unificationContext = new UnificationContext();
        unificationContext.addExtraNode(this);
        let result = unificationContext.verify();
        if (!result.result)
            throw new Error("Could not infer type: " + result.reason);
        // throw new WError(node.origin.originString, "Could not infer type: " + result.reason);
        unificationContext.commit();
        return unificationContext.find(this);
    }
    /*<@760>*/substitute(/*<@101>*/parameters, /*<@101>*/argumentList) {
        return this.visit(new Substitution(parameters, argumentList));
    }
    /*<@761>*/substituteToUnification(/*<@101>*/parameters, /*<@153>*/unificationContext) {
        return this.substitute(parameters, parameters.map(/*<@782>*/(/*<@7>*/type) => unificationContext.find(type)));
    }
}
class /*<@86>*/Type extends Node {
    get /*<@87>*/elementType() { return this._elementType; }
    get /*<@88>*/isPrimitive() { return this._isPrimitive; }
    set /*<@89>*/isPrimitive(/*<@2>*/value) { this._isPrimitive = value; }
    get /*<@90>*/isInt() { return this._isInt; }
    set /*<@91>*/isInt(/*<@2>*/val) { this._isInt = val; }
    get /*<@92>*/isNumber() { return this._isNumber; }
    set /*<@93>*/isNumber(/*<@2>*/val) { this._isNumber = val; }
    get /*<@94>*/isSigned() { return this._isSigned; }
    set /*<@95>*/isSigned(/*<@2>*/val) { this._isSigned = val; }
    get /*<@96>*/isFloating() { return this._isFloating; }
    set /*<@97>*/isFloating(/*<@2>*/val) { this._isFloating = val; }
    get /*<@98>*/size() { return this._size; }
    set /*<@99>*/size(/*<@5>*/val) { this._size = val; }
    get /*<@100>*/typeParameters() { return /*<@784>*/[]; }
    get /*<@102>*/kind() { return Type; }
    get /*<@103>*/isArray() { return false; }
    get /*<@104>*/isArrayRef() { return this._isArrayRef === true; }
    get /*<@105>*/isRef() { return this.isPtr || this.isArrayRef; }
    /*<@106>*/inherits(/*<@107>*/protocol) {
        if (!protocol)
            return /*<@785>*/{ result: true, reason: undefined };
        return protocol.hasHeir(this);
    }
    get /*<@186>*/instantiatedType() { return this.visit(new InstantiateImmediates()); }
    // Have to call these on the unifyNode.
    /*<@187>*/argumentForAndOverload(/*<@42>*/origin, /*<@188>*/value) {
        return new MakePtrExpression(origin, /*<@7>*/value);
    }
    /*<@189>*/argumentTypeForAndOverload(/*<@42>*/origin, /*<@85>*/type) {
        return new PtrType(origin, "thread", this);
    }
    /*<@190>*/returnTypeFromAndOverload(/*<@42>*/origin) {
        throw new WTypeError(origin.originString, "By-pointer overload returned non-pointer type: " + this);
    }
}
function /*<@786>*/ReferencePopulate(/*<@45>*/buffer, /*<@1>*/offset) {
    buffer.set(offset, null);
}
class /*<@368>*/ReferenceType extends Type {
    constructor(/*<@42>*/origin, /*<@3>*/addressSpace, /*<@85>*/elementType) {
        if (!elementType)
            throw new Error("Null elementType");
        if (!origin)
            throw new Error("Null origin");
        super();
        validateAddressSpace(addressSpace);
        this._origin = origin;
        this._addressSpace = addressSpace;
        this._elementType = elementType;
        this.populateDefaultValue = ReferencePopulate;
    }
    get /*<@369>*/elementType() { return this._elementType; }
    get /*<@370>*/addressSpace() {
        if (this.hasBecome)
            return this.target.addressSpace;
        return this._addressSpace;
    }
    get /*<@371>*/size() { return 1; }
}
class /*<@121>*/Value extends Node {
    get /*<@123>*/kind() { return Value; }
    get /*<@124>*/isConstexpr() {
        if (this.hasBecome)
            return this.target.isConstexpr;
        return false;
    }
    get /*<@125>*/isLValue() {
        if (this.hasBecome)
            return this.target.isLValue;
        return false;
    }
    get /*<@126>*/notLValueReason() { return null; }
    get /*<@127>*/varIsLValue() { return false; }
    get /*<@128>*/notLValueReasonString() {
        let /*<@3>*/result = this.notLValueReason;
        if (result)
            return "\n" + result;
        return "";
    }
    /*<@129>*/become(/*<@120>*/otherValue) {
        // NOTE: Make sure that IdentityExpression implements unifyNode and all that
        let /*<@42>*/origin = this.origin;
        // this.__proto__ = IdentityExpression.prototype;
        this._origin = origin;
        this._target = otherValue;
        this.hasBecome = true;
    }
}
class /*<@304>*/Expression extends Value {
    constructor(/*<@42>*/origin) {
        super();
        this._origin = origin;
    }
}
class /*<@232>*/Rewriter {
    constructor() {
        this._mapping = new Map();
    }
    /*<@233>*/_mapNode(/*<@7>*/oldItem, /*<@7>*/newItem) {
        this._mapping.set(oldItem, newItem);
        return newItem;
    }
    /*<@234>*/_getMapping(/*<@7>*/oldItem) {
        let /*<@7>*/result = this._mapping.get(oldItem);
        if (result)
            return result;
        return oldItem;
    }
    // We return identity for anything that is not inside a function/struct body. When processing
    // function bodies, we only recurse into them and never out of them - for example if there is a
    // function call to another function then we don't rewrite the other function. This is how we stop
    // that.
    /*<@235>*/visitFuncDef(/*<@227>*/node) { return node; }
    /*<@236>*/visitNativeFunc(/*<@237>*/node) { return node; }
    /*<@241>*/visitNativeFuncInstance(/*<@242>*/node) { return node; }
    /*<@248>*/visitNativeType(/*<@249>*/node) { return node; }
    /*<@274>*/visitTypeDef(/*<@275>*/node) { return node; }
    /*<@279>*/visitStructType(/*<@280>*/node) { return node; }
    /*<@295>*/visitConstexprTypeParameter(/*<@251>*/node) { return node; }
    /*<@296>*/visitProtocolDecl(/*<@109>*/node) { return node; }
    /*<@297>*/visitEnumType(/*<@298>*/node) { return node; }
    // This is almost wrong. We instantiate Func in Substitution in ProtocolDecl. Then, we end up
    // not rewriting type variables. I think that just works because not rewriting them there is OK.
    // Everywhere else, it's mandatory that we don't rewrite these because we always assume that
    // type variables are outside the scope of rewriting.
    /*<@314>*/visitTypeVariable(/*<@146>*/node) { return node; }
    /*<@315>*/visitProtocolFuncDecl(/*<@112>*/node) {
        let /*<@112>*/result = new ProtocolFuncDecl(node.origin, node.name, node.returnType.visit(this), node.typeParameters.map(/*<@787>*/(/*<@7>*/parameter) => parameter.visit(this)), node.parameters.map(/*<@788>*/(/*<@7>*/parameter) => parameter.visit(this)), node.isCast, node.shaderType);
        result.protocolDecl = node.protocolDecl;
        result.possibleOverloads = node.possibleOverloads;
        return result;
    }
    /*<@316>*/visitNativeTypeInstance(/*<@317>*/node) {
        return new NativeTypeInstance(node.type.visit(this), node.typeArguments.map(/*<@789>*/(/*<@7>*/argument) => argument.visit(this)));
    }
    /*<@324>*/visitFuncParameter(/*<@116>*/node) {
        let /*<@116>*/result = new FuncParameter(node.origin, node.name, node.type.visit(this));
        this._mapNode(node, result);
        result.ePtr = node.ePtr;
        return result;
    }
    /*<@325>*/visitVariableDecl(/*<@326>*/node) {
        let /*<@326>*/result = new VariableDecl(node.origin, node.name, node.type.visit(this), Node.visit(node.initializer, this));
        this._mapNode(node, result);
        result.ePtr = node.ePtr;
        return result;
    }
    /*<@331>*/visitBlock(/*<@332>*/node) {
        let /*<@332>*/result = new Block(node.__origin);
        for (let /*<@7>*/statement of node.statements)
            result.add(statement.visit(this));
        return result;
    }
    /*<@337>*/visitCommaExpression(/*<@338>*/node) {
        return new CommaExpression(node.origin, node.list.map(/*<@790>*/(/*<@7>*/expression) => {
            let /*<@174>*/result = expression.visit(this);
            if (!result)
                throw new Error("Null result from " + expression);
            return result;
        }));
    }
    /*<@343>*/visitProtocolRef(/*<@107>*/node) {
        return node;
    }
    /*<@344>*/visitTypeRef(/*<@345>*/node) {
        let /*<@345>*/result = new TypeRef(node.origin, node.name, node.typeArguments.map(/*<@791>*/(/*<@7>*/typeArgument) => typeArgument.visit(this)));
        result.type = Node.visit(node.type, this);
        return result;
    }
    /*<@356>*/visitField(/*<@284>*/node) {
        return new Field(node.origin, node.name, node.type.visit(this));
    }
    /*<@357>*/visitEnumMember(/*<@301>*/node) {
        return new EnumMember(node.origin, node.name, (node.value.visit(this)));
    }
    /*<@358>*/visitEnumLiteral(/*<@359>*/node) {
        let /*<@359>*/result = new EnumLiteral(node.origin, node.member);
        result.ePtr = node.ePtr;
        return result;
    }
    /*<@366>*/visitReferenceType(/*<@367>*/node) {
        if (node instanceof PtrType) {
            return new PtrType(node.origin, node.addressSpace, node.elementType.visit(this));
        }
        else if (node instanceof ArrayRefType) {
            return new ArrayRefType(node.origin, node.addressSpace, node.elementType.visit(this));
        }
        else if (node instanceof ReferenceType) {
            return new ReferenceType(node.origin, node.addressSpace, node.elementType.visit(this));
        }
        else {
            throw new Error("unknow reference type");
        }
    }
    /*<@372>*/visitPtrType(/*<@373>*/node) {
        return this.visitReferenceType(node);
    }
    /*<@384>*/visitArrayRefType(/*<@385>*/node) {
        return this.visitReferenceType(node);
    }
    /*<@391>*/visitArrayType(/*<@392>*/node) {
        return new ArrayType(node.origin, node.elementType.visit(this), node.numElements.visit(this));
    }
    /*<@404>*/visitAssignment(/*<@405>*/node) {
        let /*<@405>*/result = new Assignment(node.origin, node.lhs.visit(this), node.rhs.visit(this));
        result.type = Node.visit(node.type, this);
        return result;
    }
    /*<@410>*/visitReadModifyWriteExpression(/*<@411>*/node) {
        let /*<@411>*/result = new ReadModifyWriteExpression(node.origin, node.lValue.visit(this));
        result.oldValueVar = node.oldValueVar.visit(this);
        result.newValueVar = node.newValueVar.visit(this);
        result.newValueExp = node.newValueExp.visit(this);
        result.resultExp = node.resultExp.visit(this);
        return result;
    }
    /*<@428>*/visitDereferenceExpression(/*<@429>*/node) {
        let /*<@429>*/result = new DereferenceExpression(node.origin, node.ptr.visit(this));
        result.type = Node.visit(node.type, this);
        result.addressSpace = node./*<@3>*/addressSpace;
        return result;
    }
    /*<@434>*/_handlePropertyAccessExpression(/*<@435>*/result, /*<@435>*/node) {
        result.possibleGetOverloads = node.possibleGetOverloads;
        result.possibleSetOverloads = node.possibleSetOverloads;
        result.possibleAndOverloads = node.possibleAndOverloads;
        result.baseType = Node.visit(node.baseType, this);
        result.callForGet = Node.visit(node.callForGet, this);
        result.resultTypeForGet = Node.visit(node.resultTypeForGet, this);
        result.callForAnd = Node.visit(node.callForAnd, this);
        result.resultTypeForAnd = Node.visit(node.resultTypeForAnd, this);
        result.callForSet = Node.visit(node.callForSet, this);
        result.errorForSet = node.errorForSet;
        result.updateCalls();
    }
    /*<@465>*/visitDotExpression(/*<@466>*/node) {
        let /*<@466>*/result = new DotExpression(node.origin, node.struct.visit(this), node.fieldName);
        this._handlePropertyAccessExpression(result, node);
        return result;
    }
    /*<@474>*/visitIndexExpression(/*<@475>*/node) {
        let /*<@475>*/result = new IndexExpression(node.origin, node.array.visit(this), node.index.visit(this));
        this._handlePropertyAccessExpression(result, node);
        return result;
    }
    /*<@484>*/visitMakePtrExpression(/*<@485>*/node) {
        let /*<@485>*/result = new MakePtrExpression(node.origin, node.lValue.visit(this));
        result.ePtr = node.ePtr;
        return result;
    }
    /*<@489>*/visitMakeArrayRefExpression(/*<@377>*/node) {
        let /*<@377>*/result = new MakeArrayRefExpression(node.origin, node.lValue.visit(this));
        if (node.numElements)
            result.numElements = node.numElements.visit(this);
        result.ePtr = node.ePtr;
        return result;
    }
    /*<@490>*/visitConvertPtrToArrayRefExpression(/*<@491>*/node) {
        let /*<@491>*/result = new ConvertPtrToArrayRefExpression(node.origin, node.lValue.visit(this));
        result.ePtr = node.ePtr;
        return result;
    }
    /*<@495>*/visitVariableRef(/*<@418>*/node) {
        let /*<@418>*/result = new VariableRef(node.origin, node.name);
        result.variable = this._getMapping(node.variable);
        return result;
    }
    /*<@496>*/visitReturn(/*<@497>*/node) {
        return new Return(node.origin, Node.visit(node.value, this));
    }
    /*<@501>*/visitContinue(/*<@502>*/node) {
        return new Continue(node.origin);
    }
    /*<@505>*/visitBreak(/*<@506>*/node) {
        return new Break(node.origin);
    }
    /*<@509>*/visitTrapStatement(/*<@510>*/node) {
        return new TrapStatement(node.origin);
    }
    /*<@513>*/visitGenericLiteral(/*<@514>*/node) {
        // FIXME: This doesn't seem right.
        let /*<@523>*/result = new IntLiteral(node.origin, node.value);
        result.type = node.type.visit(this);
        result.ePtr = node.ePtr;
        return result;
    }
    /*<@527>*/visitGenericLiteralType(/*<@528>*/node) {
        let /*<@528>*/result;
        if (node instanceof DoubleLiteralType) {
            result = new DoubleLiteralType(node.origin, node.value);
        }
        else if (node instanceof FloatLiteralType) {
            result = new FloatLiteralType(node.origin, node.value);
        }
        else if (node instanceof IntLiteralType) {
            result = new IntLiteralType(node.origin, node.value);
        }
        else if (node instanceof UintLiteralType) {
            result = new UintLiteralType(node.origin, node.value);
        }
        else {
            throw new Error("unknow genericLiteralType: " + node.constructor.name);
        }
        result.type = Node.visit(node.type, this);
        result.preferredType = node.preferredType.visit(this);
        return result;
    }
    /*<@541>*/visitBoolLiteral(/*<@542>*/node) {
        return node;
    }
    /*<@547>*/visitNullLiteral(/*<@548>*/node) {
        let /*<@548>*/result = new NullLiteral(node.origin);
        result.type = node.type.visit(this);
        result.ePtr = node.ePtr;
        return result;
    }
    /*<@551>*/visitNullType(/*<@552>*/node) {
        let /*<@552>*/result = new NullType(node.origin);
        result.type = Node.visit(node.type, this);
        return result;
    }
    /*<@562>*/processDerivedCallData(/*<@437>*/node, /*<@437>*/result) {
        let /*<@792>*/handleTypeArguments = /*<@792>*/(/*<@136>*/actualTypeArguments) => {
            if (actualTypeArguments)
                return actualTypeArguments.map(/*<@793>*/(/*<@7>*/actualTypeArgument) => actualTypeArgument.visit(this));
            else
                return null;
        };
        result.actualTypeArguments = handleTypeArguments(node.actualTypeArguments);
        result.instantiatedActualTypeArguments = handleTypeArguments(node.instantiatedActualTypeArguments);
        let /*<@136>*/argumentTypes = node.argumentTypes;
        if (argumentTypes)
            result.argumentTypes = argumentTypes.map(/*<@794>*/argumentType => argumentType.visit(this));
        result.func = node.func;
        result.nativeFuncInstance = node.nativeFuncInstance;
        result.possibleOverloads = node.possibleOverloads;
        if (node.isCast)
            result.setCastData(node.returnType.visit(this));
        result.resultType = Node.visit(node.resultType, this);
        result.resultEPtr = node.resultEPtr;
        return result;
    }
    /*<@563>*/visitCallExpression(/*<@437>*/node) {
        let /*<@437>*/result = new CallExpression(node.origin, node.name, node.typeArguments.map(/*<@795>*/typeArgument => typeArgument.visit(this)), node.argumentList.map(/*<@796>*/argument => Node.visit(argument, this)));
        return this.processDerivedCallData(node, result);
    }
    /*<@564>*/visitFunctionLikeBlock(/*<@565>*/node) {
        let /*<@565>*/result = new FunctionLikeBlock(node.origin, Node.visit(node.returnType, this), node.argumentList.map(/*<@797>*/(/*<@7>*/argument) => argument.visit(this)), node.parameters.map(/*<@798>*/(/*<@7>*/parameter) => parameter.visit(this)), node.body.visit(this));
        result.returnEPtr = node.returnEPtr;
        return result;
    }
    /*<@572>*/visitLogicalNot(/*<@573>*/node) {
        let /*<@573>*/result = new LogicalNot(node.origin, node.operand.visit(this));
        result.ePtr = node.ePtr;
        return result;
    }
    /*<@578>*/visitLogicalExpression(/*<@579>*/node) {
        let /*<@579>*/result = new LogicalExpression(node.origin, node.text, node.left.visit(this), node.right.visit(this));
        result.ePtr = node.ePtr;
        return result;
    }
    /*<@585>*/visitIfStatement(/*<@586>*/node) {
        return new IfStatement(node.origin, node.conditional.visit(this), node.body.visit(this), Node.visit(node.elseBody, this));
    }
    /*<@592>*/visitWhileLoop(/*<@593>*/node) {
        return new WhileLoop(node.origin, node.conditional.visit(this), node.body.visit(this));
    }
    /*<@598>*/visitDoWhileLoop(/*<@599>*/node) {
        return new DoWhileLoop(node.origin, node.body.visit(this), node.conditional.visit(this));
    }
    /*<@604>*/visitForLoop(/*<@605>*/node) {
        return new ForLoop(node.origin, Node.visit(node.initialization, this), Node.visit(node.condition, this), Node.visit(node.increment, this), node.body.visit(this));
    }
    /*<@612>*/visitSwitchStatement(/*<@613>*/node) {
        let /*<@613>*/result = new SwitchStatement(node.origin, Node.visit(node.value, this));
        for (let /*<@615>*/switchCase of node.switchCases)
            result.add(switchCase.visit(this));
        result.type = Node.visit(node.type, this);
        return result;
    }
    /*<@626>*/visitSwitchCase(/*<@615>*/node) {
        return new SwitchCase(node.origin, Node.visit(node.value, this), node.body.visit(this));
    }
    /*<@627>*/visitAnonymousVariable(/*<@413>*/node) {
        let /*<@413>*/result = new AnonymousVariable(node.origin, node.type.visit(this));
        result.index = node.index; // XTS ._index = ._index
        this._mapNode(node, result);
        result.ePtr = node.ePtr;
        return result;
    }
    /*<@628>*/visitIdentityExpression(/*<@7>*/node) {
        return new IdentityExpression(node.target.visit(this));
    }
}
/*
 * Copyright (C) 2017 Apple Inc. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY APPLE INC. ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE INC. OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
"use strict";
class /*<@221>*/Visitor {
    /*<@222>*/visitProgram(/*<@71>*/node) {
        for (let /*<@7>*/statement of node.topLevelStatements)
            statement.visit(this);
    }
    /*<@223>*/visitFunc(/*<@114>*/node) {
        node.returnType.visit(this);
        for (let /*<@7>*/typeParameter of node.typeParameters)
            typeParameter.visit(this);
        for (let /*<@116>*/parameter of node.parameters)
            parameter.visit(this);
    }
    /*<@224>*/visitProtocolFuncDecl(/*<@112>*/node) {
        this.visitFunc(node);
    }
    /*<@225>*/visitFuncParameter(/*<@116>*/node) {
        node.type.visit(this);
    }
    /*<@226>*/visitFuncDef(/*<@227>*/node) {
        this.visitFunc(node);
        node.body.visit(this);
    }
    /*<@637>*/visitNativeFunc(/*<@237>*/node) {
        this.visitFunc(node);
    }
    /*<@638>*/visitNativeFuncInstance(/*<@242>*/node) {
        this.visitFunc(node);
        node.func.visitImplementationData(node.implementationData, this);
    }
    /*<@639>*/visitBlock(/*<@332>*/node) {
        for (let /*<@7>*/statement of node.statements)
            statement.visit(this);
    }
    /*<@640>*/visitCommaExpression(/*<@338>*/node) {
        for (let /*<@303>*/expression of node.list)
            /*<@7>*/expression.visit(this);
    }
    /*<@641>*/visitProtocolRef(/*<@107>*/node) {
    }
    /*<@642>*/visitProtocolDecl(/*<@109>*/node) {
        for (let /*<@107>*/protocol of node.extends)
            protocol.visit(this);
        for (let /*<@112>*/signature of node.signatures)
            signature.visit(this);
    }
    /*<@643>*/visitTypeRef(/*<@345>*/node) {
        for (let /*<@7>*/typeArgument of node.typeArguments)
            typeArgument.visit(this);
    }
    /*<@644>*/visitNativeType(/*<@249>*/node) {
        for (let /*<@261>*/typeParameter of node.typeParameters)
            typeParameter.visit(this);
    }
    /*<@645>*/visitNativeTypeInstance(/*<@317>*/node) {
        node.type.visit(this);
        for (let /*<@85>*/typeArgument of node.typeArguments)
            typeArgument.visit(this);
    }
    /*<@646>*/visitTypeDef(/*<@275>*/node) {
        for (let /*<@7>*/typeParameter of node.typeParameters)
            typeParameter.visit(this);
        node.type.visit(this);
    }
    /*<@647>*/visitStructType(/*<@280>*/node) {
        for (let /*<@7>*/typeParameter of node.typeParameters)
            typeParameter.visit(this);
        for (let /*<@284>*/field of node.fields)
            field.visit(this);
        return undefined;
    }
    /*<@648>*/visitTypeVariable(/*<@146>*/node) {
        Node.visit(node.protocol, this);
    }
    /*<@649>*/visitConstexprTypeParameter(/*<@251>*/node) {
        node.type.visit(this);
    }
    /*<@650>*/visitField(/*<@284>*/node) {
        node.type.visit(this);
    }
    /*<@651>*/visitEnumType(/*<@298>*/node) {
        node.baseType.visit(this);
        for (let /*<@301>*/member of node.members)
            member.visit(this);
    }
    /*<@652>*/visitEnumMember(/*<@301>*/node) {
        Node.visit(node./*<@7>*/value, this);
    }
    /*<@653>*/visitEnumLiteral(/*<@359>*/node) {
    }
    /*<@654>*/visitElementalType(/*<@655>*/node) {
        node.elementType.visit(this);
    }
    /*<@656>*/visitReferenceType(/*<@367>*/node) {
        this.visitElementalType(node);
    }
    /*<@657>*/visitPtrType(/*<@373>*/node) {
        this.visitReferenceType(node);
    }
    /*<@658>*/visitArrayRefType(/*<@385>*/node) {
        this.visitReferenceType(node);
    }
    /*<@659>*/visitArrayType(/*<@392>*/node) {
        this.visitElementalType(node);
        node.numElements.visit(this);
    }
    /*<@660>*/visitVariableDecl(/*<@326>*/node) {
        node.type.visit(this);
        Node.visit(node.initializer, this);
    }
    /*<@661>*/visitAssignment(/*<@405>*/node) {
        node.lhs.visit(this);
        node.rhs.visit(this);
        Node.visit(node.type, this);
    }
    /*<@662>*/visitReadModifyWriteExpression(/*<@411>*/node) {
        node.lValue.visit(this);
        node.oldValueVar.visit(this);
        node.newValueVar.visit(this);
        node.newValueExp.visit(this);
        node.resultExp.visit(this);
    }
    /*<@663>*/visitDereferenceExpression(/*<@429>*/node) {
        node.ptr.visit(this);
    }
    /*<@664>*/_handlePropertyAccessExpression(/*<@435>*/node) {
        Node.visit(node.baseType, this);
        Node.visit(node.callForGet, this);
        Node.visit(node.resultTypeForGet, this);
        Node.visit(node.callForAnd, this);
        Node.visit(node.resultTypeForAnd, this);
        Node.visit(node.callForSet, this);
    }
    /*<@665>*/visitDotExpression(/*<@466>*/node) {
        node.struct.visit(this);
        this._handlePropertyAccessExpression(node);
    }
    /*<@666>*/visitIndexExpression(/*<@475>*/node) {
        node.array.visit(this);
        node.index.visit(this);
        this._handlePropertyAccessExpression(node);
    }
    /*<@667>*/visitMakePtrExpression(/*<@485>*/node) {
        node.lValue.visit(this);
    }
    /*<@668>*/visitMakeArrayRefExpression(/*<@377>*/node) {
        node.lValue.visit(this);
        Node.visit(node.numElements, this);
    }
    /*<@669>*/visitConvertPtrToArrayRefExpression(/*<@491>*/node) {
        node.lValue.visit(this);
    }
    /*<@670>*/visitVariableRef(/*<@418>*/node) {
    }
    /*<@671>*/visitIfStatement(/*<@586>*/node) {
        node.conditional.visit(this);
        node.body.visit(this);
        Node.visit(node.elseBody, this);
    }
    /*<@672>*/visitWhileLoop(/*<@593>*/node) {
        node.conditional.visit(this);
        node.body.visit(this);
    }
    /*<@673>*/visitDoWhileLoop(/*<@599>*/node) {
        node.body.visit(this);
        node.conditional.visit(this);
    }
    /*<@674>*/visitForLoop(/*<@605>*/node) {
        Node.visit(node.initialization, this);
        Node.visit(node.condition, this);
        Node.visit(node.increment, this);
        node.body.visit(this);
    }
    /*<@675>*/visitSwitchStatement(/*<@613>*/node) {
        node.value.visit(this);
        for (let /*<@615>*/switchCase of node.switchCases)
            switchCase.visit(this);
    }
    /*<@676>*/visitSwitchCase(/*<@615>*/node) {
        Node.visit(node.value, this);
        node.body.visit(this);
    }
    /*<@677>*/visitReturn(/*<@497>*/node) {
        Node.visit(node.value, this);
    }
    /*<@678>*/visitContinue(/*<@502>*/node) {
    }
    /*<@679>*/visitBreak(/*<@506>*/node) {
    }
    /*<@680>*/visitTrapStatement(/*<@510>*/node) {
    }
    /*<@681>*/visitGenericLiteral(/*<@514>*/node) {
        node.type.visit(this);
    }
    /*<@682>*/visitGenericLiteralType(/*<@528>*/node) {
        Node.visit(node.type, this);
        node.preferredType.visit(this);
    }
    /*<@683>*/visitNullLiteral(/*<@548>*/node) {
        node.type.visit(this);
    }
    /*<@684>*/visitBoolLiteral(/*<@542>*/node) {
    }
    /*<@685>*/visitNullType(/*<@552>*/node) {
        Node.visit(node.type, this);
    }
    /*<@686>*/visitCallExpression(/*<@437>*/node) {
        for (let /*<@7>*/typeArgument of node.typeArguments)
            typeArgument.visit(this);
        for (let /*<@7>*/argument of node.argumentList)
            Node.visit(argument, this);
        let /*<@799>*/handleTypeArguments = /*<@799>*/(/*<@136>*/actualTypeArguments) => {
            if (actualTypeArguments) {
                for (let /*<@85>*/argument of actualTypeArguments)
                    /*<@7>*/argument.visit(this);
            }
        };
        handleTypeArguments(node.actualTypeArguments);
        handleTypeArguments(node.instantiatedActualTypeArguments);
        Node.visit(node.nativeFuncInstance, this);
        Node.visit(node.returnType, this);
        Node.visit(node.resultType, this);
    }
    /*<@687>*/visitLogicalNot(/*<@573>*/node) {
        node.operand.visit(this);
    }
    /*<@688>*/visitLogicalExpression(/*<@579>*/node) {
        node.left.visit(this);
        node.right.visit(this);
    }
    /*<@689>*/visitFunctionLikeBlock(/*<@565>*/node) {
        Node.visit(node.returnType, this);
        for (let /*<@7>*/argument of node.argumentList)
            argument.visit(this);
        for (let /*<@116>*/parameter of node.parameters)
            parameter.visit(this);
        node.body.visit(this);
        Node.visit(node.resultType, this);
    }
    /*<@690>*/visitAnonymousVariable(/*<@413>*/node) {
        Node.visit(node.type, this);
    }
    /*<@691>*/visitIdentityExpression(/*<@7>*/node) {
        node.target.visit(this);
    }
}
class /*<@515>*/GenericLiteral extends Expression {
    constructor(/*<@42>*/origin, /*<@1>*/value) {
        super(origin);
        this._value = value;
        this._isLiteral = true;
    }
    static /*<@516>*/withType(/*<@42>*/origin, /*<@1>*/value, /*<@85>*/type) {
        throw new Error("no withType");
    }
    get /*<@517>*/value() { return this._value; }
    // This is necessary because once we support int64, we'll need that to be represented as an object
    // rather than as a primitive. Then we'll need to convert.
    get /*<@518>*/valueForSelectedType() {
        let /*<@7>*/type = this.type.type.unifyNode;
        if (!type)
            throw new Error("Cannot get type for " + this);
        let func = type["formatValueFrom" + this.literalClassName];
        if (!func)
            throw new Error("Cannot get function to format type for " + this.literalClassName + " from " + type);
        return func.call(type, this.value);
    }
    get /*<@519>*/isConstexpr() {
        if (this.hasBecome)
            return this.target.isConstexpr;
        return true;
    }
    /*<@520>*/negConstexpr(/*<@42>*/origin) {
        return null;
    }
    /*<@521>*/unifyImpl(/*<@153>*/unificationContext, /*<@7>*/other) {
        if (!(other instanceof GenericLiteral))
            return false;
        return this.value == other.value;
    }
    /*<@522>*/toString() {
        return this.preferredTypeName + "Literal<" + this.value + ">";
    }
}
class /*<@801>*/DoubleLiteral extends GenericLiteral {
    constructor(/*<@42>*/origin, /*<@1>*/value) {
        super(origin, value);
        this.type = new DoubleLiteralType(origin, value);
        this.literalClassName = "DoubleLiteral";
        this.preferredTypeName = "double";
    }
    static /*<@802>*/withType(/*<@42>*/origin, /*<@1>*/value, /*<@85>*/type) {
        let /*<@800>*/result = new DoubleLiteral(origin, value);
        result.type = TypeRef.wrap(type);
        return result;
    }
    /*<@803>*/negConstexpr(/*<@42>*/origin) {
        return new IntLiteral(origin, -this.value);
    }
}
class /*<@805>*/FloatLiteral extends GenericLiteral {
    constructor(/*<@42>*/origin, /*<@1>*/value) {
        super(origin, value);
        this.type = new FloatLiteralType(origin, value);
        this.literalClassName = "FloatLiteral";
        this.preferredTypeName = "FloatLiteral";
    }
    static /*<@806>*/withType(/*<@42>*/origin, /*<@1>*/value, /*<@85>*/type) {
        let /*<@804>*/result = new FloatLiteral(origin, value);
        result.type = TypeRef.wrap(type);
        return result;
    }
    /*<@807>*/negConstexpr(/*<@42>*/origin) {
        return new IntLiteral(origin, -this.value);
    }
}
class /*<@524>*/IntLiteral extends GenericLiteral {
    constructor(/*<@42>*/origin, /*<@1>*/value) {
        super(origin, value);
        this.type = new IntLiteralType(origin, value);
        this.literalClassName = "IntLiteral";
        this.preferredTypeName = "int";
    }
    static /*<@525>*/withType(/*<@42>*/origin, /*<@1>*/value, /*<@85>*/type) {
        let /*<@523>*/result = new IntLiteral(origin, value);
        result.type = TypeRef.wrap(type);
        return result;
    }
    /*<@526>*/negConstexpr(/*<@42>*/origin) {
        return new IntLiteral(origin, (-this.value) | 0);
    }
}
class /*<@809>*/UintLiteral extends GenericLiteral {
    constructor(/*<@42>*/origin, /*<@1>*/value) {
        super(origin, value);
        this.type = new UintLiteralType(origin, value);
        this.literalClassName = "UintLiteral";
        this.preferredTypeName = "uint";
    }
    static /*<@810>*/withType(/*<@42>*/origin, /*<@1>*/value, /*<@85>*/type) {
        let /*<@808>*/result = new UintLiteral(origin, value);
        result.type = TypeRef.wrap(type);
        return result;
    }
    /*<@811>*/negConstexpr(/*<@42>*/origin) {
        return new UintLiteral(origin, (-this.value) | 0);
    }
}
class /*<@529>*/GenericLiteralType extends Type {
    constructor(/*<@42>*/origin, /*<@1>*/value, /*<@3>*/name) {
        super();
        this._origin = origin;
        this._value = value;
        this.preferredType = new TypeRef(origin, name, /*<@784>*/[]);
        this._isLiteral = true;
    }
    get /*<@530>*/value() { return this._value; }
    get /*<@531>*/isPrimitive() { return true; }
    get /*<@532>*/isUnifiable() { return true; }
    /*<@533>*/typeVariableUnify(/*<@153>*/unificationContext, /*<@85>*/other) {
        if (!(other instanceof Type))
            return false;
        return this._typeVariableUnifyImpl(unificationContext, other);
    }
    /*<@534>*/unifyImpl(/*<@153>*/unificationContext, /*<@85>*/other) {
        return this.typeVariableUnify(unificationContext, other);
    }
    /*<@535>*/prepareToVerify(/*<@153>*/unificationContext) {
        let /*<@7>*/realThis = unificationContext.find(this);
        if (realThis instanceof TypeVariable || realThis.isLiteral) {
            return /*<@812>*/() => {
                if (realThis.unify(unificationContext, this.preferredType))
                    return /*<@785>*/{ result: true, reason: undefined };
                return /*<@775>*/{ result: false, reason: "Type mismatch between " + unificationContext.find(realThis) + " and " + this.preferredType };
            };
        }
    }
    /*<@536>*/verifyAsArgument(/*<@153>*/unificationContext) {
        throw new Error("no verifyAsArgument");
    }
    /*<@537>*/verifyAsParameter(/*<@153>*/unificationContext) {
        throw new Error("GenericLiteralType should never be used as a type parameter");
    }
    /*<@538>*/conversionCost(/*<@153>*/unificationContext) {
        let /*<@7>*/realThis = unificationContext.find(this);
        if (realThis.equals(this.preferredType))
            return 0;
        return 1;
    }
    /*<@539>*/commitUnification(/*<@153>*/unificationContext) {
        this.type = unificationContext.find(this).visit(new AutoWrapper());
    }
    /*<@540>*/toString() {
        return this.preferredTypeName + "LiteralType<" + this.value + ">";
    }
}
class /*<@815>*/DoubleLiteralType extends GenericLiteralType {
    constructor(/*<@42>*/origin, /*<@1>*/value) {
        super(origin, value, "double");
        this.preferredTypeName = "double";
    }
    /*<@816>*/verifyAsArgument(/*<@153>*/unificationContext) {
        let /*<@85>*/realThis = unificationContext.find(this);
        if (!realThis.isFloating)
            return /*<@775>*/{ result: false, reason: "Cannot use double literal with non-floating type " + realThis };
        if (!realThis.canRepresent(this./*<@1>*/value))
            return /*<@775>*/{ result: false, reason: "Float literal " + this.value + " does not fit in type " + realThis };
        return /*<@785>*/{ result: true, reason: undefined };
    }
}
class /*<@818>*/FloatLiteralType extends GenericLiteralType {
    constructor(/*<@42>*/origin, /*<@1>*/value) {
        super(origin, value, "float");
        this.preferredTypeName = "float";
    }
    /*<@819>*/verifyAsArgument(/*<@153>*/unificationContext) {
        let /*<@85>*/realThis = unificationContext.find(this);
        if (!realThis.isFloating)
            return /*<@775>*/{ result: false, reason: "Cannot use float literal with non-floating type " + realThis };
        if (!realThis.canRepresent(this./*<@1>*/value))
            return /*<@775>*/{ result: false, reason: "Float literal " + this.value + " does not fit in type " + realThis };
        return /*<@785>*/{ result: true, reason: undefined };
    }
}
class /*<@821>*/IntLiteralType extends GenericLiteralType {
    constructor(/*<@42>*/origin, /*<@1>*/value) {
        super(origin, value, "int");
        this.preferredTypeName = "int";
    }
    /*<@822>*/verifyAsArgument(/*<@153>*/unificationContext) {
        let /*<@85>*/realThis = unificationContext.find(this);
        if (!realThis.isNumber)
            return /*<@775>*/{ result: false, reason: "Cannot use int literal with non-number type " + realThis };
        if (!realThis.canRepresent(this./*<@1>*/value))
            return /*<@775>*/{ result: false, reason: "Int literal " + this.value + " too large to be represented by type " + realThis };
        return /*<@785>*/{ result: true, reason: undefined };
    }
}
class /*<@824>*/UintLiteralType extends GenericLiteralType {
    constructor(/*<@42>*/origin, /*<@1>*/value) {
        super(origin, value, "uint");
        this.preferredTypeName = "uint";
    }
    /*<@825>*/verifyAsArgument(/*<@153>*/unificationContext) {
        let /*<@85>*/realThis = unificationContext.find(this);
        if (!realThis.isInt)
            return /*<@775>*/{ result: false, reason: "Cannot use uint literal with non-number type " + realThis };
        if (realThis.isSigned)
            return /*<@775>*/{ result: false, reason: "Cannot use uint literal with signed type " + realThis };
        if (!realThis.canRepresent(this./*<@1>*/value))
            return /*<@775>*/{ result: false, reason: "Uint literal " + this.value + " too large to be represented by type " + realThis };
        return /*<@785>*/{ result: true, reason: undefined };
    }
}
class /*<@436>*/PropertyAccessExpression extends Expression {
    constructor(/*<@42>*/origin, /*<@303>*/base) {
        super(origin);
        this.base = base;
        this._isLValue = null; // We use null to indicate that we don't know yet.
        this.addressSpace = null;
        this._notLValueReason = null;
    }
    get /*<@452>*/getFuncName() { return ""; }
    get /*<@453>*/andFuncName() { return ""; }
    get /*<@454>*/setFuncName() { return ""; }
    get /*<@455>*/resultType() { return this.resultTypeForGet ? this.resultTypeForGet : this.resultTypeForAnd; }
    get /*<@456>*/isLValue() {
        if (this.hasBecome)
            return this.target.isLValue;
        return this._isLValue;
    }
    set /*<@457>*/isLValue(/*<@2>*/value) { this._isLValue = value; }
    get /*<@458>*/notLValueReason() { return this._notLValueReason; }
    set /*<@459>*/notLValueReason(/*<@3>*/value) { this._notLValueReason = value; }
    /*<@460>*/rewriteAfterCloning() {
        // At this point, node.base.isLValue will only return true if it's possible to get a pointer to it,
        // since we will no longer see any DotExpressions or IndexExpressions. Also, node is a newly created
        // node and everything beneath it is newly created, so we can edit it in-place.
        if ((this.base.isLValue || this.baseType.isRef) && this.callForAnd)
            return new DereferenceExpression(this.origin, this.callForAnd, this.resultType, this.callForAnd.resultType.addressSpace);
        if (this.callForGet)
            return this.callForGet;
        if (!this.callForAnd)
            throw new Error(this.origin.originString + ": Property access without getter and ander: " + this);
        let /*<@413>*/anonVar = new AnonymousVariable(this.origin, this.baseType);
        this.callForAnd.argumentList[0] = this.baseType./*<@85>*/unifyNode.argumentForAndOverload(this.origin, VariableRef.wrap(anonVar));
        return new CommaExpression(this.origin, /*<@784>*/[
            anonVar,
            new Assignment(this.origin, VariableRef.wrap(anonVar), this.base, this.baseType),
            new DereferenceExpression(this.origin, this.callForAnd, this.resultType, this.callForAnd.resultType.addressSpace)
        ]);
    }
    /*<@462>*/updateCalls() {
        if (this.callForGet)
            this.callForGet.argumentList[0] = this.base;
        if (this.callForAnd)
            this.callForAnd.argumentList[0] = this.baseType.argumentForAndOverload(this.origin, this.base);
        if (this.callForSet)
            this.callForSet.argumentList[0] = this.base;
    }
    /*<@463>*/emitGet(/*<@303>*/base) {
        let /*<@435>*/result = this.visit(new Rewriter());
        result.base = base;
        result.updateCalls();
        return result.rewriteAfterCloning();
    }
    /*<@464>*/emitSet(/*<@303>*/base, /*<@188>*/value) {
        let /*<@435>*/result = this.visit(new Rewriter());
        if (!result.callForSet)
            throw new WTypeError(this.origin.originString, "Cannot emit set because: " + this.errorForSet.typeErrorMessage);
        result.base = base;
        result.updateCalls();
        result.callForSet.argumentList[result.callForSet.argumentList.length - 1] = /*<@7>*/value;
        return result.callForSet;
    }
}
const /*<@826>*/addressSpaces = /*<@826>*/["constant", "device", "threadgroup", "thread"];
function /*<@827>*/isAddressSpace(/*<@3>*/addressSpace) {
    switch (addressSpace) {
        case "constant":
        case "device":
        case "threadgroup":
        case "thread":
            return true;
        default:
            return false;
    }
}
function /*<@828>*/validateAddressSpace(/*<@3>*/addressSpace) {
    if (!isAddressSpace(addressSpace))
        throw new Error("Bad address space: " + addressSpace);
}
/*
 * Copyright (C) 2017 Apple Inc. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY APPLE INC. ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE INC. OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
"use strict";
let /*<@5>*/anonymousVariableCount = 0;
class /*<@414>*/AnonymousVariable extends Value {
    // You have to initialize the variable's value before use, but that could be quite late.
    constructor(/*<@42>*/origin, /*<@85>*/type = null) {
        super();
        this._origin = origin;
        this.index = anonymousVariableCount++;
        this.type = type;
        this.name = "anonVar<" + this.index + ">";
    }
    /*<@415>*/toString() {
        return this.name;
    }
}
/*
 * Copyright (C) 2017 Apple Inc. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY APPLE INC. ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE INC. OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
"use strict";
// Note that we say that T[] is "the same type" as T[c] for any T, c. This greatly simplifies the
// language.
class /*<@386>*/ArrayRefType extends ReferenceType {
    constructor(/*<@42>*/origin, /*<@3>*/addressSpace, /*<@85>*/elementType) {
        super(origin, addressSpace, elementType);
        this._isArrayRef = true;
    }
    /*<@387>*/unifyImpl(/*<@153>*/unificationContext, /*<@85>*/other) {
        if (!other.isArrayRef)
            return false;
        if (this.addressSpace != other.addressSpace)
            return false;
        return this.elementType.unify(unificationContext, other.elementType);
    }
    /*<@388>*/argumentForAndOverload(/*<@42>*/origin, /*<@188>*/value) {
        return /*<@7>*/value;
    }
    /*<@389>*/argumentTypeForAndOverload(/*<@42>*/origin) {
        return this;
    }
    /*<@390>*/toString() {
        return this.elementType + "[] " + this.addressSpace;
    }
}
/*
 * Copyright (C) 2017 Apple Inc. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY APPLE INC. ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE INC. OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
"use strict";
function /*<@829>*/ArrayTypePopulate(/*<@45>*/buffer, /*<@5>*/offset) {
    for (let /*<@5>*/i = 0; i < this.numElementsValue; ++i)
        this.elementType.populateDefaultValue(buffer, offset + i * this.elementType.size);
}
class /*<@393>*/ArrayType extends Type {
    constructor(/*<@42>*/origin, /*<@85>*/elementType, /*<@303>*/numElements) {
        if (!numElements)
            throw new Error("null numElements");
        super();
        this._origin = origin;
        this._elementType = elementType;
        this._numElements = numElements;
        this.populateDefaultValue = ArrayTypePopulate;
    }
    get /*<@394>*/elementType() { return this._elementType; }
    get /*<@395>*/numElements() { return this._numElements; }
    get /*<@396>*/isPrimitive() { return this.elementType.isPrimitive; }
    get /*<@397>*/isArray() { return true; }
    get /*<@398>*/numElementsValue() {
        if (!(this.numElements.isLiteral))
            throw new Error("numElements is not a literal: " + this.numElements);
        return this./*<@514>*/numElements./*<@1>*/value;
    }
    /*<@399>*/toString() {
        return this.elementType + "[" + this.numElements + "]";
    }
    get /*<@400>*/size() {
        return this.elementType.size * this.numElementsValue;
    }
    /*<@401>*/unifyImpl(/*<@153>*/unificationContext, /*<@392>*/other) {
        if (!(other instanceof ArrayType))
            return false;
        if (!this.numElements.unify(unificationContext, other.numElements))
            return false;
        return this.elementType.unify(unificationContext, other.elementType);
    }
    /*<@402>*/argumentForAndOverload(/*<@42>*/origin, /*<@188>*/value) {
        let /*<@377>*/result = new MakeArrayRefExpression(origin, /*<@120>*/value);
        result.numElements = this.numElements;
        return result;
    }
    /*<@403>*/argumentTypeForAndOverload(/*<@42>*/origin) {
        return new ArrayRefType(origin, "thread", this.elementType);
    }
}
class /*<@406>*/Assignment extends Expression {
    constructor(/*<@42>*/origin, /*<@120>*/lhs, /*<@7>*/rhs, /*<@85>*/type = null) {
        super(origin);
        this._lhs = lhs;
        this._rhs = rhs;
        this.type = type;
    }
    get /*<@407>*/lhs() { return this._lhs; }
    get /*<@408>*/rhs() { return this._rhs; }
    /*<@409>*/toString() {
        return this.lhs + " = " + this.rhs;
    }
}
;
/*
 * Copyright (C) 2017 Apple Inc. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY APPLE INC. ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE INC. OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
"use strict";
class /*<@831>*/AutoWrapper extends Rewriter {
    /*<@832>*/visitVariableRef(/*<@418>*/node) {
        return node;
    }
    /*<@833>*/visitTypeRef(/*<@345>*/node) {
        return node;
    }
    /*<@834>*/visitConstexprTypeParameter(/*<@251>*/node) {
        return VariableRef.wrap(node);
    }
    /*<@835>*/visitFuncParameter(/*<@116>*/node) {
        return VariableRef.wrap(node);
    }
    /*<@836>*/visitVariableDecl(/*<@326>*/node) {
        return VariableRef.wrap(node);
    }
    /*<@837>*/visitStructType(/*<@280>*/node) {
        return TypeRef.wrap(node);
    }
    /*<@838>*/visitNativeType(/*<@249>*/node) {
        return TypeRef.wrap(node);
    }
    /*<@839>*/visitTypeVariable(/*<@146>*/node) {
        return TypeRef.wrap(node);
    }
    /*<@840>*/visitGenericLiteralType(/*<@528>*/node) {
        return node;
    }
    /*<@841>*/visitNullType(/*<@552>*/node) {
        return node;
    }
}
class /*<@333>*/Block extends Node {
    constructor(/*<@3>*/origin) {
        super();
        this.__origin = origin;
        this._statements = /*<@784>*/[];
    }
    /*<@334>*/add(/*<@7>*/statement) {
        this._statements.push(statement);
    }
    get /*<@335>*/statements() { return this._statements; }
    /*<@336>*/toString() {
        if (!this.statements.length)
            return "{ }";
        return "{ " + this.statements.join("; ") + "; }";
    }
}
;
/*
 * Copyright (C) 2017 Apple Inc. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY APPLE INC. ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE INC. OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
"use strict";
class /*<@543>*/BoolLiteral extends Expression {
    constructor(/*<@42>*/origin, /*<@2>*/value) {
        super(origin);
        this._value = value;
    }
    get /*<@544>*/value() { return this._value; }
    get /*<@545>*/isConstexpr() {
        if (this.hasBecome)
            return this.target.isConstexpr;
        return true;
    }
    /*<@546>*/toString() {
        return "" + this._value;
    }
}
/*
 * Copyright (C) 2017 Apple Inc. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY APPLE INC. ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE INC. OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
"use strict";
class /*<@507>*/Break extends Node {
    constructor(/*<@42>*/origin) {
        super();
        this._origin = origin;
    }
    /*<@508>*/toString() {
        return "break";
    }
}
;
/*
 * Copyright (C) 2017 Apple Inc. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY APPLE INC. ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE INC. OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
"use strict";
class /*<@438>*/CallExpression extends Expression {
    constructor(/*<@42>*/origin, /*<@3>*/name, /*<@101>*/typeArguments, /*<@101>*/argumentList) {
        super(origin);
        this._name = name;
        this._typeArguments = typeArguments;
        this._argumentList = argumentList;
        this.func = null;
        this._isCast = false;
        this._returnType = null;
    }
    get /*<@439>*/typeArguments() { return this._typeArguments; }
    get /*<@440>*/argumentList() { return this._argumentList; }
    get /*<@441>*/isCast() { return this._isCast; }
    get /*<@442>*/returnType() { return this._returnType; }
    static /*<@443>*/resolve(/*<@42>*/origin, /*<@143>*/possibleOverloads, /*<@101>*/typeParametersInScope, /*<@3>*/name, /*<@136>*/typeArguments, /*<@101>*/argumentList, /*<@136>*/argumentTypes, /*<@345>*/returnType) {
        let /*<@437>*/call = new CallExpression(origin, name, typeArguments, argumentList);
        call.argumentTypes = argumentTypes.map(/*<@842>*/argument => argument.visit(new AutoWrapper()));
        call.possibleOverloads = possibleOverloads;
        if (returnType)
            call.setCastData(returnType);
        return /*<@771>*/{ call, resultType: call.resolve(possibleOverloads, typeParametersInScope, typeArguments) };
    }
    /*<@444>*/resolve(/*<@143>*/possibleOverloads, /*<@101>*/typeParametersInScope, /*<@136>*/typeArguments) {
        if (!possibleOverloads)
            throw new WTypeError(this.origin.originString, "Did not find any functions named " + this.name);
        let overload = null;
        let /*<@784>*/failures = /*<@784>*/[];
        for (let /*<@7>*/typeParameter of typeParametersInScope) {
            if (!(typeParameter instanceof TypeVariable))
                continue;
            if (!typeParameter.protocol)
                continue;
            let /*<@143>*/signatures = typeParameter.protocol.protocolDecl.signaturesByNameWithTypeVariable(this.name, typeParameter);
            if (!signatures)
                continue;
            overload = resolveOverloadImpl(signatures, this.typeArguments, this.argumentTypes, this.returnType);
            if (overload.func)
                break;
            failures.push(...overload.failures);
            overload = null;
        }
        if (!overload) {
            overload = resolveOverloadImpl(possibleOverloads, this.typeArguments, this.argumentTypes, this.returnType);
            if (!overload.func) {
                failures.push(...overload.failures);
                let /*<@3>*/message = "Did not find function named " + this.name + " for call with ";
                if (this.typeArguments.length)
                    message += "type arguments <" + this.typeArguments + "> and ";
                message += "argument types (" + this.argumentTypes + ")";
                if (this.returnType)
                    message += " and return type " + this.returnType;
                if (failures.length)
                    message += ", but considered:\n" + failures.join("\n");
                throw new WTypeError(this.origin.originString, message);
            }
        }
        overload = overload;
        for (let /*<@5>*/i = 0; i < typeArguments.length; ++i) {
            let /*<@85>*/typeArgumentType = typeArguments[i];
            let /*<@7>*/typeParameter = overload.func.typeParameters[i];
            if (!(typeParameter instanceof ConstexprTypeParameter))
                continue;
            if (!typeParameter.type.equalsWithCommit(typeArgumentType))
                throw new Error("At " + this.origin.originString + " constexpr type argument and parameter types not equal: argument = " + typeArgumentType + ", parameter = " + typeParameter.type);
        }
        for (let /*<@5>*/i = 0; i < this.argumentTypes.length; ++i) {
            let /*<@85>*/argumentType = this.argumentTypes[i];
            let /*<@7>*/parameterType = overload.func.parameters[i].type.substituteToUnification(overload.func.typeParameters, overload.unificationContext);
            let /*<@757>*/result = argumentType.equalsWithCommit(parameterType);
            if (!result)
                throw new Error("At " + this.origin.originString + " argument and parameter types not equal after type argument substitution: argument = " + argumentType + ", parameter = " + parameterType);
        }
        return this.resolveToOverload(overload);
    }
    /*<@445>*/resolveToOverload(overload) {
        this.func = overload.func;
        this.actualTypeArguments = overload.typeArguments.map(/*<@843>*/typeArgument => typeArgument instanceof Type ? typeArgument.visit(new AutoWrapper()) : typeArgument);
        this.instantiatedActualTypeArguments = this.actualTypeArguments;
        let /*<@85>*/result = overload.func.returnType.substituteToUnification(overload.func.typeParameters, overload.unificationContext);
        if (!result)
            throw new Error("Null return type");
        result = result.visit(new AutoWrapper());
        this.resultType = /*<@345>*/result; // XTS
        return result;
    }
    /*<@446>*/becomeCast(/*<@85>*/returnType) {
        this._returnType = new TypeRef(this.origin, this.name, this._typeArguments);
        this._returnType.type = returnType;
        this._name = "operator cast";
        this._isCast = true;
        this._typeArguments = /*<@784>*/[];
    }
    /*<@447>*/setCastData(/*<@85>*/returnType) {
        this._returnType = returnType;
        this._isCast = true;
    }
    /*<@448>*/toString() {
        return (this.isCast ? "operator " + this.returnType : this.name) +
            "<" + this.typeArguments + ">" +
            (this.actualTypeArguments ? "<<" + this.actualTypeArguments + ">>" : "") +
            "(" + this.argumentList + ")";
    }
}
// This allows you to pass structs and arrays in-place, but it's a more annoying API.
function /*<@844>*/callFunction(/*<@71>*/program, /*<@3>*/name, /*<@136>*/typeArguments, /*<@852>*/argumentList) {
    let /*<@136>*/argumentTypes = argumentList.map(/*<@853>*/(/*<@845>*/argument) => argument.type);
    let /*<@854>*/funcOrFailures = resolveInlinedFunction(program, name, typeArguments, argumentTypes, true);
    if (!(funcOrFailures instanceof Func)) {
        let /*<@769>*/failures = /*<@769>*/funcOrFailures;
        throw new WTypeError("<callFunction>", "Cannot resolve function call " + name + "<" + typeArguments + ">(" + argumentList + ")" + (failures.length ? "; tried:\n" + failures.join("\n") : ""));
    }
    let /*<@114>*/func = funcOrFailures;
    for (let /*<@5>*/i = 0; i < func.parameters.length; ++i) {
        let /*<@85>*/type = argumentTypes[i].instantiatedType;
        type.visit(new StructLayoutBuilder());
        func.parameters[i].ePtr.copyFrom(argumentList[i].ePtr, type.size);
    }
    let /*<@43>*/result = new Evaluator(program).runFunc(/*<@227>*/func);
    return new TypedValue(func.uninstantiatedReturnType, result);
}
function /*<@855>*/check(/*<@71>*/program) {
    program.visit(new Checker(program));
}
function /*<@856>*/checkLiteralTypes(/*<@71>*/program) {
    program.visit(new LiteralTypeChecker());
}
/*
 * Copyright (C) 2017 Apple Inc. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY APPLE INC. ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE INC. OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
"use strict";
function /*<@857>*/checkLoops(/*<@71>*/program) {
    program.visit(new LoopChecker());
}
/*
 * Copyright (C) 2017 Apple Inc. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY APPLE INC. ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE INC. OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
"use strict";
function /*<@858>*/checkRecursiveTypes(/*<@71>*/program) {
    program.visit(new RecursiveTypeChecker());
}
/*
 * Copyright (C) 2017 Apple Inc. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY APPLE INC. ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE INC. OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
"use strict";
function /*<@859>*/checkRecursion(/*<@71>*/program) {
    program.visit(new RecursionChecker(program));
}
/*
 * Copyright (C) 2017 Apple Inc. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY APPLE INC. ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE INC. OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
"use strict";
function /*<@860>*/checkReturns(/*<@71>*/program) {
    program.visit(new ReturnChecker(program));
}
/*
 * Copyright (C) 2017 Apple Inc. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY APPLE INC. ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE INC. OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
"use strict";
function /*<@861>*/checkUnreachableCode(/*<@71>*/program) {
    program.visit(new UnreachableCodeChecker(program));
}
/*
 * Copyright (C) 2017 Apple Inc. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY APPLE INC. ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE INC. OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
"use strict";
function /*<@862>*/checkExpressionWrapped(/*<@7>*/node) {
    node.visit(new WrapChecker(node));
}
function /*<@863>*/checkProgramWrapped(/*<@7>*/node) {
    node.visit(new ExpressionFinder(checkExpressionWrapped));
}
/*
 * Copyright (C) 2017 Apple Inc. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY APPLE INC. ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE INC. OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
"use strict";
class /*<@865>*/Checker extends Visitor {
    constructor(/*<@71>*/program) {
        super();
        this._program = program;
        this._currentStatement = null;
        this._vertexEntryPoints = new Set();
        this._fragmentEntryPoints = new Set();
    }
    /*<@866>*/doStatement(/*<@7>*/statement) {
        this._currentStatement = statement;
        statement.visit(this);
    }
    /*<@867>*/visitProgram(/*<@71>*/node) {
        for (let /*<@85>*/type of node.types.values())
            this.doStatement(type);
        for (let /*<@177>*/protocol of node.protocols.values())
            this.doStatement(protocol);
        for (let /*<@143>*/funcs of node.functions.values()) {
            for (let /*<@114>*/func of funcs) {
                this.visitFunc(func);
            }
        }
        for (let /*<@143>*/funcs of node.functions.values()) {
            for (let /*<@114>*/func of funcs)
                this.doStatement(func);
        }
    }
    /*<@868>*/_checkShaderType(/*<@114>*/node) {
        // FIXME: Relax these checks once we have implemented support for textures and samplers.
        if (node.typeParameters.length != 0)
            throw new WTypeError(node.origin.originString, "Entry point " + node.name + " must not have type arguments.");
        let /*<@114>*/shaderFunc = node;
        switch (node.shaderType) {
            case "vertex":
                if (this._vertexEntryPoints.has(node.name))
                    throw new WTypeError(node.origin.originString, "Duplicate vertex entry point name " + node.name);
                this._vertexEntryPoints.add(node.name);
                break;
            case "fragment":
                if (this._fragmentEntryPoints.has(node.name))
                    throw new WTypeError(node.origin.originString, "Duplicate fragment entry point name " + node.name);
                this._fragmentEntryPoints.add(node.name);
                break;
        }
    }
    /*<@869>*/_checkOperatorOverload(/*<@114>*/func, resolveFuncs) {
        if (Lexer.textIsIdentifier(func.name))
            return; // Not operator!
        if (!func.name.startsWith("operator"))
            throw new Error("Bad operator overload name: " + func.name);
        let /*<@906>*/typeVariableTracker = new TypeVariableTracker();
        for (let /*<@85>*/parameterType of func.parameterTypes)
            parameterType.visit(typeVariableTracker);
        Node.visit(func.returnTypeForOverloadResolution, typeVariableTracker);
        for (let /*<@7>*/typeParameter of func.typeParameters) {
            if (!typeVariableTracker.set.has(typeParameter))
                throw new WTypeError(typeParameter.origin.originString, "Type parameter " + typeParameter + " to operator " + func.toDeclString() + " is not inferrable from value parameters");
        }
        let /*<@912>*/checkGetter = /*<@912>*/(/*<@3>*/kind) => {
            let /*<@5>*/numExpectedParameters = kind == "index" ? 2 : 1;
            if (func.parameters.length != numExpectedParameters)
                throw new WTypeError(func.origin.originString, "Incorrect number of parameters for " + func.name + " (expected " + numExpectedParameters + ", got " + func.parameters.length + ")");
            if (func.parameterTypes[0].unifyNode.isPtr)
                throw new WTypeError(func.origin.originString, "Cannot have getter for pointer type: " + func.parameterTypes[0]);
        };
        let /*<@913>*/checkSetter = /*<@913>*/(/*<@3>*/kind) => {
            let /*<@5>*/numExpectedParameters = kind == "index" ? 3 : 2;
            if (func.parameters.length != numExpectedParameters)
                throw new WTypeError(func.origin.originString, "Incorrect number of parameters for " + func.name + " (expected " + numExpectedParameters + ", got " + func.parameters.length + ")");
            if (func.parameterTypes[0].unifyNode.isPtr)
                throw new WTypeError(func.origin.originString, "Cannot have setter for pointer type: " + func.parameterTypes[0]);
            if (!func.returnType.equals(func.parameterTypes[0]))
                throw new WTypeError(func.origin.originString, "First parameter type and return type of setter must match (parameter was " + func.parameterTypes[0] + " but return was " + func.returnType + ")");
            let /*<@85>*/valueType = func.parameterTypes[numExpectedParameters - 1];
            let /*<@3>*/getterName = func.name.substr(0, func.name.length - 1);
            let /*<@143>*/getterFuncs = resolveFuncs(getterName);
            if (!getterFuncs)
                throw new WTypeError(func.origin.originString, "Every setter must have a matching getter, but did not find any function named " + getterName + " to match " + func.name);
            let /*<@136>*/argumentTypes = func.parameterTypes.slice(0, numExpectedParameters - 1);
            let overload = resolveOverloadImpl(getterFuncs, /*<@784>*/[], argumentTypes, null);
            if (!overload.func) {
                throw new WTypeError(func.origin.originString, "Did not find function named " + func.name + " with arguments " + argumentTypes + (overload.failures.length ? "; tried:\n" + overload.failures.join("\n") : ""));
            }
            overload = (overload);
            let /*<@7>*/resultType = overload.func.returnType.substituteToUnification(overload.func.typeParameters, overload.unificationContext);
            if (!resultType.equals(valueType))
                throw new WTypeError(func.origin.originString, "Setter and getter must agree on value type (getter at " + overload.func.origin.originString + " says " + resultType + " while this setter says " + valueType + ")");
        };
        let /*<@914>*/checkAnder = /*<@914>*/(/*<@3>*/kind) => {
            let /*<@5>*/numExpectedParameters = kind == "index" ? 2 : 1;
            if (func.parameters.length != numExpectedParameters)
                throw new WTypeError(func.origin.originString, "Incorrect number of parameters for " + func.name + " (expected " + numExpectedParameters + ", got " + func.parameters.length + ")");
            if (!func.returnType.unifyNode.isPtr)
                throw new WTypeError(func.origin.originString, "Return type of ander is not a pointer: " + func.returnType);
            if (!func.parameterTypes[0]./*<@85>*/unifyNode.isRef)
                throw new WTypeError(func.origin.originString, "Parameter to ander is not a reference: " + func.parameterTypes[0]);
        };
        switch (func.name) {
            case "operator cast":
                break;
            case "operator++":
            case "operator--":
                if (func.parameters.length != 1)
                    throw new WTypeError(func.origin.originString, "Incorrect number of parameters for " + func.name + " (expected 1, got " + func.parameters.length + ")");
                if (!func.parameterTypes[0].equals(func.returnType))
                    throw new WTypeError(func.origin.originString, "Parameter type and return type must match for " + func.name + " (parameter is " + func.parameterTypes[0] + " while return is " + func.returnType + ")");
                break;
            case "operator+":
            case "operator-":
                if (func.parameters.length != 1 && func.parameters.length != 2)
                    throw new WTypeError(func.origin.originString, "Incorrect number of parameters for " + func.name + " (expected 1 or 2, got " + func.parameters.length + ")");
                break;
            case "operator*":
            case "operator/":
            case "operator%":
            case "operator&":
            case "operator|":
            case "operator^":
            case "operator<<":
            case "operator>>":
                if (func.parameters.length != 2)
                    throw new WTypeError(func.origin.originString, "Incorrect number of parameters for " + func.name + " (expected 2, got " + func.parameters.length + ")");
                break;
            case "operator~":
                if (func.parameters.length != 1)
                    throw new WTypeError(func.origin.originString, "Incorrect number of parameters for " + func.name + " (expected 1, got " + func.parameters.length + ")");
                break;
            case "operator==":
            case "operator<":
            case "operator<=":
            case "operator>":
            case "operator>=":
                if (func.parameters.length != 2)
                    throw new WTypeError(func.origin.originString, "Incorrect number of parameters for " + func.name + " (expected 2, got " + func.parameters.length + ")");
                if (!func.returnType.equals(this._program.intrinsics.bool))
                    throw new WTypeError(func.origin.originString, "Return type of " + func.name + " must be bool but was " + func.returnType);
                break;
            case "operator[]":
                checkGetter("index");
                break;
            case "operator[]=":
                checkSetter("index");
                break;
            case "operator&[]":
                checkAnder("index");
                break;
            default:
                if (func.name.startsWith("operator.")) {
                    if (func.name.endsWith("="))
                        checkSetter("dot");
                    else
                        checkGetter("dot");
                    break;
                }
                if (func.name.startsWith("operator&.")) {
                    checkAnder("dot");
                    break;
                }
                throw new Error("Parser accepted unrecognized operator: " + func.name);
        }
    }
    /*<@870>*/visitFuncDef(/*<@227>*/node) {
        if (node.shaderType)
            this._checkShaderType(node);
        this._checkOperatorOverload(node, /*<@915>*/name => this._program.functions.get(name));
        node.body.visit(this);
    }
    /*<@871>*/visitNativeFunc(/*<@237>*/node) {
    }
    /*<@872>*/visitProtocolDecl(/*<@109>*/node) {
        for (let /*<@112>*/signature of node.signatures) {
            let /*<@906>*/typeVariableTracker = new TypeVariableTracker();
            for (let /*<@85>*/parameterType of signature.parameterTypes)
                parameterType.visit(typeVariableTracker);
            Node.visit(signature.returnTypeForOverloadResolution, typeVariableTracker);
            for (let /*<@7>*/typeParameter of signature.typeParameters) {
                if (!typeVariableTracker.set.has(typeParameter))
                    throw new WTypeError(typeParameter.origin.originString, "Type parameter to protocol signature not inferrable from value parameters");
            }
            if (!typeVariableTracker.set.has(node.typeVariable))
                throw new WTypeError(signature.origin.originString, "Protocol's type variable (" + node.name + ") not mentioned in signature: " + signature);
            this._checkOperatorOverload(signature, /*<@916>*/name => node.signaturesByName(name));
        }
    }
    /*<@873>*/visitEnumType(/*<@298>*/node) {
        node.baseType.visit(this);
        let /*<@85>*/baseType = node.baseType./*<@85>*/unifyNode;
        if (!baseType.isInt)
            throw new WTypeError(node.origin.originString, "Base type of enum is not an integer: " + node.baseType);
        for (let /*<@301>*/member of node.members) {
            if (!member.value)
                continue;
            let /*<@174>*/memberType = member./*<@7>*/value.visit(this);
            if (!baseType.equalsWithCommit(/*<@7>*/memberType))
                throw new WTypeError(member.origin.originString, "Type of enum member " + member.value.name + " does not patch enum base type (member type is " + memberType + ", enum base type is " + node.baseType + ")");
        }
        let /*<@1>*/nextValue = baseType.defaultValue;
        for (let /*<@301>*/member of node.members) {
            if (member.value) {
                nextValue = baseType.successorValue(member.value./*<@514>*/unifyNode.valueForSelectedType);
                continue;
            }
            member.value = baseType.createLiteral(member.origin, nextValue);
            nextValue = baseType.successorValue(nextValue);
        }
        let /*<@917>*/memberArray = Array.from(node.members);
        for (let /*<@5>*/i = 0; i < memberArray.length; ++i) {
            let /*<@301>*/member = memberArray[i];
            for (let /*<@5>*/j = i + 1; j < memberArray.length; ++j) {
                let /*<@301>*/otherMember = memberArray[j];
                if (baseType.valuesEqual(member.value./*<@514>*/unifyNode.valueForSelectedType, otherMember.value./*<@514>*/unifyNode.valueForSelectedType))
                    throw new WTypeError(otherMember.origin.originString, "Duplicate enum member value (" + member.name + " has " + member.value + " while " + otherMember.name + " has " + otherMember.value + ")");
            }
        }
        let /*<@2>*/foundZero = false;
        for (let /*<@301>*/member of node.members) {
            if (baseType.valuesEqual(member.value./*<@514>*/unifyNode.valueForSelectedType, baseType.defaultValue)) {
                foundZero = true;
                break;
            }
        }
        if (!foundZero)
            throw new WTypeError(node.origin.originString, "Enum does not have a member with the value zero");
    }
    /*<@874>*/_checkTypeArguments(/*<@42>*/origin, /*<@101>*/typeParameters, /*<@101>*/typeArguments) {
        for (let /*<@5>*/i = 0; i < typeParameters.length; ++i) {
            let /*<@2>*/argumentIsType = typeArguments[i] instanceof Type;
            let /*<@174>*/result = typeArguments[i].visit(this);
            if (argumentIsType) {
                let /*<@775>*/result = typeArguments[i].inherits(typeParameters[i].protocol);
                if (!result.result)
                    throw new WTypeError(origin.originString, "Type argument does not inherit protocol: " + result.reason);
            }
            else {
                if (!/*<@7>*/result.equalsWithCommit(typeParameters[i].type))
                    throw new WTypeError(origin.originString, "Wrong type for constexpr");
            }
        }
    }
    /*<@875>*/visitTypeRef(/*<@345>*/node) {
        if (!node.type)
            throw new Error("Type reference without a type in checker: " + node + " at " + node.origin);
        if (!(node.type instanceof StructType))
            node.type.visit(this);
        this._checkTypeArguments(node.origin, node.type.typeParameters, node.typeArguments);
    }
    /*<@876>*/visitArrayType(/*<@392>*/node) {
        node.elementType.visit(this);
        if (!node.numElements.isConstexpr)
            throw new WTypeError(node.origin.originString, "Array length must be constexpr");
        let /*<@7>*/type = node.numElements.visit(this);
        if (!type.equalsWithCommit(this._program.intrinsics.uint32))
            throw new WTypeError(node.origin.originString, "Array length must be a uint32");
    }
    /*<@877>*/visitVariableDecl(/*<@326>*/node) {
        node.type.visit(this);
        if (node.initializer) {
            let /*<@85>*/lhsType = node.type;
            let /*<@7>*/rhsType = node.initializer.visit(this);
            if (!lhsType.equalsWithCommit(rhsType))
                throw new WTypeError(node.origin.originString, "Type mismatch in variable initialization: " + lhsType + " versus " + rhsType);
        }
    }
    /*<@878>*/visitAssignment(/*<@405>*/node) {
        let /*<@85>*/lhsType = node.lhs.visit(this);
        if (!node.lhs.isLValue)
            throw new WTypeError(node.origin.originString, "LHS of assignment is not an LValue: " + node.lhs + node.lhs.notLValueReasonString);
        let /*<@85>*/rhsType = node.rhs.visit(this);
        if (!lhsType.equalsWithCommit(rhsType))
            throw new WTypeError(node.origin.originString, "Type mismatch in assignment: " + lhsType + " versus " + rhsType);
        node.type = lhsType;
        return lhsType;
    }
    /*<@879>*/visitIdentityExpression(/*<@7>*/node) {
        return node.target.visit(this);
    }
    /*<@880>*/visitReadModifyWriteExpression(/*<@411>*/node) {
        let /*<@85>*/lhsType = node.lValue.visit(this);
        if (!node.lValue.isLValue)
            throw new WTypeError(node.origin.originString, "LHS of read-modify-write is not an LValue: " + node.lValue + node.lValue.notLValueReasonString);
        node.oldValueVar.type = lhsType;
        node.newValueVar.type = lhsType;
        node.oldValueVar.visit(this);
        node.newValueVar.visit(this);
        let /*<@85>*/newValueType = node.newValueExp.visit(this);
        if (!lhsType.equalsWithCommit(newValueType))
            return new WTypeError(node.origin.originString, "Type mismatch in read-modify-write: " + lhsType + " versus " + newValueType);
        return node.resultExp.visit(this);
    }
    /*<@882>*/visitAnonymousVariable(/*<@413>*/node) {
        if (!node.type)
            throw new Error("Anonymous variable must know type before first appearance");
    }
    /*<@883>*/visitDereferenceExpression(/*<@429>*/node) {
        let /*<@85>*/type = node.ptr.visit(this)./*<@85>*/unifyNode;
        if (!type.isPtr)
            throw new WTypeError(node.origin.originString, "Type passed to dereference is not a pointer: " + type);
        node.type = type.elementType;
        node.addressSpace = type.addressSpace;
        if (!node.addressSpace)
            throw new Error("Null address space in type: " + type);
        return node.type;
    }
    /*<@884>*/visitMakePtrExpression(/*<@485>*/node) {
        let /*<@85>*/elementType = node.lValue.visit(this)./*<@85>*/unifyNode;
        if (!node./*<@120>*/lValue.isLValue)
            throw new WTypeError(node.origin.originString, "Operand to & is not an LValue: " + node.lValue + node./*<@120>*/lValue.notLValueReasonString);
        return new PtrType(node.origin, node.lValue.addressSpace, elementType);
    }
    /*<@885>*/visitMakeArrayRefExpression(/*<@377>*/node) {
        let /*<@85>*/elementType = node.lValue.visit(this)./*<@85>*/unifyNode;
        if (elementType.isPtr) {
            node.become(new ConvertPtrToArrayRefExpression(node.origin, node.lValue));
            let /*<@3>*/addressSpace_ = elementType.addressSpace;
            let /*<@373>*/ptrType = (/*<@373>*/elementType);
            let /*<@85>*/elementType_ = ptrType.elementType;
            return new ArrayRefType(node.origin, addressSpace_, elementType_);
        }
        if (!node./*<@120>*/lValue.isLValue)
            throw new WTypeError(node.origin.originString, "Operand to @ is not an LValue: " + node.lValue + node.lValue.notLValueReasonString);
        if (elementType.isArray) {
            node.numElements = /*<@392>*/elementType.numElements;
            elementType = /*<@392>*/elementType.elementType;
        }
        else
            node.numElements = UintLiteral.withType(node.origin, 1, this._program.intrinsics.uint32);
        return new ArrayRefType(node.origin, node.lValue.addressSpace, elementType);
    }
    /*<@886>*/visitConvertToArrayRefExpression(/*<@491>*/node) {
        throw new Error("Should not exist yet.");
    }
    /*<@887>*/_finishVisitingPropertyAccess(/*<@435>*/node, /*<@85>*/baseType, /*<@101>*/extraArgs, /*<@136>*/extraArgTypes) {
        baseType = baseType.visit(new AutoWrapper());
        node.baseType = baseType;
        // Such a type must exist. This may throw if it doesn't.
        let /*<@85>*/typeForAnd = baseType.argumentTypeForAndOverload(node.origin);
        if (!typeForAnd)
            throw new Error("Cannot get typeForAnd");
        let /*<@449>*/errorForGet;
        let /*<@449>*/errorForAnd;
        try {
            let result = CallExpression.resolve(node.origin, node./*<@143>*/possibleGetOverloads, this./*<@114>*/_currentStatement.typeParameters, node.getFuncName, /*<@784>*/[], /*<@784>*/[node.base, ...extraArgs], /*<@136>*/[baseType, ...extraArgTypes], null);
            node.callForGet = result.call;
            node.resultTypeForGet = result.resultType;
        }
        catch (e) {
            if (!(e instanceof WTypeError))
                throw e;
            errorForGet = e;
        }
        try {
            let /*<@7>*/baseForAnd = baseType.argumentForAndOverload(node.origin, node.base);
            let result = CallExpression.resolve(node.origin, node./*<@143>*/possibleAndOverloads, this./*<@114>*/_currentStatement.typeParameters, node.andFuncName, /*<@784>*/[], /*<@101>*/[baseForAnd, ...extraArgs], /*<@136>*/[typeForAnd, ...extraArgTypes], null);
            node.callForAnd = result.call;
            node.resultTypeForAnd = result.resultType./*<@85>*/unifyNode.returnTypeFromAndOverload(node.origin);
        }
        catch (e) {
            if (!(e instanceof WTypeError))
                throw e;
            errorForAnd = e;
        }
        if (!node.resultTypeForGet && !node.resultTypeForAnd) {
            throw new WTypeError(node.origin.originString, "Cannot resolve access; tried by-value:\n" +
                errorForGet.typeErrorMessage + "\n" +
                "and tried by-pointer:\n" +
                errorForAnd.typeErrorMessage);
        }
        if (node.resultTypeForGet && node.resultTypeForAnd
            && !node.resultTypeForGet.equals(node.resultTypeForAnd))
            throw new WTypeError(node.origin.originString, "Result type resolved by-value (" + node.resultTypeForGet + ") does not match result type resolved by-pointer (" + node.resultTypeForAnd + ")");
        try {
            let result = CallExpression.resolve(node.origin, node./*<@143>*/possibleSetOverloads, this./*<@114>*/_currentStatement.typeParameters, node.setFuncName, /*<@784>*/[], /*<@784>*/[node.base, ...extraArgs, null], /*<@136>*/[baseType, ...extraArgTypes, node.resultType], null);
            node.callForSet = result.call;
            if (!result.resultType.equals(baseType))
                throw new WTypeError(node.origin.originString, "Result type of setter " + result.call.func + " is not the base type " + baseType);
        }
        catch (e) {
            if (!(e instanceof WTypeError))
                throw e;
            node.errorForSet = e;
        }
        // OK, now we need to determine if we are an lvalue. We are an lvalue if we can be assigned to. We can
        // be assigned to if we have an ander or setter. But it's weirder than that. We also need the base to be
        // an lvalue, except unless the base is an array reference.
        if (!node.callForAnd && !node.callForSet) {
            node.isLValue = false;
            node.notLValueReason =
                "Have neither ander nor setter. Tried setter:\n" +
                    node.errorForSet.typeErrorMessage + "\n" +
                    "and tried ander:\n" +
                    errorForAnd.typeErrorMessage;
        }
        else if (!node.base.isLValue && !baseType.isArrayRef) {
            node.isLValue = false;
            node.notLValueReason = "Base of property access is neither a lvalue nor an array reference";
        }
        else {
            node.isLValue = true;
            node.addressSpace = node.base.isLValue ? node.base.addressSpace : baseType.addressSpace;
        }
        return node.resultType;
    }
    /*<@888>*/visitDotExpression(/*<@466>*/node) {
        let /*<@280>*/structType = node.struct.visit(this)./*<@280>*/unifyNode;
        return this._finishVisitingPropertyAccess(node, structType, /*<@784>*/[], /*<@784>*/[]);
    }
    /*<@889>*/visitIndexExpression(/*<@475>*/node) {
        let /*<@85>*/arrayType = node.array.visit(this)./*<@85>*/unifyNode;
        let /*<@85>*/indexType = node.index.visit(this);
        return this._finishVisitingPropertyAccess(node, arrayType, /*<@340>*/[node.index], /*<@136>*/[indexType]);
    }
    /*<@890>*/visitVariableRef(/*<@418>*/node) {
        if (!node.variable.type)
            throw new Error("Variable has no type: " + node.variable);
        return node.variable.type;
    }
    /*<@891>*/visitReturn(/*<@497>*/node) {
        if (node.value) {
            let /*<@85>*/resultType = node.value.visit(this);
            if (!resultType)
                throw new Error("Null result type from " + node.value);
            if (!node.func.returnType.equalsWithCommit(resultType))
                throw new WTypeError(node.origin.originString, "Trying to return " + resultType + " in a function that returns " + node.func.returnType);
            return;
        }
        if (!node.func.returnType.equalsWithCommit(this._program.intrinsics.void))
            throw new WTypeError(node.origin.originString, "Non-void function must return a value");
    }
    /*<@892>*/visitGenericLiteral(/*<@514>*/node) {
        return node.type;
    }
    /*<@893>*/visitNullLiteral(/*<@548>*/node) {
        return node.type;
    }
    /*<@894>*/visitBoolLiteral(/*<@542>*/node) {
        return this._program.intrinsics.bool;
    }
    /*<@895>*/visitEnumLiteral(/*<@359>*/node) {
        return node.member.enumType;
    }
    /*<@896>*/_requireBool(/*<@303>*/expression) {
        let /*<@85>*/type = expression.visit(this);
        if (!type)
            throw new Error("Expression has no type, but should be bool: " + expression);
        if (!type.equals(this._program.intrinsics.bool))
            throw new WTypeError(expression.origin.originString, "Expression isn't a bool: " + expression);
    }
    /*<@897>*/visitLogicalNot(/*<@573>*/node) {
        this._requireBool(node.operand);
        return this._program.intrinsics.bool;
    }
    /*<@898>*/visitLogicalExpression(/*<@579>*/node) {
        this._requireBool(node.left);
        this._requireBool(node.right);
        return this._program.intrinsics.bool;
    }
    /*<@899>*/visitIfStatement(/*<@586>*/node) {
        this._requireBool(node.conditional);
        node.body.visit(this);
        if (node.elseBody)
            node.elseBody.visit(this);
    }
    /*<@900>*/visitWhileLoop(/*<@593>*/node) {
        this._requireBool(node.conditional);
        node.body.visit(this);
    }
    /*<@901>*/visitDoWhileLoop(/*<@599>*/node) {
        node.body.visit(this);
        this._requireBool(node.conditional);
    }
    /*<@902>*/visitForLoop(/*<@605>*/node) {
        if (node.initialization)
            node.initialization.visit(this);
        if (node.condition)
            this._requireBool(node.condition);
        if (node.increment)
            node.increment.visit(this);
        node.body.visit(this);
    }
    /*<@903>*/visitSwitchStatement(/*<@613>*/node) {
        let /*<@85>*/type = node.value.visit(this).commit();
        if (!type./*<@85>*/unifyNode.isInt && !(type.unifyNode instanceof EnumType))
            throw new WTypeError(node.origin.originString, "Cannot switch on non-integer/non-enum type: " + type);
        node.type = type;
        let /*<@2>*/hasDefault = false;
        for (let /*<@615>*/switchCase of node.switchCases) {
            switchCase.body.visit(this);
            if (switchCase.isDefault) {
                hasDefault = true;
                continue;
            }
            if (!switchCase.value.isConstexpr)
                throw new WTypeError(switchCase.origin.originString, "Switch case not constexpr: " + switchCase.value);
            let /*<@85>*/caseType = switchCase.value.visit(this);
            if (!type.equalsWithCommit(caseType))
                throw new WTypeError(switchCase.origin.originString, "Switch case type does not match switch value type (case type is " + caseType + " but switch value type is " + type + ")");
        }
        for (let /*<@5>*/i = 0; i < node.switchCases.length; ++i) {
            let /*<@615>*/firstCase = node.switchCases[i];
            for (let /*<@5>*/j = i + 1; j < node.switchCases.length; ++j) {
                let /*<@615>*/secondCase = node.switchCases[j];
                if (firstCase.isDefault != secondCase.isDefault)
                    continue;
                if (firstCase.isDefault)
                    throw new WTypeError(secondCase.origin.originString, "Duplicate default case in switch statement");
                let /*<@2>*/valuesEqual = type./*<@85>*/unifyNode.valuesEqual(firstCase.value./*<@918>*/unifyNode.valueForSelectedType, secondCase.value./*<@918>*/unifyNode.valueForSelectedType);
                if (valuesEqual)
                    throw new WTypeError(secondCase.origin.originString, "Duplicate case in switch statement for value " + firstCase.value./*<@514>*/unifyNode.valueForSelectedType);
            }
        }
        if (!hasDefault) {
            let /*<@78>*/includedValues = new Set();
            for (let /*<@615>*/switchCase of node.switchCases)
                includedValues.add(switchCase.value./*<@918>*/unifyNode.valueForSelectedType);
            for (let { /*<@1>*/value, name } of type./*<@85>*/unifyNode.allValues()) {
                if (!includedValues.has(value))
                    throw new WTypeError(node.origin.originString, "Value not handled by switch statement: " + name);
            }
        }
    }
    /*<@904>*/visitCommaExpression(/*<@338>*/node) {
        let /*<@7>*/result = null;
        for (let /*<@303>*/expression of node.list)
            result = /*<@7>*/expression.visit(this);
        return result;
    }
    /*<@905>*/visitCallExpression(/*<@437>*/node) {
        let /*<@136>*/typeArguments = node.typeArguments.map(/*<@919>*/typeArgument => typeArgument.visit(this));
        let /*<@920>*/argumentTypes = node.argumentList.map(/*<@921>*/argument => {
            let /*<@7>*/newArgument = argument.visit(this);
            if (!newArgument)
                throw new Error("visitor returned null for " + argument);
            return newArgument.visit(new AutoWrapper());
        });
        node.argumentTypes = argumentTypes;
        if (node.returnType)
            node.returnType.visit(this);
        let /*<@85>*/result = node.resolve(node.possibleOverloads, this./*<@114>*/_currentStatement.typeParameters, typeArguments);
        return result;
    }
}
function /*<@922>*/cloneProgram(/*<@71>*/program) {
    let /*<@71>*/result = new Program();
    let /*<@923>*/cloner = new StatementCloner();
    for (let /*<@7>*/statement of program.topLevelStatements)
        result.add(statement.visit(cloner));
    return result;
}
class /*<@339>*/CommaExpression extends Expression {
    constructor(/*<@42>*/origin, /*<@340>*/list) {
        super(origin);
        this._list = list;
        for (let /*<@303>*/expression of list) {
            if (!expression)
                throw new Error("null expression");
        }
    }
    get /*<@341>*/list() { return this._list; }
    // NOTE: It's super tempting to say that CommaExpression is an lValue if its last entry is an lValue. But,
    // PropertyResolver relies on this not being the case.
    /*<@342>*/toString() {
        return "(" + this.list.toString() + ")";
    }
}
class /*<@941>*/ConstexprFolder extends Visitor {
    /*<@942>*/visitCallExpression(/*<@437>*/node) {
        super.visitCallExpression(node);
        if (node.name == "operator-"
            && !node.typeArguments.length
            && node.argumentList.length == 1
            && node.argumentList[0]./*<@120>*/unifyNode.isConstexpr
            && node.argumentList[0]./*<@514>*/unifyNode.negConstexpr) {
            node.become(node.argumentList[0]./*<@514>*/unifyNode.negConstexpr(node.origin));
            return;
        }
    }
    /*<@943>*/visitTypeOrVariableRef(/*<@936>*/node) {
    }
}
class /*<@252>*/ConstexprTypeParameter extends Value {
    constructor(/*<@42>*/origin, /*<@3>*/name, /*<@85>*/type) {
        super();
        this._origin = origin;
        this._name = name;
        this._type = type;
    }
    get /*<@253>*/isConstexpr() {
        if (this.hasBecome)
            return this.target.isConstexpr;
        return true;
    }
    get /*<@254>*/isUnifiable() { return true; }
    get /*<@255>*/varIsLValue() { return false; }
    /*<@256>*/typeVariableUnify(/*<@153>*/unificationContext, /*<@120>*/other) {
        if (!(other instanceof Value))
            return false;
        if (!this.type.unify(unificationContext, other.type))
            return false;
        return this._typeVariableUnifyImpl(unificationContext, other);
    }
    /*<@257>*/unifyImpl(/*<@153>*/unificationContext, /*<@120>*/other) {
        return this.typeVariableUnify(unificationContext, other);
    }
    /*<@258>*/verifyAsArgument(/*<@153>*/unificationContext) {
        return /*<@785>*/{ result: true, reason: undefined };
    }
    /*<@259>*/verifyAsParameter(/*<@153>*/unificationContext) {
        return /*<@785>*/{ result: true, reason: undefined };
    }
    /*<@260>*/toString() {
        return this.type + " " + this.name;
    }
}
class /*<@503>*/Continue extends Node {
    constructor(/*<@42>*/origin) {
        super();
        this._origin = origin;
    }
    /*<@504>*/toString() {
        return "Continue";
    }
}
;
class /*<@492>*/ConvertPtrToArrayRefExpression extends Expression {
    constructor(/*<@42>*/origin, /*<@7>*/lValue) {
        super(origin);
        this._lValue = lValue;
    }
    get /*<@493>*/lValue() { return this._lValue; }
    /*<@494>*/toString() {
        return "@(" + this.lValue + ")";
    }
}
class /*<@430>*/DereferenceExpression extends Expression {
    constructor(/*<@42>*/origin, /*<@7>*/ptr, /*<@85>*/type = null, /*<@3>*/addressSpace = null) {
        super(origin);
        this._ptr = ptr;
        this.type = type;
        this.addressSpace = addressSpace;
    }
    get /*<@431>*/ptr() { return this._ptr; }
    get /*<@432>*/isLValue() {
        if (this.hasBecome)
            return this.target.isLValue;
        return true;
    }
    /*<@433>*/toString() {
        return "*(" + this.ptr + ")";
    }
}
class /*<@600>*/DoWhileLoop extends Node {
    constructor(/*<@42>*/origin, /*<@7>*/body, /*<@437>*/conditional) {
        super();
        this._origin = origin;
        this._body = body;
        this._conditional = conditional;
    }
    get /*<@601>*/body() { return this._body; }
    get /*<@602>*/conditional() { return this._conditional; }
    /*<@603>*/toString() {
        return "do " + this.body + " while (" + this.conditional + ");";
    }
}
;
class /*<@467>*/DotExpression extends PropertyAccessExpression {
    constructor(/*<@42>*/origin, /*<@303>*/struct, /*<@3>*/fieldName) {
        super(origin, struct);
        this._fieldName = fieldName;
    }
    get /*<@468>*/struct() { return this.base; }
    get /*<@469>*/fieldName() { return this._fieldName; }
    get /*<@470>*/getFuncName() { return "operator." + this.fieldName; }
    get /*<@471>*/andFuncName() { return "operator&." + this.fieldName; }
    get /*<@472>*/setFuncName() { return "operator." + this.fieldName + "="; }
    /*<@473>*/toString() {
        return "(" + this.struct + "." + this.fieldName + ")";
    }
}
class /*<@48>*/EArrayRef {
    constructor(/*<@43>*/ptr, /*<@5>*/length) {
        if (ptr === undefined) {
            throw new Error("EArrayRef ptr is undefined");
        }
        this._ptr = ptr;
        this._length = length;
    }
    get /*<@49>*/ptr() { return this._ptr; }
    get /*<@50>*/length() { return this._length; }
    /*<@51>*/toString() {
        return "A:<" + this.ptr + ", " + this.length + ">";
    }
}
let /*<@5>*/eBufferCount = 0;
let /*<@2>*/canAllocateEBuffers = true;
class /*<@46>*/EBuffer {
    constructor(/*<@5>*/size) {
        if (!canAllocateEBuffers)
            throw new Error("Trying to allocate EBuffer while allocation is disallowed");
        this._index = eBufferCount++;
        this._array = new /*<@53>*/Array(size);
    }
    static /*<@54>*/setCanAllocateEBuffers(/*<@2>*/value, callback) {
        let /*<@2>*/oldCanAllocateEBuffers = canAllocateEBuffers;
        canAllocateEBuffers = value;
        try {
            return callback();
        }
        finally {
            canAllocateEBuffers = oldCanAllocateEBuffers;
        }
    }
    static /*<@55>*/disallowAllocation(callback) {
        return EBuffer.setCanAllocateEBuffers(false, callback);
    }
    static /*<@56>*/allowAllocation(callback) {
        return EBuffer.setCanAllocateEBuffers(true, callback);
    }
    /*<@57>*/get(/*<@5>*/index) {
        if (index < 0 || index >= this._array.length)
            throw new Error("Out of bounds buffer access (buffer = " + this + ", index = " + index + ")");
        return this._array[index];
    }
    /*<@58>*/set(/*<@5>*/index, /*<@52>*/value) {
        if (index < 0 || index >= this._array.length)
            throw new Error("out of bounds buffer access (buffer = " + this + ", index = " + index + ")");
        this._array[index] = value;
    }
    get /*<@59>*/index() { return this._index; }
    /*<@60>*/toString() {
        return "B" + this._index + ":[" + this._array + "]";
    }
}
class /*<@945>*/EBufferBuilder extends Visitor {
    constructor(/*<@71>*/program) {
        super();
        this._program = program;
    }
    /*<@946>*/_createEPtr(/*<@85>*/type) {
        if (type.size == null)
            throw new Error("Type does not have size: " + type);
        let /*<@45>*/buffer = new EBuffer(type.size);
        if (!type.populateDefaultValue)
            throw new Error("Cannot populateDefaultValue with: " + type);
        type.populateDefaultValue(buffer, 0);
        return new EPtr(buffer, 0);
    }
    /*<@947>*/_createEPtrForNode(/*<@7>*/node) {
        if (!node.type)
            throw new Error("node has no type: " + node);
        node.ePtr = this._createEPtr(node.type);
    }
    /*<@948>*/visitFuncParameter(/*<@116>*/node) {
        this._createEPtrForNode(node);
    }
    /*<@949>*/visitVariableDecl(/*<@326>*/node) {
        this._createEPtrForNode(node);
        if (node.initializer)
            node.initializer.visit(this);
    }
    /*<@950>*/visitFuncDef(/*<@227>*/node) {
        node.returnEPtr = this._createEPtr(node.returnType);
        super.visitFuncDef(node);
    }
    /*<@951>*/visitFunctionLikeBlock(/*<@565>*/node) {
        node.returnEPtr = this._createEPtr(node.returnType);
        super.visitFunctionLikeBlock(node);
    }
    /*<@952>*/visitCallExpression(/*<@437>*/node) {
        node.resultEPtr = this._createEPtr(node.resultType);
        super.visitCallExpression(node);
    }
    /*<@953>*/visitMakePtrExpression(/*<@485>*/node) {
        node.ePtr = EPtr.box();
        super.visitMakePtrExpression(node);
    }
    /*<@954>*/visitGenericLiteral(/*<@514>*/node) {
        node.ePtr = EPtr.box();
    }
    /*<@955>*/visitNullLiteral(/*<@548>*/node) {
        node.ePtr = EPtr.box();
    }
    /*<@956>*/visitBoolLiteral(/*<@542>*/node) {
        node.ePtr = EPtr.box();
    }
    /*<@957>*/visitEnumLiteral(/*<@359>*/node) {
        node.ePtr = EPtr.box();
    }
    /*<@958>*/visitLogicalNot(/*<@573>*/node) {
        node.ePtr = EPtr.box();
        super.visitLogicalNot(node);
    }
    /*<@959>*/visitLogicalExpression(/*<@579>*/node) {
        node.ePtr = EPtr.box();
        super.visitLogicalExpression(node);
    }
    /*<@960>*/visitAnonymousVariable(/*<@413>*/node) {
        this._createEPtrForNode(node);
    }
    /*<@961>*/visitMakeArrayRefExpression(/*<@377>*/node) {
        node.ePtr = EPtr.box();
        super.visitMakeArrayRefExpression(node);
    }
    /*<@962>*/visitConvertPtrToArrayRefExpression(/*<@491>*/node) {
        node.ePtr = EPtr.box();
        super.visitConvertPtrToArrayRefExpression(node);
    }
}
class /*<@44>*/EPtr {
    constructor(/*<@45>*/buffer, /*<@5>*/offset) {
        if (offset == null || offset != offset)
            throw new Error("Bad offset: " + offset);
        this._buffer = buffer;
        this._offset = offset;
    }
    // The interpreter always passes around pointers to things. This means that sometimes we will
    // want to return a value but we have to "invent" a pointer to that value. No problem, this
    // function is here to help.
    //
    // In a real execution environment, uses of this manifest as SSA temporaries.
    static /*<@61>*/box(/*<@52>*/value) {
        return new EPtr(new EBuffer(1), 0).box(value);
    }
    /*<@62>*/box(/*<@52>*/value) {
        this._buffer.set(0, value);
        return this;
    }
    get /*<@63>*/buffer() { return this._buffer; }
    get /*<@64>*/offset() { return this._offset; }
    /*<@65>*/plus(/*<@5>*/offset) {
        return new EPtr(this.buffer, this.offset + offset);
    }
    /*<@66>*/loadValue() {
        return this.buffer.get(this.offset);
    }
    /*<@67>*/get(/*<@5>*/offset) {
        return this.buffer.get(this.offset + offset);
    }
    /*<@68>*/set(/*<@5>*/offset, /*<@52>*/value) {
        this.buffer.set(this.offset + offset, value);
    }
    /*<@69>*/copyFrom(/*<@43>*/other, /*<@5>*/size) {
        if (size == null)
            throw new Error("Cannot copy null size");
        for (let /*<@5>*/i = size; i--;)
            this.set(i, other.get(i));
    }
    /*<@70>*/toString() {
        return "B" + this.buffer.index + ":" + this.offset;
    }
}
/*
 * Copyright (C) 2017 Apple Inc. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY APPLE INC. ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE INC. OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
"use strict";
class /*<@360>*/EnumLiteral extends Expression {
    constructor(/*<@42>*/origin, /*<@301>*/member) {
        super(origin);
        this._member = member;
        this.type = this.member.enumType;
    }
    get /*<@361>*/member() { return this._member; }
    // get type() { return this.member.enumType; }
    get /*<@362>*/isConstexpr() {
        if (this.hasBecome)
            return this.target.isConstexpr;
        return true;
    }
    /*<@363>*/unifyImpl(/*<@153>*/unificationContext, /*<@359>*/other) {
        if (!(other instanceof EnumLiteral))
            return false;
        return this.member == other.member;
    }
    get /*<@364>*/valueForSelectedType() {
        return this.member.value./*<@514>*/unifyNode.valueForSelectedType;
    }
    /*<@365>*/toString() {
        return this.member.enumType.name + "." + this.member.name;
    }
}
class /*<@302>*/EnumMember extends Node {
    constructor(/*<@42>*/origin, /*<@3>*/name, /*<@303>*/value) {
        super();
        this._origin = origin;
        this._name = name;
        this.value = value;
    }
    /*<@305>*/toString() {
        let /*<@3>*/result = this.name;
        if (this.value)
            result += " = " + this.value;
        return result;
    }
}
function /*<@963>*/EnumTypePopulate(/*<@45>*/buffer, /*<@5>*/offset) {
    this.baseType.populateDefaultValue(buffer, offset);
}
class /*<@299>*/EnumType extends Type {
    constructor(/*<@42>*/origin, /*<@3>*/name, /*<@85>*/baseType) {
        super();
        this._origin = origin;
        this._name = name;
        this._baseType = baseType;
        this._members = new Map();
        this.allValues = function* /*<@964>*/() {
            for (let member of this.members)
                yield /*<@965>*/{ value: member.value./*<@514>*/unifyNode.valueForSelectedType, name: member.name };
        };
        this.valuesEqual = /*<@966>*/(/*<@1>*/a, /*<@1>*/b) => { return this.baseType./*<@85>*/unifyNode.valuesEqual(a, b); };
        this.populateDefaultValue = EnumTypePopulate;
    }
    /*<@300>*/add(/*<@301>*/member) {
        if (this._members.has(member.name))
            throw new WTypeError(member.origin.originString, "Duplicate enum member name: " + member.name);
        member.enumType = this;
        this._members.set(member.name, member);
    }
    get /*<@306>*/baseType() { return this._baseType; }
    get /*<@307>*/memberNames() { return this._members.keys(); }
    /*<@308>*/memberByName(/*<@3>*/name) { return this._members.get(name); }
    get /*<@309>*/members() { return this._members.values(); }
    get /*<@310>*/memberMap() { return this._members; }
    get /*<@311>*/isPrimitive() { return true; }
    get /*<@312>*/size() { return this.baseType.size; }
    /*<@313>*/toString() {
        return "enum " + this.name + " : " + this.baseType + " { " + Array.from(this.members).join(",") + " }";
    }
}
/*
 * Copyright (C) 2017 Apple Inc. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY APPLE INC. ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE INC. OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
"use strict";
const /*<@967>*/BreakException = Symbol("BreakException");
const /*<@967>*/ContinueException = Symbol("ContinueException");
/*
 * Copyright (C) 2017 Apple Inc. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY APPLE INC. ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE INC. OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
"use strict";
// This is a combined LHS/RHS evaluator that passes around EPtr's to everything.
class /*<@969>*/Evaluator extends Visitor {
    constructor(/*<@71>*/program) {
        super();
        this._program = program;
    }
    // You must snapshot if you use a value in rvalue context. For example, a call expression will
    // snapshot all of its arguments immedaitely upon executing them. In general, it should not be
    // possible for a pointer returned from a visit method in rvalue context to live across any effects.
    /*<@970>*/_snapshot(/*<@85>*/type, /*<@43>*/dstPtr, /*<@43>*/srcPtr) {
        let /*<@5>*/size = type.size;
        if (size == null)
            throw new Error("Cannot get size of type: " + type + " (size = " + size + ", constructor = " + type.constructor.name + ")");
        if (!dstPtr)
            dstPtr = new EPtr(new EBuffer(size), 0);
        dstPtr.copyFrom(srcPtr, size);
        return dstPtr;
    }
    /*<@971>*/runFunc(/*<@227>*/func) {
        return EBuffer.disallowAllocation(/*<@1000>*/() => this._runBody(func.returnType, func.returnEPtr, func.body));
    }
    /*<@972>*/_runBody(/*<@85>*/type, /*<@43>*/ptr, /*<@7>*/block) {
        if (!ptr)
            throw new Error("Null ptr");
        try {
            block.visit(this);
            // FIXME: We should have a check that there is no way to drop out of a function without
            // returning unless the function returns void.
            return null;
        }
        catch (e) {
            if (e == BreakException || e == ContinueException)
                throw new Error("Should not see break/continue at function scope");
            if (e instanceof ReturnException) {
                let /*<@43>*/result = this._snapshot(type, ptr, e.value);
                return result;
            }
            throw e;
        }
    }
    /*<@973>*/visitFunctionLikeBlock(/*<@565>*/node) {
        for (let /*<@5>*/i = 0; i < node.argumentList.length; ++i) {
            node.parameters[i].ePtr.copyFrom(node.argumentList[i].visit(this), node.parameters[i].type.size);
        }
        let /*<@43>*/result = this._runBody(node.returnType, node.returnEPtr, node.body);
        return result;
    }
    /*<@974>*/visitReturn(/*<@497>*/node) {
        throw new ReturnException(node.value ? node.value.visit(this) : null);
    }
    /*<@975>*/visitVariableDecl(/*<@326>*/node) {
        if (!node.ePtr.buffer)
            throw new Error("eptr without buffer in " + node);
        node.type.populateDefaultValue(node.ePtr.buffer, node.ePtr.offset);
        if (node.initializer)
            node.ePtr.copyFrom(node.initializer.visit(this), node.type.size);
    }
    /*<@976>*/visitAssignment(/*<@405>*/node) {
        let /*<@43>*/target = node.lhs.visit(this);
        let /*<@43>*/source = node.rhs.visit(this);
        target.copyFrom(source, node.type.size);
        return target;
    }
    /*<@977>*/visitIdentityExpression(/*<@7>*/node) {
        return node.target.visit(this);
    }
    /*<@978>*/visitDereferenceExpression(/*<@429>*/node) {
        let /*<@7>*/ptr = node.ptr.visit(this).loadValue();
        if (!ptr)
            throw new WTrapError(node.origin.originString, "Null dereference");
        return ptr;
    }
    /*<@979>*/visitMakePtrExpression(/*<@485>*/node) {
        let /*<@120>*/ptr = node.lValue.visit(this);
        return node.ePtr.box(ptr);
    }
    /*<@980>*/visitMakeArrayRefExpression(/*<@377>*/node) {
        // print("xxxx " + node.lValue.constructor.name);
        node.lValue.constructor.name;
        return node.ePtr.box(new EArrayRef(node.lValue.visit(this), node.numElements.visit(this).loadValue()));
    }
    /*<@981>*/visitConvertPtrToArrayRefExpression(/*<@491>*/node) {
        return node.ePtr.box(new EArrayRef(node.lValue.visit(this).loadValue(), 1));
    }
    /*<@982>*/visitCommaExpression(/*<@338>*/node) {
        let /*<@7>*/result;
        for (let /*<@303>*/expression of node.list)
            result = /*<@7>*/expression.visit(this);
        // This should almost snapshot, except that tail-returning a pointer is totally OK.
        return result;
    }
    /*<@983>*/visitVariableRef(/*<@418>*/node) {
        return node.variable.ePtr;
    }
    /*<@984>*/visitGenericLiteral(/*<@514>*/node) {
        return node.ePtr.box(node.valueForSelectedType);
    }
    /*<@985>*/visitNullLiteral(/*<@548>*/node) {
        return node.ePtr.box(null);
    }
    /*<@986>*/visitBoolLiteral(/*<@542>*/node) {
        return node.ePtr.box(node.value);
    }
    /*<@987>*/visitEnumLiteral(/*<@359>*/node) {
        return node.ePtr.box(node.member.value./*<@514>*/unifyNode.valueForSelectedType);
    }
    /*<@988>*/visitLogicalNot(/*<@573>*/node) {
        let /*<@2>*/result = !node.operand.visit(this).loadValue();
        return node.ePtr.box(result);
    }
    /*<@989>*/visitLogicalExpression(/*<@579>*/node) {
        let /*<@1>*/lhs = (node.left.visit(this).loadValue());
        let /*<@1>*/rhs = (node.right.visit(this).loadValue());
        let /*<@1>*/result;
        switch (node.text) {
            case "&&":
                result = lhs && rhs;
                break;
            case "||":
                result = lhs || rhs;
                break;
            default:
                throw new Error("Unknown type of logical expression");
        }
        return node.ePtr.box(result);
    }
    /*<@990>*/visitIfStatement(/*<@586>*/node) {
        if (node.conditional.visit(this).loadValue())
            return node.body.visit(this);
        else if (node.elseBody)
            return node.elseBody.visit(this);
    }
    /*<@991>*/visitWhileLoop(/*<@593>*/node) {
        while (node.conditional.visit(this).loadValue()) {
            try {
                node.body.visit(this);
            }
            catch (e) {
                if (e == BreakException)
                    break;
                if (e == ContinueException)
                    continue;
                throw e;
            }
        }
    }
    /*<@992>*/visitDoWhileLoop(/*<@599>*/node) {
        do {
            try {
                node.body.visit(this);
            }
            catch (e) {
                if (e == BreakException)
                    break;
                if (e == ContinueException)
                    continue;
                throw e;
            }
        } while (node.conditional.visit(this).loadValue());
    }
    /*<@993>*/visitForLoop(/*<@605>*/node) {
        for (node.initialization ? node.initialization.visit(this) : true; node.condition ? node.condition.visit(this).loadValue() : true; node.increment ? node.increment.visit(this) : true) {
            try {
                node.body.visit(this);
            }
            catch (e) {
                if (e == BreakException)
                    break;
                if (e == ContinueException)
                    continue;
                throw e;
            }
        }
    }
    /*<@994>*/visitSwitchStatement(/*<@613>*/node) {
        let /*<@1001>*/findAndRunCast = /*<@1001>*/(predicate) => {
            for (let /*<@5>*/i = 0; i < node.switchCases.length; ++i) {
                let /*<@615>*/switchCase = node.switchCases[i];
                if (predicate(switchCase)) {
                    try {
                        for (let /*<@5>*/j = i; j < node.switchCases.length; ++j)
                            node.switchCases[j].visit(this);
                    }
                    catch (e) {
                        if (e != BreakException)
                            throw e;
                    }
                    return true;
                }
            }
            return false;
        };
        let /*<@52>*/value = node.value.visit(this).loadValue();
        let /*<@2>*/found = findAndRunCast(/*<@1002>*/switchCase => {
            if (switchCase.isDefault)
                return false;
            return node.type./*<@85>*/unifyNode.valuesEqual(/*<@1>*/value, switchCase.value./*<@1003>*/unifyNode.valueForSelectedType);
        });
        if (found)
            return;
        found = findAndRunCast(/*<@1004>*/switchCase => switchCase.isDefault);
        if (!found)
            throw new Error("Switch statement did not find case");
    }
    /*<@995>*/visitBreak(/*<@506>*/node) {
        throw BreakException;
    }
    /*<@996>*/visitContinue(/*<@502>*/node) {
        throw ContinueException;
    }
    /*<@997>*/visitTrapStatement(/*<@510>*/node) {
        throw new WTrapError(node.origin.originString, "Trap statement");
    }
    /*<@998>*/visitAnonymousVariable(/*<@413>*/node) {
        node.type.populateDefaultValue(node.ePtr.buffer, node.ePtr.offset);
    }
    /*<@999>*/visitCallExpression(/*<@437>*/node) {
        // We evaluate inlined ASTs, so this can only be a native call.
        let /*<@784>*/callArguments = /*<@784>*/[];
        for (let /*<@5>*/i = 0; i < node.argumentList.length; ++i) {
            let /*<@7>*/argument = node.argumentList[i];
            let /*<@85>*/type = node.nativeFuncInstance.parameterTypes[i];
            if (!type || !argument)
                throw new Error("Cannot get type or argument; i = " + i + ", argument = " + argument + ", type = " + type + "; in " + node);
            let /*<@43>*/argumentValue = argument.visit(this);
            if (!argumentValue)
                throw new Error("Null argument value, i = " + i + ", node = " + node);
            callArguments.push(/*<@1005>*/() => {
                let /*<@43>*/result = this._snapshot(type, null, argumentValue);
                return result;
            });
        }
        // For simplicity, we allow intrinsics to just allocate new buffers, and we allocate new
        // buffers when snapshotting their arguments. This is not observable to the user, so it's OK.
        let /*<@43>*/result = EBuffer.allowAllocation(/*<@1006>*/() => node.func.implementation(callArguments.map(/*<@1007>*/(/*<@1008>*/thunk) => { let /*<@1008>*/thunkFunc = thunk; return thunkFunc(); }), node));
        result = this._snapshot(node.nativeFuncInstance.returnType, node.resultEPtr, result);
        return result;
    }
}
class /*<@1010>*/ExpressionFinder extends Visitor {
    constructor(callback) {
        super();
        this._callback = callback;
    }
    /*<@1011>*/visitFunc(/*<@114>*/node) {
        this._callback(node.returnType);
        for (let /*<@7>*/typeParameter of node.typeParameters)
            typeParameter.visit(this);
        for (let /*<@116>*/parameter of node.parameters)
            parameter.visit(this);
    }
    /*<@1012>*/visitFuncParameter(/*<@116>*/node) {
        this._callback(node.type);
    }
    /*<@1013>*/visitConstexprTypeParameter(/*<@251>*/node) {
        this._callback(node.type);
    }
    /*<@1014>*/visitAssignment(/*<@405>*/node) {
        this._callback(node);
    }
    /*<@1015>*/visitReadModifyWriteExpression(/*<@411>*/node) {
        this._callback(node);
    }
    /*<@1016>*/visitIdentityExpression(/*<@7>*/node) {
        this._callback(node);
    }
    /*<@1017>*/visitCallExpression(/*<@437>*/node) {
        this._callback(node);
    }
    /*<@1018>*/visitReturn(/*<@497>*/node) {
        if (node.value)
            this._callback(node.value);
    }
    /*<@1019>*/visitWhileLoop(/*<@593>*/node) {
        this._callback(node.conditional);
        node.body.visit(this);
    }
    /*<@1020>*/visitDoWhileLoop(/*<@599>*/node) {
        node.body.visit(this);
        this._callback(node.conditional);
    }
    /*<@1021>*/visitIfStatement(/*<@586>*/node) {
        this._callback(node.conditional);
        node.body.visit(this);
        if (node.elseBody)
            node.elseBody.visit(this);
    }
    /*<@1022>*/visitForLoop(/*<@605>*/node) {
        // Initialization is a statement, not an expression. If it's an assignment or variableDecl, we'll
        // catch it and redirect to the callback.
        if (node.initialization)
            node.initialization.visit(this);
        if (node.condition)
            this._callback(node.condition);
        if (node.increment)
            this._callback(node.increment);
        node.body.visit(this);
    }
    /*<@1023>*/visitVariableDecl(/*<@326>*/node) {
        this._callback(node.type);
        if (node.initializer)
            this._callback(node.initializer);
    }
}
class /*<@41>*/ExternalOrigin {
    constructor(/*<@3>*/originString, /*<@3>*/originKind) {
        this.originString = originString;
        this.originKind = originKind;
    }
}
const /*<@40>*/externalOrigin = new ExternalOrigin("<external>", "user");
class /*<@285>*/Field extends Node {
    constructor(/*<@42>*/origin, /*<@3>*/name, /*<@85>*/type) {
        super();
        this._origin = origin;
        this._name = name;
        this._type = type;
    }
    /*<@286>*/toString() {
        return this.type + " " + this.name;
    }
}
function /*<@1024>*/findHighZombies(/*<@71>*/program) {
    program.visit(new HighZombieFinder());
}
function /*<@1025>*/flattenProtocolExtends(/*<@71>*/program) {
    let /*<@1026>*/visiting = new VisitingSet();
    function /*<@1029>*/flatten(/*<@109>*/protocol) {
        if (!protocol.extends.length)
            return;
        visiting.doVisit(protocol, /*<@1030>*/() => {
            for (let /*<@107>*/parent of protocol.extends) {
                let /*<@109>*/parentDecl = parent.protocolDecl;
                flattenFunc(parentDecl);
                for (let /*<@112>*/signature of parentDecl.signatures) {
                    let /*<@112>*/newSignature = signature.visit(new Substitution(/*<@1031>*/[parentDecl.typeVariable], /*<@1031>*/[protocol.typeVariable]));
                    protocol.add(newSignature);
                }
            }
            protocol.extends = /*<@784>*/[];
            return undefined;
        });
    }
    let /*<@1008>*/flattenFunc = flatten;
    for (let /*<@177>*/protocol of program.protocols.values())
        flattenFunc(/*<@109>*/protocol);
}
/*
class FlattenedStructOffsetGatherer extends Visitor {
    constructor(initial)
    {
        super();
        this._offset = 0;
        this._name = [initial];
        this._result = [];
    }

    get result()
    {
        return this._result;
    }

    visitReferenceType(node)
    {
    }

    visitField(node)
    {
        this._offset += node.offset;
        this._name.push(node.name);
        super.visitField(node);
        this._name.pop();
        this._offset -= node.offset;
    }

    visitNativeType(node)
    {
        this._result.push({name: this._name.join("."), offset: this._offset, type: node.name});
        super.visitNativeType(node);
    }

    visitTypeRef(node)
    {
        super.visitTypeRef(node);
        Node.visit(node.type, this);
    }
}
*/
function /*<@1032>*/foldConstexprs(/*<@71>*/program) {
    program.visit(new ConstexprFolder());
}
class /*<@606>*/ForLoop extends Node {
    constructor(/*<@42>*/origin, /*<@303>*/initialization, /*<@437>*/condition, /*<@303>*/increment, /*<@7>*/body) {
        super();
        this._origin = origin;
        this._initialization = initialization;
        this._condition = condition;
        this._increment = increment;
        this._body = body;
    }
    get /*<@607>*/initialization() { return this._initialization; }
    get /*<@608>*/condition() { return this._condition; }
    get /*<@609>*/increment() { return this._increment; }
    get /*<@610>*/body() { return this._body; }
    /*<@611>*/toString() {
        return "for (" + (this.initialization ? this.initialization : " ") + "; " + (this.condition ? this.condition : "") + "; " + (this.increment ? this.increment : "") + ") " + this.body;
    }
}
;
class /*<@115>*/Func extends Node {
    constructor(/*<@42>*/origin, /*<@3>*/name, /*<@85>*/returnType, /*<@101>*/typeParameters, /*<@130>*/parameters, /*<@2>*/isCast, /*<@3>*/shaderType) {
        if (!(origin instanceof LexerToken))
            throw new Error("Bad origin: " + origin);
        for (let /*<@116>*/parameter of parameters) {
            if (!parameter)
                throw new Error("Null parameter");
            if (!parameter.type)
                throw new Error("Null parameter type");
        }
        super();
        this._origin = origin;
        this._name = name;
        this._returnType = returnType;
        this._typeParameters = typeParameters;
        this._parameters = parameters;
        this._isCast = isCast;
        this._shaderType = shaderType;
    }
    get /*<@131>*/returnType() { return this._returnType; }
    get /*<@132>*/typeParameters() { return this._typeParameters; }
    get /*<@133>*/typeParametersForCallResolution() { return this.typeParameters; }
    get /*<@134>*/parameters() { return this._parameters; }
    get /*<@135>*/parameterTypes() { return this.parameters.map(/*<@1033>*/parameter => parameter.type); }
    get /*<@137>*/isCast() { return this._isCast; }
    get /*<@138>*/shaderType() { return this._shaderType; }
    get /*<@139>*/returnTypeForOverloadResolution() { return this.isCast ? this.returnType : null; }
    get /*<@140>*/kind() { return Func; }
    /*<@141>*/toDeclString() {
        let /*<@3>*/result = "";
        if (this.shaderType)
            result += this.shaderType + " ";
        if (this.isCast)
            result += "operator<" + this.typeParameters + "> " + this.returnType;
        else
            result += this.returnType + " " + this.name + "<" + this.typeParameters + ">";
        return result + "(" + this.parameters + ")";
    }
    /*<@142>*/toString() {
        return this.toDeclString();
    }
}
class /*<@228>*/FuncDef extends Func {
    constructor(/*<@42>*/origin, /*<@3>*/name, /*<@85>*/returnType, /*<@101>*/typeParameters, /*<@130>*/parameters, /*<@7>*/body, /*<@2>*/isCast, /*<@3>*/shaderType) {
        super(origin, name, returnType, typeParameters, parameters, isCast, shaderType);
        this._body = body;
        this.isRestricted = false;
    }
    get /*<@229>*/body() { return this._body; }
    /*<@230>*/rewrite(/*<@231>*/rewriter) {
        if (this._typeParameters.length)
            throw new Error("Cannot rewrite an uninstantiated function");
        this._returnType = this._returnType.visit(rewriter);
        this._parameters = this._parameters.map(/*<@1034>*/parameter => parameter.visit(rewriter));
        this._body = this.body.visit(rewriter);
    }
    /*<@636>*/toString() {
        return super.toString() + " " + this.body;
    }
}
class /*<@1036>*/FindTypeVariable extends Visitor {
    constructor(/*<@114>*/func, /*<@101>*/typeArguments) {
        super();
        this.func = func;
        this.typeArguments = typeArguments;
    }
    /*<@1037>*/visitTypeRef(/*<@345>*/node) {
        for (let /*<@7>*/typeArgument of node.typeArguments)
            typeArgument.visit(this);
    }
    /*<@1038>*/visitTypeVariable(/*<@146>*/node) {
        throw new Error("Unexpected type variable: " + node + " when instantiating " + this.func + " with arguments " + this.typeArguments);
    }
}
class /*<@693>*/Instantiate {
    constructor(/*<@694>*/substitution, /*<@702>*/instantiateImmediates) {
        this.substitution = substitution;
        this.instantiateImmediates = instantiateImmediates;
    }
    /*<@709>*/visitFuncDef(/*<@227>*/func) {
        let /*<@85>*/returnType = func.returnType.visit(this.substitution);
        returnType = returnType.visit(this.instantiateImmediates);
        let /*<@130>*/parameters = func.parameters.map(/*<@1039>*/parameter => parameter.visit(this.substitution));
        parameters = parameters.map(/*<@1040>*/parameter => parameter.visit(this.instantiateImmediates));
        let /*<@7>*/body = func.body.visit(this.substitution);
        body = body.visit(this.instantiateImmediates);
        return new FuncDef(func.origin, func.name, returnType, /*<@784>*/[], parameters, body, func.isCast, func.shaderType);
    }
    /*<@710>*/visitNativeFunc(/*<@237>*/func) {
        return new NativeFuncInstance(func, func.returnType.visit(this.substitution).visit(this.instantiateImmediates), func.parameters.map(/*<@1041>*/parameter => parameter.visit(this.substitution).visit(this.instantiateImmediates)), func.isCast, func.shaderType, func.instantiateImplementation(this.substitution));
    }
}
class /*<@201>*/FuncInstantiator {
    constructor(/*<@71>*/program) {
        this._program = program;
        this._instances = new Map();
    }
    // Returns a Func object that uniquely identifies a particular system of type arguments. You must
    // intantiate things with concrete types, because this code casually assumes this. Note that this
    // will return a different func from `func` no matter what. This ensures that we can use the
    // returned func for rewrites that instantiate types without destroying our ability to do overload
    // resolutions on the original Program.
    /*<@202>*/getUnique(/*<@114>*/func, /*<@101>*/typeArguments) {
        for (let /*<@7>*/typeArgument of typeArguments)
            typeArgument.visit(new FindTypeVariable(func, typeArguments));
        let /*<@784>*/instances = this._instances.get(func);
        if (!instances)
            this._instances.set(func, instances = /*<@784>*/[]);
        for (let instance of instances) {
            let /*<@2>*/ok = true;
            for (let /*<@1>*/i = instance.typeArguments.length; i--;) {
                if (!instance.typeArguments[i].equals(typeArguments[i])) {
                    ok = false;
                    break;
                }
            }
            if (!ok)
                continue;
            return instance.func;
        }
        let /*<@200>*/thisInstantiator = this;
        let /*<@694>*/substitution = new InstantiationSubstitution(this, func.typeParameters, typeArguments);
        let /*<@702>*/instantiateImmediates = new InstantiationInstantiateImmediates();
        let /*<@114>*/resultingFunc = func.visit(new Instantiate(substitution, instantiateImmediates));
        resultingFunc.uninstantiatedReturnType = func.returnType.visit(substitution);
        let /*<@772>*/instance = /*<@772>*/{ func: resultingFunc, typeArguments };
        instances.push(instance);
        return resultingFunc;
    }
}
class /*<@117>*/FuncParameter extends Value {
    // The name is optional. It's OK for it to be null!
    constructor(/*<@42>*/origin, /*<@3>*/name, /*<@85>*/type) {
        super();
        this._origin = origin;
        this._name = name;
        this._type = type;
    }
    get /*<@118>*/varIsLValue() { return true; }
    /*<@119>*/toString() {
        if (!this.name)
            return "" + this.type;
        return this.type + " " + this.name;
    }
}
class /*<@566>*/FunctionLikeBlock extends Value {
    constructor(/*<@42>*/origin, /*<@85>*/returnType, /*<@101>*/argumentList, /*<@130>*/parameters, /*<@7>*/body) {
        super();
        this._origin = origin;
        this._returnType = returnType;
        this._argumentList = argumentList;
        this._parameters = parameters;
        this._body = body;
    }
    get /*<@567>*/returnType() { return this._returnType; }
    get /*<@568>*/argumentList() { return this._argumentList; }
    get /*<@569>*/parameters() { return this._parameters; }
    get /*<@570>*/body() { return this._body; }
    /*<@571>*/toString() {
        return "([&] (" + this.parameters + ") -> " + this.returnType + " { " + this.body + " }(" + this.argumentList + "))";
    }
}
class /*<@1043>*/HighZombieFinder extends Visitor {
    /*<@1044>*/_found(/*<@7>*/node) {
        throw new Error(node._origin.originString + ": High zombie: " + node);
    }
    /*<@1045>*/visitDotExpression(/*<@466>*/node) {
        this._found(node);
    }
    /*<@1046>*/visitIndexExpression(/*<@475>*/node) {
        this._found(node);
    }
    /*<@1047>*/visitCallExpression(/*<@437>*/node) {
        super.visitCallExpression(node);
    }
}
class /*<@630>*/IdentityExpression extends Expression {
    constructor(/*<@7>*/target) {
        super(target.origin);
        this._target = target;
    }
    get /*<@631>*/unifyNode() { return this.target.unifyNode; }
    get /*<@632>*/isConstexpr() { return this.target.isConstexpr; }
    get /*<@633>*/isLValue() { return this.target.isLValue; }
    get /*<@634>*/addressSpace() { return this.target.addressSpace; }
    /*<@635>*/toString() {
        return "(" + this.target + ")";
    }
}
class /*<@587>*/IfStatement extends Node {
    constructor(/*<@42>*/origin, /*<@437>*/conditional, /*<@7>*/body, /*<@7>*/elseBody) {
        super();
        this._origin = origin;
        this._conditional = conditional;
        this._body = body;
        this._elseBody = elseBody;
    }
    get /*<@588>*/conditional() { return this._conditional; }
    get /*<@589>*/body() { return this._body; }
    get /*<@590>*/elseBody() { return this._elseBody; }
    /*<@591>*/toString() {
        let /*<@3>*/result = "if (" + this.conditional + ") " + this.body;
        if (this.elseBody)
            return result + " else " + this.elseBody;
        return result;
    }
}
;
class /*<@476>*/IndexExpression extends PropertyAccessExpression {
    constructor(/*<@42>*/origin, /*<@303>*/array, /*<@303>*/index) {
        super(origin, array);
        this._index = index;
    }
    get /*<@477>*/array() { return this.base; }
    get /*<@478>*/index() { return this._index; }
    get /*<@479>*/getFuncName() { return "operator[]"; }
    get /*<@480>*/andFuncName() { return "operator&[]"; }
    get /*<@481>*/setFuncName() { return "operator[]="; }
    /*<@482>*/updateCalls() {
        if (this.callForGet)
            this.callForGet.argumentList[1] = this.index;
        if (this.callForAnd)
            this.callForAnd.argumentList[1] = this.index;
        if (this.callForSet)
            this.callForSet.argumentList[1] = this.index;
        super.updateCalls();
    }
    /*<@483>*/toString() {
        return "(" + this.array + "[" + this.index + "])";
    }
}
function /*<@1048>*/inferTypesForCall(/*<@114>*/func, /*<@101>*/typeArguments, /*<@136>*/argumentTypes, /*<@85>*/returnType) {
    if (typeArguments.length && typeArguments.length != func.typeParameters.length)
        return /*<@770>*/{ failure: new OverloadResolutionFailure(func, "Wrong number of type arguments (passed " + typeArguments.length + ", require " + func.typeParameters.length + ")"), func: undefined };
    if (argumentTypes.length != func.parameters.length)
        return /*<@770>*/{ failure: new OverloadResolutionFailure(func, "Wrong number of arguments (passed " + argumentTypes.length + ", require " + func.parameters.length + ")"), func: undefined };
    let /*<@153>*/unificationContext = new UnificationContext(func.typeParametersForCallResolution);
    for (let /*<@5>*/i = 0; i < typeArguments.length; ++i) {
        let /*<@7>*/argument = typeArguments[i];
        let /*<@7>*/parameter = func.typeParameters[i];
        if (!argument.unify(unificationContext, parameter))
            return /*<@770>*/{ failure: new OverloadResolutionFailure(func, "Type argument #" + (i + 1) + " for parameter " + parameter.name + " does not match (passed " + argument + ", require " + parameter + ")"), func: undefined };
    }
    for (let /*<@5>*/i = 0; i < argumentTypes.length; ++i) {
        if (!argumentTypes[i])
            throw new Error("Null argument type at i = " + i);
        if (!argumentTypes[i].unify(unificationContext, func.parameters[i].type))
            return /*<@770>*/{ failure: new OverloadResolutionFailure(func, "Argument #" + (i + 1) + " " + (func.parameters[i].name ? "for parameter " + func.parameters[i].name + " " : "") + "does not match (passed " + argumentTypes[i] + ", require " + func.parameters[i].type + ")"), func: undefined };
    }
    if (returnType && !returnType.unify(unificationContext, func.returnType))
        return /*<@770>*/{ failure: new OverloadResolutionFailure(func, "Return type " + func.returnType + " does not match " + returnType), func: undefined };
    let verificationResult = unificationContext.verify();
    if (!verificationResult.result)
        return /*<@770>*/{ failure: new OverloadResolutionFailure(func, verificationResult.reason), func: undefined };
    let /*<@2>*/shouldBuildTypeArguments = !typeArguments.length;
    if (shouldBuildTypeArguments)
        typeArguments = /*<@784>*/[];
    for (let /*<@7>*/typeParameter of func.typeParameters) {
        let /*<@85>*/typeArgument = unificationContext.find(typeParameter);
        if (typeArgument == typeParameter)
            return /*<@770>*/{ failure: new OverloadResolutionFailure(func, "Type parameter " + typeParameter + " did not get assigned a type"), func: undefined };
        if (shouldBuildTypeArguments)
            typeArguments.push(typeArgument);
    }
    return /*<@762>*/{ failure: undefined, func, unificationContext, typeArguments };
}
function /*<@1049>*/inline(/*<@71>*/program) {
    for (let /*<@143>*/funcList of program.functions.values()) {
        for (let /*<@114>*/func of funcList) {
            if (!func.typeParameters.length) {
                func = program.funcInstantiator.getUnique(func, /*<@784>*/[]);
                _inlineFunction(program, func, new VisitingSet(func));
            }
        }
    }
}
function /*<@1050>*/_inlineFunction(/*<@71>*/program, /*<@114>*/func, /*<@1026>*/visiting) {
    if (func.typeParameters.length)
        throw new Error("Cannot inline function that has type parameters");
    if (func.inlined || func.isNative)
        return;
    func.visit(new LateChecker());
    // This is the precise time when we can build EBuffers in order to get them to be uniqued by
    // type instantiation but nothing else.
    func.visit(new StructLayoutBuilder());
    func.visit(new EBufferBuilder(program));
    /*<@227>*/func.rewrite(new Inliner(program, func, visiting));
    func.inlined = true;
}
function /*<@1051>*/resolveInlinedFunction(/*<@71>*/program, /*<@3>*/name, /*<@136>*/typeArguments, /*<@136>*/argumentTypes, /*<@2>*/allowEntryPoint = false) {
    let overload = program.globalNameContext.resolveFuncOverload(name, typeArguments, argumentTypes, undefined, allowEntryPoint);
    if (!overload.func)
        return overload.failures;
    if (!overload.func.typeParameters)
        return overload.func;
    let /*<@114>*/func = program.funcInstantiator.getUnique(overload.func, overload.typeArguments);
    _inlineFunction(program, func, new VisitingSet(overload.func));
    return func;
}
class /*<@1053>*/Inliner extends Rewriter {
    constructor(/*<@71>*/program, /*<@114>*/func, /*<@1026>*/visiting) {
        super();
        this._program = program;
        this._visiting = visiting;
    }
    /*<@1054>*/visitCallExpression(/*<@437>*/node) {
        let /*<@437>*/result = super.visitCallExpression(node);
        if (result.nativeFuncInstance)
            return result;
        return this._visiting.doVisit(node.func, /*<@1055>*/() => {
            let /*<@114>*/func = this._program.funcInstantiator.getUnique(result.func, result.actualTypeArguments);
            if (func.isNative)
                throw new Error("Unexpected native func: " + func);
            _inlineFunction(this._program, func, this._visiting);
            let /*<@565>*/resultingBlock = new FunctionLikeBlock(result.origin, func.returnType, result.argumentList, func.parameters, /*<@227>*/func.body);
            resultingBlock.returnEPtr = result.resultEPtr;
            return resultingBlock;
        });
    }
}
class /*<@706>*/InstantiateImmediates extends Rewriter {
    /*<@707>*/visitTypeRef(/*<@345>*/node) {
        node = super.visitTypeRef(node);
        if (!node.type.instantiate) {
            if (node.typeArguments.length)
                throw new Error("type does not support instantiation: " + node.type + " (" + node.type.constructor.name + ")");
            return node;
        }
        return node.type.instantiate(node.typeArguments).visit(new AutoWrapper());
    }
    /*<@708>*/visitReferenceType(/*<@367>*/node) {
        return node;
    }
}
class /*<@703>*/InstantiationInstantiateImmediates extends InstantiateImmediates {
    /*<@704>*/visitCallExpression(/*<@437>*/node) {
        // We need to preserve certain things that would have instantiated, but that we cannot
        // instantiate without breaking chain-instantiations (generic function calls generic
        // function so therefore the instantiated generic function must still have the original
        // (uninstantiated) types to instantiate the generic function that it calls).
        let /*<@437>*/result = new CallExpression(node.origin, node.name, node.typeArguments, node.argumentList.map(/*<@1056>*/(/*<@7>*/argument) => Node.visit(argument, this)));
        result = this.processDerivedCallData(node, result);
        result.argumentTypes = Array.from(node.argumentTypes);
        if (node.isCast)
            result.setCastData(node.returnType);
        result.actualTypeArguments = Array.from(node.actualTypeArguments);
        return result;
    }
}
class /*<@74>*/Intrinsics {
    constructor(/*<@75>*/nameContext) {
        this._map = new Map();
        // NOTE: Intrinsic resolution happens before type name resolution, so the strings we use here
        // to catch the intrinsics must be based on the type names that StandardLibraryPrologue.js uses.
        // For example, if a native function is declared using "int" rather than "int32", then we must
        // use "int" here, since we don't yet know that they are the same type.
        this._map.set("native typedef void<>", /*<@1057>*/type => {
            type = (/*<@85>*/type);
            this.void = type;
            type.size = 0;
            type.populateDefaultValue = /*<@1058>*/() => { };
        });
        function /*<@1059>*/isBitwiseEquivalent(/*<@1>*/left, /*<@1>*/right) {
            let /*<@1060>*/doubleArray = new Float64Array(1);
            let /*<@1061>*/intArray = new Int32Array(doubleArray.buffer);
            doubleArray[0] = left;
            let /*<@1061>*/leftInts = Int32Array.from(intArray);
            doubleArray[0] = right;
            for (let /*<@5>*/i = 0; i < 2; ++i) {
                if (leftInts[i] != intArray[i])
                    return false;
            }
            return true;
        }
        this._map.set("native typedef int32<>", /*<@1062>*/(/*<@85>*/type) => {
            this.int32 = type;
            type.isPrimitive = true;
            type.isInt = true;
            type.isNumber = true;
            type.isSigned = true;
            type.canRepresent = /*<@1063>*/value => isBitwiseEquivalent(value | 0, value);
            type.size = 1;
            type.defaultValue = 0;
            type.createLiteral = /*<@1064>*/(/*<@42>*/origin, /*<@1>*/value) => IntLiteral.withType(origin, value | 0, type);
            type.successorValue = /*<@1065>*/value => (value + 1) | 0;
            type.valuesEqual = /*<@1066>*/(/*<@1>*/a, /*<@1>*/b) => a === b;
            type.populateDefaultValue = /*<@1067>*/(/*<@45>*/buffer, /*<@1>*/offset) => buffer.set(offset, 0);
            type.formatValueFromIntLiteral = /*<@1068>*/value => value | 0;
            type.formatValueFromUintLiteral = /*<@1069>*/value => value | 0;
            type.allValues = function* /*<@1070>*/() {
                for (let /*<@5>*/i = 0; i <= 0xffffffff; ++i) {
                    let /*<@5>*/value = i | 0;
                    yield /*<@1071>*/{ value: value, name: value };
                }
            };
        });
        this._map.set("native typedef uint32<>", /*<@1072>*/(/*<@85>*/type) => {
            this.uint32 = type;
            type.isPrimitive = true;
            type.isInt = true;
            type.isNumber = true;
            type.isSigned = false;
            type.canRepresent = /*<@1073>*/value => isBitwiseEquivalent(value >>> 0, value);
            type.size = 1;
            type.defaultValue = 0;
            type.createLiteral = /*<@1074>*/(/*<@42>*/origin, /*<@1>*/value) => IntLiteral.withType(origin, value >>> 0, type);
            type.successorValue = /*<@1075>*/value => (value + 1) >>> 0;
            type.valuesEqual = /*<@1076>*/(/*<@1>*/a, /*<@1>*/b) => a === b;
            type.populateDefaultValue = /*<@1077>*/(/*<@45>*/buffer, /*<@1>*/offset) => buffer.set(offset, 0);
            type.formatValueFromIntLiteral = /*<@1078>*/value => value >>> 0;
            type.formatValueFromUintLiteral = /*<@1079>*/value => value >>> 0;
            type.allValues = function* /*<@1080>*/() {
                for (let /*<@5>*/i = 0; i <= 0xffffffff; ++i)
                    yield /*<@1071>*/{ value: i, name: i };
            };
        });
        this._map.set("native typedef uint8<>", /*<@1081>*/(/*<@85>*/type) => {
            this.uint8 = type;
            type.isInt = true;
            type.isNumber = true;
            type.isSigned = false;
            type.canRepresent = /*<@1082>*/value => isBitwiseEquivalent(value & 0xff, value);
            type.size = 1;
            type.defaultValue = 0;
            type.createLiteral = /*<@1083>*/(/*<@42>*/origin, /*<@1>*/value) => IntLiteral.withType(origin, value & 0xff, type);
            type.successorValue = /*<@1084>*/value => (value + 1) & 0xff;
            type.valuesEqual = /*<@1085>*/(/*<@1>*/a, /*<@1>*/b) => a === b;
            type.populateDefaultValue = /*<@1086>*/(/*<@45>*/buffer, /*<@1>*/offset) => buffer.set(offset, 0);
            type.formatValueFromIntLiteral = /*<@1087>*/value => value & 0xff;
            type.formatValueFromUintLiteral = /*<@1088>*/value => value & 0xff;
            type.allValues = function* /*<@1089>*/() {
                for (let /*<@5>*/i = 0; i <= 0xff; ++i)
                    yield /*<@1071>*/{ value: i, name: i };
            };
        });
        this._map.set("native typedef float32<>", /*<@1090>*/(/*<@85>*/type) => {
            this.float = type;
            type.isPrimitive = true;
            type.size = 1;
            type.isFloating = true;
            type.isNumber = true;
            type.canRepresent = /*<@1091>*/value => isBitwiseEquivalent(Math.fround(value), value);
            type.populateDefaultValue = /*<@1092>*/(/*<@45>*/buffer, /*<@1>*/offset) => buffer.set(offset, 0);
            type.formatValueFromIntLiteral = /*<@1093>*/value => value;
            type.formatValueFromUintLiteral = /*<@1094>*/value => value;
            type.formatValueFromFloatLiteral = /*<@1095>*/(/*<@1>*/value) => Math.fround(value);
            type.formatValueFromDoubleLiteral = /*<@1096>*/(/*<@1>*/value) => Math.fround(value);
        });
        this._map.set("native typedef float64<>", /*<@1097>*/(/*<@85>*/type) => {
            this.double = type;
            type.isPrimitive = true;
            type.size = 1;
            type.isFloating = true;
            type.isNumber = true;
            type.canRepresent = /*<@1098>*/value => true;
            type.populateDefaultValue = /*<@1099>*/(/*<@45>*/buffer, /*<@1>*/offset) => buffer.set(offset, 0);
            type.formatValueFromIntLiteral = /*<@1100>*/value => value;
            type.formatValueFromUintLiteral = /*<@1101>*/value => value;
            type.formatValueFromFloatLiteral = /*<@1102>*/value => value;
            type.formatValueFromDoubleLiteral = /*<@1103>*/value => value;
        });
        this._map.set("native typedef bool<>", /*<@1104>*/type => {
            type = (/*<@85>*/type);
            this.bool = type;
            type.isPrimitive = true;
            type.size = 1;
            type.populateDefaultValue = /*<@1105>*/(/*<@45>*/buffer, /*<@1>*/offset) => buffer.set(offset, false);
        });
        this._map.set("native operator<> int32(uint32)", /*<@1106>*/(/*<@114>*/func) => {
            func.implementation = /*<@1107>*/(/*<@781>*/[/*<@780>*/value]) => EPtr.box(/*<@43>*/value.loadValue() | 0);
        });
        this._map.set("native operator<> int32(uint8)", /*<@1108>*/(/*<@114>*/func) => {
            func.implementation = /*<@1109>*/(/*<@781>*/[/*<@780>*/value]) => EPtr.box(/*<@43>*/value.loadValue() | 0);
        });
        this._map.set("native operator<> int32(float)", /*<@1110>*/(/*<@114>*/func) => {
            func.implementation = /*<@1111>*/(/*<@781>*/[/*<@780>*/value]) => EPtr.box(/*<@43>*/value.loadValue() | 0);
        });
        this._map.set("native operator<> int32(double)", /*<@1112>*/(/*<@114>*/func) => {
            func.implementation = /*<@1113>*/(/*<@781>*/[/*<@780>*/value]) => EPtr.box(/*<@43>*/value.loadValue() | 0);
        });
        this._map.set("native operator<> uint32(int32)", /*<@1114>*/(/*<@114>*/func) => {
            func.implementation = /*<@1115>*/(/*<@781>*/[/*<@780>*/value]) => EPtr.box(/*<@43>*/value.loadValue() >>> 0);
        });
        this._map.set("native operator<> uint32(uint8)", /*<@1116>*/(/*<@114>*/func) => {
            func.implementation = /*<@1117>*/(/*<@781>*/[/*<@780>*/value]) => EPtr.box(/*<@43>*/value.loadValue() >>> 0);
        });
        this._map.set("native operator<> uint32(float)", /*<@1118>*/(/*<@114>*/func) => {
            func.implementation = /*<@1119>*/(/*<@781>*/[/*<@780>*/value]) => EPtr.box(/*<@43>*/value.loadValue() >>> 0);
        });
        this._map.set("native operator<> uint32(double)", /*<@1120>*/(/*<@114>*/func) => {
            func.implementation = /*<@1121>*/(/*<@781>*/[/*<@780>*/value]) => EPtr.box(/*<@43>*/value.loadValue() >>> 0);
        });
        this._map.set("native operator<> uint8(int32)", /*<@1122>*/(/*<@114>*/func) => {
            func.implementation = /*<@1123>*/(/*<@781>*/[/*<@780>*/value]) => EPtr.box(/*<@43>*/value.loadValue() & 0xff);
        });
        this._map.set("native operator<> uint8(uint32)", /*<@1124>*/(/*<@114>*/func) => {
            func.implementation = /*<@1125>*/(/*<@781>*/[/*<@780>*/value]) => EPtr.box(/*<@43>*/value.loadValue() & 0xff);
        });
        this._map.set("native operator<> uint8(float)", /*<@1126>*/(/*<@114>*/func) => {
            func.implementation = /*<@1127>*/(/*<@781>*/[/*<@780>*/value]) => EPtr.box(/*<@43>*/value.loadValue() & 0xff);
        });
        this._map.set("native operator<> uint8(double)", /*<@1128>*/(/*<@114>*/func) => {
            func.implementation = /*<@1129>*/(/*<@781>*/[/*<@780>*/value]) => EPtr.box(/*<@43>*/value.loadValue() & 0xff);
        });
        this._map.set("native operator<> float(double)", /*<@1130>*/(/*<@114>*/func) => {
            func.implementation = /*<@1131>*/(/*<@781>*/[/*<@780>*/value]) => EPtr.box(Math.fround(/*<@43>*/value.loadValue()));
        });
        this._map.set("native operator<> float(int32)", /*<@1132>*/(/*<@114>*/func) => {
            func.implementation = /*<@1133>*/(/*<@781>*/[/*<@780>*/value]) => EPtr.box(Math.fround(/*<@43>*/value.loadValue()));
        });
        this._map.set("native operator<> float(uint32)", /*<@1134>*/(/*<@114>*/func) => {
            func.implementation = /*<@1135>*/(/*<@781>*/[/*<@780>*/value]) => EPtr.box(Math.fround(/*<@43>*/value.loadValue()));
        });
        this._map.set("native operator<> float(uint8)", /*<@1136>*/(/*<@114>*/func) => {
            func.implementation = /*<@1137>*/(/*<@781>*/[/*<@780>*/value]) => EPtr.box(Math.fround(/*<@43>*/value.loadValue()));
        });
        this._map.set("native operator<> double(float)", /*<@1138>*/(/*<@114>*/func) => {
            func.implementation = /*<@1139>*/(/*<@781>*/[/*<@780>*/value]) => EPtr.box(/*<@43>*/value.loadValue());
        });
        this._map.set("native operator<> double(int32)", /*<@1140>*/(/*<@114>*/func) => {
            func.implementation = /*<@1141>*/(/*<@781>*/[/*<@780>*/value]) => EPtr.box(/*<@43>*/value.loadValue());
        });
        this._map.set("native operator<> double(uint32)", /*<@1142>*/(/*<@114>*/func) => {
            func.implementation = /*<@1143>*/(/*<@781>*/[/*<@780>*/value]) => EPtr.box(/*<@43>*/value.loadValue());
        });
        this._map.set("native operator<> double(uint8)", /*<@1144>*/(/*<@114>*/func) => {
            func.implementation = /*<@1145>*/(/*<@781>*/[/*<@780>*/value]) => EPtr.box(/*<@43>*/value.loadValue());
        });
        this._map.set("native int operator+<>(int,int)", /*<@1146>*/(/*<@114>*/func) => {
            func.implementation = /*<@1147>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box((/*<@43>*/left.loadValue() + /*<@43>*/right.loadValue()) | 0);
        });
        this._map.set("native uint operator+<>(uint,uint)", /*<@1148>*/(/*<@114>*/func) => {
            func.implementation = /*<@1149>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box((/*<@43>*/left.loadValue() + /*<@43>*/right.loadValue()) >>> 0);
        });
        this._map.set("native float operator+<>(float,float)", /*<@1150>*/(/*<@114>*/func) => {
            func.implementation = /*<@1151>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box(Math.fround(/*<@43>*/left.loadValue() + /*<@43>*/right.loadValue()));
        });
        this._map.set("native double operator+<>(double,double)", /*<@1152>*/(/*<@114>*/func) => {
            func.implementation = /*<@1153>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box(/*<@43>*/left.loadValue() + /*<@43>*/right.loadValue());
        });
        this._map.set("native int operator-<>(int,int)", /*<@1154>*/(/*<@114>*/func) => {
            func.implementation = /*<@1155>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box(((/*<@43>*/left.loadValue() - /*<@43>*/right.loadValue()) | 0));
        });
        this._map.set("native uint operator-<>(uint,uint)", /*<@1156>*/(/*<@114>*/func) => {
            func.implementation = /*<@1157>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box((/*<@43>*/left.loadValue() - /*<@43>*/right.loadValue()) >>> 0);
        });
        this._map.set("native float operator-<>(float,float)", /*<@1158>*/(/*<@114>*/func) => {
            func.implementation = /*<@1159>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box(Math.fround(/*<@43>*/left.loadValue() - (/*<@43>*/right.loadValue())));
        });
        this._map.set("native double operator-<>(double,double)", /*<@1160>*/(/*<@114>*/func) => {
            func.implementation = /*<@1161>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box(/*<@43>*/left.loadValue() - /*<@43>*/right.loadValue());
        });
        this._map.set("native int operator*<>(int,int)", /*<@1162>*/(/*<@114>*/func) => {
            func.implementation = /*<@1163>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box((/*<@43>*/left.loadValue() * /*<@43>*/right.loadValue()) | 0);
        });
        this._map.set("native uint operator*<>(uint,uint)", /*<@1164>*/(/*<@114>*/func) => {
            func.implementation = /*<@1165>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box((/*<@43>*/left.loadValue() * /*<@43>*/right.loadValue()) >>> 0);
        });
        this._map.set("native float operator*<>(float,float)", /*<@1166>*/(/*<@114>*/func) => {
            func.implementation = /*<@1167>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box(Math.fround(/*<@43>*/left.loadValue() * /*<@43>*/right.loadValue()));
        });
        this._map.set("native double operator*<>(double,double)", /*<@1168>*/(/*<@114>*/func) => {
            func.implementation = /*<@1169>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box(/*<@43>*/left.loadValue() * /*<@43>*/right.loadValue());
        });
        this._map.set("native int operator/<>(int,int)", /*<@1170>*/(/*<@114>*/func) => {
            func.implementation = /*<@1171>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box((/*<@43>*/left.loadValue() / /*<@43>*/right.loadValue()) | 0);
        });
        this._map.set("native uint operator/<>(uint,uint)", /*<@1172>*/(/*<@114>*/func) => {
            func.implementation = /*<@1173>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box((/*<@43>*/left.loadValue() / /*<@43>*/right.loadValue()) >>> 0);
        });
        this._map.set("native int operator&<>(int,int)", /*<@1174>*/(/*<@114>*/func) => {
            func.implementation = /*<@1175>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box(/*<@43>*/left.loadValue() & /*<@43>*/right.loadValue());
        });
        this._map.set("native uint operator&<>(uint,uint)", /*<@1176>*/(/*<@114>*/func) => {
            func.implementation = /*<@1177>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box((/*<@43>*/left.loadValue() & /*<@43>*/right.loadValue()) >>> 0);
        });
        this._map.set("native int operator|<>(int,int)", /*<@1178>*/(/*<@114>*/func) => {
            func.implementation = /*<@1179>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box(/*<@43>*/left.loadValue() | /*<@43>*/right.loadValue());
        });
        this._map.set("native uint operator|<>(uint,uint)", /*<@1180>*/(/*<@114>*/func) => {
            func.implementation = /*<@1181>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box((/*<@43>*/left.loadValue() | /*<@43>*/right.loadValue()) >>> 0);
        });
        this._map.set("native int operator^<>(int,int)", /*<@1182>*/(/*<@114>*/func) => {
            func.implementation = /*<@1183>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box(/*<@43>*/left.loadValue() ^ /*<@43>*/right.loadValue());
        });
        this._map.set("native uint operator^<>(uint,uint)", /*<@1184>*/(/*<@114>*/func) => {
            func.implementation = /*<@1185>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box((/*<@43>*/left.loadValue() ^ /*<@43>*/right.loadValue()) >>> 0);
        });
        this._map.set("native int operator<<<>(int,uint)", /*<@1186>*/(/*<@114>*/func) => {
            func.implementation = /*<@1187>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box(/*<@43>*/left.loadValue() << /*<@43>*/right.loadValue());
        });
        this._map.set("native uint operator<<<>(uint,uint)", /*<@1188>*/(/*<@114>*/func) => {
            func.implementation = /*<@1189>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box((/*<@43>*/left.loadValue() << /*<@43>*/right.loadValue()) >>> 0);
        });
        this._map.set("native int operator>><>(int,uint)", /*<@1190>*/(/*<@114>*/func) => {
            func.implementation = /*<@1191>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box(/*<@43>*/left.loadValue() >> /*<@43>*/right.loadValue());
        });
        this._map.set("native uint operator>><>(uint,uint)", /*<@1192>*/(/*<@114>*/func) => {
            func.implementation = /*<@1193>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box(/*<@43>*/left.loadValue() >>> /*<@43>*/right.loadValue());
        });
        this._map.set("native int operator~<>(int)", /*<@1194>*/(/*<@114>*/func) => {
            func.implementation = /*<@1195>*/(/*<@781>*/[/*<@780>*/value]) => EPtr.box(~/*<@43>*/value.loadValue());
        });
        this._map.set("native uint operator~<>(uint)", /*<@1196>*/(/*<@114>*/func) => {
            func.implementation = /*<@1197>*/(/*<@781>*/[/*<@780>*/value]) => EPtr.box((~/*<@43>*/value.loadValue()) >>> 0);
        });
        this._map.set("native float operator/<>(float,float)", /*<@1198>*/(/*<@114>*/func) => {
            func.implementation = /*<@1199>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box(Math.fround(/*<@43>*/left.loadValue() / /*<@43>*/right.loadValue()));
        });
        this._map.set("native double operator/<>(double,double)", /*<@1200>*/(/*<@114>*/func) => {
            func.implementation = /*<@1201>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box(/*<@43>*/left.loadValue() / /*<@43>*/right.loadValue());
        });
        this._map.set("native bool operator==<>(int,int)", /*<@1202>*/(/*<@114>*/func) => {
            func.implementation = /*<@1203>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box(/*<@43>*/left.loadValue() == /*<@43>*/right.loadValue());
        });
        this._map.set("native bool operator==<>(uint,uint)", /*<@1204>*/(/*<@114>*/func) => {
            func.implementation = /*<@1205>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box(/*<@43>*/left.loadValue() == /*<@43>*/right.loadValue());
        });
        this._map.set("native bool operator==<>(bool,bool)", /*<@1206>*/(/*<@114>*/func) => {
            func.implementation = /*<@1207>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box(/*<@43>*/left.loadValue() == /*<@43>*/right.loadValue());
        });
        this._map.set("native bool operator==<>(float,float)", /*<@1208>*/(/*<@114>*/func) => {
            func.implementation = /*<@1209>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box(/*<@43>*/left.loadValue() == /*<@43>*/right.loadValue());
        });
        this._map.set("native bool operator==<>(double,double)", /*<@1210>*/(/*<@114>*/func) => {
            func.implementation = /*<@1211>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box(/*<@43>*/left.loadValue() == /*<@43>*/right.loadValue());
        });
        this._map.set("native bool operator<<>(int,int)", /*<@1212>*/(/*<@114>*/func) => {
            func.implementation = /*<@1213>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box(/*<@43>*/left.loadValue() < /*<@43>*/right.loadValue());
        });
        this._map.set("native bool operator<<>(uint,uint)", /*<@1214>*/(/*<@114>*/func) => {
            func.implementation = /*<@1215>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box(/*<@43>*/left.loadValue() < /*<@43>*/right.loadValue());
        });
        this._map.set("native bool operator<<>(float,float)", /*<@1216>*/(/*<@114>*/func) => {
            func.implementation = /*<@1217>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box(/*<@43>*/left.loadValue() < /*<@43>*/right.loadValue());
        });
        this._map.set("native bool operator<<>(double,double)", /*<@1218>*/(/*<@114>*/func) => {
            func.implementation = /*<@1219>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box(/*<@43>*/left.loadValue() < /*<@43>*/right.loadValue());
        });
        this._map.set("native bool operator<=<>(int,int)", /*<@1220>*/(/*<@114>*/func) => {
            func.implementation = /*<@1221>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box(/*<@43>*/left.loadValue() <= /*<@43>*/right.loadValue());
        });
        this._map.set("native bool operator<=<>(uint,uint)", /*<@1222>*/(/*<@114>*/func) => {
            func.implementation = /*<@1223>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box(/*<@43>*/left.loadValue() <= /*<@43>*/right.loadValue());
        });
        this._map.set("native bool operator<=<>(float,float)", /*<@1224>*/(/*<@114>*/func) => {
            func.implementation = /*<@1225>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box(/*<@43>*/left.loadValue() <= /*<@43>*/right.loadValue());
        });
        this._map.set("native bool operator<=<>(double,double)", /*<@1226>*/(/*<@114>*/func) => {
            func.implementation = /*<@1227>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box(/*<@43>*/left.loadValue() <= /*<@43>*/right.loadValue());
        });
        this._map.set("native bool operator><>(int,int)", /*<@1228>*/(/*<@114>*/func) => {
            func.implementation = /*<@1229>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box(/*<@43>*/left.loadValue() > /*<@43>*/right.loadValue());
        });
        this._map.set("native bool operator><>(uint,uint)", /*<@1230>*/(/*<@114>*/func) => {
            func.implementation = /*<@1231>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box(/*<@43>*/left.loadValue() > /*<@43>*/right.loadValue());
        });
        this._map.set("native bool operator><>(float,float)", /*<@1232>*/(/*<@114>*/func) => {
            func.implementation = /*<@1233>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box(/*<@43>*/left.loadValue() > /*<@43>*/right.loadValue());
        });
        this._map.set("native bool operator><>(double,double)", /*<@1234>*/(/*<@114>*/func) => {
            func.implementation = /*<@1235>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box(/*<@43>*/left.loadValue() > /*<@43>*/right.loadValue());
        });
        this._map.set("native bool operator>=<>(int,int)", /*<@1236>*/(/*<@114>*/func) => {
            func.implementation = /*<@1237>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box(/*<@43>*/left.loadValue() >= /*<@43>*/right.loadValue());
        });
        this._map.set("native bool operator>=<>(uint,uint)", /*<@1238>*/(/*<@114>*/func) => {
            func.implementation = /*<@1239>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box(/*<@43>*/left.loadValue() >= /*<@43>*/right.loadValue());
        });
        this._map.set("native bool operator>=<>(float,float)", /*<@1240>*/(/*<@114>*/func) => {
            func.implementation = /*<@1241>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box(/*<@43>*/left.loadValue() >= /*<@43>*/right.loadValue());
        });
        this._map.set("native bool operator>=<>(double,double)", /*<@1242>*/(/*<@114>*/func) => {
            func.implementation = /*<@1243>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box(/*<@43>*/left.loadValue() >= /*<@43>*/right.loadValue());
        });
        for (let /*<@3>*/addressSpace of addressSpaces) {
            this._map.set(`native T* ${addressSpace} operator&[]<T>(T[] ${addressSpace},uint)`, /*<@1244>*/(/*<@114>*/func) => {
                func.implementation = /*<@1245>*/(/*<@781>*/[/*<@780>*/ref, /*<@780>*/index], /*<@7>*/node) => {
                    let /*<@47>*/ref_v = /*<@43>*/ref.loadValue();
                    if (!ref_v)
                        throw new WTrapError(node._origin.originString, "Null dereference");
                    let /*<@1>*/index_v = /*<@43>*/index.loadValue();
                    if (index_v > ref_v.length)
                        throw new WTrapError(node._origin.originString, "Array index " + index + " is out of bounds of " + ref);
                    return EPtr.box(ref_v.ptr.plus(index_v * /*<@437>*/node.instantiatedActualTypeArguments[0].size));
                };
            });
            this._map.set(`native uint operator.length<T>(T[] ${addressSpace})`, /*<@1246>*/(/*<@114>*/func) => {
                func.implementation = /*<@1247>*/(/*<@781>*/[/*<@780>*/ref], /*<@7>*/node) => {
                    let /*<@47>*/ref_v = /*<@43>*/ref.loadValue();
                    if (!ref_v)
                        return EPtr.box(0);
                    return EPtr.box(ref_v.length);
                };
            });
        }
    }
    /*<@198>*/add(/*<@199>*/thing) {
        let intrinsic = this._map.get(/*<@7>*/thing.toString());
        if (!intrinsic)
            throw new WTypeError(thing._origin.originString, "Unrecognized intrinsic: " + thing);
        intrinsic(thing);
    }
}
class /*<@1249>*/LateChecker extends Visitor {
    /*<@1250>*/visitReferenceType(/*<@367>*/node) {
        if (node.addressSpace == "thread")
            return;
        if (!node.elementType.isPrimitive)
            throw new WTypeError(node.origin.originString, "Illegal pointer to non-primitive type: " + node);
    }
    /*<@1251>*/_checkShaderType(/*<@114>*/node) {
        // FIXME: Tighten these checks. For now, we should only accept int32, uint32, float32, and float64.
        let /*<@1253>*/assertPrimitive = /*<@1253>*/(/*<@85>*/type) => {
            if (!type.isPrimitive)
                throw new WTypeError(node.origin.originString, "Shader signature cannot include non-primitive type: " + type);
        };
        assertPrimitive(node.returnType);
        if (!(node.returnType.unifyNode instanceof StructType))
            throw new WTypeError(node.origin.originString, "Vertex shader " + node.name + " must return a struct.");
        switch (node.shaderType) {
            case "vertex":
                for (let /*<@116>*/parameter of node.parameters) {
                    if (parameter.type.unifyNode instanceof StructType)
                        assertPrimitive(parameter.type);
                    else if (!parameter.type./*<@85>*/unifyNode.isArrayRef)
                        throw new WTypeError(node.origin.originString, node.name + " accepts a parameter " + parameter.name + " which isn't a struct and isn't an ArrayRef.");
                }
                break;
            case "fragment":
                for (let /*<@116>*/parameter of node.parameters) {
                    if (parameter.name == "stageIn") {
                        if (!(parameter.type.unifyNode instanceof StructType))
                            throw new WTypeError(node.origin.originString, "Fragment entry points' stageIn parameter (of " + node.name + ") must be a struct type.");
                        assertPrimitive(parameter.type);
                    }
                    else {
                        if (!parameter.type./*<@85>*/unifyNode.isArrayRef)
                            throw new WTypeError(node.origin.originString, "Fragment entry point's " + parameter.name + " parameter is not an array reference.");
                    }
                }
                break;
            default:
                throw new Error("Bad shader type: " + node.shaderType);
        }
    }
    /*<@1252>*/visitFuncDef(/*<@227>*/node) {
        if (node.shaderType)
            this._checkShaderType(node);
        super.visitFuncDef(node);
    }
}
class /*<@12>*/Lexer {
    constructor(/*<@3>*/origin, /*<@3>*/originKind, /*<@5>*/lineNumberOffset, /*<@3>*/text) {
        if (!isOriginKind(originKind))
            throw new Error("Bad origin kind: " + originKind);
        this._origin = origin;
        this._originKind = originKind;
        this._lineNumberOffset = lineNumberOffset;
        this._text = text;
        this._index = 0;
        this._stack = /*<@784>*/[];
    }
    get /*<@14>*/origin() {
        return this._origin;
    }
    get /*<@15>*/lineNumber() {
        return this.lineNumberForIndex(this._index);
    }
    get /*<@16>*/originString() {
        return this._origin + ":" + (this.lineNumber + 1);
    }
    get /*<@17>*/originKind() { return this._originKind; }
    /*<@18>*/lineNumberForIndex(/*<@5>*/index) {
        let /*<@826>*/matches = this._text.substring(0, index).match(/\n/g);
        return (matches ? matches./*<@5>*/length : 0) + this._lineNumberOffset;
    }
    get /*<@19>*/state() { return /*<@20>*/{ index: this._index, stack: this._stack.concat() }; }
    set /*<@21>*/state(/*<@20>*/value) {
        this._index = value.index;
        this._stack = value.stack;
    }
    static /*<@22>*/_textIsIdentifierImpl(/*<@3>*/text) {
        return /^[^\d\W]\w*/.test(text);
    }
    static /*<@23>*/textIsIdentifier(/*<@3>*/text) {
        return Lexer._textIsIdentifierImpl(text) && !RegExp.rightContext.length;
    }
    /*<@24>*/next() {
        if (this._stack.length)
            return this._stack.pop();
        if (this._index >= this._text.length)
            return null;
        const /*<@778>*/isCCommentBegin = /\/\*/;
        const /*<@778>*/isCPlusPlusCommentBegin = /\/\//;
        let /*<@1254>*/result = /*<@1254>*/(/*<@3>*/kind) => {
            let /*<@3>*/text = RegExp.lastMatch;
            let /*<@9>*/token = new LexerToken(this, this._index, kind, text);
            this._index += text.length;
            return token;
        };
        let /*<@3>*/relevantText;
        for (;;) {
            relevantText = this._text.substring(this._index);
            if (/^\s+/.test(relevantText)) {
                this._index += RegExp.lastMatch.length;
                continue;
            }
            if (/^\/\*/.test(relevantText)) {
                let /*<@1>*/endIndex = relevantText.search(/\*\//);
                if (endIndex < 0)
                    this.fail("Unterminated comment");
                this._index += endIndex;
                continue;
            }
            if (/^\/\/.*/.test(relevantText)) {
                this._index += RegExp.lastMatch.length;
                continue;
            }
            break;
        }
        if (this._index >= this._text.length)
            return null;
        // FIXME: Make this handle exp-form literals like 1e1.
        if (/^(([0-9]*\.[0-9]+[fd]?)|([0-9]+\.[0-9]*[fd]?))/.test(relevantText))
            return result("floatLiteral");
        // FIXME: Make this do Unicode.
        if (Lexer._textIsIdentifierImpl(relevantText)) {
            if (/^(struct|protocol|typedef|if|else|enum|continue|break|switch|case|default|for|while|do|return|constant|device|threadgroup|thread|operator|null|true|false)$/.test(RegExp.lastMatch))
                return result("keyword");
            if (this._originKind == "native" && /^(native|restricted)$/.test(RegExp.lastMatch))
                return result("keyword");
            return result("identifier");
        }
        if (/^0x[0-9a-fA-F]+u/.test(relevantText))
            return result("uintHexLiteral");
        if (/^0x[0-9a-fA-F]+/.test(relevantText))
            return result("intHexLiteral");
        if (/^[0-9]+u/.test(relevantText))
            return result("uintLiteral");
        if (/^[0-9]+/.test(relevantText))
            return result("intLiteral");
        if (/^<<|>>|->|>=|<=|==|!=|\+=|-=|\*=|\/=|%=|\^=|\|=|&=|\+\+|--|&&|\|\||([{}()\[\]?:=+*\/,.%!~^&|<>@;-])/.test(relevantText))
            return result("punctuation");
        let /*<@3>*/remaining = relevantText.substring(0, 20).split(/\s/)[0];
        if (!remaining.length)
            remaining = relevantText.substring(0, 20);
        this.fail("Unrecognized token beginning with: " + remaining);
    }
    /*<@25>*/push(/*<@9>*/token) {
        this._stack.push(token);
    }
    /*<@26>*/peek() {
        let /*<@9>*/result = this.next();
        this.push(result);
        return result;
    }
    /*<@27>*/fail(/*<@3>*/error) {
        throw new WSyntaxError(this.originString, error);
    }
    /*<@28>*/backtrackingScope(callback) {
        let /*<@20>*/state = this.state;
        try {
            return callback();
        }
        catch (e) {
            if (e instanceof WSyntaxError) {
                this.state = state;
                return null;
            }
            throw e;
        }
    }
    /*<@30>*/testScope(callback) {
        let /*<@20>*/state = this.state;
        try {
            callback();
            return true;
        }
        catch (e) {
            if (e instanceof WSyntaxError)
                return false;
            throw e;
        }
        finally {
            this.state = state;
        }
    }
}
class /*<@10>*/LexerToken {
    constructor(/*<@11>*/lexer, /*<@5>*/index, /*<@3>*/kind, /*<@3>*/text) {
        this._lexer = lexer;
        this._index = index;
        this._kind = kind;
        this._text = text;
    }
    get /*<@31>*/lexer() {
        return this._lexer;
    }
    get /*<@32>*/kind() {
        return this._kind;
    }
    get /*<@33>*/text() {
        return this._text;
    }
    get /*<@34>*/origin() {
        return this.lexer.origin;
    }
    get /*<@35>*/originKind() {
        return this.lexer.originKind;
    }
    get /*<@36>*/index() {
        return this._index;
    }
    get /*<@37>*/lineNumber() {
        return this._lexer.lineNumberForIndex(this._index);
    }
    get /*<@38>*/originString() {
        return this.origin + ":" + (this.lineNumber + 1);
    }
    /*<@39>*/toString() {
        return "LexerToken(" + this.kind + ", " + this.text + ", " + this.lineNumber + ")";
    }
}
class /*<@1256>*/LiteralTypeChecker extends Visitor {
    /*<@1257>*/visitNullType(/*<@552>*/node) {
        if (!node.type)
            throw new Error("Null at " + node.origin.originString + " does not have type");
    }
    /*<@1258>*/visitGenericLiteralType(/*<@528>*/node) {
        if (!node.type)
            throw new Error(node + " at " + node.origin.originString + " does not have type");
    }
}
class /*<@580>*/LogicalExpression extends Expression {
    constructor(/*<@42>*/origin, /*<@3>*/text, /*<@437>*/left, /*<@437>*/right) {
        super(origin);
        this._text = text;
        this._left = left;
        this._right = right;
    }
    get /*<@581>*/text() { return this._text; }
    get /*<@582>*/left() { return this._left; }
    get /*<@583>*/right() { return this._right; }
    /*<@584>*/toString() {
        return "(" + this.left + " " + this.text + " " + this.right + ")";
    }
}
class /*<@574>*/LogicalNot extends Expression {
    constructor(/*<@42>*/origin, /*<@437>*/operand) {
        super(origin);
        this._operand = operand;
    }
    get /*<@576>*/operand() { return this._operand; }
    /*<@577>*/toString() {
        return "!(" + this.operand + ")";
    }
}
class /*<@1260>*/LoopChecker extends Visitor {
    constructor() {
        super();
        this._loopDepth = 0;
        this._switchDepth = 0;
    }
    /*<@1261>*/visitFuncDef(/*<@227>*/node) {
        if (this._loopDepth != 0)
            throw new WTypeError(node.origin.originString, "LoopChecker does not understand nested functions.");
        super.visitFuncDef(node);
    }
    /*<@1262>*/visitWhileLoop(/*<@593>*/node) {
        node.conditional.visit(this);
        ++this._loopDepth;
        node.body.visit(this);
        if (this._loopDepth == 0)
            throw new WTypeError(node.origin.originString, "The number of nested loops is negative!");
        --this._loopDepth;
    }
    /*<@1263>*/visitDoWhileLoop(/*<@599>*/node) {
        ++this._loopDepth;
        node.body.visit(this);
        if (this._loopDepth == 0)
            throw new WTypeError(node.origin.originString, "The number of nested loops is negative!");
        --this._loopDepth;
        node.conditional.visit(this);
    }
    /*<@1264>*/visitForLoop(/*<@605>*/node) {
        if (node.initialization)
            node.initialization.visit(this);
        if (node.condition)
            node.condition.visit(this);
        if (node.increment)
            node.increment.visit(this);
        ++this._loopDepth;
        node.body.visit(this);
        if (this._loopDepth == 0)
            throw new WTypeError(node.origin.originString, "The number of nested loops is negative!");
        --this._loopDepth;
    }
    /*<@1265>*/visitSwitchStatement(/*<@613>*/node) {
        node.value.visit(this);
        this._switchDepth++;
        for (let /*<@615>*/switchCase of node.switchCases)
            switchCase.visit(this);
        this._switchDepth--;
    }
    /*<@1266>*/visitBreak(/*<@506>*/node) {
        if (this._loopDepth == 0 && this._switchDepth == 0)
            throw new WTypeError(node.origin.originString, "Break statement without enclosing loop or switch!");
        super.visitBreak(node);
    }
    /*<@1267>*/visitContinue(/*<@502>*/node) {
        if (this._loopDepth == 0)
            throw new WTypeError(node.origin.originString, "Continue statement without enclosing loop!");
        super.visitContinue(node);
    }
}
class /*<@378>*/MakeArrayRefExpression extends Expression {
    constructor(/*<@42>*/origin, /*<@120>*/lValue) {
        super(origin);
        this._lValue = lValue;
    }
    get /*<@379>*/lValue() { return this._lValue; }
    /*<@380>*/toString() {
        return "@" + (this.numElements ? "<<" + this.numElements + ">>" : "") + "(" + this.lValue + ")";
    }
}
class /*<@486>*/MakePtrExpression extends Expression {
    constructor(/*<@42>*/origin, /*<@7>*/lValue) {
        super(origin);
        this._lValue = lValue;
    }
    get /*<@487>*/lValue() { return this._lValue; }
    /*<@488>*/toString() {
        return "&(" + this.lValue + ")";
    }
}
const /*<@967>*/Anything = Symbol();
function /*<@1268>*/isWildcardKind(/*<@6>*/kind) {
    return kind == Anything;
}
class /*<@76>*/NameContext {
    constructor(/*<@75>*/delegate) {
        this._map = new Map();
        this._set = new Set();
        this._currentStatement = null;
        this._delegate = delegate;
        this._intrinsics = null;
        this._program = null;
    }
    /*<@79>*/add(/*<@7>*/thing) {
        if (!thing.name)
            return;
        if (!thing.origin)
            throw new Error("Thing does not have origin: " + thing);
        if (thing.isNative && !thing.implementation) {
            if (!this._intrinsics)
                throw new Error("Native function in a scope that does not recognize intrinsics");
            this._intrinsics.add(/*<@114>*/thing);
        }
        if (thing.kind == Func) {
            this._set.add(thing);
            let array = this._map.get(thing.name);
            if (!array) {
                let /*<@143>*/arrayData = /*<@143>*/[];
                array = /*<@1270>*/{ kind: Func, array: arrayData };
                this._map.set(thing.name, array);
            }
            if (array.kind != Func)
                throw new WTypeError(thing.origin.originString, "Cannot reuse type name for function: " + thing.name);
            array.array.push(/*<@114>*/thing);
            return;
        }
        if (this._map.has(thing.name))
            throw new WTypeError(thing.origin.originString, "Duplicate name: " + thing.name);
        this._set.add(thing);
        this._map.set(thing.name, thing);
    }
    /*<@80>*/get(/*<@6>*/kind, /*<@3>*/name) {
        let result = this._map.get(name);
        if (!result && this._delegate)
            return this._delegate.get(kind, name);
        if (result && !isWildcardKind(kind) && result.kind != kind)
            return null;
        return result;
    }
    /*<@81>*/underlyingThings(/*<@6>*/kind, /*<@3>*/name) {
        let things = this.get(kind, name);
        return NameContext.underlyingThings(things);
    }
    static */*<@83>*/underlyingThings(thing) {
        if (!thing)
            return;
        if (thing.kind === Func) {
            let /*<@143>*/funcArray = thing.array;
            if (!(funcArray instanceof Array))
                throw new Error("Func thing is not array: " + funcArray);
            for (let /*<@114>*/func of funcArray)
                yield func;
            return;
        }
        yield /*<@7>*/thing;
    }
    /*<@84>*/resolveFuncOverload(/*<@3>*/name, /*<@136>*/typeArguments, /*<@136>*/argumentTypes, /*<@85>*/returnType, /*<@2>*/allowEntryPoint = false) {
        let functions = this.get(Func, name);
        if (!functions)
            return /*<@1271>*/{ failures: /*<@784>*/[], func: undefined };
        return resolveOverloadImpl(functions.array, typeArguments, argumentTypes, returnType, allowEntryPoint);
    }
    get /*<@191>*/currentStatement() {
        if (this._currentStatement)
            return this._currentStatement;
        if (this._delegate)
            return this._delegate.currentStatement;
        return null;
    }
    /*<@192>*/doStatement(/*<@7>*/statement, callback) {
        this._currentStatement = statement;
        callback();
        this._currentStatement = null;
    }
    /*<@193>*/recognizeIntrinsics() {
        this._intrinsics = new Intrinsics(this);
    }
    get /*<@194>*/intrinsics() {
        if (this._intrinsics)
            return this._intrinsics;
        if (this._delegate)
            return this._delegate.intrinsics;
        return null;
    }
    set /*<@196>*/program(/*<@71>*/value) {
        this._program = value;
    }
    get /*<@195>*/program() {
        if (this._program)
            return this._program;
        if (this._delegate)
            return this._delegate.program;
        return null;
    }
    *[Symbol.iterator]() {
        for (let value of this._map.values()) {
            if (value instanceof Array) {
                for (let func of value)
                    yield func;
                continue;
            }
            yield value;
        }
    }
}
class /*<@1273>*/NameFinder extends Visitor {
    constructor() {
        super();
        this._set = new Set();
        this._worklist = /*<@784>*/[];
    }
    get /*<@1274>*/set() { return this._set; }
    get /*<@1275>*/worklist() { return this._worklist; }
    /*<@1276>*/add(/*<@3>*/name) {
        if (this._set.has(name))
            return;
        this._set.add(name);
        this._worklist.push(name);
    }
    /*<@1277>*/visitProtocolRef(/*<@107>*/node) {
        this.add(node.name);
        super.visitProtocolRef(node);
    }
    /*<@1278>*/visitTypeRef(/*<@345>*/node) {
        this.add(node.name);
        super.visitTypeRef(node);
    }
    /*<@1279>*/visitVariableRef(/*<@418>*/node) {
        this.add(node.name);
        super.visitVariableRef(node);
    }
    /*<@1280>*/visitTypeOrVariableRef(/*<@936>*/node) {
        this.add(node.name);
    }
    /*<@1281>*/_handlePropertyAccess(/*<@435>*/node) {
        this.add(node.getFuncName);
        this.add(node.setFuncName);
        this.add(node.andFuncName);
    }
    /*<@1282>*/visitDotExpression(/*<@466>*/node) {
        this._handlePropertyAccess(node);
        super.visitDotExpression(node);
    }
    /*<@1283>*/visitIndexExpression(/*<@475>*/node) {
        this._handlePropertyAccess(node);
        super.visitIndexExpression(node);
    }
    /*<@1284>*/visitCallExpression(/*<@437>*/node) {
        this.add(node.name);
        super.visitCallExpression(node);
    }
}
// checked before TypeRefToTypeDefSkipper.
class /*<@1286>*/NameResolver extends Visitor {
    constructor(/*<@75>*/nameContext) {
        super();
        this._nameContext = nameContext;
    }
    /*<@1287>*/doStatement(/*<@7>*/statement) {
        this._nameContext.doStatement(statement, /*<@1311>*/() => statement.visit(this));
    }
    /*<@1288>*/_visitTypeParametersAndBuildNameContext(/*<@114>*/node) {
        let /*<@75>*/nameContext = new NameContext(this._nameContext);
        for (let /*<@7>*/typeParameter of node.typeParameters) {
            nameContext.add(typeParameter);
            typeParameter.visit(this);
        }
        return nameContext;
    }
    /*<@1289>*/visitFunc(/*<@114>*/node) {
        let /*<@1285>*/checker = new NameResolver(this._visitTypeParametersAndBuildNameContext(node));
        node.returnType.visit(checker);
        for (let /*<@116>*/parameter of node.parameters)
            parameter.visit(checker);
    }
    /*<@1290>*/visitFuncDef(/*<@227>*/node) {
        let /*<@75>*/contextWithTypeParameters = this._visitTypeParametersAndBuildNameContext(node);
        let /*<@1285>*/checkerWithTypeParameters = new NameResolver(contextWithTypeParameters);
        node.returnType.visit(checkerWithTypeParameters);
        let /*<@75>*/contextWithParameters = new NameContext(contextWithTypeParameters);
        for (let /*<@116>*/parameter of node.parameters) {
            parameter.visit(checkerWithTypeParameters);
            contextWithParameters.add(parameter);
        }
        let /*<@1285>*/checkerWithParameters = new NameResolver(contextWithParameters);
        node.body.visit(checkerWithParameters);
    }
    /*<@1291>*/visitBlock(/*<@332>*/node) {
        let /*<@1285>*/checker = new NameResolver(new NameContext(this._nameContext));
        for (let /*<@7>*/statement of node.statements)
            statement.visit(checker);
    }
    /*<@1292>*/visitIfStatement(/*<@586>*/node) {
        node.conditional.visit(this);
        // The bodies might not be Blocks, so we need to explicitly give them a new context.
        node.body.visit(new NameResolver(new NameContext(this._nameContext)));
        if (node.elseBody)
            node.elseBody.visit(new NameResolver(new NameContext(this._nameContext)));
    }
    /*<@1293>*/visitWhileLoop(/*<@593>*/node) {
        node.conditional.visit(this);
        // The bodies might not be Blocks, so we need to explicitly give them a new context.
        node.body.visit(new NameResolver(new NameContext(this._nameContext)));
    }
    /*<@1294>*/visitDoWhileLoop(/*<@599>*/node) {
        // The bodies might not be Blocks, so we need to explicitly give them a new context.
        node.body.visit(new NameResolver(new NameContext(this._nameContext)));
        node.conditional.visit(this);
    }
    /*<@1295>*/visitForLoop(/*<@605>*/node) {
        let /*<@1285>*/newResolver = new NameResolver(new NameContext(this._nameContext));
        if (node.initialization)
            node.initialization.visit(newResolver);
        if (node.condition)
            node.condition.visit(newResolver);
        if (node.increment)
            node.increment.visit(newResolver);
        node.body.visit(newResolver);
    }
    /*<@1296>*/visitProtocolDecl(/*<@109>*/node) {
        for (let /*<@107>*/parent of node.extends)
            parent.visit(this);
        let /*<@75>*/nameContext = new NameContext(this._nameContext);
        nameContext.add(node.typeVariable);
        let /*<@1285>*/checker = new NameResolver(nameContext);
        for (let /*<@112>*/signature of node.signatures)
            signature.visit(checker);
    }
    /*<@1297>*/visitProtocolRef(/*<@107>*/node) {
        let result = this._nameContext.get(Protocol, node.name);
        if (!result)
            throw new WTypeError(node.origin.originString, "Could not find protocol named " + node.name);
        node.protocolDecl = /*<@109>*/result;
    }
    /*<@1298>*/visitProtocolFuncDecl(/*<@112>*/node) {
        this.visitFunc(node);
        let funcs = this._nameContext.get(Func, node.name);
        if (!funcs)
            throw new WTypeError(node.origin.originString, "Cannot find any functions named " + node.name);
        node.possibleOverloads = funcs.array;
    }
    /*<@1299>*/visitTypeDef(/*<@275>*/node) {
        let /*<@75>*/nameContext = new NameContext(this._nameContext);
        for (let /*<@7>*/typeParameter of node.typeParameters) {
            typeParameter.visit(this);
            nameContext.add(typeParameter);
        }
        let /*<@1285>*/checker = new NameResolver(nameContext);
        node.type.visit(checker);
    }
    /*<@1300>*/visitStructType(/*<@280>*/node) {
        let /*<@75>*/nameContext = new NameContext(this._nameContext);
        for (let /*<@7>*/typeParameter of node.typeParameters) {
            typeParameter.visit(this);
            nameContext.add(typeParameter);
        }
        let /*<@1285>*/checker = new NameResolver(nameContext);
        for (let /*<@284>*/field of node.fields)
            field.visit(checker);
        return undefined;
    }
    /*<@1301>*/_resolveTypeArguments(/*<@101>*/typeArguments) {
        for (let /*<@5>*/i = 0; i < typeArguments.length; ++i) {
            let /*<@7>*/typeArgument = typeArguments[i];
            if (typeArgument instanceof TypeOrVariableRef) {
                let thing = this._nameContext.get(Anything, typeArgument.name);
                if (!thing)
                    new WTypeError(typeArgument.origin.originString, "Could not find type or variable named " + typeArgument.name);
                if (thing instanceof Value)
                    typeArguments[i] = new VariableRef(typeArgument.origin, typeArgument.name);
                else if (thing instanceof Type)
                    typeArguments[i] = new TypeRef(typeArgument.origin, typeArgument.name, /*<@784>*/[]);
                else
                    throw new WTypeError(typeArgument.origin.originString, "Type argument resolved to wrong kind of thing: " + thing.kind);
            }
            if (typeArgument[i] instanceof Value
                && !typeArgument[i].isConstexpr)
                throw new WTypeError(typeArgument[i].origin.originString, "Expected constexpr");
        }
    }
    /*<@1302>*/visitTypeRef(/*<@345>*/node) {
        this._resolveTypeArguments(node.typeArguments);
        let /*<@85>*/type = node.type;
        if (!type) {
            type = this._nameContext.get(Type, node.name);
            if (!type)
                throw new WTypeError(node.origin.originString, "Could not find type named " + node.name);
            node.type = type;
        }
        if (type.typeParameters.length != node.typeArguments.length)
            throw new WTypeError(node.origin.originString, "Wrong number of type arguments (passed " + node.typeArguments.length + ", expected " + type.typeParameters.length + ")");
        for (let /*<@5>*/i = 0; i < type.typeParameters.length; ++i) {
            let /*<@2>*/parameterIsType = type.typeParameters[i] instanceof TypeVariable;
            let /*<@2>*/argumentIsType = node.typeArguments[i] instanceof Type;
            node.typeArguments[i].visit(this);
            if (parameterIsType && !argumentIsType)
                throw new WTypeError(node.origin.originString, "Expected type, but got value at argument #" + i);
            if (!parameterIsType && argumentIsType)
                throw new WTypeError(node.origin.originString, "Expected value, but got type at argument #" + i);
        }
    }
    /*<@1303>*/visitReferenceType(/*<@367>*/node) {
        let /*<@75>*/nameContext = new NameContext(this._nameContext);
        node.elementType.visit(new NameResolver(nameContext));
    }
    /*<@1304>*/visitVariableDecl(/*<@326>*/node) {
        this._nameContext.add(node);
        node.type.visit(this);
        if (node.initializer)
            node.initializer.visit(this);
    }
    /*<@1305>*/visitVariableRef(/*<@418>*/node) {
        if (node.variable)
            return;
        let result = this._nameContext.get(Value, node.name);
        if (!result)
            throw new WTypeError(node.origin.originString, "Could not find variable named " + node.name);
        node.variable = /*<@120>*/result;
    }
    /*<@1306>*/visitReturn(/*<@497>*/node) {
        node.func = this._nameContext./*<@114>*/currentStatement;
        super.visitReturn(node);
    }
    /*<@1307>*/_handlePropertyAccess(/*<@435>*/node) {
        let value = this._nameContext.get(Func, node.getFuncName);
        node.possibleGetOverloads = value ? value.array : undefined;
        value = this._nameContext.get(Func, node.setFuncName);
        node.possibleSetOverloads = value ? value.array : undefined;
        value = this._nameContext.get(Func, node.andFuncName);
        node.possibleAndOverloads = value ? value.array : undefined;
        if (!node.possibleGetOverloads && !node.possibleAndOverloads)
            throw new WTypeError(node.origin.originString, "Cannot find either " + node.getFuncName + " or " + node.andFuncName);
    }
    /*<@1308>*/visitDotExpression(/*<@466>*/node) {
        // This could be a reference to an enum. Let's resolve that now.
        if (node.struct instanceof VariableRef) {
            let enumType = this._nameContext.get(Type, node.struct.name);
            if (enumType && enumType instanceof EnumType) {
                let /*<@301>*/enumMember = enumType.memberByName(node.fieldName);
                if (!enumMember)
                    throw new WTypeError(node.origin.originString, "Enum " + enumType.name + " does not have a member named " + node.fieldName);
                node.become(new EnumLiteral(node.origin, enumMember));
                return;
            }
        }
        this._handlePropertyAccess(node);
        super.visitDotExpression(node);
    }
    /*<@1309>*/visitIndexExpression(/*<@475>*/node) {
        this._handlePropertyAccess(node);
        super.visitIndexExpression(node);
    }
    /*<@1310>*/visitCallExpression(/*<@437>*/node) {
        this._resolveTypeArguments(node.typeArguments);
        let funcs = this._nameContext.get(Func, node.name);
        if (funcs)
            node.possibleOverloads = funcs.array;
        else {
            let /*<@85>*/type = this._nameContext.get(Type, node.name);
            if (!type)
                throw new WTypeError(node.origin.originString, "Cannot find any function or type named \"" + node.name + "\"");
            node.becomeCast(type);
            let ret = this._nameContext.get(Func, "operator cast");
            node.possibleOverloads = ret.array;
            if (!node.possibleOverloads)
                throw new WTypeError(node.origin.originString, "Cannot find any operator cast implementations in cast to " + type);
        }
        super.visitCallExpression(node);
    }
}
class /*<@238>*/NativeFunc extends Func {
    constructor(/*<@42>*/origin, /*<@3>*/name, /*<@85>*/returnType, /*<@101>*/typeParameters, /*<@130>*/parameters, /*<@2>*/isCast, /*<@3>*/shaderType) {
        super(origin, name, returnType, typeParameters, parameters, isCast, shaderType);
        this.isRestricted = false;
        this.implementation = null;
        this.instantiateImplementation = /*<@1313>*/(/*<@694>*/substitution) => DefaultImplementationData;
        this.visitImplementationData = /*<@1314>*/(implementationData, /*<@220>*/visitor) => null;
        this.didLayoutStructsInImplementationData = /*<@1315>*/implementationData => null;
    }
    get /*<@239>*/isNative() { return true; }
    /*<@240>*/toDeclString() {
        return "native " + super.toDeclString();
    }
}
class /*<@243>*/NativeFuncInstance extends Func {
    constructor(/*<@237>*/func, /*<@85>*/returnType, /*<@130>*/parameters, /*<@2>*/isCast, /*<@3>*/shaderType, implementationData) {
        super(func.origin, func.name, returnType, /*<@784>*/[], parameters, isCast, shaderType);
        this._func = func;
        this._implementationData = implementationData;
    }
    get /*<@244>*/func() { return this._func; }
    get /*<@245>*/isNative() { return true; }
    get /*<@246>*/implementationData() { return this._implementationData; }
    /*<@247>*/toDeclString() {
        return "native " + super.toDeclString();
    }
}
function /*<@1316>*/NativeTypeInstantiate(/*<@136>*/typeArguments) {
    if (typeArguments.length != this.typeParameters.length)
        throw new Error("Wrong number of type arguments to instantiation");
    if (!typeArguments.length)
        return this;
    return new NativeTypeInstance(this, typeArguments);
}
class /*<@250>*/NativeType extends Type {
    constructor(/*<@42>*/origin, /*<@3>*/name, /*<@262>*/typeParameters) {
        if (!(typeParameters instanceof Array))
            throw new Error("type parameters not array: " + typeParameters);
        super();
        this._origin = origin;
        this._name = name;
        this._typeParameters = typeParameters;
        this._isNumber = false;
        this._isInt = false;
        this._isFloating = false;
        this._isPrimitive = false;
        this.instantiate = NativeTypeInstantiate;
    }
    get /*<@263>*/typeParameters() { return this._typeParameters; }
    get /*<@264>*/isNative() { return true; }
    // We let Intrinsics.js set these as it likes.
    get /*<@265>*/isNumber() { return this._isNumber; }
    set /*<@266>*/isNumber(/*<@2>*/value) { this._isNumber = value; }
    get /*<@267>*/isInt() { return this._isInt; }
    set /*<@268>*/isInt(/*<@2>*/value) { this._isInt = value; }
    get /*<@269>*/isFloating() { return this._isFloating; }
    set /*<@270>*/isFloating(/*<@2>*/value) { this._isFloating = value; }
    get /*<@271>*/isPrimitive() { return this._isPrimitive; }
    set /*<@272>*/isPrimitive(/*<@2>*/value) { this._isPrimitive = value; }
    /*<@273>*/toString() {
        return "native typedef " + this.name + "<" + this.typeParameters + ">";
    }
}
class /*<@318>*/NativeTypeInstance extends Type {
    constructor(/*<@85>*/type, /*<@136>*/typeArguments) {
        super();
        this._type = type;
        this._typeArguments = typeArguments;
    }
    get /*<@319>*/typeArguments() { return this._typeArguments; }
    get /*<@320>*/isPrimitive() { return this._type.isPrimitive; }
    get /*<@321>*/isNative() { return true; }
    /*<@322>*/unifyImpl(/*<@153>*/unificationContext, /*<@317>*/other) {
        if (this.type != other.type)
            return false;
        if (this.typeArguments.length != other.typeArguments.length)
            return false;
        for (let /*<@5>*/i = 0; i < this.typeArguments.length; ++i) {
            if (!this.typeArguments[i].unify(unificationContext, other.typeArguments[i]))
                return false;
        }
        return true;
    }
    /*<@323>*/toString() {
        return this.type + "<" + this.typeArguments + ">";
    }
}
class /*<@1318>*/NormalUsePropertyResolver extends Rewriter {
    /*<@1319>*/visitDotExpression(/*<@466>*/node) {
        return super.visitDotExpression(node).rewriteAfterCloning();
    }
    /*<@1320>*/visitIndexExpression(/*<@475>*/node) {
        return super.visitIndexExpression(node).rewriteAfterCloning();
    }
}
class /*<@549>*/NullLiteral extends Expression {
    constructor(/*<@42>*/origin) {
        super(origin);
        this.type = new NullType(origin);
    }
    /*<@550>*/toString() {
        return "null";
    }
}
class /*<@553>*/NullType extends Type {
    constructor(/*<@42>*/origin) {
        super();
        this._origin = origin;
        this._isLiteral = true;
    }
    // For now we answer false for isPtr and isArrayRef because that happens to make all of the logic
    // work. But, it's strange, since as a bottom type it really is the case that this is both isPtr and
    // isArrayRef.
    get /*<@554>*/isPrimitive() { return true; }
    get /*<@555>*/isUnifiable() { return true; }
    /*<@556>*/typeVariableUnify(/*<@153>*/unificationContext, /*<@85>*/other) {
        if (!(other instanceof Type))
            return false;
        return this._typeVariableUnifyImpl(unificationContext, other);
    }
    /*<@557>*/unifyImpl(/*<@153>*/unificationContext, /*<@85>*/other) {
        return this.typeVariableUnify(unificationContext, other);
    }
    /*<@558>*/verifyAsArgument(/*<@153>*/unificationContext) {
        let /*<@7>*/realThis = unificationContext.find(this);
        if (realThis.isPtr || /*<@85>*/realThis.isArrayRef)
            return /*<@785>*/{ result: true, reason: undefined };
        return /*<@775>*/{ result: false, reason: "Null cannot be used with non-pointer type " + realThis };
    }
    /*<@559>*/verifyAsParameter(/*<@153>*/unificationContext) {
        throw new Error("NullType should never be used as a type parameter");
    }
    /*<@560>*/commitUnification(/*<@153>*/unificationContext) {
        this.type = unificationContext.find(this);
    }
    /*<@561>*/toString() {
        return "nullType";
    }
}
const /*<@826>*/originKinds = /*<@826>*/["native", "user"];
function /*<@1321>*/isOriginKind(/*<@3>*/originKind) {
    switch (originKind) {
        case "native":
        case "user":
            return true;
        default:
            return false;
    }
}
class /*<@765>*/OverloadResolutionFailure {
    constructor(/*<@114>*/func, /*<@3>*/reason) {
        this._func = func;
        this._reason = reason;
    }
    get /*<@766>*/func() { return this._func; }
    get /*<@767>*/reason() { return this._reason; }
    /*<@768>*/toString() {
        return this.func.toDeclString() + " did not match because: " + this.reason;
    }
}
class /*<@1323>*/Parse {
    constructor(/*<@71>*/program, /*<@3>*/origin, /*<@3>*/originKind, /*<@5>*/lineNumberOffset, /*<@3>*/text) {
        this.program = program;
        this.origin = origin;
        this.originKind = originKind;
        this.lineNumberOffset = lineNumberOffset;
        this.text = text;
        this.lexer = new Lexer(origin, originKind, lineNumberOffset, text);
        Parse.instance = this;
    }
    static /*<@1324>*/genericConsume(callback, /*<@826>*/explanation) {
        let /*<@9>*/token = Parse.instance.lexer.next();
        if (!token)
            Parse.instance.lexer.fail("Unexpected end of file");
        if (!callback(token))
            Parse.instance.lexer.fail("Unexpected token: " + token.text + "; expected: " + explanation);
        return token;
    }
    static /*<@1325>*/consume(.../*<@826>*/texts) {
        return Parse.genericConsume(/*<@1401>*/token => (texts.indexOf(token.text) != -1), texts);
    }
    static /*<@1326>*/consumeKind(/*<@3>*/kind) {
        return Parse.genericConsume(/*<@1402>*/token => token.kind == kind, /*<@826>*/[kind]);
    }
    static /*<@1327>*/assertNext(.../*<@826>*/texts) {
        Parse.instance.lexer.push(Parse.consume(...texts));
    }
    static /*<@1328>*/genericTest(callback) {
        let /*<@9>*/token = Parse.instance.lexer.peek();
        if (token && callback(token))
            return token;
        return null;
    }
    static /*<@1329>*/test(.../*<@826>*/texts) {
        return Parse.genericTest(/*<@1403>*/(/*<@9>*/token) => (texts.indexOf(token.text) != -1));
    }
    static /*<@1330>*/testKind(/*<@3>*/kind) {
        return Parse.genericTest(/*<@1404>*/token => token.kind == kind);
    }
    static /*<@1331>*/tryConsume(.../*<@826>*/texts) {
        let /*<@9>*/result = Parse.test(...texts);
        if (result)
            Parse.instance.lexer.next();
        return result;
    }
    static /*<@1332>*/tryConsumeKind(/*<@3>*/kind) {
        let /*<@9>*/result = Parse.testKind(kind);
        if (result)
            Parse.instance.lexer.next();
        return result;
    }
    static /*<@1333>*/parseProtocolRef() {
        let /*<@9>*/protocolToken = Parse.consumeKind("identifier");
        return new ProtocolRef(protocolToken, protocolToken.text);
    }
    static /*<@1334>*/consumeEndOfTypeArgs() {
        let /*<@9>*/rightShift = Parse.tryConsume(">>");
        if (rightShift)
            Parse.instance.lexer.push(new LexerToken(Parse.instance.lexer, rightShift.index, rightShift.kind, ">"));
        // lexer.push(new LexerToken(lexer, rightShift, rightShift.index, rightShift.kind, ">")); XTS
        else
            this.consume(">");
    }
    static /*<@1335>*/parseTypeParameters() {
        let /*<@262>*/result = new /*<@262>*/Array();
        if (!Parse.test("<"))
            return result;
        Parse.consume("<");
        let /*<@1008>*/assertNextFunc = Parse.assertNext;
        while (!Parse.test(">")) {
            let /*<@251>*/constexpr = Parse.instance.lexer.backtrackingScope(/*<@1405>*/() => {
                let /*<@85>*/type = Parse.parseType();
                let /*<@9>*/name = Parse.consumeKind("identifier");
                assertNextFunc(",", ">", ">>");
                return new ConstexprTypeParameter(type.origin, name.text, type);
            });
            if (constexpr)
                result.push(constexpr);
            else {
                let /*<@9>*/name = Parse.consumeKind("identifier");
                let /*<@107>*/protocol = Parse.tryConsume(":") ? Parse.parseProtocolRef() : null;
                result.push(new TypeVariable(name, name.text, protocol));
            }
            if (!Parse.tryConsume(","))
                break;
        }
        Parse.consumeEndOfTypeArgs();
        return result;
    }
    static /*<@1336>*/parseTerm() {
        let /*<@9>*/token;
        if (token = Parse.tryConsume("null"))
            return new NullLiteral(token);
        if (token = Parse.tryConsumeKind("identifier"))
            return new VariableRef(token, token.text);
        if (token = Parse.tryConsumeKind("intLiteral")) {
            let /*<@1>*/intVersion = (+token.text) | 0;
            if ("" + intVersion !== token.text)
                Parse.instance.lexer.fail("Integer literal is not an integer: " + token.text);
            return new IntLiteral(token, intVersion);
        }
        if (token = Parse.tryConsumeKind("uintLiteral")) {
            let /*<@1>*/uintVersion = token.text.substr(0, token.text.length - 1) >>> 0;
            if (uintVersion + "u" !== token.text)
                Parse.instance.lexer.fail("Integer literal is not 32-bit unsigned integer: " + token.text);
            return new UintLiteral(token, uintVersion);
        }
        if ((token = Parse.tryConsumeKind("intHexLiteral"))
            || (token = Parse.tryConsumeKind("uintHexLiteral"))) {
            let /*<@3>*/hexString = token.text.substr(2);
            if (token.kind == "uintHexLiteral")
                hexString = hexString.substr(0, hexString.length - 1);
            if (!hexString.length)
                throw new Error("Bad hex literal: " + token);
            let /*<@1>*/intVersion = parseInt(hexString, 16);
            if (token.kind == "intHexLiteral")
                intVersion = intVersion | 0;
            else
                intVersion = intVersion >>> 0;
            /*
            if (intVersion.toString(16) !== hexString)
                Parse.instance.lexer.fail("Hex integer literal is not an integer: " + token.text);
            */
            if (token.kind == "intHexLiteral")
                return new IntLiteral(token, intVersion);
            return new UintLiteral(token, intVersion >>> 0);
        }
        if (token = Parse.tryConsumeKind("doubleLiteral"))
            return new DoubleLiteral(token, +token.text);
        if (token = Parse.tryConsumeKind("floatLiteral")) {
            let /*<@3>*/text = token.text;
            let /*<@2>*/d = token.text.endsWith("d");
            let /*<@2>*/f = token.text.endsWith("f");
            if (d && f)
                throw new Error("Literal cannot be both a double literal and a float literal.");
            if (d || f)
                text = text.substring(0, text.length - 1);
            let /*<@1>*/value = parseFloat(text);
            if (d)
                return new DoubleLiteral(token, value);
            return new FloatLiteral(token, Math.fround(value));
        }
        if (token = Parse.tryConsume("true", "false"))
            return new BoolLiteral(token, token.text == "true");
        // FIXME: Need support for other literals too.
        Parse.consume("(");
        let /*<@303>*/result = Parse.parseExpression();
        Parse.consume(")");
        return result;
    }
    static /*<@1337>*/parseConstexpr() {
        let /*<@9>*/token;
        if (token = Parse.tryConsume("-"))
            return new CallExpression(token, "operator" + token.text, /*<@784>*/[], /*<@340>*/[Parse.parseTerm()]);
        let /*<@303>*/left = Parse.parseTerm();
        if (token = Parse.tryConsume("."))
            left = new DotExpression(token, left, Parse.consumeKind("identifier").text);
        return left;
    }
    static /*<@1338>*/parseTypeArguments() {
        if (!Parse.test("<"))
            return /*<@784>*/[];
        let /*<@784>*/result = /*<@784>*/[];
        Parse.consume("<");
        let /*<@1008>*/assertNextFunc = Parse.assertNext;
        while (!Parse.test(">")) {
            // It's possible for a constexpr or type can syntactically overlap in the single
            // identifier case. Let's consider the possibilities:
            //
            //     T          could be type or constexpr
            //     T[]        only type
            //     T[42]      only type (constexpr cannot do indexing)
            //     42         only constexpr
            //
            // In the future we'll allow constexprs to do more things, and then we'll still have
            // the problem that something of the form T[1][2][3]... can either be a type or a
            // constexpr, and we can figure out in the checker which it is.
            let /*<@29>*/typeOrVariableRef = Parse.instance.lexer.backtrackingScope(/*<@1406>*/() => {
                let /*<@9>*/result = Parse.consumeKind("identifier");
                assertNextFunc(",", ">", ">>");
                return new TypeOrVariableRef(result, result.text);
            });
            if (typeOrVariableRef)
                result.push(typeOrVariableRef);
            else {
                let /*<@29>*/constexpr = Parse.instance.lexer.backtrackingScope(/*<@1407>*/() => {
                    let parseConstexprFunc = Parse.parseConstexpr;
                    let /*<@303>*/result = parseConstexprFunc();
                    assertNextFunc(",", ">", ">>");
                    return result;
                });
                if (constexpr)
                    result.push(constexpr);
                else
                    result.push(Parse.parseType());
            }
            if (!Parse.tryConsume(","))
                break;
        }
        Parse.consumeEndOfTypeArgs();
        return result;
    }
    static /*<@1339>*/getAddressSpace(/*<@3>*/addressSpace) {
        Parse.instance.addressSpaceConsumed = true;
        if (addressSpace)
            return addressSpace;
        return Parse.consume(...addressSpaces).text;
    }
    static /*<@1340>*/parseType() {
        let /*<@9>*/token;
        let /*<@3>*/addressSpace;
        Parse.instance.addressSpaceConsumed = false;
        if (token = Parse.tryConsume(...addressSpaces))
            addressSpace = token.text;
        let /*<@9>*/name = Parse.consumeKind("identifier");
        let /*<@101>*/typeArguments = Parse.parseTypeArguments();
        let /*<@85>*/type = new TypeRef(name, name.text, typeArguments);
        while (token = Parse.tryConsume("*", "[")) {
            if (token.text == "*") {
                type = new PtrType(token, Parse.getAddressSpace(addressSpace), type);
                continue;
            }
            if (Parse.tryConsume("]")) {
                type = new ArrayRefType(token, Parse.getAddressSpace(addressSpace), type);
                continue;
            }
            type = new ArrayType(token, type, Parse.parseConstexpr());
            Parse.consume("]");
        }
        if (addressSpace && !Parse.instance.addressSpaceConsumed)
            Parse.instance.lexer.fail("Address space specified for type that does not need address space");
        return type;
    }
    static /*<@1341>*/parseTypeDef() {
        let /*<@9>*/origin = Parse.consume("typedef");
        let /*<@3>*/name = Parse.consumeKind("identifier").text;
        let /*<@262>*/typeParameters = Parse.parseTypeParameters();
        Parse.consume("=");
        let /*<@85>*/type = Parse.parseType();
        Parse.consume(";");
        return new TypeDef(origin, name, typeParameters, type);
    }
    static /*<@1342>*/genericParseLeft(/*<@826>*/texts, nextParser, constructor) {
        let /*<@303>*/left = nextParser();
        let /*<@9>*/token;
        while (token = Parse.tryConsume(...texts))
            left = constructor(token, left, nextParser());
        return left;
    }
    static /*<@1343>*/parseLeftOperatorCall(/*<@826>*/texts, nextParser) {
        //TODO: anomoy function has no feedback
        let /*<@101>*/emptyArray = /*<@101>*/[];
        return Parse.genericParseLeft(texts, nextParser, /*<@1408>*/(/*<@9>*/token, /*<@303>*/left, /*<@303>*/right) => new CallExpression(token, "operator" + token.text, emptyArray, /*<@340>*/[left, right]));
    }
    static /*<@1344>*/parseCallExpression() {
        let /*<@9>*/name = Parse.consumeKind("identifier");
        let /*<@101>*/typeArguments = Parse.parseTypeArguments();
        Parse.consume("(");
        let /*<@784>*/argumentList = /*<@784>*/[];
        while (!Parse.test(")")) {
            let /*<@303>*/argument = Parse.parsePossibleAssignment();
            argumentList.push(argument);
            if (!Parse.tryConsume(","))
                break;
        }
        Parse.consume(")");
        let /*<@437>*/result = new CallExpression(name, name.text, typeArguments, argumentList);
        return result;
    }
    static /*<@1345>*/isCallExpression() {
        return Parse.instance.lexer.testScope(/*<@1409>*/() => {
            Parse.consumeKind("identifier");
            Parse.parseTypeArguments();
            Parse.consume("(");
        });
    }
    static /*<@1346>*/emitIncrement(/*<@9>*/token, /*<@7>*/old, /*<@7>*/extraArg) {
        let /*<@101>*/args = /*<@101>*/[old];
        if (extraArg)
            args.push(extraArg);
        let /*<@3>*/name = "operator" + token.text;
        if (/=$/.test(name))
            name = RegExp.leftContext;
        if (name == "operator")
            throw new Error("Invalid name: " + name);
        return new CallExpression(token, name, /*<@784>*/[], args);
    }
    static /*<@1347>*/finishParsingPostIncrement(/*<@9>*/token, /*<@303>*/left) {
        let /*<@411>*/readModifyWrite = new ReadModifyWriteExpression(token, left);
        readModifyWrite.newValueExp = Parse.emitIncrement(token, readModifyWrite.oldValueRef());
        readModifyWrite.resultExp = readModifyWrite.oldValueRef();
        return readModifyWrite;
    }
    static /*<@1348>*/parseSuffixOperator(/*<@303>*/left, .../*<@826>*/acceptableOperators) {
        let /*<@9>*/token;
        while (token = Parse.tryConsume(...acceptableOperators)) {
            switch (token.text) {
                case "++":
                case "--":
                    return Parse.finishParsingPostIncrement(token, left);
                case ".":
                case "->":
                    if (token.text == "->")
                        left = new DereferenceExpression(token, left);
                    left = new DotExpression(token, left, Parse.consumeKind("identifier").text);
                    break;
                case "[": {
                    let /*<@303>*/index = Parse.parseExpression();
                    Parse.consume("]");
                    left = new IndexExpression(token, left, index);
                    break;
                }
                default:
                    throw new Error("Bad token: " + token);
            }
        }
        return left;
    }
    static /*<@1349>*/parsePossibleSuffix() {
        let /*<@826>*/acceptableOperators = /*<@826>*/["++", "--", ".", "->", "["];
        let /*<@826>*/limitedOperators = /*<@826>*/[".", "->", "["];
        let /*<@303>*/left;
        if (Parse.isCallExpression()) {
            left = Parse.parseCallExpression();
            return Parse.parseSuffixOperator(left, ".", "->", "[");
            // acceptableOperators = limitedOperators; XTS
        }
        else {
            left = Parse.parseTerm();
            return Parse.parseSuffixOperator(left, "++", "--", ".", "->", "[");
        }
    }
    static /*<@1350>*/finishParsingPreIncrement(/*<@9>*/token, /*<@303>*/left, /*<@7>*/extraArg) {
        let /*<@411>*/readModifyWrite = new ReadModifyWriteExpression(token, left);
        readModifyWrite.newValueExp = Parse.emitIncrement(token, readModifyWrite.oldValueRef(), extraArg);
        readModifyWrite.resultExp = readModifyWrite.newValueRef();
        return readModifyWrite;
    }
    static /*<@1351>*/parsePreIncrement() {
        let /*<@9>*/token = Parse.consume("++", "--");
        let /*<@303>*/left = Parse.parsePossiblePrefix();
        return Parse.finishParsingPreIncrement(token, left);
    }
    static /*<@1352>*/parsePossiblePrefix() {
        let /*<@9>*/token;
        if (Parse.test("++", "--"))
            return Parse.parsePreIncrement();
        if (token = Parse.tryConsume("+", "-", "~"))
            return new CallExpression(token, "operator" + token.text, /*<@784>*/[], /*<@340>*/[Parse.parsePossiblePrefix()]);
        if (token = Parse.tryConsume("*"))
            return new DereferenceExpression(token, Parse.parsePossiblePrefix());
        if (token = Parse.tryConsume("&"))
            return new MakePtrExpression(token, Parse.parsePossiblePrefix());
        if (token = Parse.tryConsume("@"))
            return new MakeArrayRefExpression(token, Parse.parsePossiblePrefix());
        if (token = Parse.tryConsume("!")) {
            let /*<@303>*/remainder = Parse.parsePossiblePrefix();
            return new LogicalNot(token, new CallExpression(remainder.origin, "bool", /*<@784>*/[], /*<@340>*/[remainder]));
        }
        return Parse.parsePossibleSuffix();
    }
    static /*<@1353>*/parsePossibleProduct() {
        return Parse.parseLeftOperatorCall(/*<@826>*/["*", "/", "%"], Parse.parsePossiblePrefix);
    }
    static /*<@1354>*/parsePossibleSum() {
        return Parse.parseLeftOperatorCall(/*<@826>*/["+", "-"], Parse.parsePossibleProduct);
    }
    static /*<@1355>*/parsePossibleShift() {
        return Parse.parseLeftOperatorCall(/*<@826>*/["<<", ">>"], Parse.parsePossibleSum);
    }
    static /*<@1356>*/parsePossibleRelationalInequality() {
        return Parse.parseLeftOperatorCall(/*<@826>*/["<", ">", "<=", ">="], Parse.parsePossibleShift);
    }
    static /*<@1357>*/parsePossibleRelationalEquality() {
        return Parse.genericParseLeft(/*<@826>*/["==", "!="], Parse.parsePossibleRelationalInequality, /*<@1410>*/(/*<@9>*/token, /*<@303>*/left, /*<@303>*/right) => {
            let /*<@303>*/result = new CallExpression(token, "operator==", /*<@784>*/[], /*<@340>*/[left, right]);
            if (token.text == "!=")
                result = new LogicalNot(token, /*<@437>*/result);
            return result;
        });
    }
    static /*<@1358>*/parsePossibleBitwiseAnd() {
        return Parse.parseLeftOperatorCall(/*<@826>*/["&"], Parse.parsePossibleRelationalEquality);
    }
    static /*<@1359>*/parsePossibleBitwiseXor() {
        return Parse.parseLeftOperatorCall(/*<@826>*/["^"], Parse.parsePossibleBitwiseAnd);
    }
    static /*<@1360>*/parsePossibleBitwiseOr() {
        return Parse.parseLeftOperatorCall(/*<@826>*/["|"], Parse.parsePossibleBitwiseXor);
    }
    static /*<@1361>*/parseLeftLogicalExpression(/*<@826>*/texts, nextParser) {
        let /*<@101>*/emptyArray = /*<@101>*/[];
        return Parse.genericParseLeft(texts, nextParser, /*<@1411>*/(/*<@9>*/token, /*<@303>*/left, /*<@303>*/right) => new LogicalExpression(token, token.text, new CallExpression(left.origin, "bool", emptyArray, /*<@340>*/[left]), new CallExpression(right.origin, "bool", emptyArray, /*<@340>*/[right])));
    }
    static /*<@1362>*/parsePossibleLogicalAnd() {
        return Parse.parseLeftLogicalExpression(/*<@826>*/["&&"], Parse.parsePossibleBitwiseOr);
    }
    static /*<@1363>*/parsePossibleLogicalOr() {
        return Parse.parseLeftLogicalExpression(/*<@826>*/["||"], Parse.parsePossibleLogicalAnd);
    }
    static /*<@1364>*/parsePossibleTernaryConditional() {
        let /*<@303>*/predicate = Parse.parsePossibleLogicalOr();
        let /*<@9>*/operator = Parse.tryConsume("?");
        if (!operator)
            return predicate;
        throw new Error("no TernaryExpression");
        // return new TernaryExpression(operator, predicate, parsePossibleAssignment(), parsePossibleAssignment());
    }
    static /*<@1365>*/parsePossibleAssignment(/*<@3>*/mode) {
        let /*<@303>*/lhs = Parse.parsePossibleTernaryConditional();
        let /*<@9>*/operator = Parse.tryConsume("=", "+=", "-=", "*=", "/=", "%=", "^=", "|=", "&=");
        if (!operator) {
            if (mode && mode == "required")
                Parse.instance.lexer.fail("Expected assignment");
            return lhs;
        }
        if (operator.text == "=")
            return new Assignment(operator, lhs, Parse.parsePossibleAssignment());
        return Parse.finishParsingPreIncrement(operator, lhs, Parse.parsePossibleAssignment());
    }
    static /*<@1366>*/parseAssignment() {
        return Parse.parsePossibleAssignment("required");
    }
    static /*<@1367>*/parsePostIncrement() {
        let /*<@303>*/left = Parse.parseSuffixOperator(Parse.parseTerm(), ".", "->", "[");
        let /*<@9>*/token = Parse.consume("++", "--");
        return Parse.finishParsingPostIncrement(token, left);
    }
    static /*<@1368>*/parseEffectfulExpression() {
        if (Parse.isCallExpression())
            return Parse.parseCallExpression();
        let /*<@303>*/preIncrement = Parse.instance.lexer.backtrackingScope(Parse.parsePreIncrement);
        if (preIncrement)
            return preIncrement;
        let /*<@303>*/postIncrement = Parse.instance.lexer.backtrackingScope(Parse.parsePostIncrement);
        if (postIncrement)
            return postIncrement;
        return Parse.parseAssignment();
    }
    static /*<@1369>*/genericParseCommaExpression(finalExpressionParser) {
        let /*<@340>*/list = /*<@340>*/[];
        let /*<@9>*/origin = Parse.instance.lexer.peek();
        if (!origin)
            Parse.instance.lexer.fail("Unexpected end of file");
        for (;;) {
            let /*<@303>*/effectfulExpression = Parse.instance.lexer.backtrackingScope(/*<@1412>*/() => {
                // XTS
                let /*<@303>*/result;
                result = Parse.parseEffectfulExpression();
                Parse.consume(",");
                return result;
            });
            if (!effectfulExpression) {
                let /*<@303>*/final = finalExpressionParser();
                list.push(final);
                break;
            }
            list.push(effectfulExpression);
        }
        if (!list.length)
            throw new Error("Length should never be zero");
        if (list.length == 1)
            return list[0];
        return new CommaExpression(origin, list);
    }
    static /*<@1370>*/parseCommaExpression() {
        return Parse.genericParseCommaExpression(Parse.parsePossibleAssignment);
    }
    static /*<@1371>*/parseExpression() {
        return Parse.parseCommaExpression();
    }
    static /*<@1372>*/parseEffectfulStatement() {
        let /*<@303>*/result = Parse.genericParseCommaExpression(Parse.parseEffectfulExpression);
        Parse.consume(";");
        return result;
    }
    static /*<@1373>*/parseReturn() {
        let /*<@9>*/origin = Parse.consume("return");
        if (Parse.tryConsume(";"))
            return new Return(origin, null);
        let /*<@303>*/expression = Parse.parseExpression();
        Parse.consume(";");
        return new Return(origin, expression);
    }
    static /*<@1374>*/parseBreak() {
        let /*<@9>*/origin = Parse.consume("break");
        Parse.consume(";");
        return new Break(origin);
    }
    static /*<@1375>*/parseContinue() {
        let /*<@9>*/origin = Parse.consume("continue");
        Parse.consume(";");
        return new Continue(origin);
    }
    static /*<@1376>*/parseIfStatement() {
        let /*<@9>*/origin = Parse.consume("if");
        Parse.consume("(");
        let /*<@303>*/conditional = Parse.parseExpression();
        Parse.consume(")");
        let /*<@7>*/body = Parse.parseStatement();
        let /*<@7>*/elseBody;
        if (Parse.tryConsume("else"))
            elseBody = Parse.parseStatement();
        return new IfStatement(origin, new CallExpression(conditional.origin, "bool", /*<@784>*/[], /*<@340>*/[conditional]), body, elseBody);
    }
    static /*<@1377>*/parseWhile() {
        let /*<@9>*/origin = Parse.consume("while");
        Parse.consume("(");
        let /*<@303>*/conditional = Parse.parseExpression();
        Parse.consume(")");
        let /*<@7>*/body = Parse.parseStatement();
        return new WhileLoop(origin, new CallExpression(conditional.origin, "bool", /*<@784>*/[], /*<@340>*/[conditional]), body);
    }
    static /*<@1378>*/parseFor() {
        let /*<@9>*/origin = Parse.consume("for");
        Parse.consume("(");
        let /*<@29>*/initialization;
        if (Parse.tryConsume(";"))
            initialization = undefined;
        else {
            initialization = Parse.instance.lexer.backtrackingScope(Parse.parseVariableDecls);
            if (!initialization)
                initialization = Parse.parseEffectfulStatement();
        }
        let /*<@9>*/conditionToken = Parse.tryConsume(";");
        let /*<@303>*/condition;
        if (conditionToken)
            condition = undefined;
        else {
            condition = Parse.parseExpression();
            Parse.consume(";");
            condition = new CallExpression(condition.origin, "bool", /*<@784>*/[], /*<@340>*/[condition]);
        }
        let /*<@303>*/increment;
        if (Parse.tryConsume(")"))
            increment = undefined;
        else {
            increment = Parse.parseExpression();
            Parse.consume(")");
        }
        let /*<@7>*/body = Parse.parseStatement();
        return new ForLoop(origin, /*<@303>*/initialization, /*<@437>*/condition, increment, body);
    }
    static /*<@1379>*/parseDo() {
        let /*<@9>*/origin = Parse.consume("do");
        let /*<@7>*/body = Parse.parseStatement();
        Parse.consume("while");
        Parse.consume("(");
        let /*<@303>*/conditional = Parse.parseExpression();
        Parse.consume(")");
        return new DoWhileLoop(origin, body, new CallExpression(conditional.origin, "bool", /*<@784>*/[], /*<@340>*/[conditional]));
    }
    static /*<@1380>*/parseVariableDecls() {
        let /*<@85>*/type = Parse.parseType();
        let /*<@784>*/list = /*<@784>*/[];
        do {
            let /*<@9>*/name = Parse.consumeKind("identifier");
            let /*<@303>*/initializer = Parse.tryConsume("=") ? Parse.parseExpression() : null;
            list.push(new VariableDecl(name, name.text, type, initializer));
        } while (Parse.consume(",", ";").text == ",");
        return new CommaExpression(type.origin, list);
    }
    static /*<@1381>*/parseSwitchCase() {
        let /*<@9>*/token = Parse.consume("default", "case");
        let /*<@120>*/value;
        if (token.text == "case")
            value = Parse.parseConstexpr();
        Parse.consume(":");
        let /*<@332>*/body = Parse.parseBlockBody("}", "default", "case");
        return new SwitchCase(token, value, body);
    }
    static /*<@1382>*/parseSwitchStatement() {
        let /*<@9>*/origin = Parse.consume("switch");
        Parse.consume("(");
        let /*<@303>*/value = Parse.parseExpression();
        Parse.consume(")");
        Parse.consume("{");
        let /*<@613>*/result = new SwitchStatement(origin, value);
        while (!Parse.tryConsume("}"))
            result.add(Parse.parseSwitchCase());
        return result;
    }
    static /*<@1383>*/parseStatement() {
        let /*<@9>*/token = Parse.instance.lexer.peek();
        if (token.text == ";") {
            Parse.instance.lexer.next();
            return null;
        }
        if (token.text == "return")
            return Parse.parseReturn();
        if (token.text == "break")
            return Parse.parseBreak();
        if (token.text == "continue")
            return Parse.parseContinue();
        if (token.text == "while")
            return Parse.parseWhile();
        if (token.text == "do")
            return Parse.parseDo();
        if (token.text == "for")
            return Parse.parseFor();
        if (token.text == "if")
            return Parse.parseIfStatement();
        if (token.text == "switch")
            return Parse.parseSwitchStatement();
        if (token.text == "trap") {
            let /*<@9>*/origin = Parse.consume("trap");
            Parse.consume(";");
            return new TrapStatement(origin);
        }
        if (token.text == "{")
            return Parse.parseBlock();
        let /*<@29>*/variableDecl = Parse.instance.lexer.backtrackingScope(Parse.parseVariableDecls);
        if (variableDecl)
            return variableDecl;
        return Parse.parseEffectfulStatement();
    }
    static /*<@1384>*/parseBlockBody(.../*<@826>*/terminators) {
        let /*<@332>*/block = new Block(Parse.instance.origin);
        while (!Parse.test(...terminators)) {
            let /*<@7>*/statement = Parse.parseStatement();
            if (statement)
                block.add(statement);
        }
        return block;
    }
    static /*<@1385>*/parseBlock() {
        let /*<@9>*/origin = Parse.consume("{");
        let /*<@332>*/block = Parse.parseBlockBody("}");
        Parse.consume("}");
        return block;
    }
    static /*<@1386>*/parseParameter() {
        let /*<@85>*/type = Parse.parseType();
        let /*<@9>*/name = Parse.tryConsumeKind("identifier");
        return new FuncParameter(type.origin, name ? name.text : null, type);
    }
    static /*<@1387>*/parseParameters() {
        Parse.consume("(");
        let /*<@784>*/parameters = /*<@784>*/[];
        while (!Parse.test(")")) {
            parameters.push(Parse.parseParameter());
            if (!Parse.tryConsume(","))
                break;
        }
        Parse.consume(")");
        return parameters;
    }
    static /*<@1388>*/parseFuncName() {
        if (Parse.tryConsume("operator")) {
            let /*<@9>*/token = Parse.consume("+", "-", "*", "/", "%", "^", "&", "|", "<", ">", "<=", ">=", "==", "++", "--", ".", "~", "<<", ">>", "[");
            if (token.text == "&") {
                if (Parse.tryConsume("[")) {
                    Parse.consume("]");
                    return "operator&[]";
                }
                if (Parse.tryConsume("."))
                    return "operator&." + Parse.consumeKind("identifier").text;
                return "operator&";
            }
            if (token.text == ".") {
                let /*<@3>*/result = "operator." + Parse.consumeKind("identifier").text;
                if (Parse.tryConsume("="))
                    result += "=";
                return result;
            }
            if (token.text == "[") {
                Parse.consume("]");
                let /*<@3>*/result = "operator[]";
                if (Parse.tryConsume("="))
                    result += "=";
                return result;
            }
            return "operator" + token.text;
        }
        return Parse.consumeKind("identifier").text;
    }
    static /*<@1389>*/parseFuncDecl() {
        let /*<@42>*/origin;
        let /*<@85>*/returnType;
        let /*<@3>*/name;
        let /*<@262>*/typeParameters;
        let /*<@2>*/isCast;
        let /*<@3>*/shaderType;
        let /*<@9>*/operatorToken = Parse.tryConsume("operator");
        if (operatorToken) {
            origin = operatorToken;
            typeParameters = Parse.parseTypeParameters();
            returnType = Parse.parseType();
            name = "operator cast";
            isCast = true;
        }
        else {
            let /*<@9>*/shaderTypeToken = Parse.tryConsume("vertex", "fragment");
            returnType = Parse.parseType();
            if (shaderTypeToken) {
                origin = shaderTypeToken;
                shaderType = shaderTypeToken.text;
            }
            else
                origin = returnType.origin;
            name = Parse.parseFuncName();
            typeParameters = Parse.parseTypeParameters();
            isCast = false;
        }
        let /*<@130>*/parameters = Parse.parseParameters();
        return new Func(origin, name, returnType, typeParameters, parameters, isCast, shaderType);
    }
    static /*<@1390>*/parseProtocolFuncDecl() {
        let /*<@114>*/func = Parse.parseFuncDecl();
        return new ProtocolFuncDecl(func.origin, func.name, func.returnType, func.typeParameters, func.parameters, func.isCast, func.shaderType);
    }
    static /*<@1391>*/parseFuncDef() {
        let /*<@114>*/func = Parse.parseFuncDecl();
        let /*<@332>*/body = Parse.parseBlock();
        return new FuncDef(func.origin, func.name, func.returnType, func.typeParameters, func.parameters, body, func.isCast, func.shaderType);
    }
    static /*<@1392>*/parseProtocolDecl() {
        let /*<@9>*/origin = Parse.consume("protocol");
        let /*<@3>*/name = Parse.consumeKind("identifier").text;
        let /*<@109>*/result = new ProtocolDecl(origin, name);
        if (Parse.tryConsume(":")) {
            while (!Parse.test("{")) {
                result.addExtends(Parse.parseProtocolRef());
                if (!Parse.tryConsume(","))
                    break;
            }
        }
        Parse.consume("{");
        while (!Parse.tryConsume("}")) {
            result.add(Parse.parseProtocolFuncDecl());
            Parse.consume(";");
        }
        return result;
    }
    static /*<@1393>*/parseField() {
        let /*<@85>*/type = Parse.parseType();
        let /*<@9>*/name = Parse.consumeKind("identifier");
        Parse.consume(";");
        return new Field(name, name.text, type);
    }
    static /*<@1394>*/parseStructType() {
        let /*<@9>*/origin = Parse.consume("struct");
        let /*<@3>*/name = Parse.consumeKind("identifier").text;
        let /*<@262>*/typeParameters = Parse.parseTypeParameters();
        let /*<@280>*/result = new StructType(origin, name, typeParameters);
        Parse.consume("{");
        while (!Parse.tryConsume("}"))
            result.add(Parse.parseField());
        return result;
    }
    static /*<@1395>*/parseNativeFunc() {
        let /*<@114>*/func = Parse.parseFuncDecl();
        Parse.consume(";");
        return new NativeFunc(func.origin, func.name, func.returnType, func.typeParameters, func.parameters, func.isCast, func.shaderType);
    }
    static /*<@1396>*/parseNative() {
        let /*<@9>*/origin = Parse.consume("native");
        if (Parse.tryConsume("typedef")) {
            let /*<@9>*/name = Parse.consumeKind("identifier");
            let /*<@262>*/parameters = Parse.parseTypeParameters();
            Parse.consume(";");
            return new NativeType(origin, name.text, parameters);
        }
        return Parse.parseNativeFunc();
    }
    static /*<@1398>*/parseRestrictedFuncDef() {
        Parse.consume("restricted");
        let /*<@114>*/result;
        if (Parse.tryConsume("native"))
            result = Parse.parseNativeFunc();
        else
            result = Parse.parseFuncDef();
        result.isRestricted = true;
        return result;
    }
    static /*<@1399>*/parseEnumMember() {
        let /*<@9>*/name = Parse.consumeKind("identifier");
        let /*<@303>*/value = null;
        if (Parse.tryConsume("="))
            value = Parse.parseConstexpr();
        return new EnumMember(name, name.text, value);
    }
    static /*<@1400>*/parseEnumType() {
        Parse.consume("enum");
        let /*<@9>*/name = Parse.consumeKind("identifier");
        let /*<@85>*/baseType;
        if (Parse.tryConsume(":"))
            baseType = Parse.parseType();
        else
            baseType = new TypeRef(name, "int", /*<@784>*/[]);
        Parse.consume("{");
        let /*<@298>*/result = new EnumType(name, name.text, baseType);
        while (!Parse.test("}")) {
            result.add(Parse.parseEnumMember());
            if (!Parse.tryConsume(","))
                break;
        }
        Parse.consume("}");
        return result;
    }
}
function /*<@1413>*/parse(/*<@71>*/program, /*<@3>*/origin, /*<@3>*/originKind, /*<@5>*/lineNumberOffset, /*<@3>*/text) {
    let /*<@1322>*/parser = new Parse(program, origin, originKind, lineNumberOffset, text);
    // The hardest part of dealing with C-like languages is parsing variable declaration statements.
    // Let's consider if this happens in WSL. Here are the valid statements in WSL that being with an
    // identifier, if we assume that any expression can be a standalone statement.
    //
    //     x;
    //     x <binop> y;
    //     x < y;
    //     x < y > z;
    //     x = y;
    //     x.f = y;
    //     \exp = y;
    //     x[42] = y;
    //     x();
    //     x<y>();
    //     x y;
    //     x<y> z;
    //     device x[] y;
    //     x[42] y;
    //     device x^ y;
    //     thread x^^ y;
    //     x^thread^thread y;
    //     x^device^thread y;
    //
    // This has two problem areas:
    //
    //     - x<y>z can parse two different ways (as (x < y) > z or x<y> z).
    //     - x[42] could become either an assignment or a variable declaration.
    //     - x<y> could become either an assignment or a variable declaration.
    //
    // We solve the first problem by forbidding expressions as statements. The lack of function
    // pointers means that we can still allow function call statements - unlike in C, those cannot
    // have arbitrary expressions as the callee. The remaining two problems are solved by
    // backtracking. In all other respects, this is a simple recursive descent parser.
    for (;;) {
        let /*<@9>*/token = parser.lexer.peek();
        if (!token)
            return;
        if (token.text == ";")
            parser.lexer.next();
        else if (token.text == "typedef")
            program.add(Parse.parseTypeDef());
        else if (originKind == "native" && token.text == "native")
            program.add(Parse.parseNative());
        else if (originKind == "native" && token.text == "restricted")
            program.add(Parse.parseRestrictedFuncDef());
        else if (token.text == "struct")
            program.add(Parse.parseStructType());
        else if (token.text == "enum")
            program.add(Parse.parseEnumType());
        else if (token.text == "protocol")
            program.add(Parse.parseProtocolDecl());
        else
            program.add(Parse.parseFuncDef());
    }
}
let /*<@1414>*/prepare = (/*<@1415>*/() => {
    let /*<@71>*/standardProgram;
    return function /*<@1414>*/(/*<@3>*/origin, /*<@5>*/lineNumberOffset, /*<@3>*/text) {
        if (!standardProgram) {
            standardProgram = new Program();
            let /*<@5>*/firstLineOfStandardLibrary = 28; // See StandardLibrary.js.
            parse(standardProgram, "/internal/stdlib", "native", firstLineOfStandardLibrary - 1, standardLibrary);
        }
        let /*<@71>*/program = cloneProgram(standardProgram);
        if (arguments.length) {
            parse(program, origin, "user", lineNumberOffset, text);
            program = programWithUnnecessaryThingsRemoved(program);
        }
        foldConstexprs(program);
        let /*<@1285>*/nameResolver = createNameResolver(program);
        resolveNamesInTypes(program, nameResolver);
        resolveNamesInProtocols(program, nameResolver);
        resolveTypeDefsInTypes(program);
        resolveTypeDefsInProtocols(program);
        checkRecursiveTypes(program);
        synthesizeStructAccessors(program);
        synthesizeEnumFunctions(program);
        resolveNamesInFunctions(program, nameResolver);
        resolveTypeDefsInFunctions(program);
        flattenProtocolExtends(program);
        check(program);
        checkLiteralTypes(program);
        resolveProperties(program);
        findHighZombies(program);
        checkLiteralTypes(program);
        checkProgramWrapped(program);
        checkReturns(program);
        checkUnreachableCode(program);
        checkLoops(program);
        checkRecursion(program);
        checkProgramWrapped(program);
        findHighZombies(program);
        inline(program);
        return program;
    };
})();
class /*<@72>*/Program extends Node {
    constructor() {
        super();
        this._topLevelStatements = /*<@784>*/[];
        this._functions = new Map();
        this._types = new Map();
        this._protocols = new Map();
        this._funcInstantiator = new FuncInstantiator(this);
        this._globalNameContext = new NameContext();
        this._globalNameContext.program = this;
        this._globalNameContext.recognizeIntrinsics();
        this.intrinsics = this._globalNameContext.intrinsics;
    }
    get /*<@203>*/topLevelStatements() { return this._topLevelStatements; }
    get /*<@204>*/functions() { return this._functions; }
    get /*<@205>*/types() { return this._types; }
    get /*<@206>*/protocols() { return this._protocols; }
    get /*<@207>*/funcInstantiator() { return this._funcInstantiator; }
    get /*<@208>*/globalNameContext() { return this._globalNameContext; }
    /*<@209>*/add(/*<@7>*/statement) {
        statement.program = this;
        if (statement instanceof Func) {
            let /*<@143>*/array = this._functions.get(statement.name);
            if (!array)
                this._functions.set(statement.name, array = /*<@784>*/[]);
            array.push(statement);
        }
        else if (statement instanceof Type)
            this._types.set(statement.name, statement);
        else if (statement instanceof Protocol)
            this._protocols.set(statement.name, statement);
        else
            throw new Error("Statement is not a function or type: " + statement);
        this._topLevelStatements.push(statement);
        this._globalNameContext.add(statement);
    }
    /*<@210>*/toString() {
        if (!this._topLevelStatements.length)
            return "";
        return this._topLevelStatements.join(";") + ";";
    }
}
function /*<@1416>*/programWithUnnecessaryThingsRemoved(/*<@71>*/program) {
    let /*<@1272>*/nameFinder = new NameFinder();
    // Build our roots.
    for (let /*<@7>*/statement of program.topLevelStatements) {
        if (statement.origin.originKind === "user")
            nameFinder.add(statement.name);
    }
    // Unfortunately, we cannot know yet which operator casts we'll need.
    nameFinder.add("operator cast");
    // We need these even if the program doesn't mention them by name.
    nameFinder.add("void");
    nameFinder.add("bool");
    nameFinder.add("int");
    // Pull in things as necessary.
    while (nameFinder.worklist.length) {
        let /*<@3>*/name = nameFinder.worklist.pop();
        for (let /*<@7>*/thing of program.globalNameContext.underlyingThings(Anything, name))
            thing.visit(nameFinder);
    }
    let /*<@71>*/result = new Program();
    for (let /*<@3>*/name of nameFinder.set) {
        for (let /*<@7>*/thing of program.globalNameContext.underlyingThings(Anything, name))
            result.add(thing);
    }
    return result;
}
class /*<@712>*/RValueFinder {
    constructor(/*<@713>*/resolver) {
        this.resolver_ = resolver;
    }
    /*<@724>*/visit(/*<@7>*/node) {
        node.visit(this.resolver_);
    }
    /*<@725>*/visitDotExpression(/*<@466>*/node) {
        node.struct.visit(this.resolver_);
    }
    /*<@726>*/visitIndexExpression(/*<@475>*/node) {
        node.array.visit(this.resolver_);
        this.visit(node.index);
    }
    /*<@727>*/visitVariableRef(/*<@418>*/node) {
    }
    /*<@728>*/visitDereferenceExpression(/*<@429>*/node) {
        this.visit(node.ptr);
    }
    /*<@729>*/visitIdentityExpression(/*<@7>*/node) {
        node.target.visit(this.resolver_);
    }
    /*<@730>*/visitMakeArrayRefExpression(/*<@377>*/node) {
        this.visit(node.lValue);
    }
}
class /*<@714>*/PropertyResolver extends Visitor {
    /*<@715>*/_visitRValuesWithinLValue(/*<@7>*/node) {
        node.visit(new RValueFinder(this));
    }
    /*<@716>*/_visitPropertyAccess(/*<@435>*/node) {
        let /*<@120>*/newNode = node.visit(new NormalUsePropertyResolver());
        newNode.visit(this);
        node.become(newNode);
    }
    /*<@717>*/visitDotExpression(/*<@466>*/node) {
        this._visitPropertyAccess(node);
    }
    /*<@718>*/visitIndexExpression(/*<@475>*/node) {
        this._visitPropertyAccess(node);
    }
    /*<@719>*/_handleReadModifyWrite(/*<@411>*/node) {
        let /*<@85>*/type = node.oldValueVar.type;
        if (!type)
            throw new Error("Null type");
        let /*<@120>*/simpleLHS = node.lValue.visit(new NormalUsePropertyResolver());
        if (simpleLHS.isLValue) {
            if (!simpleLHS.addressSpace)
                throw new Error(node.origin.originString + ": LHS without address space: " + simpleLHS);
            let /*<@373>*/ptrType = new PtrType(node.origin, simpleLHS.addressSpace, type);
            let /*<@413>*/ptrVar = new AnonymousVariable(node.origin, ptrType);
            node.become(new CommaExpression(node.origin, /*<@784>*/[
                node.oldValueVar, node.newValueVar, ptrVar,
                new Assignment(node.origin, VariableRef.wrap(ptrVar), new MakePtrExpression(node.origin, simpleLHS), ptrType),
                new Assignment(node.origin, node.oldValueRef(), new DereferenceExpression(node.origin, VariableRef.wrap(ptrVar), type, simpleLHS.addressSpace), type),
                new Assignment(node.origin, node.newValueRef(), node.newValueExp, type),
                new Assignment(node.origin, new DereferenceExpression(node.origin, VariableRef.wrap(ptrVar), type, simpleLHS.addressSpace), node.newValueRef(), type),
                node.resultExp
            ]));
            return;
        }
        node.lValue.hasBecome = false;
        let /*<@411>*/result = new ReadModifyWriteExpression(node.origin, node./*<@435>*/lValue.base, node./*<@435>*/lValue.baseType);
        result.newValueExp = new CommaExpression(node.origin, /*<@784>*/[
            node.oldValueVar, node.newValueVar,
            new Assignment(node.origin, node.oldValueRef(), node./*<@435>*/lValue.emitGet(result.oldValueRef()), type),
            new Assignment(node.origin, node.newValueRef(), node.newValueExp, type),
            node./*<@435>*/lValue.emitSet(result.oldValueRef(), node.newValueRef())
        ]);
        result.resultExp = node.newValueRef();
        this._handleReadModifyWrite(result);
        node.become(result);
    }
    /*<@720>*/visitReadModifyWriteExpression(/*<@411>*/node) {
        node.newValueExp.visit(this);
        node.resultExp.visit(this);
        this._visitRValuesWithinLValue(node.lValue);
        this._handleReadModifyWrite(node);
    }
    /*<@721>*/visitAssignment(/*<@405>*/node) {
        this._visitRValuesWithinLValue(node.lhs);
        node.rhs.visit(this);
        let /*<@120>*/simpleLHS = node.lhs.visit(new NormalUsePropertyResolver());
        if (simpleLHS.isLValue) {
            node.lhs.become(simpleLHS);
            return;
        }
        if (!(node.lhs instanceof PropertyAccessExpression))
            throw new Error("Unexpected lhs type: " + node.lhs.constructor.name);
        let /*<@411>*/result = new ReadModifyWriteExpression(node.origin, node.lhs./*<@435>*/base, node.lhs.baseType);
        let /*<@413>*/resultVar = new AnonymousVariable(node.origin, node.type);
        result.newValueExp = new CommaExpression(node.origin, /*<@784>*/[
            resultVar,
            new Assignment(node.origin, VariableRef.wrap(resultVar), node.rhs, node.type),
            node.lhs.emitSet(result.oldValueRef(), VariableRef.wrap(resultVar))
        ]);
        result.resultExp = VariableRef.wrap(resultVar);
        this._handleReadModifyWrite(result);
        node.become(result);
    }
    /*<@722>*/visitMakePtrExpression(/*<@377>*/node) {
        super.visitMakePtrExpression(node);
        let /*<@1417>*/value = /*<@1417>*/node;
        if (!value.lValue.isLValue)
            throw new WTypeError(node.origin.originString, "Not an lvalue: " + node.lValue);
    }
    /*<@723>*/visitMakeArrayRefExpression(/*<@377>*/node) {
        super.visitMakeArrayRefExpression(node);
        if (!node.lValue.isLValue)
            throw new WTypeError(node.origin.originString, "Not an lvalue: " + node.lValue);
    }
}
class /*<@178>*/Protocol extends Node {
    constructor(/*<@42>*/origin, /*<@3>*/name) {
        super();
        this._origin = origin;
        this._name = name;
    }
    get /*<@179>*/kind() { return Protocol; }
    /*<@180>*/toString() {
        return this.name;
    }
}
class /*<@110>*/ProtocolDecl extends Protocol {
    constructor(/*<@42>*/origin, /*<@3>*/name) {
        super(origin, name);
        this.extends = /*<@784>*/[];
        this._signatures = /*<@784>*/[];
        this._signatureMap = new Map();
        this._typeVariable = new TypeVariable(origin, name, null);
    }
    /*<@168>*/addExtends(/*<@107>*/protocol) {
        this.extends.push(protocol);
    }
    /*<@169>*/add(/*<@112>*/signature) {
        if (!(signature instanceof ProtocolFuncDecl))
            throw new Error("Signature isn't a ProtocolFuncDecl but a " + /*<@112>*/signature.constructor.name);
        signature.protocolDecl = this;
        this._signatures.push(signature);
        let /*<@143>*/overloads = this._signatureMap.get(signature.name);
        if (!overloads)
            this._signatureMap.set(signature.name, overloads = /*<@784>*/[]);
        overloads.push(signature);
    }
    get /*<@170>*/signatures() { return this._signatures; }
    /*<@171>*/signaturesByName(/*<@3>*/name) { return this._signatureMap.get(name); }
    get /*<@172>*/typeVariable() { return this._typeVariable; }
    /*<@173>*/signaturesByNameWithTypeVariable(/*<@3>*/name, /*<@7>*/typeVariable) {
        let /*<@697>*/substitution = new Substitution(/*<@1031>*/[this.typeVariable], /*<@101>*/[typeVariable]);
        let /*<@143>*/result = this.signaturesByName(name);
        if (!result)
            return null;
        return result.map(/*<@1418>*/signature => signature.visit(substitution));
    }
    /*<@176>*/inherits(/*<@177>*/otherProtocol) {
        if (!otherProtocol)
            return /*<@785>*/{ result: true, reason: undefined };
        if (otherProtocol instanceof ProtocolRef)
            otherProtocol = otherProtocol.protocolDecl;
        for (let /*<@112>*/otherSignature of /*<@109>*/otherProtocol.signatures) {
            let /*<@143>*/signatures = this.signaturesByName(otherSignature.name);
            if (!signatures)
                return /*<@775>*/{ result: false, reason: "Protocol " + this.name + " does not have a function named " + otherSignature.name + " (looking at signature " + otherSignature + ")" };
            let overload = resolveOverloadImpl(signatures, /*<@784>*/[], otherSignature.parameterTypes, otherSignature.returnTypeForOverloadResolution);
            if (!overload.func)
                return /*<@775>*/{ result: false, reason: "Did not find matching signature for " + otherSignature + " in " + this.name + (overload.failures.length ? " (tried: " + overload.failures.join("; ") + ")" : "") };
            let /*<@7>*/substitutedReturnType = overload.func.returnType.substituteToUnification(overload.func.typeParameters, overload.unificationContext);
            if (!substitutedReturnType.equals(otherSignature.returnType))
                return /*<@775>*/{ result: false, reason: "Return type mismatch between " + otherSignature.returnType + " and " + substitutedReturnType };
        }
        return /*<@785>*/{ result: true, reason: undefined };
    }
    /*<@181>*/hasHeir(/*<@85>*/type) {
        let /*<@697>*/substitution = new Substitution(/*<@1031>*/[this._typeVariable], /*<@136>*/[type]);
        let /*<@145>*/signatures = this.signatures;
        for (let /*<@112>*/originalSignature of signatures) {
            let /*<@112>*/signature = originalSignature.visit(substitution);
            let overload = resolveOverloadImpl(signature.possibleOverloads, signature.typeParameters, signature.parameterTypes, signature.returnTypeForOverloadResolution);
            if (!overload.func)
                return /*<@775>*/{ result: false, reason: "Did not find matching signature for " + originalSignature + " (at " + originalSignature.origin.originString + ") with type " + type + (overload.failures.length ? " (tried: " + overload.failures.join("; ") + ")" : "") };
            let /*<@7>*/substitutedReturnType = overload.func.returnType.substituteToUnification(overload.func.typeParameters, overload.unificationContext);
            if (!substitutedReturnType.equals(signature.returnType))
                return /*<@775>*/{ result: false, reason: "At signature " + originalSignature + " (at " + originalSignature.origin.originString + "): return type mismatch between " + signature.returnType + " and " + substitutedReturnType + " in found function " + overload.func.toDeclString() };
        }
        return /*<@785>*/{ result: true, reason: undefined };
    }
    /*<@182>*/toString() {
        return "protocol " + this.name + " { " + this.signatures.join("; ") + "; }";
    }
}
class /*<@113>*/ProtocolFuncDecl extends Func {
    get /*<@144>*/typeParametersForCallResolution() {
        return this.typeParameters.concat(this.protocolDecl.typeVariable);
    }
}
class /*<@108>*/ProtocolRef extends Protocol {
    constructor(/*<@42>*/origin, /*<@3>*/name) {
        super(origin, name);
        this.protocolDecl = null;
    }
    /*<@183>*/inherits(/*<@177>*/other) {
        return this.protocolDecl.inherits(other);
    }
    /*<@184>*/hasHeir(/*<@85>*/type) {
        return this.protocolDecl.hasHeir(type);
    }
    get /*<@185>*/isPrimitive() {
        return this.protocolDecl.isPrimitive;
    }
}
class /*<@374>*/PtrType extends ReferenceType {
    constructor(/*<@42>*/origin, /*<@3>*/addressSpace, /*<@85>*/elementType) {
        super(origin, addressSpace, elementType);
        this._isPtr = true;
    }
    /*<@375>*/unifyImpl(/*<@153>*/unificationContext, /*<@85>*/other) {
        if (!other.isPtr)
            return false;
        if (this.addressSpace != other.addressSpace)
            return false;
        return this.elementType.unify(unificationContext, other.elementType);
    }
    /*<@376>*/argumentForAndOverload(/*<@42>*/origin, /*<@188>*/value) {
        throw new WTypeError(origin.originString, "Pointer subscript is not valid");
    }
    /*<@381>*/argumentTypeForAndOverload(/*<@42>*/origin, /*<@85>*/type) {
        throw new WTypeError(origin.originString, "Pointer subscript is not valid");
    }
    /*<@382>*/returnTypeFromAndOverload(/*<@42>*/origin) {
        return this.elementType;
    }
    /*<@383>*/toString() {
        return this.elementType + "* " + this.addressSpace;
    }
}
class /*<@412>*/ReadModifyWriteExpression extends Expression {
    constructor(/*<@42>*/origin, /*<@303>*/lValue, /*<@85>*/type = null) {
        super(origin);
        this._lValue = lValue;
        this.oldValueVar = new AnonymousVariable(origin, type);
        this.newValueVar = new AnonymousVariable(origin, type);
        this.newValueExp = null;
        this.resultExp = null;
    }
    get /*<@416>*/lValue() { return this._lValue; }
    /*<@417>*/oldValueRef() { return VariableRef.wrap(this.oldValueVar); }
    /*<@426>*/newValueRef() { return VariableRef.wrap(this.newValueVar); }
    /*<@427>*/toString() {
        return "RMW(" + this.lValue + ", " + this.oldValueVar + ", " + this.newValueVar + ", " + this.newValueExp + ", " + this.resultExp + ")";
    }
}
class /*<@1420>*/RecursionChecker extends Visitor {
    constructor(/*<@71>*/program) {
        super();
        this._visiting = new VisitingSet();
    }
    /*<@1421>*/visitFuncDef(/*<@227>*/node) {
        this._visiting.doVisit(node, /*<@1423>*/() => super.visitFuncDef(node));
    }
    /*<@1422>*/visitCallExpression(/*<@437>*/node) {
        node.func.visit(this);
    }
}
class /*<@1425>*/RecursiveTypeChecker extends Visitor {
    constructor() {
        super();
        this._visiting = new VisitingSet();
    }
    /*<@1426>*/visitFuncDef(/*<@227>*/node) {
    }
    /*<@1427>*/visitNativeFunc(/*<@237>*/node) {
    }
    /*<@1428>*/visitStructType(/*<@280>*/node) {
        this._visiting.doVisit(node, /*<@1431>*/() => super.visitStructType(node));
        return undefined;
    }
    /*<@1429>*/visitReferenceType(/*<@367>*/node) {
    }
    /*<@1430>*/visitTypeRef(/*<@345>*/node) {
        super.visitTypeRef(node);
        node.type.visit(this);
    }
}
function /*<@1432>*/createNameResolver(/*<@71>*/program) {
    return new NameResolver(program.globalNameContext);
}
function /*<@1433>*/resolveNamesInTypes(/*<@71>*/program, /*<@1285>*/nameResolver) {
    for (let /*<@85>*/type of program.types.values())
        nameResolver.doStatement(type);
}
function /*<@1434>*/resolveNamesInProtocols(/*<@71>*/program, /*<@1285>*/nameResolver) {
    for (let /*<@177>*/protocol of program.protocols.values())
        nameResolver.doStatement(protocol);
}
function /*<@1435>*/resolveNamesInFunctions(/*<@71>*/program, /*<@1285>*/nameResolver) {
    for (let /*<@143>*/funcs of program.functions.values()) {
        for (let /*<@114>*/func of funcs)
            nameResolver.doStatement(func);
    }
}
function /*<@1436>*/resolveOverloadImpl(/*<@143>*/functions, /*<@101>*/typeArguments, /*<@136>*/argumentTypes, /*<@85>*/returnType, /*<@2>*/allowEntryPoint = false) {
    if (!functions)
        throw new Error("Null functions; that should have been caught by the caller.");
    let /*<@784>*/failures = /*<@784>*/[];
    let /*<@784>*/successes = /*<@784>*/[];
    for (let /*<@114>*/func of functions) {
        if (!allowEntryPoint && func.shaderType) {
            failures.push(new OverloadResolutionFailure(func, "Function is a " + func.shaderType + " shader, so it cannot be called from within an existing shader."));
            continue;
        }
        let overload = inferTypesForCall(func, typeArguments, argumentTypes, returnType);
        if (overload.failure)
            failures.push(overload.failure);
        else
            successes.push(overload);
    }
    if (!successes.length)
        return /*<@763>*/{ failures: failures, func: undefined };
    let /*<@1>*/minimumConversionCost = successes.reduce(/*<@1437>*/(/*<@1>*/result, overload) => Math.min(result, overload.unificationContext.conversionCost), Infinity);
    successes = successes.filter(/*<@1438>*/overload => overload.unificationContext.conversionCost == minimumConversionCost);
    // If any of the signatures are restricted then we consider those first. This is an escape mechanism for
    // built-in things.
    // FIXME: It should be an error to declare a function that is at least as specific as a restricted function.
    // https://bugs.webkit.org/show_bug.cgi?id=176580
    let /*<@2>*/hasRestricted = successes.reduce(/*<@1439>*/(/*<@2>*/result, overload) => result || overload.func.isRestricted, false);
    if (hasRestricted)
        successes = successes.filter(/*<@1440>*/overload => overload.func.isRestricted);
    // We are only interested in functions that are at least as specific as all of the others. This means
    // that they can be "turned around" and applied onto all of the other functions in the list.
    let /*<@784>*/prunedSuccesses = /*<@784>*/[];
    for (let /*<@5>*/i = 0; i < successes.length; ++i) {
        let /*<@2>*/ok = true;
        let /*<@114>*/argumentFunc = successes[i].func;
        for (let /*<@5>*/j = 0; j < successes.length; ++j) {
            if (i == j)
                continue;
            let /*<@114>*/parameterFunc = successes[j].func;
            let overload = inferTypesForCall(parameterFunc, typeArguments.length ? argumentFunc.typeParameters : /*<@784>*/[], argumentFunc.parameterTypes, argumentFunc.returnTypeForOverloadResolution);
            if (!overload.func) {
                ok = false;
                break;
            }
        }
        if (ok)
            prunedSuccesses.push(successes[i]);
    }
    if (prunedSuccesses.length == 1)
        return prunedSuccesses[0];
    let /*<@784>*/ambiguityList;
    let /*<@3>*/message;
    if (prunedSuccesses.length == 0) {
        ambiguityList = successes;
        message = "Ambiguous overload - no function can be applied to all others";
    }
    else {
        ambiguityList = prunedSuccesses;
        message = "Ambiguous overload - functions mutually applicable";
    }
    return /*<@763>*/{ failures: ambiguityList.map(/*<@1441>*/overload => new OverloadResolutionFailure(overload.func, message)), func: undefined };
}
function /*<@1442>*/resolveProperties(/*<@71>*/program) {
    program.visit(new PropertyResolver());
}
function /*<@1443>*/resolveTypeDefsInTypes(/*<@71>*/program) {
    let /*<@1444>*/resolver = new TypeDefResolver();
    for (let /*<@85>*/type of program.types.values())
        type.visit(resolver);
}
function /*<@1447>*/resolveTypeDefsInProtocols(/*<@71>*/program) {
    let /*<@1444>*/resolver = new TypeDefResolver();
    for (let /*<@177>*/protocol of program.protocols.values())
        /*<@7>*/protocol.visit(resolver);
}
function /*<@1448>*/resolveTypeDefsInFunctions(/*<@71>*/program) {
    let /*<@1444>*/resolver = new TypeDefResolver();
    for (let /*<@143>*/funcs of program.functions.values()) {
        for (let /*<@114>*/func of funcs)
            func.visit(resolver);
    }
}
class /*<@498>*/Return extends Node {
    constructor(/*<@42>*/origin, /*<@120>*/value) {
        super();
        this._origin = origin;
        this._value = value;
    }
    get /*<@499>*/value() { return this._value; }
    /*<@500>*/toString() {
        if (this.value)
            return "return " + this.value;
        return "return";
    }
}
;
class /*<@1450>*/ReturnChecker extends Visitor {
    constructor(/*<@71>*/program) {
        super();
        this.returnStyle = /*<@1451>*/{
            DefinitelyReturns: "Definitely Returns",
            DefinitelyDoesntReturn: "Definitely Doesn't Return",
            HasntReturnedYet: "Hasn't Returned Yet"
        };
        this._program = program;
    }
    /*<@1452>*/_mergeReturnStyle(/*<@3>*/a, /*<@3>*/b) {
        if (!a)
            return b;
        if (!b)
            return a;
        switch (a) {
            case this.returnStyle.DefinitelyReturns:
            case this.returnStyle.DefinitelyDoesntReturn:
                if (a == b)
                    return a;
                return this.returnStyle.HasntReturnedYet;
            case this.returnStyle.HasntReturnedYet:
                return this.returnStyle.HasntReturnedYet;
            default:
                throw new Error("Bad return style: " + a);
        }
    }
    /*<@1453>*/visitFuncDef(/*<@227>*/node) {
        if (node.returnType.equals(node.program.intrinsics.void))
            return;
        let /*<@174>*/bodyValue = node.body.visit(this);
        if (bodyValue == this.returnStyle.DefinitelyDoesntReturn || bodyValue == this.returnStyle.HasntReturnedYet)
            throw new WTypeError(node.origin.originString, "Function does not return");
    }
    /*<@1454>*/visitBlock(/*<@332>*/node) {
        for (let /*<@7>*/statement of node.statements) {
            switch (statement.visit(this)) {
                case this.returnStyle.DefinitelyReturns:
                    return this.returnStyle.DefinitelyReturns;
                case this.returnStyle.DefinitelyDoesntReturn:
                    return this.returnStyle.DefinitelyDoesntReturn;
                case this.returnStyle.HasntReturnedYet:
                    continue;
            }
        }
        return this.returnStyle.HasntReturnedYet;
    }
    /*<@1455>*/visitIfStatement(/*<@586>*/node) {
        if (node.elseBody) {
            let /*<@174>*/bodyValue = node.body.visit(this);
            let /*<@174>*/elseValue = node.elseBody.visit(this);
            return this._mergeReturnStyle(/*<@3>*/bodyValue, /*<@3>*/elseValue);
        }
        return this.returnStyle.HasntReturnedYet;
    }
    /*<@1456>*/_isBoolCastFromLiteralTrue(/*<@575>*/node) {
        return node.isCast && node.returnType instanceof TypeRef && node.returnType.equals(this._program.intrinsics.bool) && node.argumentList.length == 1 && node.argumentList[0] instanceof BoolLiteral && node.argumentList[0].value;
    }
    /*<@1457>*/visitWhileLoop(/*<@593>*/node) {
        let /*<@3>*/bodyReturn = node.body.visit(this);
        if (node.conditional instanceof CallExpression && this._isBoolCastFromLiteralTrue(node.conditional)) {
            switch (bodyReturn) {
                case this.returnStyle.DefinitelyReturns:
                    return this.returnStyle.DefinitelyReturns;
                case this.returnStyle.DefinitelyDoesntReturn:
                case this.returnStyle.HasntReturnedYet:
                    return this.returnStyle.HasntReturnedYet;
            }
        }
        return this.returnStyle.HasntReturnedYet;
    }
    /*<@1458>*/visitDoWhileLoop(/*<@599>*/node) {
        let /*<@3>*/result = this.returnStyle.HasntReturnedYet;
        switch (node.body.visit(this)) {
            case this.returnStyle.DefinitelyReturns:
                result = this.returnStyle.DefinitelyReturns;
            case this.returnStyle.DefinitelyDoesntReturn:
            case this.returnStyle.HasntReturnedYet:
                result = this.returnStyle.HasntReturnedYet;
        }
        return result;
    }
    /*<@1459>*/visitForLoop(/*<@605>*/node) {
        let /*<@174>*/bodyReturn = node.body.visit(this);
        if (node.condition === undefined || this._isBoolCastFromLiteralTrue(node.condition)) {
            switch (bodyReturn) {
                case this.returnStyle.DefinitelyReturns:
                    return this.returnStyle.DefinitelyReturns;
                case this.returnStyle.DefinitelyDoesntReturn:
                case this.returnStyle.HasntReturnedYet:
                    return this.returnStyle.HasntReturnedYet;
            }
        }
    }
    /*<@1460>*/visitSwitchStatement(/*<@613>*/node) {
        // FIXME: This seems like it's missing things. For example, we need to be smart about this:
        //
        // for (;;) {
        //     switch (...) {
        //     ...
        //         continue; // This continues the for loop
        //     }
        // }
        //
        // I'm not sure what that means for this analysis. I'm starting to think that the right way to
        // build this analysis is to run a visitor that builds a CFG and then analyze the CFG.
        // https://bugs.webkit.org/show_bug.cgi?id=177172
        let /*<@3>*/returnStyle = null;
        for (let /*<@615>*/switchCase of node.switchCases) {
            let /*<@3>*/bodyStyle = switchCase.body.visit(this);
            // FIXME: The fact that we need this demonstrates the need for CFG analysis.
            if (bodyStyle == this.returnStyle.DefinitelyDoesntReturn)
                bodyStyle = this.returnStyle.HasntReturnedYet;
            returnStyle = this._mergeReturnStyle(returnStyle, bodyStyle);
        }
        return returnStyle;
    }
    /*<@1461>*/visitReturn(/*<@497>*/node) {
        return this.returnStyle.DefinitelyReturns;
    }
    /*<@1462>*/visitTrapStatement(/*<@510>*/node) {
        return this.returnStyle.DefinitelyReturns;
    }
    /*<@1463>*/visitBreak(/*<@506>*/node) {
        return this.returnStyle.DefinitelyDoesntReturn;
    }
    /*<@1464>*/visitContinue(/*<@502>*/node) {
        // FIXME: This seems wrong. Consider a loop like:
        //
        // int foo() { for (;;) { continue; } }
        //
        // This program shouldn't claim that the problem is that it doesn't return.
        // https://bugs.webkit.org/show_bug.cgi?id=177172
        return this.returnStyle.DefinitelyDoesntReturn;
    }
}
class /*<@1466>*/ReturnException {
    constructor(/*<@120>*/value) {
        this._value = value;
    }
    get /*<@1467>*/value() { return this._value; }
}
// NOTE: The next line is line 28, and we rely on this in Prepare.js.
let /*<@3>*/standardLibrary = `
// This is the WSL standard library. Implementations of all of these things are in
// Intrinsics.js.

// Need to bootstrap void first.
native typedef void;

native typedef uint8;
native typedef int32;
native typedef uint32;
native typedef bool;
typedef int = int32;
typedef uint = uint32;

native typedef float32;
native typedef float64;
typedef float = float32;
typedef double = float64;

native operator int32(uint32);
native operator int32(uint8);
native operator int32(float);
native operator int32(double);
native operator uint32(int32);
native operator uint32(uint8);
native operator uint32(float);
native operator uint32(double);
native operator uint8(int32);
native operator uint8(uint32);
native operator uint8(float);
native operator uint8(double);
native operator float(int32);
native operator float(uint32);
native operator float(uint8);
native operator float(double);
native operator double(float);
native operator double(int32);
native operator double(uint32);
native operator double(uint8);

native int operator+(int, int);
native uint operator+(uint, uint);
uint8 operator+(uint8 a, uint8 b) { return uint8(uint(a) + uint(b)); }
native float operator+(float, float);
native double operator+(double, double);
int operator++(int value) { return value + 1; }
uint operator++(uint value) { return value + 1; }
uint8 operator++(uint8 value) { return value + 1; }
native int operator-(int, int);
native uint operator-(uint, uint);
uint8 operator-(uint8 a, uint8 b) { return uint8(uint(a) - uint(b)); }
native float operator-(float, float);
native double operator-(double, double);
int operator--(int value) { return value - 1; }
uint operator--(uint value) { return value - 1; }
uint8 operator--(uint8 value) { return value - 1; }
native int operator*(int, int);
native uint operator*(uint, uint);
uint8 operator*(uint8 a, uint8 b) { return uint8(uint(a) * uint(b)); }
native float operator*(float, float);
native double operator*(double, double);
native int operator/(int, int);
native uint operator/(uint, uint);
uint8 operator/(uint8 a, uint8 b) { return uint8(uint(a) / uint(b)); }
native int operator&(int, int);
native int operator|(int, int);
native int operator^(int, int);
native int operator~(int);
native int operator<<(int, uint);
native int operator>>(int, uint);
native uint operator&(uint, uint);
native uint operator|(uint, uint);
native uint operator^(uint, uint);
native uint operator~(uint);
native uint operator<<(uint, uint);
native uint operator>>(uint, uint);
uint8 operator&(uint8 a, uint8 b) { return uint8(uint(a) & uint(b)); }
uint8 operator|(uint8 a, uint8 b) { return uint8(uint(a) | uint(b)); }
uint8 operator^(uint8 a, uint8 b) { return uint8(uint(a) ^ uint(b)); }
uint8 operator~(uint8 value) { return uint8(~uint(value)); }
uint8 operator<<(uint8 a, uint b) { return uint8(uint(a) << (b & 7)); }
uint8 operator>>(uint8 a, uint b) { return uint8(uint(a) >> (b & 7)); }
native float operator/(float, float);
native double operator/(double, double);
native bool operator==(int, int);
native bool operator==(uint, uint);
bool operator==(uint8 a, uint8 b) { return uint(a) == uint(b); }
native bool operator==(bool, bool);
native bool operator==(float, float);
native bool operator==(double, double);
native bool operator<(int, int);
native bool operator<(uint, uint);
bool operator<(uint8 a, uint8 b) { return uint(a) < uint(b); }
native bool operator<(float, float);
native bool operator<(double, double);
native bool operator<=(int, int);
native bool operator<=(uint, uint);
bool operator<=(uint8 a, uint8 b) { return uint(a) <= uint(b); }
native bool operator<=(float, float);
native bool operator<=(double, double);
native bool operator>(int, int);
native bool operator>(uint, uint);
bool operator>(uint8 a, uint8 b) { return uint(a) > uint(b); }
native bool operator>(float, float);
native bool operator>(double, double);
native bool operator>=(int, int);
native bool operator>=(uint, uint);
bool operator>=(uint8 a, uint8 b) { return uint(a) >= uint(b); }
native bool operator>=(float, float);
native bool operator>=(double, double);

bool operator&(bool a, bool b)
{
    if (a)
        return b;
    return false;
}

bool operator|(bool a, bool b)
{
    if (a)
        return true;
    if (b)
        return true;
    return false;
}

bool operator^(bool a, bool b)
{
    if (a)
        return !b;
    return b;
}

bool operator~(bool value)
{
    return !value;
}

protocol Addable {
    Addable operator+(Addable, Addable);
}

protocol Equatable {
    bool operator==(Equatable, Equatable);
}

restricted operator<T> T()
{
    T defaultValue;
    return defaultValue;
}

restricted operator<T> T(T x)
{
    return x;
}

operator<T:Equatable> bool(T x)
{
    return x != T();
}

struct vec2<T> {
    T x;
    T y;
}

typedef int2 = vec2<int>;
typedef uint2 = vec2<uint>;
typedef float2 = vec2<float>;
typedef double2 = vec2<double>;

operator<T> vec2<T>(T x, T y)
{
    vec2<T> result;
    result.x = x;
    result.y = y;
    return result;
}

bool operator==<T:Equatable>(vec2<T> a, vec2<T> b)
{
    return a.x == b.x && a.y == b.y;
}

thread T* operator&[]<T>(thread vec2<T>* foo, uint index)
{
    if (index == 0)
        return &foo->x;
    if (index == 1)
        return &foo->y;
    trap;
}

struct vec3<T> {
    T x;
    T y;
    T z;
}

typedef int3 = vec3<int>;
typedef uint3 = vec3<uint>;
typedef float3 = vec3<float>;
typedef double3 = vec3<double>;

operator<T> vec3<T>(T x, T y, T z)
{
    vec3<T> result;
    result.x = x;
    result.y = y;
    result.z = z;
    return result;
}

operator<T> vec3<T>(vec2<T> v2, T z)
{
    vec3<T> result;
    result.x = v2.x;
    result.y = v2.y;
    result.z = z;
    return result;
}

operator<T> vec3<T>(T x, vec2<T> v2)
{
    vec3<T> result;
    result.x = x;
    result.y = v2.x;
    result.z = v2.y;
    return result;
}

bool operator==<T:Equatable>(vec3<T> a, vec3<T> b)
{
    return a.x == b.x && a.y == b.y && a.z == b.z;
}

thread T* operator&[]<T>(thread vec3<T>* foo, uint index)
{
    if (index == 0)
        return &foo->x;
    if (index == 1)
        return &foo->y;
    if (index == 2)
        return &foo->z;
    trap;
}

struct vec4<T> {
    T x;
    T y;
    T z;
    T w;
}

typedef int4 = vec4<int>;
typedef uint4 = vec4<uint>;
typedef float4 = vec4<float>;
typedef double4 = vec4<double>;

operator<T> vec4<T>(T x, T y, T z, T w)
{
    vec4<T> result;
    result.x = x;
    result.y = y;
    result.z = z;
    result.w = w;
    return result;
}

operator<T> vec4<T>(vec2<T> v2, T z, T w)
{
    vec4<T> result;
    result.x = v2.x;
    result.y = v2.y;
    result.z = z;
    result.w = w;
    return result;
}

operator<T> vec4<T>(T x, vec2<T> v2, T w)
{
    vec4<T> result;
    result.x = x;
    result.y = v2.x;
    result.z = v2.y;
    result.w = w;
    return result;
}

operator<T> vec4<T>(T x, T y, vec2<T> v2)
{
    vec4<T> result;
    result.x = x;
    result.y = y;
    result.z = v2.x;
    result.w = v2.y;
    return result;
}

operator<T> vec4<T>(vec2<T> v2a, vec2<T> v2b)
{
    vec4<T> result;
    result.x = v2a.x;
    result.y = v2a.y;
    result.z = v2b.x;
    result.w = v2b.y;
    return result;
}

operator<T> vec4<T>(vec3<T> v3, T w)
{
    vec4<T> result;
    result.x = v3.x;
    result.y = v3.y;
    result.z = v3.z;
    result.w = w;
    return result;
}

operator<T> vec4<T>(T x, vec3<T> v3)
{
    vec4<T> result;
    result.x = x;
    result.y = v3.x;
    result.z = v3.y;
    result.w = v3.z;
    return result;
}

bool operator==<T:Equatable>(vec4<T> a, vec4<T> b)
{
    return a.x == b.x && a.y == b.y && a.z == b.z && a.w == b.w;
}

thread T* operator&[]<T>(thread vec4<T>* foo, uint index)
{
    if (index == 0)
        return &foo->x;
    if (index == 1)
        return &foo->y;
    if (index == 2)
        return &foo->z;
    if (index == 3)
        return &foo->w;
    trap;
}

native thread T* operator&[]<T>(thread T[], uint);
native threadgroup T* operator&[]<T>(threadgroup T[], uint);
native device T* operator&[]<T>(device T[], uint);
native constant T* operator&[]<T>(constant T[], uint);

native uint operator.length<T>(thread T[]);
native uint operator.length<T>(threadgroup T[]);
native uint operator.length<T>(device T[]);
native uint operator.length<T>(constant T[]);

uint operator.length<T, uint length>(T[length])
{
    return length;
}
`;
function /*<@1468>*/intToString(/*<@5>*/x) {
    switch (x) {
        case 0:
            return "x";
        case 1:
            return "y";
        case 2:
            return "z";
        case 3:
            return "w";
        default:
            throw new Error("Could not generate standard library.");
    }
}
// There are 481 swizzle operators. Let's not list them explicitly.
function /*<@1469>*/_generateSwizzle(/*<@1>*/maxDepth, /*<@5>*/maxItems, /*<@826>*/array) {
    if (!array)
        array = /*<@784>*/[];
    if (array.length == maxDepth) {
        let /*<@3>*/result = `vec${array.length}<T> operator.${array.join("")}<T>(vec${maxItems}<T> v)
{
    vec${array.length}<T> result;
`;
        for (let /*<@5>*/i = 0; i < array.length; ++i) {
            result += `    result.${intToString(i)} = v.${array[i]};
`;
        }
        result += `    return result;
}
`;
        return result;
    }
    let /*<@3>*/result = "";
    for (let /*<@5>*/i = 0; i < maxItems; ++i) {
        array.push(intToString(i));
        result += _generateSwizzle(maxDepth, maxItems, array);
        array.pop();
    }
    return result;
}
for (let /*<@5>*/maxDepth = 2; maxDepth <= 4; maxDepth++) {
    for (let /*<@5>*/maxItems = 2; maxItems <= 4; maxItems++)
        standardLibrary += _generateSwizzle(maxDepth, maxItems);
}
class /*<@924>*/StatementCloner extends Rewriter {
    /*<@925>*/visitFuncDef(/*<@227>*/node) {
        let /*<@175>*/typeParameters = node.typeParameters.map(/*<@1470>*/typeParameter => typeParameter.visit(this));
        let /*<@227>*/result = new FuncDef(node.origin, node.name, node.returnType.visit(this), /*<@262>*/typeParameters, node.parameters.map(/*<@1471>*/parameter => parameter.visit(this)), node.body.visit(this), node.isCast, node.shaderType);
        result.isRestricted = node.isRestricted;
        return result;
    }
    /*<@926>*/visitNativeFunc(/*<@237>*/node) {
        let /*<@237>*/result = new NativeFunc(node.origin, node.name, node.returnType.visit(this), node.typeParameters.map(/*<@1472>*/typeParameter => typeParameter.visit(this)), node.parameters.map(/*<@1473>*/parameter => parameter.visit(this)), node.isCast, node.shaderType);
        result.isRestricted = node.isRestricted;
        return result;
    }
    /*<@927>*/visitNativeType(/*<@249>*/node) {
        return new NativeType(node.origin, node.name, node.typeParameters.map(/*<@1474>*/typeParameter => typeParameter.visit(this)));
    }
    /*<@928>*/visitTypeDef(/*<@275>*/node) {
        return new TypeDef(node.origin, node.name, node.typeParameters.map(/*<@1475>*/(/*<@7>*/typeParameter) => typeParameter.visit(this)), node.type.visit(this));
    }
    /*<@929>*/visitStructType(/*<@280>*/node) {
        let /*<@280>*/result = new StructType(node.origin, node.name, node.typeParameters.map(/*<@1476>*/(/*<@7>*/typeParameter) => typeParameter.visit(this)));
        for (let /*<@284>*/field of node.fields)
            result.add(field.visit(this));
        return result;
    }
    /*<@930>*/visitConstexprTypeParameter(/*<@251>*/node) {
        return new ConstexprTypeParameter(node.origin, node.name, node.type.visit(this));
    }
    /*<@931>*/visitProtocolDecl(/*<@109>*/node) {
        let /*<@109>*/result = new ProtocolDecl(node.origin, node.name);
        for (let /*<@107>*/protocol of node.extends)
            result.addExtends(protocol.visit(this));
        for (let /*<@112>*/signature of node.signatures)
            result.add(signature.visit(this));
        return result;
    }
    /*<@932>*/visitTypeVariable(/*<@146>*/node) {
        return new TypeVariable(node.origin, node.name, Node.visit(node.protocol, this));
    }
    /*<@933>*/visitProtocolRef(/*<@107>*/node) {
        return new ProtocolRef(node.origin, node.name);
    }
    /*<@934>*/visitBoolLiteral(/*<@542>*/node) {
        return new BoolLiteral(node.origin, node.value);
    }
    /*<@935>*/visitTypeOrVariableRef(/*<@936>*/node) {
        return new TypeOrVariableRef(node.origin, node.name);
    }
    /*<@939>*/visitEnumType(/*<@298>*/node) {
        let /*<@298>*/result = new EnumType(node.origin, node.name, node.baseType.visit(this));
        for (let /*<@301>*/member of node.members)
            result.add(member);
        return result;
    }
}
class /*<@1478>*/StructLayoutBuilder extends Visitor {
    constructor() {
        super();
        this._offset = 0;
    }
    /*<@1479>*/visitReferenceType(/*<@367>*/node) {
    }
    /*<@1480>*/visitStructType(/*<@280>*/node) {
        if (node.size != null)
            return;
        if (node.typeParameters.length)
            throw new Error("Cannot do layout for generic type: " + node);
        let /*<@5>*/oldOffset = this._offset;
        this._offset = 0;
        super.visitStructType(node);
        node.size = this._offset;
        this._offset += oldOffset;
    }
    get /*<@1481>*/offset() { return this._offset; }
    /*<@1482>*/visitField(/*<@284>*/node) {
        super.visitField(node);
        node.offset = this._offset;
        let /*<@5>*/size = node.type.size;
        if (size == null)
            throw new Error("Type does not have size: " + node.type);
        this._offset += size;
    }
    /*<@1483>*/visitNativeFuncInstance(/*<@242>*/node) {
        super.visitNativeFuncInstance(node);
        node.func.didLayoutStructsInImplementationData(node.implementationData);
    }
    /*<@1484>*/visitTypeRef(/*<@345>*/node) {
        super.visitTypeRef(node);
        node.type.visit(this);
    }
    /*<@1485>*/visitCallExpression(/*<@437>*/node) {
        for (let /*<@7>*/argument of node.argumentList)
            Node.visit(argument, this);
        let /*<@1486>*/handleTypeArguments = /*<@1486>*/(/*<@101>*/actualTypeArguments) => {
            if (actualTypeArguments) {
                for (let /*<@7>*/argument of actualTypeArguments)
                    /*<@7>*/argument.visit(this);
            }
        };
        handleTypeArguments(node.instantiatedActualTypeArguments);
        Node.visit(node.nativeFuncInstance, this);
        Node.visit(node.resultType, this);
    }
}
function /*<@1487>*/StructTypePopulate(/*<@45>*/buffer, /*<@5>*/offset) {
    if (this.size == null)
        throw new Error("Struct does not have layout: " + this + " "); //+ describe(this));
    for (let field of this.fields)
        field.type.populateDefaultValue(buffer, offset + field.offset);
}
class /*<@281>*/StructType extends Type {
    constructor(/*<@42>*/origin, /*<@3>*/name, /*<@101>*/typeParameters) {
        super();
        this._origin = origin;
        this._name = name;
        this._typeParameters = typeParameters;
        this._fields = new Map();
        this.instantiate = this._instantiate;
        this.populateDefaultValue = StructTypePopulate;
    }
    /*<@282>*/_instantiate(/*<@101>*/typeArguments) {
        let /*<@697>*/substitution = null;
        let /*<@101>*/typeParameters = this.typeParameters;
        if (typeArguments) {
            if (typeArguments.length != this.typeParameters.length)
                throw new WTypeError(this.origin.originString, "Wrong number of type arguments to instantiation");
            substitution = new Substitution(this.typeParameters, typeArguments);
            typeParameters = /*<@784>*/[];
        }
        let /*<@705>*/instantiateImmediates = new InstantiateImmediates();
        let /*<@280>*/result = new StructType(this.origin, this.name, typeParameters);
        for (let /*<@284>*/field of this.fields) {
            let /*<@284>*/newField = field;
            if (substitution)
                newField = newField.visit(substitution);
            newField = newField.visit(instantiateImmediates);
            result.add(newField);
        }
        return result;
    }
    ;
    /*<@283>*/add(/*<@284>*/field) {
        field.struct = this;
        if (this._fields.has(field.name))
            throw new WTypeError(field.origin.originString, "Duplicate field name: " + field.name);
        this._fields.set(field.name, field);
    }
    get /*<@287>*/typeParameters() { return this._typeParameters; }
    get /*<@288>*/fieldNames() { return this._fields.keys(); }
    /*<@290>*/fieldByName(/*<@3>*/name) { return this._fields.get(name); }
    get /*<@291>*/fields() { return this._fields.values(); }
    get /*<@292>*/fieldMap() { return this._fields; }
    get /*<@293>*/isPrimitive() {
        let /*<@2>*/result = true;
        for (let /*<@284>*/field of this.fields)
            result = result && field.type.isPrimitive;
        return result;
    }
    /*<@294>*/toString() {
        return "struct " + this.name + "<" + this.typeParameters + "> { " + Array.from(this.fields).join("; ") + "; }";
    }
}
class /*<@698>*/Substitution extends Rewriter {
    constructor(/*<@101>*/parameters, /*<@101>*/argumentList) {
        super();
        if (parameters.length != argumentList.length)
            throw new Error("Parameters and arguments are mismatched");
        this._map = new Map();
        for (let /*<@5>*/i = 0; i < parameters.length; ++i)
            this._map.set(parameters[i], argumentList[i]);
    }
    get /*<@699>*/map() { return this._map; }
    /*<@700>*/visitTypeRef(/*<@345>*/node) {
        let /*<@7>*/replacement = this._map.get(node.type);
        if (replacement) {
            if (node.typeArguments.length)
                throw new Error("Unexpected type arguments on type variable");
            let /*<@174>*/result = replacement.visit(new AutoWrapper());
            return result;
        }
        let /*<@174>*/result = super.visitTypeRef(node);
        return result;
    }
    /*<@701>*/visitVariableRef(/*<@418>*/node) {
        let /*<@7>*/replacement = this._map.get(node.variable);
        if (replacement)
            return replacement.visit(new AutoWrapper());
        return super.visitVariableRef(node);
    }
}
class /*<@695>*/InstantiationSubstitution extends Substitution {
    constructor(/*<@200>*/thisInstantiator, /*<@101>*/typeParameters, /*<@101>*/typeArguments) {
        super(typeParameters, typeArguments);
        this.thisInstantiator = thisInstantiator;
    }
    /*<@696>*/visitCallExpression(/*<@437>*/node) {
        let /*<@437>*/result = super.visitCallExpression(node);
        // We may have to re-resolve the function call, if it was a call to a protocol
        // signature.
        if (result.func instanceof ProtocolFuncDecl) {
            let overload = resolveOverloadImpl(result.possibleOverloads, result.typeArguments, result.argumentTypes, result.returnType);
            if (!overload.func)
                throw new Error("Could not resolve protocol signature function call during instantiation: " + result.func + (overload.failures.length ? "; tried:\n" + overload.failures.join("\n") : ""));
            result.resolveToOverload(overload);
        }
        if (result.func.isNative)
            /*<@437>*/result.nativeFuncInstance = this.thisInstantiator.getUnique(result.func, result.actualTypeArguments);
        return result;
    }
}
class /*<@616>*/SwitchCase extends Node {
    constructor(/*<@42>*/origin, /*<@120>*/value, /*<@332>*/body) {
        super();
        this._origin = origin;
        this._value = value;
        this._body = body;
    }
    get /*<@617>*/isDefault() { return !this._value; }
    get /*<@618>*/value() { return this._value; }
    get /*<@619>*/body() { return this._body; }
    /*<@620>*/toString() {
        let /*<@3>*/result = "";
        if (this.isDefault)
            result += "default";
        else
            result += "cast " + this.value;
        return result + ": " + this.body;
    }
}
class /*<@614>*/SwitchStatement extends Node {
    constructor(/*<@42>*/origin, /*<@120>*/value) {
        super();
        this._origin = origin;
        this._value = value;
        this._switchCases = /*<@784>*/[];
    }
    get /*<@622>*/value() { return this._value; }
    /*<@623>*/add(/*<@615>*/switchCase) {
        this._switchCases.push(switchCase);
    }
    get /*<@624>*/switchCases() { return this._switchCases; }
    /*<@625>*/toString() {
        let /*<@3>*/result = "switch (" + this.value + ") { ";
        if (this.switchCases.length)
            result += this.switchCases.join("; ");
        +"; ";
        return result + "}";
    }
}
function /*<@1488>*/synthesizeEnumFunctions(/*<@71>*/program) {
    for (let /*<@85>*/type of program.types.values()) {
        if (!(type instanceof EnumType))
            continue;
        let /*<@237>*/nativeFunc;
        let /*<@2>*/isCast = false;
        let shaderType;
        nativeFunc = new NativeFunc(type.origin, "operator==", new TypeRef(type.origin, "bool", /*<@784>*/[]), /*<@784>*/[], /*<@130>*/[
            new FuncParameter(type.origin, null, new TypeRef(type.origin, type.name, /*<@784>*/[])),
            new FuncParameter(type.origin, null, new TypeRef(type.origin, type.name, /*<@784>*/[]))
        ], isCast, shaderType);
        nativeFunc.implementation = /*<@1489>*/(/*<@781>*/[/*<@780>*/left, /*<@780>*/right]) => EPtr.box(/*<@43>*/left.loadValue() == /*<@43>*/right.loadValue());
        program.add(nativeFunc);
        nativeFunc = new NativeFunc(type.origin, "operator.value", type.baseType.visit(new Rewriter()), /*<@784>*/[], /*<@130>*/[new FuncParameter(type.origin, null, new TypeRef(type.origin, type.name, /*<@784>*/[]))], isCast, shaderType);
        nativeFunc.implementation = /*<@1490>*/(/*<@781>*/[/*<@780>*/value]) => /*<@43>*/value;
        program.add(nativeFunc);
        nativeFunc = new NativeFunc(type.origin, "operator cast", type.baseType.visit(new Rewriter()), /*<@784>*/[], /*<@130>*/[new FuncParameter(type.origin, null, new TypeRef(type.origin, type.name, /*<@784>*/[]))], isCast, shaderType);
        nativeFunc.implementation = /*<@1491>*/(/*<@781>*/[/*<@780>*/value]) => /*<@43>*/value;
        program.add(nativeFunc);
        nativeFunc = new NativeFunc(type.origin, "operator cast", new TypeRef(type.origin, type.name, /*<@784>*/[]), /*<@784>*/[], /*<@130>*/[new FuncParameter(type.origin, null, type.baseType.visit(new Rewriter()))], isCast, shaderType);
        nativeFunc.implementation = /*<@1492>*/(/*<@781>*/[/*<@780>*/value]) => /*<@43>*/value;
        program.add(nativeFunc);
    }
}
function /*<@1493>*/createTypeParameters(/*<@85>*/type) {
    let /*<@101>*/typeParameters = type.typeParameters;
    return typeParameters.map(/*<@1494>*/(/*<@7>*/typeParameter) => { return typeParameter.visit(new TypeParameterRewriter()); });
}
function /*<@1495>*/createTypeArguments(/*<@101>*/typeParameters) {
    return typeParameters.map(/*<@1496>*/typeParameter => typeParameter.visit(new AutoWrapper()));
}
function /*<@1497>*/setupImplementationData(/*<@237>*/nativeFunc, implementation, /*<@85>*/type, /*<@284>*/field) {
    nativeFunc.instantiateImplementation = /*<@1499>*/(/*<@697>*/substitution) => {
        let /*<@85>*/newType = type.instantiate(nativeFunc.typeParameters.map(/*<@1500>*/typeParameter => {
            let /*<@7>*/substitute = substitution.map.get(typeParameter);
            if (!substitute)
                throw new Error("Null substitute for type parameter " + typeParameter);
            return substitute;
        }));
        return /*<@1501>*/{ type: newType, fieldName: field.name, offset: -1, structSize: -1, fieldSize: -1 };
    };
    nativeFunc.visitImplementationData = /*<@1502>*/(implementationData, /*<@220>*/visitor) => {
        // Visiting the type first ensures that the struct layout builder figures out the field's
        // offset.
        implementationData.type.visit(visitor);
    };
    nativeFunc.didLayoutStructsInImplementationData = /*<@1503>*/implementationData => {
        let /*<@5>*/structSize = implementationData.type.size;
        if (structSize == null)
            throw new Error("No struct size for " + nativeFunc);
        let /*<@284>*/field = implementationData./*<@280>*/type.fieldByName(implementationData.fieldName);
        if (!field)
            throw new Error("Could not find field");
        let /*<@5>*/offset = field.offset;
        let /*<@5>*/fieldSize = field.type.size;
        if (fieldSize == null)
            throw new Error("No field size for " + nativeFunc);
        if (offset == null)
            throw new Error("No offset for " + nativeFunc);
        implementationData.offset = offset;
        implementationData.structSize = structSize;
        implementationData.fieldSize = fieldSize;
    };
    nativeFunc.implementation = /*<@1504>*/(/*<@1498>*/argumentList, /*<@7>*/node) => {
        let /*<@242>*/nativeFuncInstance = /*<@437>*/node.nativeFuncInstance;
        let implementationData = nativeFuncInstance.implementationData;
        return implementation(argumentList, implementationData.offset, implementationData.structSize, implementationData.fieldSize);
    };
}
function /*<@1505>*/createFieldType(/*<@85>*/type, /*<@101>*/typeParameters, /*<@284>*/field) {
    return field.type.visit(new Substitution(type.typeParameters, typeParameters));
}
function /*<@1506>*/createTypeRef(/*<@85>*/type, /*<@101>*/typeParameters) {
    return TypeRef.instantiate(type, createTypeArguments(typeParameters));
}
function /*<@1507>*/synthesizeStructAccessors(/*<@71>*/program) {
    for (let /*<@85>*/type of program.types.values()) {
        if (!(type instanceof StructType))
            continue;
        for (let /*<@284>*/field of type.fields) {
            let /*<@2>*/isCast = false;
            let /*<@3>*/shaderType;
            let /*<@101>*/typeParameters;
            let /*<@237>*/nativeFunc;
            // The getter: operator.field
            typeParameters = createTypeParameters(type);
            nativeFunc = new NativeFunc(field.origin, "operator." + field.name, createFieldType(type, typeParameters, field), typeParameters, /*<@130>*/[new FuncParameter(field.origin, null, createTypeRef(type, typeParameters))], isCast, shaderType);
            setupImplementationData(nativeFunc, /*<@1508>*/(/*<@1498>*/[/*<@43>*/base], /*<@5>*/offset, /*<@5>*/structSize, /*<@5>*/fieldSize) => {
                let /*<@43>*/result = new EPtr(new EBuffer(fieldSize), 0);
                result.copyFrom(base.plus(offset), fieldSize);
                return result;
            }, type, field);
            program.add(nativeFunc);
            // The setter: operator.field=
            typeParameters = createTypeParameters(type);
            nativeFunc = new NativeFunc(field.origin, "operator." + field.name + "=", createTypeRef(type, typeParameters), typeParameters, /*<@130>*/[
                new FuncParameter(field.origin, null, createTypeRef(type, typeParameters)),
                new FuncParameter(field.origin, null, createFieldType(type, typeParameters, field))
            ], isCast, shaderType);
            setupImplementationData(nativeFunc, /*<@1509>*/(/*<@1498>*/[/*<@43>*/base, /*<@43>*/value], /*<@5>*/offset, /*<@5>*/structSize, /*<@5>*/fieldSize) => {
                let /*<@43>*/result = new EPtr(new EBuffer(structSize), 0);
                result.copyFrom(base, structSize);
                result.plus(offset).copyFrom(value, fieldSize);
                return result;
            }, type, field);
            program.add(nativeFunc);
            // The ander: operator&.field
            function /*<@1510>*/setupAnder(/*<@3>*/addressSpace) {
                typeParameters = createTypeParameters(type);
                nativeFunc = new NativeFunc(field.origin, "operator&." + field.name, new PtrType(field.origin, addressSpace, createFieldType(type, typeParameters, field)), typeParameters, /*<@130>*/[
                    new FuncParameter(field.origin, null, new PtrType(field.origin, addressSpace, createTypeRef(type, typeParameters)))
                ], isCast, shaderType);
                setupImplementationData(nativeFunc, /*<@1511>*/(/*<@1498>*/[/*<@43>*/base], /*<@5>*/offset, /*<@5>*/structSize, /*<@5>*/fieldSize) => {
                    base = base.loadValue();
                    if (!base)
                        throw new WTrapError(field.origin.originString, "Null dereference");
                    return EPtr.box(base.plus(offset));
                }, type, field);
                program.add(nativeFunc);
            }
            setupAnder("thread");
            setupAnder("threadgroup");
            setupAnder("device");
            setupAnder("constant");
        }
    }
}
class /*<@511>*/TrapStatement extends Node {
    constructor(/*<@42>*/origin) {
        super();
        this._origin = origin;
    }
    /*<@512>*/toString() {
        return "trap";
    }
}
;
class /*<@276>*/TypeDef extends Type {
    constructor(/*<@42>*/origin, /*<@3>*/name, /*<@101>*/typeParameters, /*<@85>*/type) {
        super();
        this._origin = origin;
        this._name = name;
        this._typeParameters = typeParameters;
        this._type = type;
    }
    get /*<@277>*/typeParameters() { return this._typeParameters; }
    /*<@278>*/toString() {
        return "typedef " + this.name + "<" + this.typeParameters + "> = " + this.type;
    }
}
class /*<@1445>*/TypeDefResolver extends Visitor {
    constructor() {
        super();
        this._visiting = new VisitingSet();
    }
    /*<@1446>*/visitTypeRef(/*<@345>*/node) {
        this._visiting.doVisit(node, /*<@1512>*/() => {
            for (let /*<@7>*/typeArgument of node.typeArguments)
                typeArgument.visit(this);
            if (node.type instanceof TypeDef) {
                let /*<@153>*/unificationContext = new UnificationContext(node.type.typeParameters);
                if (node.typeArguments.length != node.type.typeParameters.length)
                    throw new Error("argument/parameter mismatch (should have been caught earlier)");
                for (let /*<@5>*/i = 0; i < node.typeArguments.length; ++i)
                    node.typeArguments[i].unify(unificationContext, node.type.typeParameters[i]);
                let verificationResult = unificationContext.verify();
                if (!verificationResult.result)
                    throw new WTypeError(node.origin.originString, "Type reference to a type definition violates protocol constraints: " + verificationResult.reason);
                let /*<@85>*/newType = node.type.type.substituteToUnification(node.type.typeParameters, unificationContext);
                newType.visit(this);
                let /*<@101>*/array = new /*<@101>*/Array();
                node.setTypeAndArguments(newType, array);
            }
        });
    }
}
class /*<@937>*/TypeOrVariableRef extends Node {
    constructor(/*<@42>*/origin, /*<@3>*/name) {
        super();
        this._origin = origin;
        this._name = name;
    }
    /*<@938>*/toString() {
        return this.name;
    }
}
class /*<@732>*/TypeParameterRewriter {
    /*<@733>*/visitConstexprTypeParameter(/*<@251>*/node) {
        return new ConstexprTypeParameter(node.origin, node.name, node.type.visit(new Rewriter()));
    }
    /*<@734>*/visitTypeVariable(/*<@146>*/node) {
        return new TypeVariable(node.origin, node.name, node.protocol);
    }
}
function /*<@1513>*/TypeRefPopulate(/*<@45>*/buffer, /*<@5>*/offset) {
    if (!this.typeArguments.length)
        return this.type.populateDefaultValue(buffer, offset);
    throw new Error("Cannot get default value of a type instantiation");
}
class /*<@346>*/TypeRef extends Type {
    constructor(/*<@42>*/origin, /*<@3>*/name, /*<@101>*/typeArguments) {
        super();
        this._origin = origin;
        this._name = name;
        this.type = null;
        this._typeArguments = typeArguments;
        this.populateDefaultValue = TypeRefPopulate;
    }
    static /*<@347>*/wrap(/*<@85>*/type) {
        if (type instanceof TypeRef && !type.typeArguments)
            return type;
        let /*<@3>*/name = type.name;
        let /*<@345>*/result = new TypeRef(type.origin, name, /*<@784>*/[]);
        result.type = type;
        return result;
    }
    static /*<@348>*/instantiate(/*<@85>*/type, /*<@101>*/typeArguments) {
        let /*<@345>*/result = new TypeRef(type.origin, type.name, typeArguments);
        result.type = type;
        return result;
    }
    get /*<@349>*/typeArguments() { return this._typeArguments; }
    get /*<@350>*/unifyNode() {
        if (this.hasBecome)
            return this.target.unifyNode;
        if (!this.typeArguments.length)
            return this.type.unifyNode;
        return this;
    }
    get /*<@351>*/size() {
        if (!this.typeArguments.length)
            return this.type.size;
        throw new Error("Cannot get size of a type instantiation");
    }
    get /*<@352>*/isPrimitive() {
        if (!this.typeArguments.length)
            return this.type.isPrimitive;
        throw new Error("Cannot determine if an uninstantiated type is primitive: " + this);
    }
    /*<@353>*/setTypeAndArguments(/*<@85>*/type, /*<@101>*/typeArguments) {
        this._name = null;
        this.type = type;
        this._typeArguments = typeArguments;
    }
    /*<@354>*/unifyImpl(/*<@153>*/unificationContext, /*<@345>*/other) {
        if (!(other instanceof TypeRef))
            return false;
        if (!this.type.unify(unificationContext, other.type))
            return false;
        if (this.typeArguments.length != other.typeArguments.length)
            return false;
        for (let /*<@5>*/i = 0; i < this.typeArguments.length; ++i) {
            if (!this.typeArguments[i].unify(unificationContext, other.typeArguments[i]))
                return false;
        }
        return true;
    }
    /*<@355>*/toString() {
        if (!this.name)
            return this.type.toString();
        if (!this.typeArguments.length)
            return this.name;
        return this.name + "<" + this.typeArguments + ">";
    }
}
class /*<@147>*/TypeVariable extends Type {
    constructor(/*<@42>*/origin, /*<@3>*/name, /*<@107>*/protocol) {
        super();
        this._origin = origin;
        this._name = name;
        this._protocol = protocol;
    }
    get /*<@148>*/protocol() { return this._protocol; }
    get /*<@149>*/isPrimitive() {
        return this._protocol && this._protocol.isPrimitive;
    }
    get /*<@150>*/isUnifiable() { return true; }
    /*<@151>*/inherits(/*<@107>*/protocol) {
        if (!protocol)
            return /*<@785>*/{ result: true, reason: undefined };
        if (!this.protocol)
            return /*<@775>*/{ result: false, reason: "Type variable " + this + " does not have a protocol" };
        return this.protocol.inherits(protocol);
    }
    /*<@152>*/typeVariableUnify(/*<@153>*/unificationContext, /*<@146>*/other) {
        if (!(other instanceof Type))
            return false;
        return this._typeVariableUnifyImpl(unificationContext, other);
    }
    /*<@164>*/unifyImpl(/*<@153>*/unificationContext, /*<@146>*/other) {
        return this.typeVariableUnify(unificationContext, other);
    }
    /*<@165>*/verifyAsArgument(/*<@153>*/unificationContext) {
        let /*<@7>*/realThis = unificationContext.find(this);
        // The thing we get unified with must be a type variable that accepts a broader set of
        // things than we do.
        if (!(realThis instanceof TypeVariable))
            return /*<@775>*/{ result: false, reason: "Type variable argument " + this.toString() + " cannot be passed to non-type-variable parameter type " + realThis };
        if (!this.protocol) {
            if (realThis.protocol)
                return /*<@775>*/{ result: false, reason: "Type variable without protocol " + this + " cannot be passed to parameter type variable with protocol " + realThis.protocol };
            return /*<@785>*/{ result: true, reason: undefined };
        }
        let result = this.protocol.inherits(realThis.protocol);
        if (!result.result)
            return /*<@775>*/{ result: false, reason: "Protocol " + this.protocol + " does not subsume protocol " + realThis.protocol + " (passing type " + this + " to type " + realThis + "): " + result.reason };
        return /*<@785>*/{ result: true, reason: undefined };
    }
    /*<@166>*/verifyAsParameter(/*<@153>*/unificationContext) {
        if (!this.protocol)
            return /*<@785>*/{ result: true, reason: undefined };
        let /*<@85>*/realThis = unificationContext.find(this);
        let result = realThis.inherits(this.protocol);
        if (!result.result)
            return /*<@775>*/{ result: false, reason: "Type " + realThis + " does not inherit protocol " + this.protocol + " (passing type " + realThis + " to type " + this.toString() + "): " + result.reason };
        return /*<@785>*/{ result: true, reason: undefined };
    }
    /*<@167>*/toString() {
        return this.name + (this.protocol ? ":" + this.protocol.name : "");
    }
}
class /*<@907>*/TypeVariableTracker extends Visitor {
    constructor() {
        super();
        this._set = new Set();
    }
    get /*<@908>*/set() { return this._set; }
    /*<@909>*/_consider(/*<@7>*/thing) {
        if (thing.isUnifiable)
            this._set.add(thing);
    }
    /*<@910>*/visitTypeRef(/*<@345>*/node) {
        if (node.typeArguments.length) {
            for (let /*<@7>*/typeArgument of node.typeArguments)
                typeArgument.visit(this);
            return;
        }
        this._consider(node.type);
    }
    /*<@911>*/visitVariableRef(/*<@418>*/node) {
        this._consider(node.variable);
    }
}
class /*<@846>*/TypedValue {
    constructor(/*<@85>*/type, /*<@43>*/ePtr) {
        this._type = type;
        this._ePtr = ePtr;
    }
    get /*<@847>*/type() { return this._type; }
    get /*<@848>*/ePtr() { return this._ePtr; }
    static /*<@849>*/box(/*<@85>*/type, /*<@52>*/value) {
        return new TypedValue(type, EPtr.box(value));
    }
    get /*<@850>*/value() { return this.ePtr.loadValue(); }
    /*<@851>*/toString() {
        return this.type + "(" + this.ePtr + ")";
    }
}
class /*<@154>*/UnificationContext {
    constructor(/*<@101>*/typeParameters) {
        this._typeParameters = new Set(typeParameters);
        this._nextMap = new Map();
        this._extraNodes = new Set();
    }
    /*<@155>*/union(/*<@7>*/a, /*<@7>*/b) {
        a = this.find(a);
        b = this.find(b);
        if (a == b)
            return;
        if (!a.isUnifiable) {
            /*<@101>*/[a, b] = /*<@101>*/[b, a];
            if (!a.isUnifiable)
                throw new Error("Cannot unify non-unifiable things " + a + " and " + b);
        }
        // Make sure that type parameters don't end up being roots.
        if (a.isUnifiable && b.isUnifiable && this._typeParameters.has(b))
            /*<@101>*/[a, b] = /*<@101>*/[b, a];
        this._nextMap.set(a, b);
    }
    /*<@156>*/find(/*<@7>*/node) {
        let /*<@7>*/currentNode = node;
        let /*<@7>*/nextNode = this._nextMap.get(currentNode);
        if (!nextNode)
            return currentNode;
        for (;;) {
            currentNode = nextNode;
            nextNode = this._nextMap.get(currentNode);
            if (!nextNode)
                break;
        }
        this._nextMap.set(node, currentNode);
        return currentNode;
    }
    /*<@157>*/addExtraNode(/*<@7>*/node) {
        this._extraNodes.add(node);
    }
    get /*<@158>*/nodes() {
        let /*<@78>*/result = new Set();
        for (let /*<@101>*/[/*<@7>*/key, /*<@7>*/value] of this._nextMap) {
            result.add(key);
            result.add(value);
        }
        for (let /*<@7>*/node of this._extraNodes)
            result.add(node);
        return result;
    }
    /*<@159>*/typeParameters() { return this._typeParameters; }
    */*<@160>*/typeArguments() {
        for (let /*<@7>*/typeArgument of this.nodes) {
            if (!typeArgument.isUnifiable)
                continue;
            if (this._typeParameters.has(typeArgument))
                continue;
            yield typeArgument;
        }
    }
    /*<@161>*/verify() {
        // We do a two-phase pre-verification. This gives literals a chance to select a more specific type.
        let /*<@784>*/preparations = /*<@784>*/[];
        for (let /*<@7>*/node of this.nodes) {
            let preparation = node.prepareToVerify(this);
            if (preparation)
                preparations.push(preparation);
        }
        for (let preparation of preparations) {
            let result = preparation();
            if (!result.result)
                return result;
        }
        for (let /*<@7>*/typeParameter of this._typeParameters) {
            let result = typeParameter.verifyAsParameter(this);
            if (!result.result)
                return result;
        }
        let /*<@5>*/numTypeVariableArguments = 0;
        let /*<@78>*/argumentSet = new Set();
        for (let /*<@7>*/typeArgument of this.typeArguments()) {
            let result = typeArgument.verifyAsArgument(this);
            if (!result.result)
                return result;
            if (typeArgument.isLiteral)
                continue;
            argumentSet.add(this.find(typeArgument));
            numTypeVariableArguments++;
        }
        if (argumentSet.size == numTypeVariableArguments)
            return /*<@785>*/{ result: true, reason: undefined };
        return /*<@775>*/{ result: false, reason: "Type variables used as arguments got unified with each other" };
    }
    get /*<@162>*/conversionCost() {
        let /*<@5>*/result = 0;
        for (let /*<@7>*/typeArgument of this.typeArguments())
            result += typeArgument.conversionCost(this);
        return result;
    }
    /*<@163>*/commit() {
        for (let /*<@7>*/typeArgument of this.typeArguments())
            typeArgument.commitUnification(this);
    }
}
class /*<@1515>*/UnreachableCodeChecker extends Visitor {
    constructor(/*<@71>*/program) {
        super();
        this._returnChecker = new ReturnChecker(program);
    }
    /*<@1516>*/visitBlock(/*<@332>*/node) {
        super.visitBlock(node);
        for (let /*<@5>*/i = 0; i < node.statements.length - 1; ++i) {
            switch (node.statements[i].visit(this._returnChecker)) {
                case this._returnChecker.returnStyle.DefinitelyReturns:
                case this._returnChecker.returnStyle.DefinitelyDoesntReturn:
                    throw new WTypeError(node.statements[i + 1].origin.originString, "Unreachable code");
                case this._returnChecker.returnStyle.HasntReturnedYet:
                    continue;
            }
        }
    }
}
class /*<@327>*/VariableDecl extends Value {
    constructor(/*<@42>*/origin, /*<@3>*/name, /*<@85>*/type, /*<@303>*/initializer) {
        super();
        this._origin = origin;
        this._name = name;
        this._type = type;
        this._initializer = initializer;
    }
    get /*<@328>*/initializer() { return this._initializer; }
    get /*<@329>*/varIsLValue() { return true; }
    /*<@330>*/toString() {
        return this.type + " " + this.name + (this.initializer ? " = " + this.initializer : "");
    }
}
class /*<@419>*/VariableRef extends Expression {
    constructor(/*<@42>*/origin, /*<@3>*/name) {
        super(origin);
        this._name = name;
        this.variable = null;
        this._addressSpace = "thread";
    }
    get /*<@420>*/addressSpace() {
        if (this.hasBecome)
            return this.target.addressSpace;
        return "thread";
    }
    static /*<@421>*/wrap(/*<@120>*/variable) {
        let /*<@418>*/result = new VariableRef(variable.origin, variable.name);
        result.variable = variable;
        return result;
    }
    get /*<@422>*/isConstexpr() {
        if (this.hasBecome)
            return this.target.isConstexpr;
        return this.variable.isConstexpr;
    }
    get /*<@423>*/unifyNode() {
        if (this.hasBecome)
            return this.target.unifyNode;
        return this.variable.unifyNode;
    } // This only makes sense when this is a constexpr.
    get /*<@424>*/isLValue() {
        if (this.hasBecome)
            return this.target.isLValue;
        return this.variable.varIsLValue;
    }
    /*<@425>*/toString() {
        return this.name;
    }
}
class /*<@1027>*/VisitingSet {
    constructor(.../*<@101>*/items) {
        this._set = new Set(items);
    }
    /*<@1028>*/doVisit(/*<@7>*/item, callback) {
        if (this._set.has(item))
            throw new WTypeError(item.origin.originString, "Recursive " + item./*<@8>*/kind.name);
        this._set.add(item);
        try {
            return callback();
        }
        finally {
            this._set.delete(item);
        }
    }
}
class /*<@1518>*/WSyntaxError extends Error {
    constructor(/*<@3>*/originString, /*<@3>*/message) {
        super("Syntax error at " + originString + ": " + message);
        this.originString = originString;
        this.syntaxErrorMessage = message;
    }
}
class /*<@1520>*/WTrapError extends Error {
    constructor(/*<@3>*/originString, /*<@3>*/message) {
        super("Trap at " + originString + ": " + message);
        this.originString = originString;
        this.syntaxErrorMessage = message;
    }
}
class /*<@450>*/WTypeError extends Error {
    constructor(/*<@3>*/originString, /*<@3>*/message) {
        super("Type error at " + originString + ": " + message);
        this.originString = originString;
        this.typeErrorMessage = message;
    }
}
class /*<@594>*/WhileLoop extends Node {
    constructor(/*<@42>*/origin, /*<@437>*/conditional, /*<@7>*/body) {
        super();
        this._origin = origin;
        this._conditional = conditional;
        this._body = body;
    }
    get /*<@595>*/conditional() { return this._conditional; }
    get /*<@596>*/body() { return this._body; }
    /*<@597>*/toString() {
        return "while (" + this.conditional + ") " + this.body;
    }
}
;
class /*<@1522>*/WrapChecker extends Visitor {
    constructor(/*<@7>*/node) {
        super();
        this._startNode = node;
    }
    /*<@1523>*/visitVariableRef(/*<@418>*/node) {
    }
    /*<@1524>*/visitTypeRef(/*<@345>*/node) {
    }
    /*<@1525>*/_foundUnwrapped(/*<@7>*/node) {
        function /*<@1532>*/originString(/*<@7>*/node) {
            let /*<@42>*/origin = node.origin;
            if (!origin)
                return "<null origin>";
            return origin.originString;
        }
        throw new Error("Found unwrapped " + node.constructor.name + " at " + originString(node) + ": " + node + "\nWhile visiting " + this._startNode.constructor.name + " at " + originString(this._startNode) + ": " + this._startNode);
    }
    /*<@1526>*/visitConstexprTypeParameter(/*<@251>*/node) {
        this._foundUnwrapped(node);
    }
    /*<@1527>*/visitFuncParameter(/*<@116>*/node) {
        this._foundUnwrapped(node);
    }
    /*<@1528>*/visitVariableDecl(/*<@326>*/node) {
        this._foundUnwrapped(node);
    }
    /*<@1529>*/visitStructType(/*<@280>*/node) {
        this._foundUnwrapped(node);
        return undefined;
    }
    /*<@1530>*/visitNativeType(/*<@249>*/node) {
        this._foundUnwrapped(node);
    }
    /*<@1531>*/visitTypeVariable(/*<@146>*/node) {
        this._foundUnwrapped(node);
    }
}
function /*<@1533>*/doPrep(/*<@3>*/code) {
    return prepare("/internal/test", 0, code);
}
function /*<@1534>*/doLex(/*<@3>*/code) {
    let /*<@11>*/lexer = new Lexer("/internal/test", "native", 0, code);
    var /*<@784>*/result = /*<@784>*/[];
    for (;;) {
        let /*<@9>*/next = lexer.next();
        if (!next)
            return result;
        result.push(next);
    }
    return result;
}
function /*<@1535>*/makeInt(/*<@71>*/program, /*<@1>*/value) {
    return TypedValue.box(program.intrinsics.int32, value);
}
function /*<@1536>*/makeUint(/*<@71>*/program, /*<@1>*/value) {
    return TypedValue.box(program.intrinsics.uint32, value);
}
function /*<@1537>*/makeUint8(/*<@71>*/program, /*<@1>*/value) {
    return TypedValue.box(program.intrinsics.uint8, value);
}
function /*<@1538>*/makeBool(/*<@71>*/program, /*<@2>*/value) {
    return TypedValue.box(program.intrinsics.bool, value);
}
function /*<@1539>*/makeFloat(/*<@71>*/program, /*<@7>*/value) {
    return TypedValue.box(program.intrinsics.float, value);
}
function /*<@1540>*/makeDouble(/*<@71>*/program, /*<@7>*/value) {
    return TypedValue.box(program.intrinsics.double, value);
}
function /*<@1541>*/makeEnum(/*<@71>*/program, /*<@3>*/enumName, /*<@3>*/value) {
    let /*<@298>*/enumType = program.types.get(enumName);
    if (!enumType)
        throw new Error("No type named " + enumName);
    let /*<@301>*/enumMember = enumType.memberByName(value);
    if (!enumMember)
        throw new Error("No member named " + enumMember + " in " + enumType);
    return TypedValue.box(enumType, enumMember.value./*<@1003>*/unifyNode.valueForSelectedType);
}
function /*<@1542>*/checkNumber(/*<@71>*/program, /*<@845>*/result, /*<@1>*/expected) {
    if (!result.type./*<@1543>*/unifyNode.isNumber)
        throw new Error("Wrong result type; result: " + result);
    if (result.value != expected)
        throw new Error("Wrong result: " + result.value + " (expected " + expected + ")");
}
function /*<@1544>*/checkInt(/*<@71>*/program, /*<@845>*/result, /*<@1>*/expected) {
    if (!result.type.equals(program.intrinsics.int32))
        throw new Error("Wrong result type; result: " + result);
    checkNumber(program, result, expected);
}
function /*<@1545>*/checkEnum(/*<@71>*/program, /*<@845>*/result, /*<@1>*/expected) {
    if (!(result.type.unifyNode instanceof EnumType))
        throw new Error("Wrong result type; result: " + result);
    if (result.value != expected)
        throw new Error("Wrong result: " + result.value + " (expected " + expected + ")");
}
function /*<@1546>*/checkUint(/*<@71>*/program, /*<@845>*/result, /*<@1>*/expected) {
    if (!result.type.equals(program.intrinsics.uint32))
        throw new Error("Wrong result type: " + result.type);
    if (result.value != expected)
        throw new Error("Wrong result: " + result.value + " (expected " + expected + ")");
}
function /*<@1547>*/checkUint8(/*<@71>*/program, /*<@845>*/result, /*<@1>*/expected) {
    if (!result.type.equals(program.intrinsics.uint8))
        throw new Error("Wrong result type: " + result.type);
    if (result.value != expected)
        throw new Error("Wrong result: " + result.value + " (expected " + expected + ")");
}
function /*<@1548>*/checkBool(/*<@71>*/program, /*<@845>*/result, /*<@2>*/expected) {
    if (!result.type.equals(program.intrinsics.bool))
        throw new Error("Wrong result type: " + result.type);
    if (result.value != expected)
        throw new Error("Wrong result: " + result.value + " (expected " + expected + ")");
}
function /*<@1549>*/checkFloat(/*<@71>*/program, /*<@845>*/result, /*<@1>*/expected) {
    if (!result.type.equals(program.intrinsics.float))
        throw new Error("Wrong result type: " + result.type);
    if (result.value != expected)
        throw new Error("Wrong result: " + result.value + " (expected " + expected + ")");
}
function /*<@1550>*/checkDouble(/*<@71>*/program, /*<@845>*/result, /*<@1>*/expected) {
    if (!result.type.equals(program.intrinsics.double))
        throw new Error("Wrong result type: " + result.type);
    if (result.value != expected)
        throw new Error("Wrong result: " + result.value + " (expected " + expected + ")");
}
function /*<@1551>*/checkLexerToken(/*<@9>*/result, /*<@1>*/expectedIndex, /*<@3>*/expectedKind, /*<@3>*/expectedText) {
    if (result._index != expectedIndex)
        throw new Error("Wrong lexer index; result: " + result._index + " (expected " + expectedIndex + ")");
    if (result._kind != expectedKind)
        throw new Error("Wrong lexer kind; result: " + result._kind + " (expected " + expectedKind + ")");
    if (result._text != expectedText)
        throw new Error("Wrong lexer text; result: " + result._text + " (expected " + expectedText + ")");
}
function /*<@1552>*/checkFail(callback, predicate) {
    try {
        callback();
        throw new Error("Did not throw exception");
    }
    catch (e) {
        if (predicate(e)) {
            return;
        }
        throw e;
    }
}
let /*<@2>*/okToTest = false;
/*
let tests = new Proxy({}, {
    set(target, property, value, receiver)
    {
        if (property in target)
            throw new Error("Trying to declare duplicate test: " + <string>property);
        target[property] = value;
        return true;
    }
});
*/
let /*<@6>*/tests = /*<@6>*/{};
tests.literalBool = function /*<@1553>*/() {
    let /*<@71>*/program = doPrep("bool foo() { return true; }");
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), true);
};
tests.identityBool = function /*<@1554>*/() {
    let /*<@71>*/program = doPrep("bool foo(bool x) { return x; }");
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeBool(program, true)]), true);
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeBool(program, false)]), false);
};
tests.intSimpleMath = function /*<@1555>*/() {
    let /*<@71>*/program = doPrep("int foo(int x, int y) { return x + y; }");
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 7), makeInt(program, 5)]), 12);
    program = doPrep("int foo(int x, int y) { return x - y; }");
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 7), makeInt(program, 5)]), 2);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 5), makeInt(program, 7)]), -2);
    program = doPrep("int foo(int x, int y) { return x * y; }");
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 7), makeInt(program, 5)]), 35);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 7), makeInt(program, -5)]), -35);
    program = doPrep("int foo(int x, int y) { return x / y; }");
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 7), makeInt(program, 2)]), 3);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 7), makeInt(program, -2)]), -3);
};
tests.uintSimpleMath = function /*<@1556>*/() {
    let /*<@71>*/program = doPrep("uint foo(uint x, uint y) { return x + y; }");
    checkUint(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint(program, 7), makeUint(program, 5)]), 12);
    program = doPrep("uint foo(uint x, uint y) { return x - y; }");
    checkUint(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint(program, 7), makeUint(program, 5)]), 2);
    checkUint(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint(program, 5), makeUint(program, 7)]), 4294967294);
    program = doPrep("uint foo(uint x, uint y) { return x * y; }");
    checkUint(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint(program, 7), makeUint(program, 5)]), 35);
    program = doPrep("uint foo(uint x, uint y) { return x / y; }");
    checkUint(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint(program, 7), makeUint(program, 2)]), 3);
};
tests.uint8SimpleMath = function /*<@1557>*/() {
    let /*<@71>*/program = doPrep("uint8 foo(uint8 x, uint8 y) { return x + y; }");
    checkUint8(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint8(program, 7), makeUint8(program, 5)]), 12);
    program = doPrep("uint8 foo(uint8 x, uint8 y) { return x - y; }");
    checkUint8(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint8(program, 7), makeUint8(program, 5)]), 2);
    checkUint8(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint8(program, 5), makeUint8(program, 7)]), 254);
    program = doPrep("uint8 foo(uint8 x, uint8 y) { return x * y; }");
    checkUint8(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint8(program, 7), makeUint8(program, 5)]), 35);
    program = doPrep("uint8 foo(uint8 x, uint8 y) { return x / y; }");
    checkUint8(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint8(program, 7), makeUint8(program, 2)]), 3);
};
tests.equality = function /*<@1558>*/() {
    let /*<@71>*/program = doPrep("bool foo(uint x, uint y) { return x == y; }");
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint(program, 7), makeUint(program, 5)]), false);
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint(program, 7), makeUint(program, 7)]), true);
    program = doPrep("bool foo(uint8 x, uint8 y) { return x == y; }");
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint8(program, 7), makeUint8(program, 5)]), false);
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint8(program, 7), makeUint8(program, 7)]), true);
    program = doPrep("bool foo(int x, int y) { return x == y; }");
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 7), makeInt(program, 5)]), false);
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 7), makeInt(program, 7)]), true);
    program = doPrep("bool foo(bool x, bool y) { return x == y; }");
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeBool(program, false), makeBool(program, true)]), false);
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeBool(program, true), makeBool(program, false)]), false);
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeBool(program, false), makeBool(program, false)]), true);
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeBool(program, true), makeBool(program, true)]), true);
};
tests.logicalNegation = function /*<@1559>*/() {
    let /*<@71>*/program = doPrep("bool foo(bool x) { return !x; }");
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeBool(program, true)]), false);
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeBool(program, false)]), true);
};
tests.notEquality = function /*<@1560>*/() {
    let /*<@71>*/program = doPrep("bool foo(uint x, uint y) { return x != y; }");
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint(program, 7), makeUint(program, 5)]), true);
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint(program, 7), makeUint(program, 7)]), false);
    program = doPrep("bool foo(uint8 x, uint8 y) { return x != y; }");
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint8(program, 7), makeUint8(program, 5)]), true);
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint8(program, 7), makeUint8(program, 7)]), false);
    program = doPrep("bool foo(int x, int y) { return x != y; }");
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 7), makeInt(program, 5)]), true);
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 7), makeInt(program, 7)]), false);
    program = doPrep("bool foo(bool x, bool y) { return x != y; }");
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeBool(program, false), makeBool(program, true)]), true);
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeBool(program, true), makeBool(program, false)]), true);
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeBool(program, false), makeBool(program, false)]), false);
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeBool(program, true), makeBool(program, true)]), false);
};
tests.equalityTypeFailure = function /*<@1561>*/() {
    checkFail(/*<@1562>*/() => doPrep("bool foo(int x, uint y) { return x == y; }"), /*<@1563>*/(/*<@451>*/e) => e instanceof WTypeError && e.message.indexOf("/internal/test:1") != -1);
};
tests.generalNegation = function /*<@1564>*/() {
    let /*<@71>*/program = doPrep("bool foo(int x) { return !x; }");
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 7)]), false);
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 0)]), true);
};
tests.add1 = function /*<@1565>*/() {
    let /*<@71>*/program = doPrep("int foo(int x) { return x + 1; }");
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 42)]), 43);
};
tests.simpleGeneric = function /*<@1566>*/() {
    let /*<@71>*/program = doPrep(`
        T id<T>(T x) { return x; }
        int foo(int x) { return id(x) + 1; }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 42)]), 43);
};
tests.nameResolutionFailure = function /*<@1567>*/() {
    checkFail(/*<@1568>*/() => doPrep("int foo(int x) { return x + y; }"), /*<@1569>*/(/*<@451>*/e) => e instanceof WTypeError && e.message.indexOf("/internal/test:1") != -1);
};
tests.simpleVariable = function /*<@1570>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(int p)
        {
            int result = p;
            return result;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 42)]), 42);
};
tests.simpleAssignment = function /*<@1571>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(int p)
        {
            int result;
            result = p;
            return result;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 42)]), 42);
};
tests.simpleDefault = function /*<@1572>*/() {
    let /*<@71>*/program = doPrep(`
        int foo()
        {
            int result;
            return result;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), 0);
};
tests.simpleDereference = function /*<@1573>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(device int* p)
        {
            return *p;
        }
    `);
    let /*<@45>*/buffer = new EBuffer(1);
    buffer.set(0, 13);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[TypedValue.box(new PtrType(externalOrigin, "device", program.intrinsics.int32), new EPtr(buffer, 0))]), 13);
};
tests.dereferenceStore = function /*<@1574>*/() {
    let /*<@71>*/program = doPrep(`
        void foo(device int* p)
        {
            *p = 52;
        }
    `);
    let /*<@45>*/buffer = new EBuffer(1);
    buffer.set(0, 13);
    callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[TypedValue.box(new PtrType(externalOrigin, "device", program.intrinsics.int32), new EPtr(buffer, 0))]);
    if (buffer.get(0) != 52)
        throw new Error("Expected buffer to contain 52 but it contains: " + buffer.get(0));
};
tests.simpleMakePtr = function /*<@1575>*/() {
    let /*<@71>*/program = doPrep(`
        thread int* foo()
        {
            int x = 42;
            return &x;
        }
    `);
    let /*<@845>*/result = callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]);
    if (!result.type.isPtr)
        throw new Error("Return type is not a pointer: " + result.type);
    if (!result./*<@367>*/type.elementType.equals(program.intrinsics.int32))
        throw new Error("Return type is not a pointer to an int: " + result.type);
    if (!(result.value instanceof EPtr))
        throw new Error("Return value is not an EPtr: " + result.value);
    let /*<@52>*/value = result.value.loadValue();
    if (value != 42)
        throw new Error("Expected 42 but got: " + value);
};
tests.threadArrayLoad = function /*<@1576>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(thread int[] array)
        {
            return array[0u];
        }
    `);
    let /*<@45>*/buffer = new EBuffer(1);
    buffer.set(0, 89);
    let /*<@845>*/result = callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[TypedValue.box(new ArrayRefType(externalOrigin, "thread", program.intrinsics.int32), new EArrayRef(new EPtr(buffer, 0), 1))]);
    checkInt(program, result, 89);
};
tests.threadArrayLoadIntLiteral = function /*<@1577>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(thread int[] array)
        {
            return array[0];
        }
    `);
    let /*<@45>*/buffer = new EBuffer(1);
    buffer.set(0, 89);
    let /*<@845>*/result = callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[TypedValue.box(new ArrayRefType(externalOrigin, "thread", program.intrinsics.int32), new EArrayRef(new EPtr(buffer, 0), 1))]);
    checkInt(program, result, 89);
};
tests.deviceArrayLoad = function /*<@1578>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(device int[] array)
        {
            return array[0u];
        }
    `);
    let /*<@45>*/buffer = new EBuffer(1);
    buffer.set(0, 89);
    let /*<@845>*/result = callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[TypedValue.box(new ArrayRefType(externalOrigin, "device", program.intrinsics.int32), new EArrayRef(new EPtr(buffer, 0), 1))]);
    checkInt(program, result, 89);
};
tests.threadArrayStore = function /*<@1579>*/() {
    let /*<@71>*/program = doPrep(`
        void foo(thread int[] array, int value)
        {
            array[0u] = value;
        }
    `);
    let /*<@45>*/buffer = new EBuffer(1);
    buffer.set(0, 15);
    let /*<@845>*/arrayRef = TypedValue.box(new ArrayRefType(externalOrigin, "thread", program.intrinsics.int32), new EArrayRef(new EPtr(buffer, 0), 1));
    callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[arrayRef, makeInt(program, 65)]);
    if (buffer.get(0) != 65)
        throw new Error("Bad value stored into buffer (expected 65): " + buffer.get(0));
    callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[arrayRef, makeInt(program, -111)]);
    if (buffer.get(0) != -111)
        throw new Error("Bad value stored into buffer (expected -111): " + buffer.get(0));
};
tests.deviceArrayStore = function /*<@1580>*/() {
    let /*<@71>*/program = doPrep(`
        void foo(device int[] array, int value)
        {
            array[0u] = value;
        }
    `);
    let /*<@45>*/buffer = new EBuffer(1);
    buffer.set(0, 15);
    let /*<@845>*/arrayRef = TypedValue.box(new ArrayRefType(externalOrigin, "device", program.intrinsics.int32), new EArrayRef(new EPtr(buffer, 0), 1));
    callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[arrayRef, makeInt(program, 65)]);
    if (buffer.get(0) != 65)
        throw new Error("Bad value stored into buffer (expected 65): " + buffer.get(0));
    callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[arrayRef, makeInt(program, -111)]);
    if (buffer.get(0) != -111)
        throw new Error("Bad value stored into buffer (expected -111): " + buffer.get(0));
};
tests.deviceArrayStoreIntLiteral = function /*<@1581>*/() {
    let /*<@71>*/program = doPrep(`
        void foo(device int[] array, int value)
        {
            array[0] = value;
        }
    `);
    let /*<@45>*/buffer = new EBuffer(1);
    buffer.set(0, 15);
    let /*<@845>*/arrayRef = TypedValue.box(new ArrayRefType(externalOrigin, "device", program.intrinsics.int32), new EArrayRef(new EPtr(buffer, 0), 1));
    callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[arrayRef, makeInt(program, 65)]);
    if (buffer.get(0) != 65)
        throw new Error("Bad value stored into buffer (expected 65): " + buffer.get(0));
    callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[arrayRef, makeInt(program, -111)]);
    if (buffer.get(0) != -111)
        throw new Error("Bad value stored into buffer (expected -111): " + buffer.get(0));
};
tests.simpleProtocol = function /*<@1582>*/() {
    let /*<@71>*/program = doPrep(`
        protocol MyAddable {
            MyAddable operator+(MyAddable, MyAddable);
        }
        T add<T:MyAddable>(T a, T b)
        {
            return a + b;
        }
        int foo(int x)
        {
            return add(x, 73);
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 45)]), 45 + 73);
};
tests.typeMismatchReturn = function /*<@1583>*/() {
    checkFail(/*<@1584>*/() => doPrep(`
            int foo()
            {
                return 0u;
            }
        `), /*<@1585>*/(/*<@451>*/e) => e instanceof WTypeError);
};
tests.typeMismatchVariableDecl = function /*<@1586>*/() {
    checkFail(/*<@1587>*/() => doPrep(`
            void foo(uint x)
            {
                int y = x;
            }
        `), /*<@1588>*/(/*<@451>*/e) => e instanceof WTypeError);
};
tests.typeMismatchAssignment = function /*<@1589>*/() {
    checkFail(/*<@1590>*/() => doPrep(`
            void foo(uint x)
            {
                int y;
                y = x;
            }
        `), /*<@1591>*/(/*<@451>*/e) => e instanceof WTypeError);
};
tests.typeMismatchReturnParam = function /*<@1592>*/() {
    checkFail(/*<@1593>*/() => doPrep(`
            int foo(uint x)
            {
                return x;
            }
        `), /*<@1594>*/(/*<@451>*/e) => e instanceof WTypeError);
};
tests.badAdd = function /*<@1595>*/() {
    checkFail(/*<@1596>*/() => doPrep(`
            void bar<T>(T) { }
            void foo(int x, uint y)
            {
                bar(x + y);
            }
        `), /*<@1597>*/(/*<@451>*/e) => e instanceof WTypeError && e.message.indexOf("native int32 operator+<>(int32,int32)") != -1);
};
tests.lexerKeyword = function /*<@1598>*/() {
    let /*<@784>*/result = doLex("ident for while 123 123u { } {asd asd{ 1a3 1.2 + 3.4 + 1. + .2 1.2d 0.d .3d && ||");
    if (result.length != 25)
        throw new Error("Lexer emitted an incorrect number of tokens (expected 23): " + result.length);
    checkLexerToken(result[0], 0, "identifier", "ident");
    checkLexerToken(result[1], 6, "keyword", "for");
    checkLexerToken(result[2], 10, "keyword", "while");
    checkLexerToken(result[3], 16, "intLiteral", "123");
    checkLexerToken(result[4], 20, "uintLiteral", "123u");
    checkLexerToken(result[5], 25, "punctuation", "{");
    checkLexerToken(result[6], 27, "punctuation", "}");
    checkLexerToken(result[7], 29, "punctuation", "{");
    checkLexerToken(result[8], 30, "identifier", "asd");
    checkLexerToken(result[9], 34, "identifier", "asd");
    checkLexerToken(result[10], 37, "punctuation", "{");
    checkLexerToken(result[11], 39, "intLiteral", "1");
    checkLexerToken(result[12], 40, "identifier", "a3");
    checkLexerToken(result[13], 43, "floatLiteral", "1.2");
    checkLexerToken(result[14], 47, "punctuation", "+");
    checkLexerToken(result[15], 49, "floatLiteral", "3.4");
    checkLexerToken(result[16], 53, "punctuation", "+");
    checkLexerToken(result[17], 55, "floatLiteral", "1.");
    checkLexerToken(result[18], 58, "punctuation", "+");
    checkLexerToken(result[19], 60, "floatLiteral", ".2");
    checkLexerToken(result[20], 63, "floatLiteral", "1.2d");
    checkLexerToken(result[21], 68, "floatLiteral", "0.d");
    checkLexerToken(result[22], 72, "floatLiteral", ".3d");
    checkLexerToken(result[23], 76, "punctuation", "&&");
    checkLexerToken(result[24], 79, "punctuation", "||");
};
tests.simpleNoReturn = function /*<@1599>*/() {
    checkFail(/*<@1600>*/() => doPrep("int foo() { }"), /*<@1601>*/(/*<@451>*/e) => e instanceof WTypeError);
};
tests.simpleUnreachableCode = function /*<@1602>*/() {
    checkFail(/*<@1603>*/() => doPrep(`
            void foo()
            {
                return;
                int x;
            }
        `), /*<@1604>*/(/*<@451>*/e) => e instanceof WTypeError);
};
tests.simpleStruct = function /*<@1605>*/() {
    let /*<@71>*/program = doPrep(`
        struct Foo {
            int x;
            int y;
        }
        Foo foo(Foo foo)
        {
            Foo result;
            result.x = foo.y;
            result.y = foo.x;
            return result;
        }
    `);
    let /*<@85>*/structType = program.types.get("Foo");
    if (!structType)
        throw new Error("Did not find Foo type");
    let /*<@45>*/buffer = new EBuffer(2);
    buffer.set(0, 62);
    buffer.set(1, 24);
    let /*<@845>*/result = callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[new TypedValue(structType, new EPtr(buffer, 0))]);
    if (!result.type.equals(structType))
        throw new Error("Wrong result type: " + result.type);
    let /*<@52>*/x = result.ePtr.get(0);
    let /*<@52>*/y = result.ePtr.get(1);
    if (x != 24)
        throw new Error("Wrong result for x: " + x + " (y = " + y + ")");
    if (y != 62)
        throw new Error("Wrong result for y: " + y + " (x + " + x + ")");
};
tests.genericStructInstance = function /*<@1606>*/() {
    let /*<@71>*/program = doPrep(`
        struct Foo<T> {
            T x;
            T y;
        }
        Foo<int> foo(Foo<int> foo)
        {
            Foo<int> result;
            result.x = foo.y;
            result.y = foo.x;
            return result;
        }
    `);
    let /*<@345>*/structType = TypeRef.instantiate(program.types.get("Foo"), /*<@136>*/[program.intrinsics.int32]);
    let /*<@45>*/buffer = new EBuffer(2);
    buffer.set(0, 62);
    buffer.set(1, 24);
    let /*<@845>*/result = callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[new TypedValue(structType, new EPtr(buffer, 0))]);
    let /*<@52>*/x = result.ePtr.get(0);
    let /*<@52>*/y = result.ePtr.get(1);
    if (x != 24)
        throw new Error("Wrong result for x: " + x + " (y = " + y + ")");
    if (y != 62)
        throw new Error("Wrong result for y: " + y + " (x + " + x + ")");
};
tests.doubleGenericCallsDoubleGeneric = function /*<@1607>*/() {
    doPrep(`
        void foo<T, U>(T, U) { }
        void bar<V, W>(V x, W y) { foo(x, y); }
    `);
};
tests.doubleGenericCallsSingleGeneric = function /*<@1608>*/() {
    checkFail(/*<@1609>*/() => doPrep(`
            void foo<T>(T, T) { }
            void bar<V, W>(V x, W y) { foo(x, y); }
        `), /*<@1610>*/(/*<@451>*/e) => e instanceof WTypeError);
};
tests.loadNull = function /*<@1611>*/() {
    checkFail(/*<@1612>*/() => doPrep(`
            void sink<T>(T) { }
            void foo() { sink(*null); }
        `), /*<@1613>*/(/*<@451>*/e) => e instanceof WTypeError && e.message.indexOf("Type passed to dereference is not a pointer: null") != -1);
};
tests.storeNull = function /*<@1614>*/() {
    checkFail(/*<@1615>*/() => doPrep(`
            void foo() { *null = 42; }
        `), /*<@1616>*/(/*<@451>*/e) => e instanceof WTypeError && e.message.indexOf("Type passed to dereference is not a pointer: null") != -1);
};
tests.returnNull = function /*<@1617>*/() {
    let /*<@71>*/program = doPrep(`
        thread int* foo() { return null; }
    `);
    let /*<@845>*/result = callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]);
    if (!result.type.isPtr)
        throw new Error("Return type is not a pointer: " + result.type);
    if (!result./*<@367>*/type.elementType.equals(program.intrinsics.int32))
        throw new Error("Return type is not a pointer to an int: " + result.type);
    if (result.value != null)
        throw new Error("Return value is not null: " + result.value);
};
tests.dereferenceDefaultNull = function /*<@1618>*/() {
    let /*<@71>*/program = doPrep(`
        int foo()
        {
            thread int* p;
            return *p;
        }
    `);
    checkFail(/*<@1619>*/() => callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), /*<@1620>*/(/*<@451>*/e) => e instanceof WTrapError);
};
tests.defaultInitializedNull = function /*<@1621>*/() {
    let /*<@71>*/program = doPrep(`
        int foo()
        {
            thread int* p = null;;
            return *p;
        }
    `);
    checkFail(/*<@1622>*/() => callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), /*<@1623>*/(/*<@451>*/e) => e instanceof WTrapError);
};
tests.passNullToPtrMonomorphic = function /*<@1624>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(thread int* ptr)
        {
            return *ptr;
        }
        int bar()
        {
            return foo(null);
        }
    `);
    checkFail(/*<@1625>*/() => callFunction(program, "bar", /*<@784>*/[], /*<@784>*/[]), /*<@1626>*/(/*<@451>*/e) => e instanceof WTrapError);
};
tests.passNullToPtrPolymorphic = function /*<@1627>*/() {
    checkFail(/*<@1628>*/() => doPrep(`
            T foo<T>(thread T* ptr)
            {
                return *ptr;
            }
            int bar()
            {
                return foo(null);
            }
        `), /*<@1629>*/(/*<@451>*/e) => e instanceof WTypeError);
};
tests.passNullToPolymorphic = function /*<@1630>*/() {
    checkFail(/*<@1631>*/() => doPrep(`
            T foo<T>(T ptr)
            {
                return ptr;
            }
            int bar()
            {
                return foo(null);
            }
        `), /*<@1632>*/(/*<@451>*/e) => e instanceof WTypeError);
};
tests.loadNullArrayRef = function /*<@1633>*/() {
    checkFail(/*<@1634>*/() => doPrep(`
            void sink<T>(T) { }
            void foo() { sink(null[0u]); }
        `), /*<@1635>*/(/*<@451>*/e) => e instanceof WTypeError && e.message.indexOf("Cannot resolve access") != -1);
};
tests.storeNullArrayRef = function /*<@1636>*/() {
    checkFail(/*<@1637>*/() => doPrep(`
            void foo() { null[0u] = 42; }
        `), /*<@1638>*/(/*<@451>*/e) => e instanceof WTypeError && e.message.indexOf("Cannot resolve access") != -1);
};
tests.returnNullArrayRef = function /*<@1639>*/() {
    let /*<@71>*/program = doPrep(`
        thread int[] foo() { return null; }
    `);
    let /*<@845>*/result = callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]);
    if (!result.type.isArrayRef)
        throw new Error("Return type is not an array reference: " + result.type);
    if (!result./*<@367>*/type.elementType.equals(program.intrinsics.int32))
        throw new Error("Return type is not an int array reference: " + result.type);
    if (result.value != null)
        throw new Error("Return value is not null: " + result.value);
};
tests.dereferenceDefaultNullArrayRef = function /*<@1640>*/() {
    let /*<@71>*/program = doPrep(`
        int foo()
        {
            thread int[] p;
            return p[0u];
        }
    `);
    checkFail(/*<@1641>*/() => callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), /*<@1642>*/(/*<@451>*/e) => e instanceof WTrapError);
};
tests.defaultInitializedNullArrayRef = function /*<@1643>*/() {
    let /*<@71>*/program = doPrep(`
        int foo()
        {
            thread int[] p = null;
            return p[0u];
        }
    `);
    checkFail(/*<@1644>*/() => callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), /*<@1645>*/(/*<@451>*/e) => e instanceof WTrapError);
};
tests.defaultInitializedNullArrayRefIntLiteral = function /*<@1646>*/() {
    let /*<@71>*/program = doPrep(`
        int foo()
        {
            thread int[] p = null;
            return p[0];
        }
    `);
    checkFail(/*<@1647>*/() => callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), /*<@1648>*/(/*<@451>*/e) => e instanceof WTrapError);
};
tests.passNullToPtrMonomorphicArrayRef = function /*<@1649>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(thread int[] ptr)
        {
            return ptr[0u];
        }
        int bar()
        {
            return foo(null);
        }
    `);
    checkFail(/*<@1650>*/() => callFunction(program, "bar", /*<@784>*/[], /*<@784>*/[]), /*<@1651>*/(/*<@451>*/e) => e instanceof WTrapError);
};
tests.passNullToPtrPolymorphicArrayRef = function /*<@1652>*/() {
    checkFail(/*<@1653>*/() => doPrep(`
            T foo<T>(thread T[] ptr)
            {
                return ptr[0u];
            }
            int bar()
            {
                return foo(null);
            }
        `), /*<@1654>*/(/*<@451>*/e) => e instanceof WTypeError);
};
tests.returnIntLiteralUint = function /*<@1655>*/() {
    let /*<@71>*/program = doPrep("uint foo() { return 42; }");
    checkNumber(program, callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), 42);
};
tests.returnIntLiteralDouble = function /*<@1656>*/() {
    let /*<@71>*/program = doPrep("double foo() { return 42; }");
    checkNumber(program, callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), 42);
};
tests.badIntLiteralForInt = function /*<@1657>*/() {
    checkFail(/*<@1658>*/() => doPrep("void foo() { int x = 3000000000; }"), /*<@1659>*/(/*<@451>*/e) => e instanceof WSyntaxError);
};
tests.badIntLiteralForUint = function /*<@1660>*/() {
    checkFail(/*<@1661>*/() => doPrep("void foo() { uint x = 5000000000; }"), /*<@1662>*/(/*<@451>*/e) => e instanceof WSyntaxError);
};
tests.badIntLiteralForDouble = function /*<@1663>*/() {
    checkFail(/*<@1664>*/() => doPrep("void foo() { double x = 5000000000000000000000000000000000000; }"), /*<@1665>*/(/*<@451>*/e) => e instanceof WSyntaxError);
};
tests.passNullAndNotNull = function /*<@1666>*/() {
    let /*<@71>*/program = doPrep(`
        T bar<T>(device T* p, device T*)
        {
            return *p;
        }
        int foo(device int* p)
        {
            return bar(p, null);
        }
    `);
    let /*<@45>*/buffer = new EBuffer(1);
    buffer.set(0, 13);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[TypedValue.box(new PtrType(externalOrigin, "device", program.intrinsics.int32), new EPtr(buffer, 0))]), 13);
};
tests.passNullAndNotNullFullPoly = function /*<@1667>*/() {
    let /*<@71>*/program = doPrep(`
        T bar<T>(T p, T)
        {
            return p;
        }
        int foo(device int* p)
        {
            return *bar(p, null);
        }
    `);
    let /*<@45>*/buffer = new EBuffer(1);
    buffer.set(0, 13);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[TypedValue.box(new PtrType(externalOrigin, "device", program.intrinsics.int32), new EPtr(buffer, 0))]), 13);
};
tests.passNullAndNotNullFullPolyReverse = function /*<@1668>*/() {
    let /*<@71>*/program = doPrep(`
        T bar<T>(T, T p)
        {
            return p;
        }
        int foo(device int* p)
        {
            return *bar(null, p);
        }
    `);
    let /*<@45>*/buffer = new EBuffer(1);
    buffer.set(0, 13);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[TypedValue.box(new PtrType(externalOrigin, "device", program.intrinsics.int32), new EPtr(buffer, 0))]), 13);
};
tests.nullTypeVariableUnify = function /*<@1669>*/() {
    let /*<@552>*/left = new NullType(externalOrigin);
    let /*<@146>*/right = new TypeVariable(externalOrigin, "T", null);
    if (left.equals(right))
        throw new Error("Should not be equal but are: " + left + " and " + right);
    if (right.equals(left))
        throw new Error("Should not be equal but are: " + left + " and " + right);
    /*

    function everyOrder(array: string[][], callback: ())
    {
        function recurse(array, callback, order)
        {
            if (!array.length)
                return callback.call(null, order);

            for (let i = 0; i < array.length; ++i) {
                let nextArray = array.concat();
                nextArray.splice(i, 1);
                recurse(nextArray, callback, order.concat([array[i]]));
            }
        }

        recurse(array, callback, []);
    }

    function everyPair(things: string[])
    {
        let result = [];
        for (let i = 0; i < things.length; ++i) {
            for (let j = 0; j < things.length; ++j) {
                if (i != j)
                    result.push([things[i], things[j]]);
            }
        }
        return result;
    }

    everyOrder(
        everyPair(["nullType", "variableType", "ptrType"]),
        order => {
            let types = {};
            types.nullType = new NullType(externalOrigin);
            types.variableType = new TypeVariable(externalOrigin, "T", null);
            types.ptrType = new PtrType(externalOrigin, "constant", new NativeType(externalOrigin, "foo_t", []));
            let unificationContext = new UnificationContext([types.variableType]);
            for (let [leftName, rightName] of order) {
                let left = types[leftName];
                let right = types[rightName];
                let result = left.unify(unificationContext, right);
                if (!result)
                    throw new Error("In order " + order + " cannot unify " + left + " with " + right);
            }
            if (!unificationContext.verify().result)
                throw new Error("In order " + order.map(value => "(" + value + ")") + " cannot verify");
        });
        */
};
tests.doubleNot = function /*<@1670>*/() {
    let /*<@71>*/program = doPrep(`
        bool foo(bool x)
        {
            return !!x;
        }
    `);
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeBool(program, true)]), true);
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeBool(program, false)]), false);
};
tests.simpleRecursion = function /*<@1671>*/() {
    checkFail(/*<@1672>*/() => doPrep(`
            void foo<T>(T x)
            {
                foo(&x);
            }
        `), /*<@1673>*/(/*<@451>*/e) => e instanceof WTypeError);
};
tests.protocolMonoSigPolyDef = function /*<@1674>*/() {
    let /*<@71>*/program = doPrep(`
        struct IntAnd<T> {
            int first;
            T second;
        }
        IntAnd<T> intAnd<T>(int first, T second)
        {
            IntAnd<T> result;
            result.first = first;
            result.second = second;
            return result;
        }
        protocol IntAndable {
            IntAnd<int> intAnd(IntAndable, int);
        }
        int foo<T:IntAndable>(T first, int second)
        {
            IntAnd<int> result = intAnd(first, second);
            return result.first + result.second;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 54), makeInt(program, 12)]), 54 + 12);
};
tests.protocolPolySigPolyDef = function /*<@1675>*/() {
    let /*<@71>*/program = doPrep(`
        struct IntAnd<T> {
            int first;
            T second;
        }
        IntAnd<T> intAnd<T>(int first, T second)
        {
            IntAnd<T> result;
            result.first = first;
            result.second = second;
            return result;
        }
        protocol IntAndable {
            IntAnd<T> intAnd<T>(IntAndable, T);
        }
        int foo<T:IntAndable>(T first, int second)
        {
            IntAnd<int> result = intAnd(first, second);
            return result.first + result.second;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 54), makeInt(program, 12)]), 54 + 12);
};
tests.protocolDoublePolySigDoublePolyDef = function /*<@1676>*/() {
    let /*<@71>*/program = doPrep(`
        struct IntAnd<T, U> {
            int first;
            T second;
            U third;
        }
        IntAnd<T, U> intAnd<T, U>(int first, T second, U third)
        {
            IntAnd<T, U> result;
            result.first = first;
            result.second = second;
            result.third = third;
            return result;
        }
        protocol IntAndable {
            IntAnd<T, U> intAnd<T, U>(IntAndable, T, U);
        }
        int foo<T:IntAndable>(T first, int second, int third)
        {
            IntAnd<int, int> result = intAnd(first, second, third);
            return result.first + result.second + result.third;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 54), makeInt(program, 12), makeInt(program, 39)]), 54 + 12 + 39);
};
tests.protocolDoublePolySigDoublePolyDefExplicit = function /*<@1677>*/() {
    let /*<@71>*/program = doPrep(`
        struct IntAnd<T, U> {
            int first;
            T second;
            U third;
        }
        IntAnd<T, U> intAnd<T, U>(int first, T second, U third)
        {
            IntAnd<T, U> result;
            result.first = first;
            result.second = second;
            result.third = third;
            return result;
        }
        protocol IntAndable {
            IntAnd<T, U> intAnd<T, U>(IntAndable, T, U);
        }
        int foo<T:IntAndable>(T first, int second, int third)
        {
            IntAnd<int, int> result = intAnd<int, int>(first, second, third);
            return result.first + result.second + result.third;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 54), makeInt(program, 12), makeInt(program, 39)]), 54 + 12 + 39);
};
tests.variableShadowing = function /*<@1678>*/() {
    let /*<@71>*/program = doPrep(`
        int foo()
        {
            int y;
            int x = 7;
            {
                int x = 8;
                y = x;
            }
            return y;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), 8);
    program = doPrep(`
        int foo()
        {
            int y;
            int x = 7;
            {
                int x = 8;
            }
            y = x;
            return y;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), 7);
};
tests.ifStatement = function /*<@1679>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(int x)
        {
            int y = 6;
            if (x == 7) {
                y = 8;
            }
            return y;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 3)]), 6);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 4)]), 6);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 5)]), 6);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 6)]), 6);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 7)]), 8);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 8)]), 6);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 9)]), 6);
};
tests.ifElseStatement = function /*<@1680>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(int x)
        {
            int y = 6;
            if (x == 7) {
                y = 8;
            } else {
                y = 9;
            }
            return y;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 3)]), 9);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 4)]), 9);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 5)]), 9);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 6)]), 9);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 7)]), 8);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 8)]), 9);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 9)]), 9);
};
tests.ifElseIfStatement = function /*<@1681>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(int x)
        {
            int y = 6;
            if (x == 7) {
                y = 8;
            } else if (x == 8) {
                y = 9;
            }
            return y;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 3)]), 6);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 4)]), 6);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 5)]), 6);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 6)]), 6);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 7)]), 8);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 8)]), 9);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 9)]), 6);
};
tests.ifElseIfElseStatement = function /*<@1682>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(int x)
        {
            int y = 6;
            if (x == 7) {
                y = 8;
            } else if (x == 8) {
                y = 9;
            } else {
                y = 10;
            }
            return y;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 3)]), 10);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 4)]), 10);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 5)]), 10);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 6)]), 10);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 7)]), 8);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 8)]), 9);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 9)]), 10);
};
tests.returnIf = function /*<@1683>*/() {
    checkFail(/*<@1684>*/() => doPrep(`
            int foo(int x)
            {
                int y = 6;
                if (x == 7) {
                    return y;
                }
            }
        `), /*<@1685>*/(/*<@451>*/e) => e instanceof WTypeError);
    checkFail(/*<@1686>*/() => doPrep(`
            int foo(int x)
            {
                int y = 6;
                if (x == 7) {
                    return y;
                } else {
                    y = 8;
                }
            }
        `), /*<@1687>*/(/*<@451>*/e) => e instanceof WTypeError);
    checkFail(/*<@1688>*/() => doPrep(`
            int foo(int x)
            {
                int y = 6;
                if (x == 7) {
                    y = 8;
                } else {
                    return y;
                }
            }
        `), /*<@1689>*/(/*<@451>*/e) => e instanceof WTypeError);
    let /*<@71>*/program = doPrep(`
        int foo(int x)
        {
            int y = 6;
            if (x == 7) {
                return 8;
            } else {
                return 10;
            }
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 3)]), 10);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 4)]), 10);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 5)]), 10);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 6)]), 10);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 7)]), 8);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 8)]), 10);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 9)]), 10);
    checkFail(/*<@1690>*/() => doPrep(`
            int foo(int x)
            {
                int y = 6;
                if (x == 7) {
                    return 8;
                } else if (x == 9) {
                    return 10;
                }
            }
        `), /*<@1691>*/(/*<@451>*/e) => e instanceof WTypeError);
    program = doPrep(`
        int foo(int x)
        {
            int y = 6;
            if (x == 7) {
                return 8;
            } else {
                y = 9;
            }
            return y;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 3)]), 9);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 4)]), 9);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 5)]), 9);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 6)]), 9);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 7)]), 8);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 8)]), 9);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 9)]), 9);
    checkFail(/*<@1692>*/() => doPrep(`
            int foo(int x)
            {
                int y = 6;
                if (x == 7) {
                    return 8;
                } else {
                    return 10;
                }
                return 11;
            }
        `), /*<@1693>*/(/*<@451>*/e) => e instanceof WTypeError);
    program = doPrep(`
        int foo(int x)
        {
            int y = 6;
            if (x == 7)
                int y = 8;
            return y;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 7)]), 6);
};
tests.simpleWhile = function /*<@1694>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(int x)
        {
            while (x < 13)
                x = x * 2;
            return x;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 1)]), 16);
};
tests.protocolMonoPolySigDoublePolyDefExplicit = function /*<@1695>*/() {
    checkFail(/*<@1696>*/() => {
        let /*<@71>*/program = doPrep(`
                struct IntAnd<T, U> {
                    int first;
                    T second;
                    U third;
                }
                IntAnd<T, U> intAnd<T, U>(int first, T second, U third)
                {
                    IntAnd<T, U> result;
                    result.first = first;
                    result.second = second;
                    result.third = third;
                    return result;
                }
                protocol IntAndable {
                    IntAnd<T, int> intAnd<T>(IntAndable, T, int);
                }
                int foo<T:IntAndable>(T first, int second, int third)
                {
                    IntAnd<int, int> result = intAnd<int>(first, second, third);
                    return result.first + result.second + result.third;
                }
            `);
        callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 54), makeInt(program, 12), makeInt(program, 39)]);
    }, /*<@1697>*/(/*<@451>*/e) => e instanceof WTypeError);
};
tests.ambiguousOverloadSimple = function /*<@1698>*/() {
    checkFail(/*<@1699>*/() => doPrep(`
            void foo<T>(int, T) { }
            void foo<T>(T, int) { }
            void bar(int a, int b) { foo(a, b); }
        `), /*<@1700>*/(/*<@451>*/e) => e instanceof WTypeError);
};
tests.ambiguousOverloadOverlapping = function /*<@1701>*/() {
    checkFail(/*<@1702>*/() => doPrep(`
            void foo<T>(int, T) { }
            void foo<T>(T, T) { }
            void bar(int a, int b) { foo(a, b); }
        `), /*<@1703>*/(/*<@451>*/e) => e instanceof WTypeError);
};
tests.ambiguousOverloadTieBreak = function /*<@1704>*/() {
    doPrep(`
        void foo<T>(int, T) { }
        void foo<T>(T, T) { }
        void foo(int, int) { }
        void bar(int a, int b) { foo(a, b); }
    `);
};
tests.intOverloadResolution = function /*<@1705>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(int) { return 1; }
        int foo(uint) { return 2; }
        int foo(double) { return 3; }
        int bar() { return foo(42); }
    `);
    checkInt(program, callFunction(program, "bar", /*<@784>*/[], /*<@784>*/[]), 1);
};
tests.intOverloadResolutionReverseOrder = function /*<@1706>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(double) { return 3; }
        int foo(uint) { return 2; }
        int foo(int) { return 1; }
        int bar() { return foo(42); }
    `);
    checkInt(program, callFunction(program, "bar", /*<@784>*/[], /*<@784>*/[]), 1);
};
tests.intOverloadResolutionGeneric = function /*<@1707>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(int) { return 1; }
        int foo<T>(T) { return 2; }
        int bar() { return foo(42); }
    `);
    checkInt(program, callFunction(program, "bar", /*<@784>*/[], /*<@784>*/[]), 1);
};
tests.intLiteralGeneric = function /*<@1708>*/() {
    let /*<@71>*/program = doPrep(`
        int foo<T>(T x) { return 3478; }
        int bar() { return foo(42); }
    `);
    checkInt(program, callFunction(program, "bar", /*<@784>*/[], /*<@784>*/[]), 3478);
};
tests.intLiteralGenericWithProtocols = function /*<@1709>*/() {
    let /*<@71>*/program = doPrep(`
        protocol MyConvertibleToInt {
            operator int(MyConvertibleToInt);
        }
        int foo<T:MyConvertibleToInt>(T x) { return int(x); }
        int bar() { return foo(42); }
    `);
    checkInt(program, callFunction(program, "bar", /*<@784>*/[], /*<@784>*/[]), 42);
};
tests.uintLiteralGeneric = function /*<@1710>*/() {
    let /*<@71>*/program = doPrep(`
        int foo<T>(T x) { return 3478; }
        int bar() { return foo(42u); }
    `);
    checkInt(program, callFunction(program, "bar", /*<@784>*/[], /*<@784>*/[]), 3478);
};
tests.uintLiteralGenericWithProtocols = function /*<@1711>*/() {
    let /*<@71>*/program = doPrep(`
        protocol MyConvertibleToUint {
            operator uint(MyConvertibleToUint);
        }
        uint foo<T:MyConvertibleToUint>(T x) { return uint(x); }
        uint bar() { return foo(42u); }
    `);
    checkUint(program, callFunction(program, "bar", /*<@784>*/[], /*<@784>*/[]), 42);
};
tests.intLiteralGenericSpecific = function /*<@1712>*/() {
    let /*<@71>*/program = doPrep(`
        T foo<T>(T x) { return x; }
        int bar() { return foo(int(42)); }
    `);
    checkInt(program, callFunction(program, "bar", /*<@784>*/[], /*<@784>*/[]), 42);
};
tests.simpleConstexpr = function /*<@1713>*/() {
    let /*<@71>*/program = doPrep(`
        int foo<int a>(int b)
        {
            return a + b;
        }
        int bar(int b)
        {
            return foo<42>(b);
        }
    `);
    checkInt(program, callFunction(program, "bar", /*<@784>*/[], /*<@852>*/[makeInt(program, 58)]), 58 + 42);
};
tests.break = function /*<@1714>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(int x)
        {
            while (true) {
                x = x * 2;
                if (x >= 7)
                    break;
            }
            return x;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 1)]), 8);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 10)]), 20);
    program = doPrep(`
        int foo(int x)
        {
            while (true) {
                while (true) {
                    x = x * 2;
                    if (x >= 7)
                        break;
                }
                x = x - 1;
                break;
            }
            return x;

        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 1)]), 7);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 10)]), 19);
    checkFail(/*<@1715>*/() => doPrep(`
            int foo(int x)
            {
                while (true) {
                    {
                        break;
                    }
                    x = x + 1;
                }
                return x;
            }
        `), /*<@1716>*/(/*<@451>*/e) => e instanceof WTypeError);
    checkFail(/*<@1717>*/() => doPrep(`
            int foo(int x)
            {
                break;
                return x;
            }
        `), /*<@1718>*/(/*<@451>*/e) => e instanceof WTypeError);
    program = doPrep(`
            int foo(int x)
            {
                while (true) {
                    if (x == 7) {
                        break;
                    }
                    x = x + 1;
                }
                return x;
            }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 1)]), 7);
    program = doPrep(`
            int foo(int x)
            {
                while (true) {
                    break;
                }
                return x;
            }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 1)]), 1);
    program = doPrep(`
            int foo()
            {
                while (true) {
                    return 7;
                }
            }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), 7);
    checkFail(/*<@1719>*/() => doPrep(`
            int foo(int x)
            {
                while(true) {
                    break;
                    return 7;
                }
            }
        `), /*<@1720>*/(/*<@451>*/e) => e instanceof WTypeError);
};
tests.continue = function /*<@1721>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(int x)
        {
            while (x < 10) {
                if (x == 8) {
                    x = x + 1;
                    continue;
                }
                x = x * 2;
            }
            return x;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 1)]), 18);
    checkFail(/*<@1722>*/() => doPrep(`
            int foo(int x)
            {
                continue;
                return x;

            }
        `), /*<@1723>*/(/*<@451>*/e) => e instanceof WTypeError);
};
tests.doWhile = function /*<@1724>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(int x)
        {
            int y = 7;
            do {
                y = 8;
                break;
            } while (x < 10);
            return y;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 1)]), 8);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 11)]), 8);
    program = doPrep(`
        int foo(int x)
        {
            int y = 7;
            do {
                y = 8;
                break;
            } while (y == 7);
            return y;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 1)]), 8);
    program = doPrep(`
        int foo(int x)
        {
            int sum = 0;
            do {
                if (x == 11) {
                    x = 15;
                    continue;
                }
                sum = sum + x;
                x = x + 1;
            } while (x < 13);
            return sum;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 9)]), 19);
};
tests.forLoop = function /*<@1725>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(int x)
        {
            int sum = 0;
            int i;
            for (i = 0; i < x; i = i + 1) {
                sum = sum + i;
            }
            return sum;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 3)]), 3);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 4)]), 6);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 5)]), 10);
    program = doPrep(`
        int foo(int x)
        {
            int sum = 0;
            for (int i = 0; i < x; i = i + 1) {
                sum = sum + i;
            }
            return sum;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 3)]), 3);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 4)]), 6);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 5)]), 10);
    program = doPrep(`
        int foo(int x)
        {
            int sum = 0;
            int i = 100;
            for (int i = 0; i < x; i = i + 1) {
                sum = sum + i;
            }
            return sum;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 3)]), 3);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 4)]), 6);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 5)]), 10);
    program = doPrep(`
        int foo(int x)
        {
            int sum = 0;
            for (int i = 0; i < x; i = i + 1) {
                if (i == 4)
                    continue;
                sum = sum + i;
            }
            return sum;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 3)]), 3);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 4)]), 6);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 5)]), 6);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 6)]), 11);
    program = doPrep(`
        int foo(int x)
        {
            int sum = 0;
            for (int i = 0; i < x; i = i + 1) {
                if (i == 5)
                    break;
                sum = sum + i;
            }
            return sum;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 3)]), 3);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 4)]), 6);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 5)]), 10);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 6)]), 10);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 7)]), 10);
    program = doPrep(`
        int foo(int x)
        {
            int sum = 0;
            for (int i = 0; ; i = i + 1) {
                if (i >= x)
                    break;
                sum = sum + i;
            }
            return sum;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 3)]), 3);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 4)]), 6);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 5)]), 10);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 6)]), 15);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 7)]), 21);
    program = doPrep(`
        int foo(int x)
        {
            int sum = 0;
            int i = 0;
            for ( ; ; i = i + 1) {
                if (i >= x)
                    break;
                sum = sum + i;
            }
            return sum;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 3)]), 3);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 4)]), 6);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 5)]), 10);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 6)]), 15);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 7)]), 21);
    program = doPrep(`
        int foo(int x)
        {
            int sum = 0;
            int i = 0;
            for ( ; ; ) {
                if (i >= x)
                    break;
                sum = sum + i;
                i = i + 1;
            }
            return sum;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 3)]), 3);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 4)]), 6);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 5)]), 10);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 6)]), 15);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 7)]), 21);
    checkFail(/*<@1726>*/() => doPrep(`
            void foo(int x)
            {
                for (int i = 0; ; i = i + 1) {
                    break;
                    x = i;
                }
            }
        `), /*<@1727>*/(/*<@451>*/e) => e instanceof WTypeError);
    program = doPrep(`
        int foo(int x)
        {
            for ( ; ; ) {
                return 7;
            }
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 3)]), 7);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 4)]), 7);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 5)]), 7);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 6)]), 7);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 7)]), 7);
    checkFail(/*<@1728>*/() => doPrep(`
            int foo(int x)
            {
                for ( ; x < 10; ) {
                    return 7;
                }
            }
        `), /*<@1729>*/(/*<@451>*/e) => e instanceof WTypeError);
    program = doPrep(`
        int foo(int x)
        {
            for ( ; true; ) {
                return 7;
            }
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 3)]), 7);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 4)]), 7);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 5)]), 7);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 6)]), 7);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 7)]), 7);
};
tests.chainConstexpr = function /*<@1730>*/() {
    let /*<@71>*/program = doPrep(`
        int foo<int a>(int b)
        {
            return a + b;
        }
        int bar<int a>(int b)
        {
            return foo<a>(b);
        }
        int baz(int b)
        {
            return bar<42>(b);
        }
    `);
    checkInt(program, callFunction(program, "baz", /*<@784>*/[], /*<@852>*/[makeInt(program, 58)]), 58 + 42);
};
tests.chainGeneric = function /*<@1731>*/() {
    let /*<@71>*/program = doPrep(`
        T foo<T>(T x)
        {
            return x;
        }
        T bar<T>(thread T* ptr)
        {
            return *foo(ptr);
        }
        int baz(int x)
        {
            return bar(&x);
        }
    `);
    checkInt(program, callFunction(program, "baz", /*<@784>*/[], /*<@852>*/[makeInt(program, 37)]), 37);
};
tests.chainStruct = function /*<@1732>*/() {
    let /*<@71>*/program = doPrep(`
        struct Foo<T> {
            T f;
        }
        struct Bar<T> {
            Foo<thread T*> f;
        }
        int foo(thread Bar<int>* x)
        {
            return *x->f.f;
        }
        int bar(int a)
        {
            Bar<int> x;
            x.f.f = &a;
            return foo(&x);
        }
    `);
    checkInt(program, callFunction(program, "bar", /*<@784>*/[], /*<@852>*/[makeInt(program, 4657)]), 4657);
};
tests.chainStructNewlyValid = function /*<@1733>*/() {
    let /*<@71>*/program = doPrep(`
        struct Foo<T> {
            T f;
        }
        struct Bar<T> {
            Foo<device T*> f;
        }
        int foo(thread Bar<int>* x)
        {
            return *x->f.f;
        }
        int bar(device int* a)
        {
            Bar<int> x;
            x.f.f = a;
            return foo(&x);
        }
    `);
    let /*<@45>*/buffer = new EBuffer(1);
    buffer.set(0, 78453);
    checkInt(program, callFunction(program, "bar", /*<@784>*/[], /*<@852>*/[TypedValue.box(new PtrType(externalOrigin, "device", program.intrinsics.int32), new EPtr(buffer, 0))]), 78453);
};
tests.chainStructDevice = function /*<@1734>*/() {
    let /*<@71>*/program = doPrep(`
        struct Foo<T> {
            T f;
        }
        struct Bar<T> {
            Foo<device T*> f;
        }
        int foo(thread Bar<int>* x)
        {
            return *x->f.f;
        }
        int bar(device int* a)
        {
            Bar<int> x;
            x.f.f = a;
            return foo(&x);
        }
    `);
    let /*<@45>*/buffer = new EBuffer(1);
    buffer.set(0, 79201);
    checkInt(program, callFunction(program, "bar", /*<@784>*/[], /*<@852>*/[TypedValue.box(new PtrType(externalOrigin, "device", program.intrinsics.int32), new EPtr(buffer, 0))]), 79201);
};
tests.paramChainStructDevice = function /*<@1735>*/() {
    let /*<@71>*/program = doPrep(`
        struct Foo<T> {
            T f;
        }
        struct Bar<T> {
            Foo<T> f;
        }
        int foo(thread Bar<device int*>* x)
        {
            return *x->f.f;
        }
        int bar(device int* a)
        {
            Bar<device int*> x;
            x.f.f = a;
            return foo(&x);
        }
    `);
    let /*<@45>*/buffer = new EBuffer(1);
    buffer.set(0, 79201);
    checkInt(program, callFunction(program, "bar", /*<@784>*/[], /*<@852>*/[TypedValue.box(new PtrType(externalOrigin, "device", program.intrinsics.int32), new EPtr(buffer, 0))]), 79201);
};
tests.simpleProtocolExtends = function /*<@1736>*/() {
    let /*<@71>*/program = doPrep(`
        protocol Foo {
            void foo(thread Foo*);
        }
        protocol Bar : Foo {
            void bar(thread Bar*);
        }
        void fuzz<T:Foo>(thread T* p)
        {
            foo(p);
        }
        void buzz<T:Bar>(thread T* p)
        {
            fuzz(p);
            bar(p);
        }
        void foo(thread int* p)
        {
            *p = *p + 743;
        }
        void bar(thread int* p)
        {
            *p = *p + 91;
        }
        int thingy(int a)
        {
            buzz(&a);
            return a;
        }
    `);
    checkInt(program, callFunction(program, "thingy", /*<@784>*/[], /*<@852>*/[makeInt(program, 642)]), 642 + 743 + 91);
};
tests.protocolExtendsTwo = function /*<@1737>*/() {
    let /*<@71>*/program = doPrep(`
        protocol Foo {
            void foo(thread Foo*);
        }
        protocol Bar {
            void bar(thread Bar*);
        }
        protocol Baz : Foo, Bar {
            void baz(thread Baz*);
        }
        void fuzz<T:Foo>(thread T* p)
        {
            foo(p);
        }
        void buzz<T:Bar>(thread T* p)
        {
            bar(p);
        }
        void xuzz<T:Baz>(thread T* p)
        {
            fuzz(p);
            buzz(p);
            baz(p);
        }
        void foo(thread int* p)
        {
            *p = *p + 743;
        }
        void bar(thread int* p)
        {
            *p = *p + 91;
        }
        void baz(thread int* p)
        {
            *p = *p + 39;
        }
        int thingy(int a)
        {
            xuzz(&a);
            return a;
        }
    `);
    checkInt(program, callFunction(program, "thingy", /*<@784>*/[], /*<@852>*/[makeInt(program, 642)]), 642 + 743 + 91 + 39);
};
tests.prefixPlusPlus = function /*<@1738>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(int x)
        {
            ++x;
            return x;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 64)]), 65);
};
tests.prefixPlusPlusResult = function /*<@1739>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(int x)
        {
            return ++x;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 64)]), 65);
};
tests.postfixPlusPlus = function /*<@1740>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(int x)
        {
            x++;
            return x;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 64)]), 65);
};
tests.postfixPlusPlusResult = function /*<@1741>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(int x)
        {
            return x++;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 64)]), 64);
};
tests.prefixMinusMinus = function /*<@1742>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(int x)
        {
            --x;
            return x;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 64)]), 63);
};
tests.prefixMinusMinusResult = function /*<@1743>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(int x)
        {
            return --x;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 64)]), 63);
};
tests.postfixMinusMinus = function /*<@1744>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(int x)
        {
            x--;
            return x;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 64)]), 63);
};
tests.postfixMinusMinusResult = function /*<@1745>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(int x)
        {
            return x--;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 64)]), 64);
};
tests.plusEquals = function /*<@1746>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(int x)
        {
            x += 42;
            return x;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 385)]), 385 + 42);
};
tests.plusEqualsResult = function /*<@1747>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(int x)
        {
            return x += 42;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 385)]), 385 + 42);
};
tests.minusEquals = function /*<@1748>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(int x)
        {
            x -= 42;
            return x;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 385)]), 385 - 42);
};
tests.minusEqualsResult = function /*<@1749>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(int x)
        {
            return x -= 42;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 385)]), 385 - 42);
};
tests.timesEquals = function /*<@1750>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(int x)
        {
            x *= 42;
            return x;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 385)]), 385 * 42);
};
tests.timesEqualsResult = function /*<@1751>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(int x)
        {
            return x *= 42;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 385)]), 385 * 42);
};
tests.divideEquals = function /*<@1752>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(int x)
        {
            x /= 42;
            return x;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 385)]), (385 / 42) | 0);
};
tests.divideEqualsResult = function /*<@1753>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(int x)
        {
            return x /= 42;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 385)]), (385 / 42) | 0);
};
tests.twoIntLiterals = function /*<@1754>*/() {
    let /*<@71>*/program = doPrep(`
        bool foo()
        {
            return 42 == 42;
        }
    `);
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), true);
};
tests.unifyDifferentLiterals = function /*<@1755>*/() {
    checkFail(/*<@1756>*/() => doPrep(`
            void bar<T>(T, T)
            {
            }
            void foo()
            {
                bar(42, 42u);
            }
        `), /*<@1757>*/(/*<@451>*/e) => e instanceof WTypeError);
};
tests.unifyDifferentLiteralsBackwards = function /*<@1758>*/() {
    checkFail(/*<@1759>*/() => doPrep(`
            void bar<T>(T, T)
            {
            }
            void foo()
            {
                bar(42u, 42);
            }
        `), /*<@1760>*/(/*<@451>*/e) => e instanceof WTypeError);
};
tests.unifyVeryDifferentLiterals = function /*<@1761>*/() {
    checkFail(/*<@1762>*/() => doPrep(`
            void bar<T>(T, T)
            {
            }
            void foo()
            {
                bar(42, null);
            }
        `), /*<@1763>*/(/*<@451>*/e) => e instanceof WTypeError);
};
tests.unifyVeryDifferentLiteralsBackwards = function /*<@1764>*/() {
    checkFail(/*<@1765>*/() => doPrep(`
            void bar<T>(T, T)
            {
            }
            void foo()
            {
                bar(null, 42);
            }
        `), /*<@1766>*/(/*<@451>*/e) => e instanceof WTypeError);
};
tests.assignUintToInt = function /*<@1767>*/() {
    checkFail(/*<@1768>*/() => doPrep(`
            void foo()
            {
                int x = 42u;
            }
        `), /*<@1769>*/(/*<@451>*/e) => e instanceof WTypeError && e.message.indexOf("Type mismatch in variable initialization") != -1);
};
tests.buildArrayThenSumIt = function /*<@1770>*/() {
    let /*<@71>*/program = doPrep(`
        int foo()
        {
            int[42] array;
            for (uint i = 0; i < 42; i = i + 1)
                array[i] = int(i + 5);
            int result;
            for (uint i = 0; i < 42; i = i + 1)
                result = result + array[i];
            return result;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), 42 * 5 + 42 * 41 / 2);
};
tests.buildArrayThenSumItUsingArrayReference = function /*<@1771>*/() {
    let /*<@71>*/program = doPrep(`
        int bar(thread int[] array)
        {
            for (uint i = 0; i < 42; i = i + 1)
                array[i] = int(i + 5);
            int result;
            for (uint i = 0; i < 42; i = i + 1)
                result = result + array[i];
            return result;
        }
        int foo()
        {
            int[42] array;
            return bar(@array);
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), 42 * 5 + 42 * 41 / 2);
};
tests.overrideSubscriptStruct = function /*<@1772>*/() {
    let /*<@71>*/program = doPrep(`
        struct Foo {
            int x;
            int y;
        }
        thread int* operator&[](thread Foo* foo, uint index)
        {
            if (index == 0)
                return &foo->x;
            if (index == 1)
                return &foo->y;
            return null;
        }
        int foo()
        {
            Foo foo;
            foo.x = 498;
            foo.y = 19;
            return foo[0] + foo[1] * 3;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), 498 + 19 * 3);
};
tests.overrideSubscriptStructAndDoStores = function /*<@1773>*/() {
    let /*<@71>*/program = doPrep(`
        struct Foo {
            int x;
            int y;
        }
        thread int* operator&[](thread Foo* foo, uint index)
        {
            if (index == 0)
                return &foo->x;
            if (index == 1)
                return &foo->y;
            return null;
        }
        int foo()
        {
            Foo foo;
            foo[0] = 498;
            foo[1] = 19;
            return foo.x + foo.y;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), 498 + 19);
};
tests.overrideSubscriptStructAndUsePointers = function /*<@1774>*/() {
    let /*<@71>*/program = doPrep(`
        struct Foo {
            int x;
            int y;
        }
        thread int* operator&[](thread Foo* foo, uint index)
        {
            if (index == 0)
                return &foo->x;
            if (index == 1)
                return &foo->y;
            return null;
        }
        int bar(thread Foo* foo)
        {
            return (*foo)[0] + (*foo)[1];
        }
        int foo()
        {
            Foo foo;
            foo.x = 498;
            foo.y = 19;
            return bar(&foo);
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), 498 + 19);
};
tests.overrideSubscriptStructAndUsePointersIncorrectly = function /*<@1775>*/() {
    checkFail(/*<@1776>*/() => doPrep(`
            struct Foo {
                int x;
                int y;
            }
            thread int* operator&[](thread Foo* foo, uint index)
            {
                if (index == 0)
                    return &foo->x;
                if (index == 1)
                    return &foo->y;
                return null;
            }
            int bar(thread Foo* foo)
            {
                return foo[0] + foo[1];
            }
            int foo()
            {
                Foo foo;
                foo.x = 498;
                foo.y = 19;
                return bar(&foo);
            }
        `), /*<@1777>*/(/*<@451>*/e) => e instanceof WTypeError);
};
tests.makeArrayRefFromLocal = function /*<@1778>*/() {
    let /*<@71>*/program = doPrep(`
        int bar(thread int[] ref)
        {
            return ref[0];
        }
        int foo()
        {
            int x = 48;
            return bar(@x);
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), 48);
};
tests.makeArrayRefFromPointer = function /*<@1779>*/() {
    let /*<@71>*/program = doPrep(`
        int bar(thread int[] ref)
        {
            return ref[0];
        }
        int baz(thread int* ptr)
        {
            return bar(@ptr);
        }
        int foo()
        {
            int x = 48;
            return baz(&x);
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), 48);
};
tests.makeArrayRefFromArrayRef = function /*<@1780>*/() {
    checkFail(/*<@1781>*/() => doPrep(`
            int bar(thread int[] ref)
            {
                return ref[0];
            }
            int baz(thread int[] ptr)
            {
                return bar(@ptr);
            }
            int foo()
            {
                int x = 48;
                return baz(@x);
            }
        `), /*<@1782>*/(/*<@451>*/e) => e instanceof WTypeError);
};
tests.simpleLength = function /*<@1783>*/() {
    let /*<@71>*/program = doPrep(`
        uint foo()
        {
            double[754] array;
            return (@array).length;
        }
    `);
    checkUint(program, callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), 754);
};
tests.nonArrayRefArrayLengthSucceed = function /*<@1784>*/() {
    let /*<@71>*/program = doPrep(`
        uint foo()
        {
            double[754] array;
            return array.length;
        }
    `);
    checkUint(program, callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), 754);
};
tests.nonArrayRefArrayLengthFail = function /*<@1785>*/() {
    checkFail(/*<@1786>*/() => doPrep(`
            thread uint* lengthPtr()
            {
                int[42] array;
                return &(array.length);
            }
        `), /*<@1787>*/e => e instanceof WTypeError);
};
tests.constexprIsNotLValuePtr = function /*<@1788>*/() {
    checkFail(/*<@1789>*/() => doPrep(`
            thread int* foo<int x>()
            {
                return &x;
            }
        `), /*<@1790>*/e => e instanceof WTypeError);
};
tests.constexprIsNotLValueAssign = function /*<@1791>*/() {
    checkFail(/*<@1792>*/() => doPrep(`
            void foo<int x>()
            {
                x = 42;
            }
        `), /*<@1793>*/e => e instanceof WTypeError);
};
tests.constexprIsNotLValueRMW = function /*<@1794>*/() {
    checkFail(/*<@1795>*/() => doPrep(`
            void foo<int x>()
            {
                x += 42;
            }
        `), /*<@1796>*/e => e instanceof WTypeError);
};
tests.assignLength = function /*<@1797>*/() {
    checkFail(/*<@1798>*/() => doPrep(`
            void foo()
            {
                double[754] array;
                (@array).length = 42;
            }
        `), /*<@1799>*/(/*<@451>*/e) => e instanceof WTypeError && e.message.indexOf("Have neither ander nor setter") != -1);
};
tests.assignLengthHelper = function /*<@1800>*/() {
    checkFail(/*<@1801>*/() => doPrep(`
            void bar(thread double[] array)
            {
                array.length = 42;
            }
            void foo()
            {
                double[754] array;
                bar(@array);
            }
        `), /*<@1802>*/(/*<@451>*/e) => e instanceof WTypeError && e.message.indexOf("Have neither ander nor setter") != -1);
};
tests.simpleGetter = function /*<@1803>*/() {
    let /*<@71>*/program = doPrep(`
        struct Foo {
            int x;
        }
        int operator.y(Foo foo)
        {
            return foo.x;
        }
        int foo()
        {
            Foo foo;
            foo.x = 7804;
            return foo.y;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), 7804);
};
tests.simpleSetter = function /*<@1804>*/() {
    let /*<@71>*/program = doPrep(`
        struct Foo {
            int x;
        }
        int operator.y(Foo foo)
        {
            return foo.x;
        }
        Foo operator.y=(Foo foo, int value)
        {
            foo.x = value;
            return foo;
        }
        int foo()
        {
            Foo foo;
            foo.y = 7804;
            return foo.x;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), 7804);
};
tests.genericAccessors = function /*<@1805>*/() {
    let /*<@71>*/program = doPrep(`
        struct Foo<T> {
            T x;
            T[3] y;
        }
        struct Bar<T> {
            T x;
            T y;
        }
        Bar<T> operator.z<T>(Foo<T> foo)
        {
            Bar<T> result;
            result.x = foo.x;
            result.y = foo.y[1];
            return result;
        }
        Foo<T> operator.z=<T>(Foo<T> foo, Bar<T> bar)
        {
            foo.x = bar.x;
            foo.y[1] = bar.y;
            return foo;
        }
        T operator.sum<T:Addable>(Foo<T> foo)
        {
            return foo.x + foo.y[0] + foo.y[1] + foo.y[2];
        }
        T operator.sum<T:Addable>(Bar<T> bar)
        {
            return bar.x + bar.y;
        }
        operator<T> Bar<T>(T x, T y)
        {
            Bar<T> result;
            result.x = x;
            result.y = y;
            return result;
        }
        void setup(thread Foo<int>* foo)
        {
            foo->x = 1;
            foo->y[0] = 2;
            foo->y[1] = 3;
            foo->y[2] = 4;
        }
        int testSuperBasic()
        {
            Foo<int> foo;
            setup(&foo);
            return foo.sum;
        }
        int testZSetterDidSetY()
        {
            Foo<int> foo;
            foo.z = Bar<int>(53, 932);
            return foo.y[1];
        }
        int testZSetter()
        {
            Foo<int> foo;
            foo.z = Bar<int>(53, 932);
            return foo.sum;
        }
        int testZGetter()
        {
            Foo<int> foo;
            // This deliberately does not call setup() just so we test this syntax.
            foo.x = 1;
            foo.y[0] = 2;
            foo.y[1] = 3;
            foo.y[2] = 4;
            return foo.z.sum;
        }
        int testLValueEmulation()
        {
            Foo<int> foo;
            setup(&foo);
            foo.z.y *= 5;
            return foo.sum;
        }
    `);
    checkInt(program, callFunction(program, "testSuperBasic", /*<@784>*/[], /*<@784>*/[]), 1 + 2 + 3 + 4);
    checkInt(program, callFunction(program, "testZSetterDidSetY", /*<@784>*/[], /*<@784>*/[]), 932);
    checkInt(program, callFunction(program, "testZSetter", /*<@784>*/[], /*<@784>*/[]), 53 + 932);
    checkInt(program, callFunction(program, "testZGetter", /*<@784>*/[], /*<@784>*/[]), 1 + 3);
    checkInt(program, callFunction(program, "testLValueEmulation", /*<@784>*/[], /*<@784>*/[]), 1 + 2 + 3 * 5 + 4);
};
tests.bitSubscriptAccessor = function /*<@1806>*/() {
    let /*<@71>*/program = doPrep(`
        protocol MyBitmaskable : Equatable {
            MyBitmaskable operator&(MyBitmaskable, MyBitmaskable);
            MyBitmaskable operator|(MyBitmaskable, MyBitmaskable);
            MyBitmaskable operator~(MyBitmaskable);
            MyBitmaskable operator<<(MyBitmaskable, uint);
            MyBitmaskable operator>>(MyBitmaskable, uint);
            operator MyBitmaskable(int);
        }
        T maskForBitIndex<T:MyBitmaskable>(uint index)
        {
            return T(1) << index;
        }
        bool operator[]<T:MyBitmaskable>(T value, uint index)
        {
            return bool(value & maskForBitIndex<T>(index));
        }
        T operator[]=<T:MyBitmaskable>(T value, uint index, bool bit)
        {
            T mask = maskForBitIndex<T>(index);
            if (bit)
                value |= mask;
            else
                value &= ~mask;
            return value;
        }
        uint operator.length(int)
        {
            return 32;
        }
        uint operator.length(uint)
        {
            return 32;
        }
        int testIntSetBit3()
        {
            int foo;
            foo[3] = true;
            return foo;
        }
        bool testIntSetGetBit5()
        {
            int foo;
            foo[5] = true;
            return foo[5];
        }
        bool testIntGetBit1()
        {
            int foo;
            return foo[1];
        }
        int testUintSumBits()
        {
            int foo = 42;
            int result;
            for (uint i = 0; i < foo.length; ++i) {
                if (foo[i])
                    result++;
            }
            return result;
        }
        int testUintSwapBits()
        {
            int foo = 42;
            for (uint i = 0; i < foo.length / 2; ++i) {
                bool tmp = foo[i];
                foo[i] = foo[foo.length - i - 1];
                foo[foo.length - i - 1] = tmp;
            }
            return foo;
        }
        struct Foo {
            uint f;
            uint g;
        }
        operator Foo(uint f, uint g)
        {
            Foo result;
            result.f = f;
            result.g = g;
            return result;
        }
        int operator.h(Foo foo)
        {
            return int((foo.f & 0xffff) | ((foo.g & 0xffff) << 16));
        }
        Foo operator.h=(Foo foo, int value)
        {
            foo.f &= ~0xffffu;
            foo.f |= uint(value) & 0xffff;
            foo.g &= ~0xffffu;
            foo.g |= (uint(value) >> 16) & 0xffff;
            return foo;
        }
        int testLValueEmulation()
        {
            Foo foo;
            foo.f = 42;
            foo.g = 37;
            for (uint i = 0; i < foo.h.length; ++i)
                foo.h[i] ^= true;
            return int(foo.f + foo.g);
        }
        struct Bar {
            Foo a;
            Foo b;
        }
        Foo operator.c(Bar bar)
        {
            return Foo(uint(bar.a.h), uint(bar.b.h));
        }
        Bar operator.c=(Bar bar, Foo foo)
        {
            bar.a.h = int(foo.f);
            bar.b.h = int(foo.g);
            return bar;
        }
        int testCrazyLValueEmulation()
        {
            Bar bar;
            bar.a.f = 1;
            bar.a.g = 2;
            bar.b.f = 3;
            bar.b.g = 4;
            for (uint i = 0; i < bar.c.h.length; i += 2)
                bar.c.h[i] ^= true;
            return int(bar.a.f + bar.a.g + bar.b.f + bar.b.g);
        }
    `);
    checkInt(program, callFunction(program, "testIntSetBit3", /*<@784>*/[], /*<@784>*/[]), 8);
    checkBool(program, callFunction(program, "testIntSetGetBit5", /*<@784>*/[], /*<@784>*/[]), true);
    checkBool(program, callFunction(program, "testIntGetBit1", /*<@784>*/[], /*<@784>*/[]), false);
    checkInt(program, callFunction(program, "testUintSumBits", /*<@784>*/[], /*<@784>*/[]), 3);
    checkInt(program, callFunction(program, "testUintSwapBits", /*<@784>*/[], /*<@784>*/[]), 1409286144);
    checkInt(program, callFunction(program, "testLValueEmulation", /*<@784>*/[], /*<@784>*/[]), 130991);
    checkInt(program, callFunction(program, "testCrazyLValueEmulation", /*<@784>*/[], /*<@784>*/[]), 43696);
};
tests.nestedSubscriptLValueEmulationSimple = function /*<@1807>*/() {
    let /*<@71>*/program = doPrep(`
        struct Foo {
            int[7] array;
        }
        int operator[](Foo foo, uint index)
        {
            return foo.array[index];
        }
        Foo operator[]=(Foo foo, uint index, int value)
        {
            foo.array[index] = value;
            return foo;
        }
        uint operator.length(Foo foo)
        {
            return foo.array.length;
        }
        int sum(Foo foo)
        {
            int result = 0;
            for (uint i = foo.length; i--;)
                result += foo[i];
            return result;
        }
        struct Bar {
            Foo[6] array;
        }
        uint operator.length(Bar bar)
        {
            return bar.array.length;
        }
        Foo operator[](Bar bar, uint index)
        {
            return bar.array[index];
        }
        Bar operator[]=(Bar bar, uint index, Foo value)
        {
            bar.array[index] = value;
            return bar;
        }
        int sum(Bar bar)
        {
            int result = 0;
            for (uint i = bar.length; i--;)
                result += sum(bar[i]);
            return result;
        }
        struct Baz {
            Bar[5] array;
        }
        Bar operator[](Baz baz, uint index)
        {
            return baz.array[index];
        }
        Baz operator[]=(Baz baz, uint index, Bar value)
        {
            baz.array[index] = value;
            return baz;
        }
        uint operator.length(Baz baz)
        {
            return baz.array.length;
        }
        int sum(Baz baz)
        {
            int result = 0;
            for (uint i = baz.length; i--;)
                result += sum(baz[i]);
            return result;
        }
        void setValues(thread Baz* baz)
        {
            for (uint i = baz->length; i--;) {
                for (uint j = (*baz)[i].length; j--;) {
                    for (uint k = (*baz)[i][j].length; k--;)
                        (*baz)[i][j][k] = int(i + j + k);
                }
            }
        }
        int testSetValuesAndSum()
        {
            Baz baz;
            setValues(&baz);
            return sum(baz);
        }
        int testSetValuesMutateValuesAndSum()
        {
            Baz baz;
            setValues(&baz);
            for (uint i = baz.length; i--;) {
                for (uint j = baz[i].length; j--;) {
                    for (uint k = baz[i][j].length; k--;)
                        baz[i][j][k] *= int(k);
                }
            }
            return sum(baz);
        }
    `);
    checkInt(program, callFunction(program, "testSetValuesAndSum", /*<@784>*/[], /*<@784>*/[]), 1575);
    checkInt(program, callFunction(program, "testSetValuesMutateValuesAndSum", /*<@784>*/[], /*<@784>*/[]), 5565);
};
tests.nestedSubscriptLValueEmulationGeneric = function /*<@1808>*/() {
    let /*<@71>*/program = doPrep(`
        struct Foo<T> {
            T[7] array;
        }
        T operator[]<T>(Foo<T> foo, uint index)
        {
            return foo.array[index];
        }
        Foo<T> operator[]=<T>(Foo<T> foo, uint index, T value)
        {
            foo.array[index] = value;
            return foo;
        }
        uint operator.length<T>(Foo<T> foo)
        {
            return foo.array.length;
        }
        protocol MyAddable {
            MyAddable operator+(MyAddable, MyAddable);
        }
        T sum<T:MyAddable>(Foo<T> foo)
        {
            T result;
            for (uint i = foo.length; i--;)
                result += foo[i];
            return result;
        }
        struct Bar<T> {
            Foo<T>[6] array;
        }
        uint operator.length<T>(Bar<T> bar)
        {
            return bar.array.length;
        }
        Foo<T> operator[]<T>(Bar<T> bar, uint index)
        {
            return bar.array[index];
        }
        Bar<T> operator[]=<T>(Bar<T> bar, uint index, Foo<T> value)
        {
            bar.array[index] = value;
            return bar;
        }
        T sum<T:MyAddable>(Bar<T> bar)
        {
            T result;
            for (uint i = bar.length; i--;)
                result += sum(bar[i]);
            return result;
        }
        struct Baz<T> {
            Bar<T>[5] array;
        }
        Bar<T> operator[]<T>(Baz<T> baz, uint index)
        {
            return baz.array[index];
        }
        Baz<T> operator[]=<T>(Baz<T> baz, uint index, Bar<T> value)
        {
            baz.array[index] = value;
            return baz;
        }
        uint operator.length<T>(Baz<T> baz)
        {
            return baz.array.length;
        }
        T sum<T:MyAddable>(Baz<T> baz)
        {
            T result;
            for (uint i = baz.length; i--;)
                result += sum(baz[i]);
            return result;
        }
        protocol MyConvertibleFromUint {
            operator MyConvertibleFromUint(uint);
        }
        protocol SetValuable : MyAddable, MyConvertibleFromUint { }
        void setValues<T:SetValuable>(thread Baz<T>* baz)
        {
            for (uint i = baz->length; i--;) {
                for (uint j = (*baz)[i].length; j--;) {
                    for (uint k = (*baz)[i][j].length; k--;)
                        (*baz)[i][j][k] = T(i + j + k);
                }
            }
        }
        int testSetValuesAndSum()
        {
            Baz<int> baz;
            setValues(&baz);
            return sum(baz);
        }
        int testSetValuesMutateValuesAndSum()
        {
            Baz<int> baz;
            setValues(&baz);
            for (uint i = baz.length; i--;) {
                for (uint j = baz[i].length; j--;) {
                    for (uint k = baz[i][j].length; k--;)
                        baz[i][j][k] *= int(k);
                }
            }
            return sum(baz);
        }
    `);
    checkInt(program, callFunction(program, "testSetValuesAndSum", /*<@784>*/[], /*<@784>*/[]), 1575);
    checkInt(program, callFunction(program, "testSetValuesMutateValuesAndSum", /*<@784>*/[], /*<@784>*/[]), 5565);
};
tests.boolBitAnd = function /*<@1809>*/() {
    let /*<@71>*/program = doPrep(`
        bool foo(bool a, bool b)
        {
            return a & b;
        }
    `);
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeBool(program, false), makeBool(program, false)]), false);
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeBool(program, true), makeBool(program, false)]), false);
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeBool(program, false), makeBool(program, true)]), false);
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeBool(program, true), makeBool(program, true)]), true);
};
tests.boolBitOr = function /*<@1810>*/() {
    let /*<@71>*/program = doPrep(`
        bool foo(bool a, bool b)
        {
            return a | b;
        }
    `);
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeBool(program, false), makeBool(program, false)]), false);
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeBool(program, true), makeBool(program, false)]), true);
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeBool(program, false), makeBool(program, true)]), true);
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeBool(program, true), makeBool(program, true)]), true);
};
tests.boolBitXor = function /*<@1811>*/() {
    let /*<@71>*/program = doPrep(`
        bool foo(bool a, bool b)
        {
            return a ^ b;
        }
    `);
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeBool(program, false), makeBool(program, false)]), false);
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeBool(program, true), makeBool(program, false)]), true);
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeBool(program, false), makeBool(program, true)]), true);
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeBool(program, true), makeBool(program, true)]), false);
};
tests.boolBitNot = function /*<@1812>*/() {
    let /*<@71>*/program = doPrep(`
        bool foo(bool a)
        {
            return ~a;
        }
    `);
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeBool(program, false)]), true);
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeBool(program, true)]), false);
};
tests.intBitAnd = function /*<@1813>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(int a, int b)
        {
            return a & b;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 1), makeInt(program, 7)]), 1);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 65535), makeInt(program, 42)]), 42);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, -1), makeInt(program, -7)]), -7);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 0), makeInt(program, 85732)]), 0);
};
tests.intBitOr = function /*<@1814>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(int a, int b)
        {
            return a | b;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 1), makeInt(program, 7)]), 7);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 65535), makeInt(program, 42)]), 65535);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, -1), makeInt(program, -7)]), -1);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 0), makeInt(program, 85732)]), 85732);
};
tests.intBitXor = function /*<@1815>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(int a, int b)
        {
            return a ^ b;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 1), makeInt(program, 7)]), 6);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 65535), makeInt(program, 42)]), 65493);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, -1), makeInt(program, -7)]), 6);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 0), makeInt(program, 85732)]), 85732);
};
tests.intBitNot = function /*<@1816>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(int a)
        {
            return ~a;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 1)]), -2);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 65535)]), -65536);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, -1)]), 0);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 0)]), -1);
};
tests.intLShift = function /*<@1817>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(int a, uint b)
        {
            return a << b;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 1), makeUint(program, 7)]), 128);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 65535), makeUint(program, 2)]), 262140);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, -1), makeUint(program, 5)]), -32);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 0), makeUint(program, 3)]), 0);
};
tests.intRShift = function /*<@1818>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(int a, uint b)
        {
            return a >> b;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 1), makeUint(program, 7)]), 0);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 65535), makeUint(program, 2)]), 16383);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, -1), makeUint(program, 5)]), -1);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 0), makeUint(program, 3)]), 0);
};
tests.uintBitAnd = function /*<@1819>*/() {
    let /*<@71>*/program = doPrep(`
        uint foo(uint a, uint b)
        {
            return a & b;
        }
    `);
    checkUint(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint(program, 1), makeUint(program, 7)]), 1);
    checkUint(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint(program, 65535), makeUint(program, 42)]), 42);
    checkUint(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint(program, -1), makeUint(program, -7)]), 4294967289);
    checkUint(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint(program, 0), makeUint(program, 85732)]), 0);
};
tests.uintBitOr = function /*<@1820>*/() {
    let /*<@71>*/program = doPrep(`
        uint foo(uint a, uint b)
        {
            return a | b;
        }
    `);
    checkUint(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint(program, 1), makeUint(program, 7)]), 7);
    checkUint(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint(program, 65535), makeUint(program, 42)]), 65535);
    checkUint(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint(program, -1), makeUint(program, -7)]), 4294967295);
    checkUint(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint(program, 0), makeUint(program, 85732)]), 85732);
};
tests.uintBitXor = function /*<@1821>*/() {
    let /*<@71>*/program = doPrep(`
        uint foo(uint a, uint b)
        {
            return a ^ b;
        }
    `);
    checkUint(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint(program, 1), makeUint(program, 7)]), 6);
    checkUint(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint(program, 65535), makeUint(program, 42)]), 65493);
    checkUint(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint(program, -1), makeUint(program, -7)]), 6);
    checkUint(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint(program, 0), makeUint(program, 85732)]), 85732);
};
tests.uintBitNot = function /*<@1822>*/() {
    let /*<@71>*/program = doPrep(`
        uint foo(uint a)
        {
            return ~a;
        }
    `);
    checkUint(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint(program, 1)]), 4294967294);
    checkUint(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint(program, 65535)]), 4294901760);
    checkUint(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint(program, -1)]), 0);
    checkUint(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint(program, 0)]), 4294967295);
};
tests.uintLShift = function /*<@1823>*/() {
    let /*<@71>*/program = doPrep(`
        uint foo(uint a, uint b)
        {
            return a << b;
        }
    `);
    checkUint(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint(program, 1), makeUint(program, 7)]), 128);
    checkUint(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint(program, 65535), makeUint(program, 2)]), 262140);
    checkUint(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint(program, -1), makeUint(program, 5)]), 4294967264);
    checkUint(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint(program, 0), makeUint(program, 3)]), 0);
};
tests.uintRShift = function /*<@1824>*/() {
    let /*<@71>*/program = doPrep(`
        uint foo(uint a, uint b)
        {
            return a >> b;
        }
    `);
    checkUint(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint(program, 1), makeUint(program, 7)]), 0);
    checkUint(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint(program, 65535), makeUint(program, 2)]), 16383);
    checkUint(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint(program, -1), makeUint(program, 5)]), 134217727);
    checkUint(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint(program, 0), makeUint(program, 3)]), 0);
};
tests.uint8BitAnd = function /*<@1825>*/() {
    let /*<@71>*/program = doPrep(`
        uint8 foo(uint8 a, uint8 b)
        {
            return a & b;
        }
    `);
    checkUint8(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint8(program, 1), makeUint8(program, 7)]), 1);
    checkUint8(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint8(program, 65535), makeUint8(program, 42)]), 42);
    checkUint8(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint8(program, -1), makeUint8(program, -7)]), 249);
    checkUint8(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint8(program, 0), makeUint8(program, 85732)]), 0);
};
tests.uint8BitOr = function /*<@1826>*/() {
    let /*<@71>*/program = doPrep(`
        uint8 foo(uint8 a, uint8 b)
        {
            return a | b;
        }
    `);
    checkUint8(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint8(program, 1), makeUint8(program, 7)]), 7);
    checkUint8(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint8(program, 65535), makeUint8(program, 42)]), 255);
    checkUint8(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint8(program, -1), makeUint8(program, -7)]), 255);
    checkUint8(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint8(program, 0), makeUint8(program, 85732)]), 228);
};
tests.uint8BitXor = function /*<@1827>*/() {
    let /*<@71>*/program = doPrep(`
        uint8 foo(uint8 a, uint8 b)
        {
            return a ^ b;
        }
    `);
    checkUint8(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint8(program, 1), makeUint8(program, 7)]), 6);
    checkUint8(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint8(program, 65535), makeUint8(program, 42)]), 213);
    checkUint8(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint8(program, -1), makeUint8(program, -7)]), 6);
    checkUint8(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint8(program, 0), makeUint8(program, 85732)]), 228);
};
tests.uint8BitNot = function /*<@1828>*/() {
    let /*<@71>*/program = doPrep(`
        uint8 foo(uint8 a)
        {
            return ~a;
        }
    `);
    checkUint8(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint8(program, 1)]), 254);
    checkUint8(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint8(program, 65535)]), 0);
    checkUint8(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint8(program, -1)]), 0);
    checkUint8(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint8(program, 0)]), 255);
};
tests.uint8LShift = function /*<@1829>*/() {
    let /*<@71>*/program = doPrep(`
        uint8 foo(uint8 a, uint b)
        {
            return a << b;
        }
    `);
    checkUint8(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint8(program, 1), makeUint(program, 7)]), 128);
    checkUint8(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint8(program, 65535), makeUint(program, 2)]), 252);
    checkUint8(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint8(program, -1), makeUint(program, 5)]), 224);
    checkUint8(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint8(program, 0), makeUint(program, 3)]), 0);
};
tests.uint8RShift = function /*<@1830>*/() {
    let /*<@71>*/program = doPrep(`
        uint8 foo(uint8 a, uint b)
        {
            return a >> b;
        }
    `);
    checkUint8(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint8(program, 1), makeUint(program, 7)]), 0);
    checkUint8(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint8(program, 65535), makeUint(program, 2)]), 255);
    checkUint8(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint8(program, -1), makeUint(program, 5)]), 255);
    checkUint8(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint8(program, 0), makeUint(program, 3)]), 0);
};
tests.floatMath = function /*<@1831>*/() {
    let /*<@71>*/program = doPrep(`
        bool foo()
        {
            return 42.5 == 42.5;
        }
        bool foo2()
        {
            return 42.5f == 42.5;
        }
        bool foo3()
        {
            return 42.5 == 42.5f;
        }
        bool foo4()
        {
            return 42.5f == 42.5f;
        }
        bool foo5()
        {
            return 42.5d == 42.5d;
        }
        float bar(float x)
        {
            return x;
        }
        float foo6()
        {
            return bar(7.5);
        }
        float foo7()
        {
            return bar(7.5f);
        }
        float foo8()
        {
            return bar(7.5d);
        }
        float foo9()
        {
            return float(7.5);
        }
        float foo10()
        {
            return float(7.5f);
        }
        float foo11()
        {
            return float(7.5d);
        }
        float foo12()
        {
            return float(7);
        }
        float foo13()
        {
            double x = 7.5d;
            return float(x);
        }
        double foo14()
        {
            double x = 7.5f;
            return double(x);
        }
    `);
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), true);
    checkBool(program, callFunction(program, "foo2", /*<@784>*/[], /*<@784>*/[]), true);
    checkBool(program, callFunction(program, "foo3", /*<@784>*/[], /*<@784>*/[]), true);
    checkBool(program, callFunction(program, "foo4", /*<@784>*/[], /*<@784>*/[]), true);
    checkBool(program, callFunction(program, "foo5", /*<@784>*/[], /*<@784>*/[]), true);
    checkFloat(program, callFunction(program, "foo6", /*<@784>*/[], /*<@784>*/[]), 7.5);
    checkFloat(program, callFunction(program, "foo7", /*<@784>*/[], /*<@784>*/[]), 7.5);
    checkFloat(program, callFunction(program, "foo8", /*<@784>*/[], /*<@784>*/[]), 7.5);
    checkFloat(program, callFunction(program, "foo9", /*<@784>*/[], /*<@784>*/[]), 7.5);
    checkFloat(program, callFunction(program, "foo10", /*<@784>*/[], /*<@784>*/[]), 7.5);
    checkFloat(program, callFunction(program, "foo11", /*<@784>*/[], /*<@784>*/[]), 7.5);
    checkFloat(program, callFunction(program, "foo12", /*<@784>*/[], /*<@784>*/[]), 7);
    checkFloat(program, callFunction(program, "foo13", /*<@784>*/[], /*<@784>*/[]), 7.5);
    checkDouble(program, callFunction(program, "foo14", /*<@784>*/[], /*<@784>*/[]), 7.5);
    checkFail(/*<@1832>*/() => doPrep(`
            int bar(int x)
            {
                return x;
            }
            int foo()
            {
                bar(4.);
            }
        `), /*<@1833>*/(/*<@451>*/e) => e instanceof WTypeError);
    checkFail(/*<@1834>*/() => doPrep(`
            int bar(int x)
            {
                return x;
            }
            int foo()
            {
                bar(4.d);
            }
        `), /*<@1835>*/(/*<@451>*/e) => e instanceof WTypeError);
    checkFail(/*<@1836>*/() => doPrep(`
            int bar(int x)
            {
                return x;
            }
            int foo()
            {
                bar(4.f);
            }
        `), /*<@1837>*/(/*<@451>*/e) => e instanceof WTypeError);
    checkFail(/*<@1838>*/() => doPrep(`
            uint bar(uint x)
            {
                return x;
            }
            int foo()
            {
                bar(4.);
            }
        `), /*<@1839>*/(/*<@451>*/e) => e instanceof WTypeError);
    checkFail(/*<@1840>*/() => doPrep(`
            uint bar(uint x)
            {
                return x;
            }
            int foo()
            {
                bar(4.d);
            }
        `), /*<@1841>*/(/*<@451>*/e) => e instanceof WTypeError);
    checkFail(/*<@1842>*/() => doPrep(`
            uint bar(uint x)
            {
                return x;
            }
            int foo()
            {
                bar(4.f);
            }
        `), /*<@1843>*/(/*<@451>*/e) => e instanceof WTypeError);
    checkFail(/*<@1844>*/() => doPrep(`
            float bar(float x)
            {
                return x;
            }
            void foo()
            {
                bar(16777217.d);
            }
        `), /*<@1845>*/(/*<@451>*/e) => e instanceof WTypeError);
    checkFail(/*<@1846>*/() => doPrep(`
            float bar(float x)
            {
                return x;
            }
            float foo()
            {
                double x = 7.;
                return bar(x);
            }
        `), /*<@1847>*/(/*<@451>*/e) => e instanceof WTypeError);
    checkFail(/*<@1848>*/() => doPrep(`
            float foo()
            {
                double x = 7.;
                return x;
            }
        `), /*<@1849>*/(/*<@451>*/e) => e instanceof WTypeError);
};
tests.genericCastInfer = function /*<@1850>*/() {
    let /*<@71>*/program = doPrep(`
        struct Complex<T> {
            T real;
            T imag;
        }
        operator<T> Complex<T>(T real, T imag)
        {
            Complex<T> result;
            result.real = real;
            result.imag = imag;
            return result;
        }
        int foo()
        {
            Complex<int> x = Complex<int>(1, 2);
            return x.real + x.imag;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), 3);
};
tests.booleanMath = function /*<@1851>*/() {
    let /*<@71>*/program = doPrep(`
        bool foo()
        {
            return true && true;
        }
        bool foo2()
        {
            return true && false;
        }
        bool foo3()
        {
            return false && true;
        }
        bool foo4()
        {
            return false && false;
        }
        bool foo5()
        {
            return true || true;
        }
        bool foo6()
        {
            return true || false;
        }
        bool foo7()
        {
            return false || true;
        }
        bool foo8()
        {
            return false || false;
        }
    `);
    checkBool(program, callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), true);
    checkBool(program, callFunction(program, "foo2", /*<@784>*/[], /*<@784>*/[]), false);
    checkBool(program, callFunction(program, "foo3", /*<@784>*/[], /*<@784>*/[]), false);
    checkBool(program, callFunction(program, "foo4", /*<@784>*/[], /*<@784>*/[]), false);
    checkBool(program, callFunction(program, "foo5", /*<@784>*/[], /*<@784>*/[]), true);
    checkBool(program, callFunction(program, "foo6", /*<@784>*/[], /*<@784>*/[]), true);
    checkBool(program, callFunction(program, "foo7", /*<@784>*/[], /*<@784>*/[]), true);
    checkBool(program, callFunction(program, "foo8", /*<@784>*/[], /*<@784>*/[]), false);
};
tests.typedefArray = function /*<@1852>*/() {
    let /*<@71>*/program = doPrep(`
        typedef ArrayTypedef = int[2];
        int foo()
        {
            ArrayTypedef arrayTypedef;
            return arrayTypedef[0];
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), 0);
};
tests.shaderTypes = function /*<@1853>*/() {
    checkFail(/*<@1854>*/() => doPrep(`
            struct Foo {
                float4 x;
            }
            vertex Foo bar()
            {
                Foo result;
                result.x = float4();
                return result;
            }
            Foo foo() {
                return bar();
            }
        `), /*<@1855>*/(/*<@451>*/e) => e instanceof WTypeError);
    checkFail(/*<@1856>*/() => doPrep(`
            vertex float bar()
            {
                return 4.;
            }
        `), /*<@1857>*/(/*<@451>*/e) => e instanceof WTypeError);
    checkFail(/*<@1858>*/() => doPrep(`
            struct Foo {
                float4 x;
            }
            vertex Foo bar(device Foo* x)
            {
                return Foo();
            }
        `), /*<@1859>*/(/*<@451>*/e) => e instanceof WTypeError);
    checkFail(/*<@1860>*/() => doPrep(`
            struct Boo {
                float4 x;
            }
            struct Foo {
                float4 x;
                device Boo* y;
            }
            vertex Foo bar()
            {
                return Foo();
            }
        `), /*<@1861>*/(/*<@451>*/e) => e instanceof WTypeError);
    checkFail(/*<@1862>*/() => doPrep(`
            struct Foo {
                float4 x;
            }
            struct Boo {
                device Foo* y;
            }
            vertex Foo bar(Boo b)
            {
                return Foo();
            }
        `), /*<@1863>*/(/*<@451>*/e) => e instanceof WTypeError);
    checkFail(/*<@1864>*/() => doPrep(`
            struct Foo {
                float4 x;
            }
            vertex Foo bar(device Foo* x)
            {
                return Foo();
            }
        `), /*<@1865>*/(/*<@451>*/e) => e instanceof WTypeError);
    checkFail(/*<@1866>*/() => doPrep(`
            struct Foo {
                float4 x;
            }
            fragment Foo bar(Foo foo)
            {
                return Foo();
            }
        `), /*<@1867>*/(/*<@451>*/e) => e instanceof WTypeError);
    checkFail(/*<@1868>*/() => doPrep(`
            struct Foo {
                float4 x;
            }
            fragment Foo bar(device Foo* stageIn)
            {
                return Foo();
            }
        `), /*<@1869>*/(/*<@451>*/e) => e instanceof WTypeError);
    checkFail(/*<@1870>*/() => doPrep(`
            struct Boo {
                float4 x;
            }
            struct Foo {
                float4 x;
                device Boo* y;
            }
            fragment Boo bar(Foo stageIn)
            {
                return boo();
            }
        `), /*<@1871>*/(/*<@451>*/e) => e instanceof WTypeError);
    checkFail(/*<@1872>*/() => doPrep(`
            struct Boo {
                float4 x;
            }
            struct Foo {
                float4 x;
                device Boo* y;
            }
            fragment Foo bar(Boo stageIn)
            {
                return Foo();
            }
        `), /*<@1873>*/(/*<@451>*/e) => e instanceof WTypeError);
};
tests.builtinVectors = function /*<@1874>*/() {
    let /*<@71>*/program = doPrep(`
        int foo()
        {
            int2 a = int2(3, 4);
            return a[0];
        }
        int foo2()
        {
            int2 a = int2(3, 4);
            int3 b = int3(a, 5);
            return b[1];
        }
        int foo3()
        {
            int3 a = int3(3, 4, 5);
            int4 b = int4(6, a);
            return b[1];
        }
        int foo4()
        {
            int2 a = int2(3, 4);
            int2 b = int2(5, 6);
            int4 c = int4(a, b);
            return c[2];
        }
        bool foo5()
        {
            int4 a = int4(3, 4, 5, 6);
            int2 b = int2(4, 5);
            int4 c = int4(3, b, 6);
            return a == c;
        }
        bool foo6()
        {
            int2 a = int2(4, 5);
            int3 b = int3(3, a);
            int3 c = int3(3, 4, 6);
            return b == c;
        }
        uint foou()
        {
            uint2 a = uint2(3, 4);
            return a[0];
        }
        uint foou2()
        {
            uint2 a = uint2(3, 4);
            uint3 b = uint3(a, 5);
            return b[1];
        }
        uint foou3()
        {
            uint3 a = uint3(3, 4, 5);
            uint4 b = uint4(6, a);
            return b[1];
        }
        uint foou4()
        {
            uint2 a = uint2(3, 4);
            uint2 b = uint2(5, 6);
            uint4 c = uint4(a, b);
            return c[2];
        }
        bool foou5()
        {
            uint4 a = uint4(3, 4, 5, 6);
            uint2 b = uint2(4, 5);
            uint4 c = uint4(3, b, 6);
            return a == c;
        }
        bool foou6()
        {
            uint2 a = uint2(4, 5);
            uint3 b = uint3(3, a);
            uint3 c = uint3(3, 4, 6);
            return b == c;
        }
        float foof()
        {
            float2 a = float2(3., 4.);
            return a[0];
        }
        float foof2()
        {
            float2 a = float2(3., 4.);
            float3 b = float3(a, 5.);
            return b[1];
        }
        float foof3()
        {
            float3 a = float3(3., 4., 5.);
            float4 b = float4(6., a);
            return b[1];
        }
        float foof4()
        {
            float2 a = float2(3., 4.);
            float2 b = float2(5., 6.);
            float4 c = float4(a, b);
            return c[2];
        }
        bool foof5()
        {
            float4 a = float4(3., 4., 5., 6.);
            float2 b = float2(4., 5.);
            float4 c = float4(3., b, 6.);
            return a == c;
        }
        bool foof6()
        {
            float2 a = float2(4., 5.);
            float3 b = float3(3., a);
            float3 c = float3(3., 4., 6.);
            return b == c;
        }
        double food()
        {
            double2 a = double2(3., 4.);
            return a[0];
        }
        double food2()
        {
            double2 a = double2(3., 4.);
            double3 b = double3(a, 5.);
            return b[1];
        }
        double food3()
        {
            double3 a = double3(3., 4., 5.);
            double4 b = double4(6., a);
            return b[1];
        }
        double food4()
        {
            double2 a = double2(3., 4.);
            double2 b = double2(5., 6.);
            double4 c = double4(a, b);
            return c[2];
        }
        bool food5()
        {
            double4 a = double4(3., 4., 5., 6.);
            double2 b = double2(4., 5.);
            double4 c = double4(3., b, 6.);
            return a == c;
        }
        bool food6()
        {
            double2 a = double2(4., 5.);
            double3 b = double3(3., a);
            double3 c = double3(3., 4., 6.);
            return b == c;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), 3);
    checkInt(program, callFunction(program, "foo2", /*<@784>*/[], /*<@784>*/[]), 4);
    checkInt(program, callFunction(program, "foo3", /*<@784>*/[], /*<@784>*/[]), 3);
    checkInt(program, callFunction(program, "foo4", /*<@784>*/[], /*<@784>*/[]), 5);
    checkBool(program, callFunction(program, "foo5", /*<@784>*/[], /*<@784>*/[]), true);
    checkBool(program, callFunction(program, "foo6", /*<@784>*/[], /*<@784>*/[]), false);
    checkUint(program, callFunction(program, "foou", /*<@784>*/[], /*<@784>*/[]), 3);
    checkUint(program, callFunction(program, "foou2", /*<@784>*/[], /*<@784>*/[]), 4);
    checkUint(program, callFunction(program, "foou3", /*<@784>*/[], /*<@784>*/[]), 3);
    checkUint(program, callFunction(program, "foou4", /*<@784>*/[], /*<@784>*/[]), 5);
    checkBool(program, callFunction(program, "foou5", /*<@784>*/[], /*<@784>*/[]), true);
    checkBool(program, callFunction(program, "foou6", /*<@784>*/[], /*<@784>*/[]), false);
    checkFloat(program, callFunction(program, "foof", /*<@784>*/[], /*<@784>*/[]), 3);
    checkFloat(program, callFunction(program, "foof2", /*<@784>*/[], /*<@784>*/[]), 4);
    checkFloat(program, callFunction(program, "foof3", /*<@784>*/[], /*<@784>*/[]), 3);
    checkFloat(program, callFunction(program, "foof4", /*<@784>*/[], /*<@784>*/[]), 5);
    checkBool(program, callFunction(program, "foof5", /*<@784>*/[], /*<@784>*/[]), true);
    checkBool(program, callFunction(program, "foof6", /*<@784>*/[], /*<@784>*/[]), false);
    checkDouble(program, callFunction(program, "food", /*<@784>*/[], /*<@784>*/[]), 3);
    checkDouble(program, callFunction(program, "food2", /*<@784>*/[], /*<@784>*/[]), 4);
    checkDouble(program, callFunction(program, "food3", /*<@784>*/[], /*<@784>*/[]), 3);
    checkDouble(program, callFunction(program, "food4", /*<@784>*/[], /*<@784>*/[]), 5);
    checkBool(program, callFunction(program, "food5", /*<@784>*/[], /*<@784>*/[]), true);
    checkBool(program, callFunction(program, "food6", /*<@784>*/[], /*<@784>*/[]), false);
};
tests.instantiateStructInStruct = function /*<@1875>*/() {
    let /*<@71>*/program = doPrep(`
        struct Bar<T> {
            T x;
        }
        struct Foo {
            Bar<int> x;
        }
        int foo()
        {
            Foo x;
            x.x.x = 42;
            x.x.x++;
            return x.x.x;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), 43);
};
tests.instantiateStructInStructWithInt2 = function /*<@1876>*/() {
    let /*<@71>*/program = doPrep(`
        struct Foo {
            int2 x;
        }
        int foo()
        {
            Foo x;
            x.x.x = 42;
            x.x.x++;
            return x.x.x;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), 43);
};
tests.simpleEnum = function /*<@1877>*/() {
    let /*<@71>*/program = doPrep(`
        enum Foo {
            War,
            Famine,
            Pestilence,
            Death
        }
        Foo war()
        {
            return Foo.War;
        }
        Foo famine()
        {
            return Foo.Famine;
        }
        Foo pestilence()
        {
            return Foo.Pestilence;
        }
        Foo death()
        {
            return Foo.Death;
        }
        bool equals(Foo a, Foo b)
        {
            return a == b;
        }
        bool notEquals(Foo a, Foo b)
        {
            return a != b;
        }
        bool testSimpleEqual()
        {
            return equals(Foo.War, Foo.War);
        }
        bool testAnotherEqual()
        {
            return equals(Foo.Pestilence, Foo.Pestilence);
        }
        bool testNotEqual()
        {
            return equals(Foo.Famine, Foo.Death);
        }
        bool testSimpleNotEqual()
        {
            return notEquals(Foo.War, Foo.War);
        }
        bool testAnotherNotEqual()
        {
            return notEquals(Foo.Pestilence, Foo.Pestilence);
        }
        bool testNotNotEqual()
        {
            return notEquals(Foo.Famine, Foo.Death);
        }
        int intWar()
        {
            return int(war());
        }
        int intFamine()
        {
            return int(famine());
        }
        int intPestilence()
        {
            return int(pestilence());
        }
        int intDeath()
        {
            return int(death());
        }
        int warValue()
        {
            return war().value;
        }
        int famineValue()
        {
            return famine().value;
        }
        int pestilenceValue()
        {
            return pestilence().value;
        }
        int deathValue()
        {
            return death().value;
        }
        int warValueLiteral()
        {
            return Foo.War.value;
        }
        int famineValueLiteral()
        {
            return Foo.Famine.value;
        }
        int pestilenceValueLiteral()
        {
            return Foo.Pestilence.value;
        }
        int deathValueLiteral()
        {
            return Foo.Death.value;
        }
        Foo intWarBackwards()
        {
            return Foo(intWar());
        }
        Foo intFamineBackwards()
        {
            return Foo(intFamine());
        }
        Foo intPestilenceBackwards()
        {
            return Foo(intPestilence());
        }
        Foo intDeathBackwards()
        {
            return Foo(intDeath());
        }
    `);
    checkEnum(program, callFunction(program, "war", /*<@784>*/[], /*<@784>*/[]), 0);
    checkEnum(program, callFunction(program, "famine", /*<@784>*/[], /*<@784>*/[]), 1);
    checkEnum(program, callFunction(program, "pestilence", /*<@784>*/[], /*<@784>*/[]), 2);
    checkEnum(program, callFunction(program, "death", /*<@784>*/[], /*<@784>*/[]), 3);
    checkBool(program, callFunction(program, "testSimpleEqual", /*<@784>*/[], /*<@784>*/[]), true);
    checkBool(program, callFunction(program, "testAnotherEqual", /*<@784>*/[], /*<@784>*/[]), true);
    checkBool(program, callFunction(program, "testNotEqual", /*<@784>*/[], /*<@784>*/[]), false);
    checkBool(program, callFunction(program, "testSimpleNotEqual", /*<@784>*/[], /*<@784>*/[]), false);
    checkBool(program, callFunction(program, "testAnotherNotEqual", /*<@784>*/[], /*<@784>*/[]), false);
    checkBool(program, callFunction(program, "testNotNotEqual", /*<@784>*/[], /*<@784>*/[]), true);
    checkInt(program, callFunction(program, "intWar", /*<@784>*/[], /*<@784>*/[]), 0);
    checkInt(program, callFunction(program, "intFamine", /*<@784>*/[], /*<@784>*/[]), 1);
    checkInt(program, callFunction(program, "intPestilence", /*<@784>*/[], /*<@784>*/[]), 2);
    checkInt(program, callFunction(program, "intDeath", /*<@784>*/[], /*<@784>*/[]), 3);
    checkInt(program, callFunction(program, "warValue", /*<@784>*/[], /*<@784>*/[]), 0);
    checkInt(program, callFunction(program, "famineValue", /*<@784>*/[], /*<@784>*/[]), 1);
    checkInt(program, callFunction(program, "pestilenceValue", /*<@784>*/[], /*<@784>*/[]), 2);
    checkInt(program, callFunction(program, "deathValue", /*<@784>*/[], /*<@784>*/[]), 3);
    checkInt(program, callFunction(program, "warValueLiteral", /*<@784>*/[], /*<@784>*/[]), 0);
    checkInt(program, callFunction(program, "famineValueLiteral", /*<@784>*/[], /*<@784>*/[]), 1);
    checkInt(program, callFunction(program, "pestilenceValueLiteral", /*<@784>*/[], /*<@784>*/[]), 2);
    checkInt(program, callFunction(program, "deathValueLiteral", /*<@784>*/[], /*<@784>*/[]), 3);
    checkEnum(program, callFunction(program, "intWarBackwards", /*<@784>*/[], /*<@784>*/[]), 0);
    checkEnum(program, callFunction(program, "intFamineBackwards", /*<@784>*/[], /*<@784>*/[]), 1);
    checkEnum(program, callFunction(program, "intPestilenceBackwards", /*<@784>*/[], /*<@784>*/[]), 2);
    checkEnum(program, callFunction(program, "intDeathBackwards", /*<@784>*/[], /*<@784>*/[]), 3);
};
tests.enumWithManualValues = function /*<@1878>*/() {
    let /*<@71>*/program = doPrep(`
        enum Foo {
            War = 72,
            Famine = 0,
            Pestilence = 23,
            Death = -42
        }
        Foo war()
        {
            return Foo.War;
        }
        Foo famine()
        {
            return Foo.Famine;
        }
        Foo pestilence()
        {
            return Foo.Pestilence;
        }
        Foo death()
        {
            return Foo.Death;
        }
    `);
    checkEnum(program, callFunction(program, "war", /*<@784>*/[], /*<@784>*/[]), 72);
    checkEnum(program, callFunction(program, "famine", /*<@784>*/[], /*<@784>*/[]), 0);
    checkEnum(program, callFunction(program, "pestilence", /*<@784>*/[], /*<@784>*/[]), 23);
    checkEnum(program, callFunction(program, "death", /*<@784>*/[], /*<@784>*/[]), -42);
};
tests.enumWithoutZero = function /*<@1879>*/() {
    checkFail(/*<@1880>*/() => doPrep(`
            enum Foo {
                War = 72,
                Famine = 64,
                Pestilence = 23,
                Death = -42
            }
        `), /*<@1881>*/e => e instanceof WTypeError);
};
tests.enumDuplicates = function /*<@1882>*/() {
    checkFail(/*<@1883>*/() => doPrep(`
            enum Foo {
                War = -42,
                Famine = 0,
                Pestilence = 23,
                Death = -42
            }
        `), /*<@1884>*/e => e instanceof WTypeError);
};
tests.enumWithSomeManualValues = function /*<@1885>*/() {
    let /*<@71>*/program = doPrep(`
        enum Foo {
            War = 72,
            Famine,
            Pestilence = 0,
            Death
        }
        Foo war()
        {
            return Foo.War;
        }
        Foo famine()
        {
            return Foo.Famine;
        }
        Foo pestilence()
        {
            return Foo.Pestilence;
        }
        Foo death()
        {
            return Foo.Death;
        }
    `);
    checkEnum(program, callFunction(program, "war", /*<@784>*/[], /*<@784>*/[]), 72);
    checkEnum(program, callFunction(program, "famine", /*<@784>*/[], /*<@784>*/[]), 73);
    checkEnum(program, callFunction(program, "pestilence", /*<@784>*/[], /*<@784>*/[]), 0);
    checkEnum(program, callFunction(program, "death", /*<@784>*/[], /*<@784>*/[]), 1);
};
tests.enumConstexprGenericFunction = function /*<@1886>*/() {
    let /*<@71>*/program = doPrep(`
        enum Axis { X, Y }
        int foo<Axis axis>() { return int(axis); }
        int testX() { return foo<Axis.X>(); }
        int testY() { return foo<Axis.Y>(); }
    `);
    checkInt(program, callFunction(program, "testX", /*<@784>*/[], /*<@784>*/[]), 0);
    checkInt(program, callFunction(program, "testY", /*<@784>*/[], /*<@784>*/[]), 1);
};
tests.enumConstexprGenericStruct = function /*<@1887>*/() {
    let /*<@71>*/program = doPrep(`
        enum Axis { X, Y }
        struct Foo<Axis axis> { }
        int foo<Axis axis>(Foo<axis>) { return int(axis); }
        int testX()
        {
            Foo<Axis.X> f;
            return foo(f);
        }
        int testY()
        {
            Foo<Axis.Y> f;
            return foo(f);
        }
    `);
    checkInt(program, callFunction(program, "testX", /*<@784>*/[], /*<@784>*/[]), 0);
    checkInt(program, callFunction(program, "testY", /*<@784>*/[], /*<@784>*/[]), 1);
};
tests.trap = function /*<@1888>*/() {
    let /*<@71>*/program = doPrep(`
        int foo()
        {
            trap;
        }
        int foo2(int x)
        {
            if (x == 3)
                trap;
            return 4;
        }
        struct Bar {
            int3 x;
            float y;
        }
        Bar foo3()
        {
            trap;
        }
    `);
    checkFail(/*<@1889>*/() => callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), /*<@1890>*/e => e instanceof WTrapError);
    checkInt(program, callFunction(program, "foo2", /*<@784>*/[], /*<@852>*/[makeInt(program, 1)]), 4);
    checkFail(/*<@1891>*/() => callFunction(program, "foo2", /*<@784>*/[], /*<@852>*/[makeInt(program, 3)]), /*<@1892>*/e => e instanceof WTrapError);
    checkFail(/*<@1893>*/() => callFunction(program, "foo3", /*<@784>*/[], /*<@784>*/[]), /*<@1894>*/e => e instanceof WTrapError);
};
tests.swizzle = function /*<@1895>*/() {
    let /*<@71>*/program = doPrep(`
        float foo() {
            float4 bar = float4(3., 4., 5., 6.);
            float3 baz = bar.zzx;
            return baz.z;
        }
        float foo2() {
            float4 bar = float4(3., 4., 5., 6.);
            float3 baz = bar.wyz;
            return baz.x;
        }
        float foo3() {
            float3 bar = float3(3., 4., 5.);
            float2 baz = bar.yz;
            float4 quix = baz.yyxx;
            return quix.z;
        }
    `);
    checkFloat(program, callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), 3);
    checkFloat(program, callFunction(program, "foo2", /*<@784>*/[], /*<@784>*/[]), 6);
    checkFloat(program, callFunction(program, "foo3", /*<@784>*/[], /*<@784>*/[]), 4);
};
tests.enumWithExplicitIntBase = function /*<@1896>*/() {
    let /*<@71>*/program = doPrep(`
        enum Foo : int {
            War,
            Famine,
            Pestilence,
            Death
        }
        Foo war()
        {
            return Foo.War;
        }
        Foo famine()
        {
            return Foo.Famine;
        }
        Foo pestilence()
        {
            return Foo.Pestilence;
        }
        Foo death()
        {
            return Foo.Death;
        }
        bool equals(Foo a, Foo b)
        {
            return a == b;
        }
        bool notEquals(Foo a, Foo b)
        {
            return a != b;
        }
        bool testSimpleEqual()
        {
            return equals(Foo.War, Foo.War);
        }
        bool testAnotherEqual()
        {
            return equals(Foo.Pestilence, Foo.Pestilence);
        }
        bool testNotEqual()
        {
            return equals(Foo.Famine, Foo.Death);
        }
        bool testSimpleNotEqual()
        {
            return notEquals(Foo.War, Foo.War);
        }
        bool testAnotherNotEqual()
        {
            return notEquals(Foo.Pestilence, Foo.Pestilence);
        }
        bool testNotNotEqual()
        {
            return notEquals(Foo.Famine, Foo.Death);
        }
        int intWar()
        {
            return int(war());
        }
        int intFamine()
        {
            return int(famine());
        }
        int intPestilence()
        {
            return int(pestilence());
        }
        int intDeath()
        {
            return int(death());
        }
        int warValue()
        {
            return war().value;
        }
        int famineValue()
        {
            return famine().value;
        }
        int pestilenceValue()
        {
            return pestilence().value;
        }
        int deathValue()
        {
            return death().value;
        }
        int warValueLiteral()
        {
            return Foo.War.value;
        }
        int famineValueLiteral()
        {
            return Foo.Famine.value;
        }
        int pestilenceValueLiteral()
        {
            return Foo.Pestilence.value;
        }
        int deathValueLiteral()
        {
            return Foo.Death.value;
        }
        Foo intWarBackwards()
        {
            return Foo(intWar());
        }
        Foo intFamineBackwards()
        {
            return Foo(intFamine());
        }
        Foo intPestilenceBackwards()
        {
            return Foo(intPestilence());
        }
        Foo intDeathBackwards()
        {
            return Foo(intDeath());
        }
    `);
    checkEnum(program, callFunction(program, "war", /*<@784>*/[], /*<@784>*/[]), 0);
    checkEnum(program, callFunction(program, "famine", /*<@784>*/[], /*<@784>*/[]), 1);
    checkEnum(program, callFunction(program, "pestilence", /*<@784>*/[], /*<@784>*/[]), 2);
    checkEnum(program, callFunction(program, "death", /*<@784>*/[], /*<@784>*/[]), 3);
    checkBool(program, callFunction(program, "testSimpleEqual", /*<@784>*/[], /*<@784>*/[]), true);
    checkBool(program, callFunction(program, "testAnotherEqual", /*<@784>*/[], /*<@784>*/[]), true);
    checkBool(program, callFunction(program, "testNotEqual", /*<@784>*/[], /*<@784>*/[]), false);
    checkBool(program, callFunction(program, "testSimpleNotEqual", /*<@784>*/[], /*<@784>*/[]), false);
    checkBool(program, callFunction(program, "testAnotherNotEqual", /*<@784>*/[], /*<@784>*/[]), false);
    checkBool(program, callFunction(program, "testNotNotEqual", /*<@784>*/[], /*<@784>*/[]), true);
    checkInt(program, callFunction(program, "intWar", /*<@784>*/[], /*<@784>*/[]), 0);
    checkInt(program, callFunction(program, "intFamine", /*<@784>*/[], /*<@784>*/[]), 1);
    checkInt(program, callFunction(program, "intPestilence", /*<@784>*/[], /*<@784>*/[]), 2);
    checkInt(program, callFunction(program, "intDeath", /*<@784>*/[], /*<@784>*/[]), 3);
    checkInt(program, callFunction(program, "warValue", /*<@784>*/[], /*<@784>*/[]), 0);
    checkInt(program, callFunction(program, "famineValue", /*<@784>*/[], /*<@784>*/[]), 1);
    checkInt(program, callFunction(program, "pestilenceValue", /*<@784>*/[], /*<@784>*/[]), 2);
    checkInt(program, callFunction(program, "deathValue", /*<@784>*/[], /*<@784>*/[]), 3);
    checkInt(program, callFunction(program, "warValueLiteral", /*<@784>*/[], /*<@784>*/[]), 0);
    checkInt(program, callFunction(program, "famineValueLiteral", /*<@784>*/[], /*<@784>*/[]), 1);
    checkInt(program, callFunction(program, "pestilenceValueLiteral", /*<@784>*/[], /*<@784>*/[]), 2);
    checkInt(program, callFunction(program, "deathValueLiteral", /*<@784>*/[], /*<@784>*/[]), 3);
    checkEnum(program, callFunction(program, "intWarBackwards", /*<@784>*/[], /*<@784>*/[]), 0);
    checkEnum(program, callFunction(program, "intFamineBackwards", /*<@784>*/[], /*<@784>*/[]), 1);
    checkEnum(program, callFunction(program, "intPestilenceBackwards", /*<@784>*/[], /*<@784>*/[]), 2);
    checkEnum(program, callFunction(program, "intDeathBackwards", /*<@784>*/[], /*<@784>*/[]), 3);
};
tests.enumWithUintBase = function /*<@1897>*/() {
    let /*<@71>*/program = doPrep(`
        enum Foo : uint {
            War,
            Famine,
            Pestilence,
            Death
        }
        Foo war()
        {
            return Foo.War;
        }
        Foo famine()
        {
            return Foo.Famine;
        }
        Foo pestilence()
        {
            return Foo.Pestilence;
        }
        Foo death()
        {
            return Foo.Death;
        }
        bool equals(Foo a, Foo b)
        {
            return a == b;
        }
        bool notEquals(Foo a, Foo b)
        {
            return a != b;
        }
        bool testSimpleEqual()
        {
            return equals(Foo.War, Foo.War);
        }
        bool testAnotherEqual()
        {
            return equals(Foo.Pestilence, Foo.Pestilence);
        }
        bool testNotEqual()
        {
            return equals(Foo.Famine, Foo.Death);
        }
        bool testSimpleNotEqual()
        {
            return notEquals(Foo.War, Foo.War);
        }
        bool testAnotherNotEqual()
        {
            return notEquals(Foo.Pestilence, Foo.Pestilence);
        }
        bool testNotNotEqual()
        {
            return notEquals(Foo.Famine, Foo.Death);
        }
        uint uintWar()
        {
            return uint(war());
        }
        uint uintFamine()
        {
            return uint(famine());
        }
        uint uintPestilence()
        {
            return uint(pestilence());
        }
        uint uintDeath()
        {
            return uint(death());
        }
        uint warValue()
        {
            return war().value;
        }
        uint famineValue()
        {
            return famine().value;
        }
        uint pestilenceValue()
        {
            return pestilence().value;
        }
        uint deathValue()
        {
            return death().value;
        }
        uint warValueLiteral()
        {
            return Foo.War.value;
        }
        uint famineValueLiteral()
        {
            return Foo.Famine.value;
        }
        uint pestilenceValueLiteral()
        {
            return Foo.Pestilence.value;
        }
        uint deathValueLiteral()
        {
            return Foo.Death.value;
        }
        Foo uintWarBackwards()
        {
            return Foo(uintWar());
        }
        Foo uintFamineBackwards()
        {
            return Foo(uintFamine());
        }
        Foo uintPestilenceBackwards()
        {
            return Foo(uintPestilence());
        }
        Foo uintDeathBackwards()
        {
            return Foo(uintDeath());
        }
    `);
    checkEnum(program, callFunction(program, "war", /*<@784>*/[], /*<@784>*/[]), 0);
    checkEnum(program, callFunction(program, "famine", /*<@784>*/[], /*<@784>*/[]), 1);
    checkEnum(program, callFunction(program, "pestilence", /*<@784>*/[], /*<@784>*/[]), 2);
    checkEnum(program, callFunction(program, "death", /*<@784>*/[], /*<@784>*/[]), 3);
    checkBool(program, callFunction(program, "testSimpleEqual", /*<@784>*/[], /*<@784>*/[]), true);
    checkBool(program, callFunction(program, "testAnotherEqual", /*<@784>*/[], /*<@784>*/[]), true);
    checkBool(program, callFunction(program, "testNotEqual", /*<@784>*/[], /*<@784>*/[]), false);
    checkBool(program, callFunction(program, "testSimpleNotEqual", /*<@784>*/[], /*<@784>*/[]), false);
    checkBool(program, callFunction(program, "testAnotherNotEqual", /*<@784>*/[], /*<@784>*/[]), false);
    checkBool(program, callFunction(program, "testNotNotEqual", /*<@784>*/[], /*<@784>*/[]), true);
    checkUint(program, callFunction(program, "uintWar", /*<@784>*/[], /*<@784>*/[]), 0);
    checkUint(program, callFunction(program, "uintFamine", /*<@784>*/[], /*<@784>*/[]), 1);
    checkUint(program, callFunction(program, "uintPestilence", /*<@784>*/[], /*<@784>*/[]), 2);
    checkUint(program, callFunction(program, "uintDeath", /*<@784>*/[], /*<@784>*/[]), 3);
    checkUint(program, callFunction(program, "warValue", /*<@784>*/[], /*<@784>*/[]), 0);
    checkUint(program, callFunction(program, "famineValue", /*<@784>*/[], /*<@784>*/[]), 1);
    checkUint(program, callFunction(program, "pestilenceValue", /*<@784>*/[], /*<@784>*/[]), 2);
    checkUint(program, callFunction(program, "deathValue", /*<@784>*/[], /*<@784>*/[]), 3);
    checkUint(program, callFunction(program, "warValueLiteral", /*<@784>*/[], /*<@784>*/[]), 0);
    checkUint(program, callFunction(program, "famineValueLiteral", /*<@784>*/[], /*<@784>*/[]), 1);
    checkUint(program, callFunction(program, "pestilenceValueLiteral", /*<@784>*/[], /*<@784>*/[]), 2);
    checkUint(program, callFunction(program, "deathValueLiteral", /*<@784>*/[], /*<@784>*/[]), 3);
    checkEnum(program, callFunction(program, "uintWarBackwards", /*<@784>*/[], /*<@784>*/[]), 0);
    checkEnum(program, callFunction(program, "uintFamineBackwards", /*<@784>*/[], /*<@784>*/[]), 1);
    checkEnum(program, callFunction(program, "uintPestilenceBackwards", /*<@784>*/[], /*<@784>*/[]), 2);
    checkEnum(program, callFunction(program, "uintDeathBackwards", /*<@784>*/[], /*<@784>*/[]), 3);
};
tests.enumFloatBase = function /*<@1898>*/() {
    checkFail(/*<@1899>*/() => doPrep(`
            enum Foo : float {
                Bar
            }
        `), /*<@1900>*/e => e instanceof WTypeError);
};
tests.enumPtrBase = function /*<@1901>*/() {
    checkFail(/*<@1902>*/() => doPrep(`
            enum Foo : thread int* {
                Bar
            }
        `), /*<@1903>*/e => e instanceof WTypeError);
};
tests.enumArrayRefBase = function /*<@1904>*/() {
    checkFail(/*<@1905>*/() => doPrep(`
            enum Foo : thread int[] {
                Bar
            }
        `), /*<@1906>*/e => e instanceof WTypeError);
};
tests.emptyStruct = function /*<@1907>*/() {
    let /*<@71>*/program = doPrep(`
        struct Thingy { }
        int foo()
        {
            Thingy thingy;
            return 46;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), 46);
};
tests.enumStructBase = function /*<@1908>*/() {
    checkFail(/*<@1909>*/() => doPrep(`
            struct Thingy { }
            enum Foo : Thingy {
                Bar
            }
        `), /*<@1910>*/e => e instanceof WTypeError);
};
tests.enumNoMembers = function /*<@1911>*/() {
    checkFail(/*<@1912>*/() => doPrep(`
            enum Foo { }
        `), /*<@1913>*/e => e instanceof WTypeError);
};
tests.simpleSwitch = function /*<@1914>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(int x)
        {
            switch (x) {
            case 767:
                return 27;
            case 69:
                return 7624;
            default:
                return 49;
            }
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 767)]), 27);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 69)]), 7624);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 0)]), 49);
};
tests.exhaustiveUint8Switch = function /*<@1915>*/() {
    let /*<@3>*/text = "double foo(uint8 x) { switch (uint8(x)) {";
    for (let /*<@5>*/i = 0; i <= 0xff; ++i)
        text += "case " + i + ": return " + i * 1.5 + ";";
    text += "} }";
    let /*<@71>*/program = doPrep(text);
    for (let /*<@5>*/i = 0; i < 0xff; ++i)
        checkDouble(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint8(program, i)]), i * 1.5);
};
tests.notQuiteExhaustiveUint8Switch = function /*<@1916>*/() {
    let /*<@3>*/text = "double foo(uint8 x) { switch (uint8(x)) {";
    for (let /*<@5>*/i = 0; i <= 0xfe; ++i)
        text += "case " + i + ": return " + i * 1.5 + ";";
    text += "} }";
    checkFail(/*<@1917>*/() => doPrep(text), /*<@1918>*/e => e instanceof WTypeError);
};
tests.notQuiteExhaustiveUint8SwitchWithDefault = function /*<@1919>*/() {
    let /*<@3>*/text = "double foo(uint8 x) { switch (uint8(x)) {";
    for (let /*<@5>*/i = 0; i <= 0xfe; ++i)
        text += "case " + i + ": return " + i * 1.5 + ";";
    text += "default: return " + 0xff * 1.5 + ";";
    text += "} }";
    let /*<@71>*/program = doPrep(text);
    for (let /*<@5>*/i = 0; i < 0xff; ++i)
        checkDouble(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeUint8(program, i)]), i * 1.5);
};
tests.switchFallThrough = function /*<@1920>*/() {
    // FIXME: This might become an error in future versions.
    // https://bugs.webkit.org/show_bug.cgi?id=177172
    let /*<@71>*/program = doPrep(`
        int foo(int x)
        {
            int result = 0;
            switch (x) {
            case 767:
                result += 27;
            case 69:
                result += 7624;
            default:
                result += 49;
            }
            return result;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 767)]), 27 + 7624 + 49);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 69)]), 7624 + 49);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 0)]), 49);
};
tests.switchBreak = function /*<@1921>*/() {
    let /*<@71>*/program = doPrep(`
        int foo(int x)
        {
            int result = 0;
            switch (x) {
            case 767:
                result += 27;
                break;
            case 69:
                result += 7624;
                break;
            default:
                result += 49;
                break;
            }
            return result;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 767)]), 27);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 69)]), 7624);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeInt(program, 0)]), 49);
};
tests.enumSwitchBreakExhaustive = function /*<@1922>*/() {
    let /*<@71>*/program = doPrep(`
        enum Foo {
            A, B, C
        }
        int foo(Foo x)
        {
            int result = 0;
            switch (x) {
            case Foo.A:
                result += 27;
                break;
            case Foo.B:
                result += 7624;
                break;
            case Foo.C:
                result += 49;
                break;
            }
            return result;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeEnum(program, "Foo", "A")]), 27);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeEnum(program, "Foo", "B")]), 7624);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeEnum(program, "Foo", "C")]), 49);
};
tests.enumSwitchBreakNotQuiteExhaustive = function /*<@1923>*/() {
    checkFail(/*<@1924>*/() => doPrep(`
            enum Foo {
                A, B, C, D
            }
            int foo(Foo x)
            {
                int result = 0;
                switch (x) {
                case Foo.A:
                    result += 27;
                    break;
                case Foo.B:
                    result += 7624;
                    break;
                case Foo.C:
                    result += 49;
                    break;
                }
                return result;
            }
        `), /*<@1925>*/e => e instanceof WTypeError);
};
tests.enumSwitchBreakNotQuiteExhaustiveWithDefault = function /*<@1926>*/() {
    let /*<@71>*/program = doPrep(`
        enum Foo {
            A, B, C
        }
        int foo(Foo x)
        {
            int result = 0;
            switch (x) {
            case Foo.A:
                result += 27;
                break;
            case Foo.B:
                result += 7624;
                break;
            default:
                result += 49;
                break;
            }
            return result;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeEnum(program, "Foo", "A")]), 27);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeEnum(program, "Foo", "B")]), 7624);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@852>*/[makeEnum(program, "Foo", "C")]), 49);
};
tests.simpleRecursiveStruct = function /*<@1927>*/() {
    checkFail(/*<@1928>*/() => doPrep(`
            struct Foo {
                Foo foo;
            }
        `), /*<@1929>*/e => e instanceof WTypeError);
};
tests.mutuallyRecursiveStruct = function /*<@1930>*/() {
    checkFail(/*<@1931>*/() => doPrep(`
            struct Foo {
                Bar bar;
            }
            struct Bar {
                Foo foo;
            }
        `), /*<@1932>*/e => e instanceof WTypeError);
};
tests.mutuallyRecursiveStructWithPointersBroken = function /*<@1933>*/() {
    let /*<@71>*/program = doPrep(`
        struct Foo {
            thread Bar* bar;
            int foo;
        }
        struct Bar {
            thread Foo* foo;
            int bar;
        }
        int foo()
        {
            Foo foo;
            Bar bar;
            foo.foo = 564;
            bar.bar = 53;
            return foo.bar->bar - bar.foo->foo;
        }
    `);
    checkFail(/*<@1934>*/() => checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), -511), /*<@1935>*/e => e instanceof WTrapError);
};
tests.mutuallyRecursiveStructWithPointers = function /*<@1936>*/() {
    let /*<@71>*/program = doPrep(`
        struct Foo {
            thread Bar* bar;
            int foo;
        }
        struct Bar {
            thread Foo* foo;
            int bar;
        }
        int foo()
        {
            Foo foo;
            Bar bar;
            foo.bar = &bar;
            bar.foo = &foo;
            foo.foo = 564;
            bar.bar = 53;
            return foo.bar->bar - bar.foo->foo;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), -511);
};
tests.linkedList = function /*<@1937>*/() {
    let /*<@71>*/program = doPrep(`
        struct Node {
            thread Node* next;
            int value;
        }
        int foo()
        {
            Node x, y, z;
            x.next = &y;
            y.next = &z;
            x.value = 1;
            y.value = 2;
            z.value = 3;
            return x.next->next->value;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), 3);
};
tests.pointerToPointer = function /*<@1938>*/() {
    let /*<@71>*/program = doPrep(`
        int foo()
        {
            int x;
            thread int* p = &x;
            thread int** pp = &p;
            int*thread*thread qq = pp;
            int result = 0;
            x = 42;
            *p = 76;
            result += x;
            **pp = 39;
            result += x;
            **qq = 83;
            result += x;
            return result;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), 76 + 39 + 83);
};
tests.arrayRefToArrayRef = function /*<@1939>*/() {
    let /*<@71>*/program = doPrep(`
        int foo()
        {
            int x;
            thread int[] p = @x;
            thread int[][] pp = @p;
            int[]thread[]thread qq = pp;
            int result = 0;
            x = 42;
            p[0] = 76;
            result += x;
            pp[0][0] = 39;
            result += x;
            qq[0][0] = 83;
            result += x;
            return result;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), 76 + 39 + 83);
};
tests.pointerGetter = function /*<@1940>*/() {
    checkFail(/*<@1941>*/() => doPrep(`
            int operator.foo(device int*)
            {
                return 543;
            }
        `), /*<@1942>*/e => e instanceof WTypeError);
    checkFail(/*<@1943>*/() => doPrep(`
            int operator.foo(thread int*)
            {
                return 543;
            }
        `), /*<@1944>*/e => e instanceof WTypeError);
    checkFail(/*<@1945>*/() => doPrep(`
            int operator.foo(threadgroup int*)
            {
                return 543;
            }
        `), /*<@1946>*/e => e instanceof WTypeError);
    checkFail(/*<@1947>*/() => doPrep(`
            int operator.foo(constant int*)
            {
                return 543;
            }
        `), /*<@1948>*/e => e instanceof WTypeError);
};
tests.loneSetter = function /*<@1949>*/() {
    checkFail(/*<@1950>*/() => doPrep(`
            int operator.foo=(int, int)
            {
                return 543;
            }
        `), /*<@1951>*/e => e instanceof WTypeError);
};
tests.setterWithMismatchedType = function /*<@1952>*/() {
    checkFail(/*<@1953>*/() => doPrep(`
            double operator.foo(int)
            {
                return 5.43;
            }
            int operator.foo=(int, int)
            {
                return 543;
            }
        `), /*<@1954>*/e => e instanceof WTypeError);
};
tests.setterWithMatchedType = function /*<@1955>*/() {
    doPrep(`
        int operator.foo(int)
        {
            return 5;
        }
        int operator.foo=(int, int)
        {
            return 543;
        }
    `);
};
tests.operatorWithUninferrableTypeVariable = function /*<@1956>*/() {
    checkFail(/*<@1957>*/() => doPrep(`
            struct Foo {
                int x;
            }
            Foo operator+<T>(Foo a, Foo b)
            {
                Foo result;
                result.x = a.x + b.x;
                return result;
            }
        `), /*<@1958>*/e => e instanceof WTypeError);
};
tests.operatorWithoutUninferrableTypeVariable = function /*<@1959>*/() {
    let /*<@71>*/program = doPrep(`
        struct Foo {
            int x;
        }
        Foo operator+(Foo a, Foo b)
        {
            Foo result;
            result.x = a.x + b.x;
            return result;
        }
        int foo()
        {
            Foo a;
            a.x = 645;
            Foo b;
            b.x = -35;
            return (a + b).x;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), 645 - 35);
};
tests.operatorCastWithUninferrableTypeVariable = function /*<@1960>*/() {
    checkFail(/*<@1961>*/() => doPrep(`
            struct Foo {
                int x;
            }
            operator<T> Foo(int x)
            {
                Foo result;
                result.x = x;
                return result;
            }
        `), /*<@1962>*/e => e instanceof WTypeError);
};
tests.operatorCastWithTypeVariableInferredFromReturnType = function /*<@1963>*/() {
    let /*<@71>*/program = doPrep(`
        struct Foo {
            int x;
        }
        protocol Barable {
            void bar(thread Barable*, int);
        }
        void bar(thread double* result, int value)
        {
            *result = double(value);
        }
        operator<T:Barable> T(Foo foo)
        {
            T result;
            bar(&result, foo.x);
            return result;
        }
        int foo()
        {
            Foo foo;
            foo.x = 75;
            double x = double(foo);
            return int(x * 1.5);
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), 112);
};
tests.incWrongArgumentLength = function /*<@1964>*/() {
    checkFail(/*<@1965>*/() => doPrep(`
            int operator++() { return 32; }
        `), /*<@1966>*/e => e instanceof WTypeError);
    checkFail(/*<@1967>*/() => doPrep(`
            int operator++(int, int) { return 76; }
        `), /*<@1968>*/e => e instanceof WTypeError);
};
tests.decWrongArgumentLength = function /*<@1969>*/() {
    checkFail(/*<@1970>*/() => doPrep(`
            int operator--() { return 32; }
        `), /*<@1971>*/e => e instanceof WTypeError);
    checkFail(/*<@1972>*/() => doPrep(`
            int operator--(int, int) { return 76; }
        `), /*<@1973>*/e => e instanceof WTypeError);
};
tests.incWrongTypes = function /*<@1974>*/() {
    checkFail(/*<@1975>*/() => doPrep(`
            int operator++(double) { return 32; }
        `), /*<@1976>*/e => e instanceof WTypeError);
};
tests.decWrongTypes = function /*<@1977>*/() {
    checkFail(/*<@1978>*/() => doPrep(`
            int operator--(double) { return 32; }
        `), /*<@1979>*/e => e instanceof WTypeError);
};
tests.plusWrongArgumentLength = function /*<@1980>*/() {
    checkFail(/*<@1981>*/() => doPrep(`
            int operator+() { return 32; }
        `), /*<@1982>*/e => e instanceof WTypeError);
    checkFail(/*<@1983>*/() => doPrep(`
            int operator+(int, int, int) { return 76; }
        `), /*<@1984>*/e => e instanceof WTypeError);
};
tests.minusWrongArgumentLength = function /*<@1985>*/() {
    checkFail(/*<@1986>*/() => doPrep(`
            int operator-() { return 32; }
        `), /*<@1987>*/e => e instanceof WTypeError);
    checkFail(/*<@1988>*/() => doPrep(`
            int operator-(int, int, int) { return 76; }
        `), /*<@1989>*/e => e instanceof WTypeError);
};
tests.timesWrongArgumentLength = function /*<@1990>*/() {
    checkFail(/*<@1991>*/() => doPrep(`
            int operator*() { return 32; }
        `), /*<@1992>*/e => e instanceof WTypeError);
    checkFail(/*<@1993>*/() => doPrep(`
            int operator*(int) { return 534; }
        `), /*<@1994>*/e => e instanceof WTypeError);
    checkFail(/*<@1995>*/() => doPrep(`
            int operator*(int, int, int) { return 76; }
        `), /*<@1996>*/e => e instanceof WTypeError);
};
tests.divideWrongArgumentLength = function /*<@1997>*/() {
    checkFail(/*<@1998>*/() => doPrep(`
            int operator/() { return 32; }
        `), /*<@1999>*/e => e instanceof WTypeError);
    checkFail(/*<@2000>*/() => doPrep(`
            int operator/(int) { return 534; }
        `), /*<@2001>*/e => e instanceof WTypeError);
    checkFail(/*<@2002>*/() => doPrep(`
            int operator/(int, int, int) { return 76; }
        `), /*<@2003>*/e => e instanceof WTypeError);
};
tests.moduloWrongArgumentLength = function /*<@2004>*/() {
    checkFail(/*<@2005>*/() => doPrep(`
            int operator%() { return 32; }
        `), /*<@2006>*/e => e instanceof WTypeError);
    checkFail(/*<@2007>*/() => doPrep(`
            int operator%(int) { return 534; }
        `), /*<@2008>*/e => e instanceof WTypeError);
    checkFail(/*<@2009>*/() => doPrep(`
            int operator%(int, int, int) { return 76; }
        `), /*<@2010>*/e => e instanceof WTypeError);
};
tests.bitAndWrongArgumentLength = function /*<@2011>*/() {
    checkFail(/*<@2012>*/() => doPrep(`
            int operator&() { return 32; }
        `), /*<@2013>*/e => e instanceof WTypeError);
    checkFail(/*<@2014>*/() => doPrep(`
            int operator&(int) { return 534; }
        `), /*<@2015>*/e => e instanceof WTypeError);
    checkFail(/*<@2016>*/() => doPrep(`
            int operator&(int, int, int) { return 76; }
        `), /*<@2017>*/e => e instanceof WTypeError);
};
tests.bitOrWrongArgumentLength = function /*<@2018>*/() {
    checkFail(/*<@2019>*/() => doPrep(`
            int operator|() { return 32; }
        `), /*<@2020>*/e => e instanceof WTypeError);
    checkFail(/*<@2021>*/() => doPrep(`
            int operator|(int) { return 534; }
        `), /*<@2022>*/e => e instanceof WTypeError);
    checkFail(/*<@2023>*/() => doPrep(`
            int operator|(int, int, int) { return 76; }
        `), /*<@2024>*/e => e instanceof WTypeError);
};
tests.bitXorWrongArgumentLength = function /*<@2025>*/() {
    checkFail(/*<@2026>*/() => doPrep(`
            int operator^() { return 32; }
        `), /*<@2027>*/e => e instanceof WTypeError);
    checkFail(/*<@2028>*/() => doPrep(`
            int operator^(int) { return 534; }
        `), /*<@2029>*/e => e instanceof WTypeError);
    checkFail(/*<@2030>*/() => doPrep(`
            int operator^(int, int, int) { return 76; }
        `), /*<@2031>*/e => e instanceof WTypeError);
};
tests.lShiftWrongArgumentLength = function /*<@2032>*/() {
    checkFail(/*<@2033>*/() => doPrep(`
            int operator<<() { return 32; }
        `), /*<@2034>*/e => e instanceof WTypeError);
    checkFail(/*<@2035>*/() => doPrep(`
            int operator<<(int) { return 534; }
        `), /*<@2036>*/e => e instanceof WTypeError);
    checkFail(/*<@2037>*/() => doPrep(`
            int operator<<(int, int, int) { return 76; }
        `), /*<@2038>*/e => e instanceof WTypeError);
};
tests.rShiftWrongArgumentLength = function /*<@2039>*/() {
    checkFail(/*<@2040>*/() => doPrep(`
            int operator>>() { return 32; }
        `), /*<@2041>*/e => e instanceof WTypeError);
    checkFail(/*<@2042>*/() => doPrep(`
            int operator>>(int) { return 534; }
        `), /*<@2043>*/e => e instanceof WTypeError);
    checkFail(/*<@2044>*/() => doPrep(`
            int operator>>(int, int, int) { return 76; }
        `), /*<@2045>*/e => e instanceof WTypeError);
};
tests.bitNotWrongArgumentLength = function /*<@2046>*/() {
    checkFail(/*<@2047>*/() => doPrep(`
            int operator~() { return 32; }
        `), /*<@2048>*/e => e instanceof WTypeError);
    checkFail(/*<@2049>*/() => doPrep(`
            int operator~(int, int) { return 534; }
        `), /*<@2050>*/e => e instanceof WTypeError);
};
tests.equalsWrongArgumentLength = function /*<@2051>*/() {
    checkFail(/*<@2052>*/() => doPrep(`
            bool operator==() { return true; }
        `), /*<@2053>*/e => e instanceof WTypeError);
    checkFail(/*<@2054>*/() => doPrep(`
            bool operator==(int) { return true; }
        `), /*<@2055>*/e => e instanceof WTypeError);
    checkFail(/*<@2056>*/() => doPrep(`
            bool operator==(int, int, int) { return true; }
        `), /*<@2057>*/e => e instanceof WTypeError);
};
tests.lessThanWrongArgumentLength = function /*<@2058>*/() {
    checkFail(/*<@2059>*/() => doPrep(`
            bool operator<() { return true; }
        `), /*<@2060>*/e => e instanceof WTypeError);
    checkFail(/*<@2061>*/() => doPrep(`
            bool operator<(int) { return true; }
        `), /*<@2062>*/e => e instanceof WTypeError);
    checkFail(/*<@2063>*/() => doPrep(`
            bool operator<(int, int, int) { return true; }
        `), /*<@2064>*/e => e instanceof WTypeError);
};
tests.lessEqualWrongArgumentLength = function /*<@2065>*/() {
    checkFail(/*<@2066>*/() => doPrep(`
            bool operator<=() { return true; }
        `), /*<@2067>*/e => e instanceof WTypeError);
    checkFail(/*<@2068>*/() => doPrep(`
            bool operator<=(int) { return true; }
        `), /*<@2069>*/e => e instanceof WTypeError);
    checkFail(/*<@2070>*/() => doPrep(`
            bool operator<=(int, int, int) { return true; }
        `), /*<@2071>*/e => e instanceof WTypeError);
};
tests.greaterWrongArgumentLength = function /*<@2072>*/() {
    checkFail(/*<@2073>*/() => doPrep(`
            bool operator>() { return true; }
        `), /*<@2074>*/e => e instanceof WTypeError);
    checkFail(/*<@2075>*/() => doPrep(`
            bool operator>(int) { return true; }
        `), /*<@2076>*/e => e instanceof WTypeError);
    checkFail(/*<@2077>*/() => doPrep(`
            bool operator>(int, int, int) { return true; }
        `), /*<@2078>*/e => e instanceof WTypeError);
};
tests.greaterEqualWrongArgumentLength = function /*<@2079>*/() {
    checkFail(/*<@2080>*/() => doPrep(`
            bool operator>=() { return true; }
        `), /*<@2081>*/e => e instanceof WTypeError);
    checkFail(/*<@2082>*/() => doPrep(`
            bool operator>=(int) { return true; }
        `), /*<@2083>*/e => e instanceof WTypeError);
    checkFail(/*<@2084>*/() => doPrep(`
            bool operator>=(int, int, int) { return true; }
        `), /*<@2085>*/e => e instanceof WTypeError);
};
tests.equalsWrongReturnType = function /*<@2086>*/() {
    checkFail(/*<@2087>*/() => doPrep(`
            int operator==(int a, int b) { return a + b; }
        `), /*<@2088>*/e => e instanceof WTypeError);
};
tests.notEqualsOverload = function /*<@2089>*/() {
    checkFail(/*<@2090>*/() => doPrep(`
            struct Foo { }
            bool operator!=(Foo, Foo) { return true; }
        `), /*<@2091>*/e => e instanceof WSyntaxError);
};
tests.lessThanWrongReturnType = function /*<@2092>*/() {
    checkFail(/*<@2093>*/() => doPrep(`
            int operator<(int a, int b) { return a + b; }
        `), /*<@2094>*/e => e instanceof WTypeError);
};
tests.lessEqualWrongReturnType = function /*<@2095>*/() {
    checkFail(/*<@2096>*/() => doPrep(`
            int operator<=(int a, int b) { return a + b; }
        `), /*<@2097>*/e => e instanceof WTypeError);
};
tests.greaterThanWrongReturnType = function /*<@2098>*/() {
    checkFail(/*<@2099>*/() => doPrep(`
            int operator>(int a, int b) { return a + b; }
        `), /*<@2100>*/e => e instanceof WTypeError);
};
tests.greaterEqualWrongReturnType = function /*<@2101>*/() {
    checkFail(/*<@2102>*/() => doPrep(`
            int operator>=(int a, int b) { return a + b; }
        `), /*<@2103>*/e => e instanceof WTypeError);
};
tests.dotOperatorWrongArgumentLength = function /*<@2104>*/() {
    checkFail(/*<@2105>*/() => doPrep(`
            int operator.foo() { return 42; }
        `), /*<@2106>*/e => e instanceof WTypeError);
    checkFail(/*<@2107>*/() => doPrep(`
            struct Foo { }
            int operator.foo(Foo, int) { return 42; }
        `), /*<@2108>*/e => e instanceof WTypeError);
};
tests.dotOperatorSetterWrongArgumentLength = function /*<@2109>*/() {
    checkFail(/*<@2110>*/() => doPrep(`
            struct Foo { }
            Foo operator.foo=() { return 42; }
        `), /*<@2111>*/e => e instanceof WTypeError);
    checkFail(/*<@2112>*/() => doPrep(`
            struct Foo { }
            Foo operator.foo=(Foo) { return 42; }
        `), /*<@2113>*/e => e instanceof WTypeError);
    checkFail(/*<@2114>*/() => doPrep(`
            struct Foo { }
            Foo operator.foo=(Foo, int, int) { return 42; }
        `), /*<@2115>*/e => e instanceof WTypeError);
};
tests.loneSetterPointer = function /*<@2116>*/() {
    checkFail(/*<@2117>*/() => doPrep(`
            thread int* operator.foo=(thread int* ptr, int)
            {
                return ptr;
            }
        `), /*<@2118>*/e => e instanceof WTypeError);
};
tests.setterWithNoGetterOverload = function /*<@2119>*/() {
    checkFail(/*<@2120>*/() => doPrep(`
            struct Foo { }
            struct Bar { }
            int operator.foo(Foo)
            {
                return 534;
            }
            Bar operator.foo=(Bar, int)
            {
                return Bar();
            }
        `), /*<@2121>*/e => e instanceof WTypeError);
};
tests.setterWithNoGetterOverloadFixed = function /*<@2122>*/() {
    doPrep(`
        struct Bar { }
        int operator.foo(Bar)
        {
            return 534;
        }
        Bar operator.foo=(Bar, int)
        {
            return Bar();
        }
    `);
};
tests.anderWithNothingWrong = function /*<@2123>*/() {
    let /*<@71>*/program = doPrep(`
        struct Foo {
            int x;
        }
        thread int* operator&.foo(thread Foo* foo)
        {
            return &foo->x;
        }
        int foo()
        {
            Foo x;
            x.x = 13;
            return x.foo;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), 13);
};
tests.anderWithWrongNumberOfArguments = function /*<@2124>*/() {
    checkFail(/*<@2125>*/() => doPrep(`
            thread int* operator&.foo()
            {
                int x;
                return &x;
            }
        `), /*<@2126>*/e => e instanceof WTypeError);
    checkFail(/*<@2127>*/() => doPrep(`
            struct Foo {
                int x;
            }
            thread int* operator&.foo(thread Foo* foo, int blah)
            {
                return &foo->x;
            }
        `), /*<@2128>*/e => e instanceof WTypeError);
};
tests.anderDoesntReturnPointer = function /*<@2129>*/() {
    checkFail(/*<@2130>*/() => doPrep(`
            struct Foo {
                int x;
            }
            int operator&.foo(thread Foo* foo)
            {
                return foo->x;
            }
        `), /*<@2131>*/e => e instanceof WTypeError);
};
tests.anderDoesntTakeReference = function /*<@2132>*/() {
    checkFail(/*<@2133>*/() => doPrep(`
            struct Foo {
                int x;
            }
            thread int* operator&.foo(Foo foo)
            {
                return &foo.x;
            }
        `), /*<@2134>*/e => e instanceof WTypeError);
};
tests.anderWithArrayRef = function /*<@2135>*/() {
    let /*<@71>*/program = doPrep(`
        struct Foo {
            int x;
        }
        thread int* operator&.foo(thread Foo[] foo)
        {
            return &foo[0].x;
        }
        int foo()
        {
            Foo x;
            x.x = 13;
            return (@x).foo;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), 13);
};
tests.pointerIndexGetter = function /*<@2136>*/() {
    checkFail(/*<@2137>*/() => doPrep(`
            int operator[](device int*, uint)
            {
                return 543;
            }
        `), /*<@2138>*/e => e instanceof WTypeError);
    checkFail(/*<@2139>*/() => doPrep(`
            int operator[](thread int*, uint)
            {
                return 543;
            }
        `), /*<@2140>*/e => e instanceof WTypeError);
    checkFail(/*<@2141>*/() => doPrep(`
            int operator[](threadgroup int*, uint)
            {
                return 543;
            }
        `), /*<@2142>*/e => e instanceof WTypeError);
    checkFail(/*<@2143>*/() => doPrep(`
            int operator[](constant int*, uint)
            {
                return 543;
            }
        `), /*<@2144>*/e => e instanceof WTypeError);
};
tests.loneIndexSetter = function /*<@2145>*/() {
    checkFail(/*<@2146>*/() => doPrep(`
            int operator[]=(int, uint, int)
            {
                return 543;
            }
        `), /*<@2147>*/e => e instanceof WTypeError);
};
tests.notLoneIndexSetter = function /*<@2148>*/() {
    doPrep(`
        int operator[](int, uint)
        {
            return 65;
        }
        int operator[]=(int, uint, int)
        {
            return 543;
        }
    `);
};
tests.indexSetterWithMismatchedType = function /*<@2149>*/() {
    checkFail(/*<@2150>*/() => doPrep(`
            double operator[](int, uint)
            {
                return 5.43;
            }
            int operator[]=(int, uint, int)
            {
                return 543;
            }
        `), /*<@2151>*/e => e instanceof WTypeError && e.message.indexOf("Setter and getter must agree on value type") != -1);
};
tests.indexOperatorWrongArgumentLength = function /*<@2152>*/() {
    checkFail(/*<@2153>*/() => doPrep(`
            int operator[]() { return 42; }
        `), /*<@2154>*/e => e instanceof WTypeError);
    checkFail(/*<@2155>*/() => doPrep(`
            int operator[](int) { return 42; }
        `), /*<@2156>*/e => e instanceof WTypeError);
    checkFail(/*<@2157>*/() => doPrep(`
            int operator[](int, int, int) { return 42; }
        `), /*<@2158>*/e => e instanceof WTypeError);
};
tests.indexOperatorSetterWrongArgumentLength = function /*<@2159>*/() {
    checkFail(/*<@2160>*/() => doPrep(`
            int operator[]=() { return 42; }
        `), /*<@2161>*/e => e instanceof WTypeError);
    checkFail(/*<@2162>*/() => doPrep(`
            int operator[]=(int) { return 42; }
        `), /*<@2163>*/e => e instanceof WTypeError);
    checkFail(/*<@2164>*/() => doPrep(`
            int operator[]=(int, int) { return 42; }
        `), /*<@2165>*/e => e instanceof WTypeError);
    checkFail(/*<@2166>*/() => doPrep(`
            int operator[]=(int, int, int, int) { return 42; }
        `), /*<@2167>*/e => e instanceof WTypeError);
};
tests.loneIndexSetterPointer = function /*<@2168>*/() {
    checkFail(/*<@2169>*/() => doPrep(`
            thread int* operator[]=(thread int* ptr, uint, int)
            {
                return ptr;
            }
        `), /*<@2170>*/e => e instanceof WTypeError);
};
tests.indexSetterWithNoGetterOverload = function /*<@2171>*/() {
    checkFail(/*<@2172>*/() => doPrep(`
            struct Foo { }
            struct Bar { }
            int operator[](Foo, uint)
            {
                return 534;
            }
            Bar operator[]=(Bar, uint, int)
            {
                return Bar();
            }
        `), /*<@2173>*/e => e instanceof WTypeError);
};
tests.indexSetterWithNoGetterOverloadFixed = function /*<@2174>*/() {
    doPrep(`
        struct Bar { }
        int operator[](Bar, uint)
        {
            return 534;
        }
        Bar operator[]=(Bar, uint, int)
        {
            return Bar();
        }
    `);
};
tests.indexAnderWithNothingWrong = function /*<@2175>*/() {
    let /*<@71>*/program = doPrep(`
        struct Foo {
            int x;
        }
        thread int* operator&[](thread Foo* foo, uint)
        {
            return &foo->x;
        }
        int foo()
        {
            Foo x;
            x.x = 13;
            return x[666];
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), 13);
};
tests.indexAnderWithWrongNumberOfArguments = function /*<@2176>*/() {
    checkFail(/*<@2177>*/() => doPrep(`
            thread int* operator&[]()
            {
                int x;
                return &x;
            }
        `), /*<@2178>*/e => e instanceof WTypeError);
    checkFail(/*<@2179>*/() => doPrep(`
            struct Foo {
                int x;
            }
            thread int* operator&[](thread Foo* foo)
            {
                return &foo->x;
            }
        `), /*<@2180>*/e => e instanceof WTypeError);
    checkFail(/*<@2181>*/() => doPrep(`
            struct Foo {
                int x;
            }
            thread int* operator&[](thread Foo* foo, uint, uint)
            {
                return &foo->x;
            }
        `), /*<@2182>*/e => e instanceof WTypeError);
};
tests.indexAnderDoesntReturnPointer = function /*<@2183>*/() {
    checkFail(/*<@2184>*/() => doPrep(`
            struct Foo {
                int x;
            }
            int operator&[](thread Foo* foo, uint)
            {
                return foo->x;
            }
        `), /*<@2185>*/e => e instanceof WTypeError && e.message.indexOf("Return type of ander is not a pointer") != -1);
};
tests.indexAnderDoesntTakeReference = function /*<@2186>*/() {
    checkFail(/*<@2187>*/() => doPrep(`
            struct Foo {
                int x;
            }
            thread int* operator&[](Foo foo, uint)
            {
                return &foo.x;
            }
        `), /*<@2188>*/e => e instanceof WTypeError && e.message.indexOf("Parameter to ander is not a reference") != -1);
};
tests.indexAnderWithArrayRef = function /*<@2189>*/() {
    let /*<@71>*/program = doPrep(`
        struct Foo {
            int x;
        }
        thread int* operator&[](thread Foo[] array, double index)
        {
            return &array[uint(index + 1)].x;
        }
        int foo()
        {
            Foo x;
            x.x = 13;
            return (@x)[double(-1)];
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), 13);
};
tests.devicePtrPtr = function /*<@2190>*/() {
    checkFail(/*<@2191>*/() => doPrep(`
            void foo()
            {
                device int** p;
            }
        `), /*<@2192>*/e => e instanceof WTypeError && e.message.indexOf("Illegal pointer to non-primitive type: int32* device* device") != -1);
};
tests.threadgroupPtrPtr = function /*<@2193>*/() {
    checkFail(/*<@2194>*/() => doPrep(`
            void foo()
            {
                threadgroup int** p;
            }
        `), /*<@2195>*/e => e instanceof WTypeError && e.message.indexOf("Illegal pointer to non-primitive type: int32* threadgroup* threadgroup") != -1);
};
tests.constantPtrPtr = function /*<@2196>*/() {
    checkFail(/*<@2197>*/() => doPrep(`
            void foo()
            {
                constant int** p;
            }
        `), /*<@2198>*/e => e instanceof WTypeError && e.message.indexOf("Illegal pointer to non-primitive type: int32* constant* constant") != -1);
};
tests.pointerIndexGetterInProtocol = function /*<@2199>*/() {
    for (let /*<@3>*/addressSpace of addressSpaces) {
        checkFail(/*<@2200>*/() => doPrep(`
                protocol Foo {
                    int operator[](${addressSpace} Foo*, uint);
                }
                struct Bar { }
                int operator[](Bar, uint) { return 42; }
            `), /*<@2201>*/e => e instanceof WTypeError && e.message.indexOf("Cannot have getter for pointer type") != -1);
    }
};
tests.loneIndexSetterInProtocol = function /*<@2202>*/() {
    checkFail(/*<@2203>*/() => doPrep(`
            protocol Foo {
                Foo operator[]=(Foo, uint, int);
            }
            struct Bar { }
            int operator[](Bar, uint) { return 42; }
            Bar operator[]=(Bar, uint, int) { return Bar(); }
        `), /*<@2204>*/e => e instanceof WTypeError && e.message.indexOf("Every setter must have a matching getter") != -1);
};
tests.notLoneIndexSetterInProtocol = function /*<@2205>*/() {
    doPrep(`
        protocol Foo {
            int operator[](Foo, uint);
            Foo operator[]=(Foo, uint, int);
        }
        struct Bar { }
        int operator[](Bar, uint) { return 42; }
        Bar operator[]=(Bar, uint, int) { return Bar(); }
    `);
};
tests.indexSetterWithMismatchedTypeInProtocol = function /*<@2206>*/() {
    checkFail(/*<@2207>*/() => doPrep(`
            protocol Foo {
                double operator[](Foo, uint);
                Foo operator[]=(Foo, uint, int);
            }
            struct Bar { }
            int operator[](Bar, uint) { return 42; }
            Bar operator[]=(Bar, uint, int) { return Bar(); }
        `), /*<@2208>*/e => e instanceof WTypeError && e.message.indexOf("Setter and getter must agree on value type") != -1);
};
tests.indexOperatorWrongArgumentLengthInProtocol = function /*<@2209>*/() {
    checkFail(/*<@2210>*/() => doPrep(`
            protocol Foo {
                int operator[]();
            }
            struct Bar { }
            int operator[](Bar, uint) { return 42; }
        `), /*<@2211>*/e => e instanceof WTypeError && e.message.indexOf("Protocol's type variable (Foo) not mentioned in signature") != -1);
    checkFail(/*<@2212>*/() => doPrep(`
            protocol Foo {
                int operator[](Foo);
            }
            struct Bar { }
            int operator[](Bar, uint) { return 42; }
        `), /*<@2213>*/e => e instanceof WTypeError && e.message.indexOf("Incorrect number of parameters") != -1);
    checkFail(/*<@2214>*/() => doPrep(`
            protocol Foo {
                int operator[](Foo, int, int);
            }
            struct Bar { }
            int operator[](Bar, uint) { return 42; }
        `), /*<@2215>*/e => e instanceof WTypeError && e.message.indexOf("Incorrect number of parameters") != -1);
};
tests.indexOperatorSetterWrongArgumentLengthInProtocol = function /*<@2216>*/() {
    checkFail(/*<@2217>*/() => doPrep(`
            protocol Foo {
                int operator[]=();
            }
            struct Bar { }
            int operator[](Bar, uint) { return 42; }
            Bar operator[]=(Bar, uint, int) { return Bar(); }
        `), /*<@2218>*/e => e instanceof WTypeError && e.message.indexOf("Protocol's type variable (Foo) not mentioned in signature") != -1);
    checkFail(/*<@2219>*/() => doPrep(`
            protocol Foo {
                int operator[]=(Foo);
            }
            struct Bar { }
            int operator[](Bar, uint) { return 42; }
            Bar operator[]=(Bar, uint, int) { return Bar(); }
        `), /*<@2220>*/e => e instanceof WTypeError && e.message.indexOf("Incorrect number of parameters") != -1);
    checkFail(/*<@2221>*/() => doPrep(`
            protocol Foo {
                int operator[]=(Foo, int);
            }
            struct Bar { }
            int operator[](Bar, uint) { return 42; }
            Bar operator[]=(Bar, uint, int) { return Bar(); }
        `), /*<@2222>*/e => e instanceof WTypeError && e.message.indexOf("Incorrect number of parameters") != -1);
    checkFail(/*<@2223>*/() => doPrep(`
            protocol Foo {
                int operator[]=(Foo, int, int, int);
            }
            struct Bar { }
            int operator[](Bar, uint) { return 42; }
            Bar operator[]=(Bar, uint, int) { return Bar(); }
        `), /*<@2224>*/e => e instanceof WTypeError && e.message.indexOf("Incorrect number of parameters") != -1);
};
tests.loneIndexSetterPointerInProtocol = function /*<@2225>*/() {
    checkFail(/*<@2226>*/() => doPrep(`
            protocol Foo {
                thread int* operator[]=(thread Foo* ptr, uint, int);
            }
            struct Bar { }
            int operator[](Bar, uint) { return 42; }
            Bar operator[]=(Bar, uint, int) { return Bar(); }
        `), /*<@2227>*/e => e instanceof WTypeError && e.message.indexOf("Cannot have setter for pointer type") != -1);
};
tests.indexSetterWithNoGetterOverloadInProtocol = function /*<@2228>*/() {
    checkFail(/*<@2229>*/() => doPrep(`
            protocol Foo {
                int operator[](int, Foo);
                Foo operator[]=(Foo, uint, int);
            }
            struct Bar { }
            int operator[](Bar, uint) { return 42; }
            Bar operator[]=(Bar, uint, int) { return Bar(); }
        `), /*<@2230>*/e => e instanceof WTypeError && e.message.indexOf("Did not find function named operator[]= with arguments Foo,uint32") != -1);
};
tests.indexSetterWithNoGetterOverloadFixedInProtocol = function /*<@2231>*/() {
    doPrep(`
        protocol Foo {
            int operator[](Foo, uint);
            Foo operator[]=(Foo, uint, int);
        }
        struct Bar { }
        int operator[](Bar, uint) { return 42; }
        Bar operator[]=(Bar, uint, int) { return Bar(); }
    `);
};
tests.indexAnderWithNothingWrongInProtocol = function /*<@2232>*/() {
    let /*<@71>*/program = doPrep(`
        protocol Foo {
            thread int* operator&[](thread Foo* foo, uint);
        }
        int bar<T:Foo>(T x)
        {
            return x[42];
        }
        struct Bar { }
        thread int* operator&[](thread Bar*, uint)
        {
            int result = 1234;
            return &result;
        }
        int foo()
        {
            return bar(Bar());
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), 1234);
};
tests.indexAnderWithWrongNumberOfArgumentsInProtocol = function /*<@2233>*/() {
    checkFail(/*<@2234>*/() => doPrep(`
            protocol Foo {
                thread int* operator&[]();
            }
            struct Bar { }
            thread int* operator&[](thread Bar*, uint)
            {
                int result = 1234;
                return &result;
            }
        `), /*<@2235>*/e => e instanceof WTypeError && e.message.indexOf("Protocol's type variable (Foo) not mentioned in signature") != -1);
    checkFail(/*<@2236>*/() => doPrep(`
            protocol Foo {
                thread int* operator&[](thread Foo* foo);
            }
            struct Bar { }
            thread int* operator&[](thread Bar*, uint)
            {
                int result = 1234;
                return &result;
            }
        `), /*<@2237>*/e => e instanceof WTypeError && e.message.indexOf("Incorrect number of parameters for operator&[]") != -1);
    checkFail(/*<@2238>*/() => doPrep(`
            protocol Foo {
                thread int* operator&[](thread Foo* foo, uint, uint);
            }
            struct Bar { }
            thread int* operator&[](thread Bar*, uint)
            {
                int result = 1234;
                return &result;
            }
        `), /*<@2239>*/e => e instanceof WTypeError && e.message.indexOf("Incorrect number of parameters for operator&[]") != -1);
};
tests.indexAnderDoesntReturnPointerInProtocol = function /*<@2240>*/() {
    checkFail(/*<@2241>*/() => doPrep(`
            protocol Foo {
                int operator&[](thread Foo* foo, uint);
            }
            struct Bar { }
            thread int* operator&[](thread Bar*, uint)
            {
                int result = 1234;
                return &result;
            }
        `), /*<@2242>*/e => e instanceof WTypeError && e.message.indexOf("Return type of ander is not a pointer") != -1);
};
tests.indexAnderDoesntTakeReferenceInProtocol = function /*<@2243>*/() {
    checkFail(/*<@2244>*/() => doPrep(`
            protocol Foo {
                thread int* operator&[](Foo foo, uint);
            }
            struct Bar { }
            thread int* operator&[](thread Bar*, uint)
            {
                int result = 1234;
                return &result;
            }
        `), /*<@2245>*/e => e instanceof WTypeError && e.message.indexOf("Parameter to ander is not a reference") != -1);
};
tests.indexAnderWithArrayRefInProtocol = function /*<@2246>*/() {
    let /*<@71>*/program = doPrep(`
        protocol Foo {
            thread int* operator&[](thread Foo[] array, double index);
        }
        int bar<T:Foo>(thread T[] x)
        {
            return x[1.5];
        }
        struct Bar { }
        thread int* operator&[](thread Bar[], double)
        {
            int result = 1234;
            return &result;
        }
        int foo()
        {
            Bar x;
            return bar(@x);
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), 1234);
};
tests.andReturnedArrayRef = function /*<@2247>*/() {
    let /*<@71>*/program = doPrep(`
        thread int[] getArray()
        {
            int[10] x;
            x[5] = 354;
            return @x;
        }
        int foo()
        {
            thread int* ptr = &getArray()[5];
            return *ptr;
        }
    `);
    checkInt(program, callFunction(program, "foo", /*<@784>*/[], /*<@784>*/[]), 354);
};
okToTest = true;
function /*<@2248>*/doTest() {
    if (!okToTest)
        throw new Error("Test setup is incomplete.");
    let /*<@784>*/names = /*<@784>*/[];
    for (let /*<@3>*/s in tests)
        names.push(s);
    names.sort();
    for (let /*<@3>*/s of names) {
        tests[s]();
    }
}
class /*<@2250>*/Benchmark {
    /*<@2251>*/buildStdlib() {
        prepare();
    }
    /*<@2252>*/run() {
        doTest();
    }
}
let /*<@1>*/stdLib;
let /*<@1>*/mainRun;
function /*<@2254>*/toScore(/*<@1>*/timeValue) {
    return timeValue;
}
/*
function mean(values) {
    assert(values instanceof Array);
    let sum = 0;
    for (let x of values)
        sum += x;
    return sum / values.length;
}
*/
function /*<@2255>*/assert(/*<@2>*/condition) {
    if (!condition) {
        throw new Error("assert false");
    }
}
function /*<@2256>*/processResults(/*<@2257>*/results) {
    stdLib = toScore(results[0]);
    mainRun = toScore(results[1]);
}
function /*<@2258>*/printScore() {
    // print("stdLib: " + stdLib);
    // print("mainRun: " + mainRun);
    print("total: " + (stdLib + mainRun));
}
function /*<@2259>*/main() {
    let /*<@2249>*/benchmark = new Benchmark();
    let /*<@2257>*/results = /*<@2257>*/[];
    {
        let /*<@1>*/start = performance.now();
        benchmark.buildStdlib();
        results.push(performance.now() - start);
    }
    {
        let /*<@1>*/start = performance.now();
        benchmark.run();
        results.push(performance.now() - start);
    }
    processResults(results);
    printScore();
}
main();
