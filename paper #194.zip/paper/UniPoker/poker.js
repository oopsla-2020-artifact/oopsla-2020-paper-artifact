/*<@type>{
    "header": {
        "version": "3.0.1",
        "filename": "poker.js",
        "sound": 1
    },
    "types": [
        "any",
        "number",
        "boolean",
        "string",
        "void",
        "int",
        "object",
        {
            "index": 7,
            "cname": "CardDeck",
            "fields": {
                "_cards": 9
            },
            "sfields": {
                "const cardRank": 13,
                "const cardName": 14,
                "static _rankNames": -9,
                "static _newDeck": -9
            },
            "methods": [
                8,
                10,
                11,
                12
            ]
        },
        {
            "index": 8,
            "fname": "constructor",
            "ret": 7
        },
        {
            "index": 9,
            "aname": "",
            "element": 3,
            "mode": "normal"
        },
        {
            "index": 10,
            "fname": "newDeck"
        },
        {
            "index": 11,
            "fname": "shuffle"
        },
        {
            "index": 12,
            "fname": "dealOneCard",
            "ret": 3
        },
        {
            "index": 13,
            "fname": "static cardRank",
            "params": {
                "card": 3
            },
            "ret": 5
        },
        {
            "index": 14,
            "fname": "static cardName",
            "params": {
                "card": 15
            },
            "ret": 3
        },
        {
            "index": 15,
            "uname": "",
            "types": [
                3,
                5
            ]
        },
        {
            "index": 16,
            "cname": "Hand",
            "fields": {
                "_cards": 9,
                "_rank": 5
            },
            "sfields": {
                "static FlushRegExp": -23,
                "static StraightRegExp": -23,
                "static OfAKindRegExp": -23,
                "static RoyalFlush": -5,
                "static StraightFlush": -5,
                "static FourOfAKind": -5,
                "static FullHouse": -5,
                "static Flush": -5,
                "static Straight": -5,
                "static ThreeOfAKind": -5,
                "static TwoPair": -5,
                "static Pair": -5
            },
            "methods": [
                17,
                18,
                19,
                20,
                21,
                22
            ]
        },
        {
            "index": 17,
            "fname": "constructor",
            "ret": 16
        },
        {
            "index": 18,
            "fname": "clear"
        },
        {
            "index": 19,
            "fname": "takeCard",
            "params": {
                "card": 3
            }
        },
        {
            "index": 20,
            "fname": "score"
        },
        {
            "index": 21,
            "fname": "get rank",
            "ret": 5
        },
        {
            "index": 22,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 23,
            "bname": "RegExp"
        },
        {
            "index": 24,
            "aname": "",
            "element": 0,
            "mode": "normal"
        },
        {
            "index": 25,
            "fname": "",
            "params": {
                "a": 3,
                "b": 3
            },
            "ret": 5
        },
        {
            "index": 26,
            "bname": "RegExpMatchArray"
        },
        {
            "index": 27,
            "uname": "",
            "types": [
                4,
                26
            ]
        },
        {
            "index": 28,
            "bname": "Object"
        },
        {
            "index": 29,
            "cname": "Player",
            "supers": {
                "Hand": 17
            },
            "fields": {
                "_name": 3,
                "_wins": 5,
                "_handTypeCounts": 31
            },
            "methods": [
                30,
                32,
                33,
                34,
                35,
                36,
                37
            ]
        },
        {
            "index": 30,
            "fname": "constructor",
            "params": {
                "name": 3
            },
            "ret": 29,
            "hobj": 1
        },
        {
            "index": 31,
            "aname": "",
            "element": 5,
            "mode": "normal"
        },
        {
            "index": 32,
            "fname": "scoreHand"
        },
        {
            "index": 33,
            "fname": "wonHand"
        },
        {
            "index": 34,
            "fname": "get name",
            "ret": 3
        },
        {
            "index": 35,
            "fname": "get hand",
            "ret": 3,
            "hobj": 1
        },
        {
            "index": 36,
            "fname": "get wins",
            "ret": 5
        },
        {
            "index": 37,
            "fname": "get handTypeCounts",
            "ret": 31
        },
        {
            "index": 38,
            "fname": "playHands",
            "params": {
                "players": 39
            }
        },
        {
            "index": 39,
            "aname": "",
            "element": 29,
            "mode": "normal"
        },
        {
            "index": 40,
            "cname": "PlayerExpectation",
            "fields": {
                "_wins": -5,
                "_handTypeCounts": -31
            },
            "sfields": {
                "static _handTypes": -9
            },
            "methods": [
                41,
                42
            ]
        },
        {
            "index": 41,
            "fname": "constructor",
            "params": {
                "wins": 5,
                "handTypeCounts": 31
            },
            "ret": 40
        },
        {
            "index": 42,
            "fname": "validate",
            "params": {
                "player": 29
            }
        },
        {
            "index": 43,
            "aname": "",
            "element": 40,
            "mode": "normal"
        },
        {
            "index": 44,
            "cname": "Benchmark",
            "fields": {
                "_players": -39
            },
            "methods": [
                45,
                46,
                47,
                48
            ]
        },
        {
            "index": 45,
            "fname": "constructor",
            "ret": 44
        },
        {
            "index": 46,
            "fname": "runIteration"
        },
        {
            "index": 47,
            "fname": "validate"
        },
        {
            "index": 48,
            "fname": "runIterations",
            "params": {
                "numIterations": 5,
                "results": 49
            }
        },
        {
            "index": 49,
            "aname": "",
            "element": 1,
            "mode": "normal"
        },
        {
            "index": 50,
            "fname": "summation",
            "params": {
                "values": 51
            },
            "ret": 1
        },
        {
            "index": 51,
            "aname": "",
            "element": 28,
            "mode": "normal"
        },
        {
            "index": 52,
            "fname": "toScore",
            "params": {
                "timeValue": 28
            },
            "ret": 1
        },
        {
            "index": 53,
            "fname": "mean",
            "params": {
                "values": 51
            },
            "ret": 1
        },
        {
            "index": 54,
            "fname": "assert",
            "params": {
                "condition": 2
            }
        },
        {
            "index": 55,
            "fname": "static now",
            "ret": 1
        },
        {
            "index": 56,
            "fname": "processResults",
            "params": {
                "results": 51
            }
        },
        {
            "index": 57,
            "fname": "copyArray",
            "params": {
                "a": 51
            },
            "ret": 51
        },
        {
            "index": 58,
            "fname": "",
            "params": {
                "a": 28,
                "b": 28
            },
            "ret": 5
        },
        {
            "index": 59,
            "fname": "printScore"
        },
        {
            "index": 60,
            "fname": "main"
        }
    ]
}*/
"use strict";
class /*<@8>*/CardDeck {
    constructor() {
        this.newDeck();
    }
    /*<@10>*/newDeck() {
        // Make a shallow copy of a new deck
        this._cards = CardDeck._newDeck.slice(0);
    }
    /*<@11>*/shuffle() {
        this.newDeck();
        for (let /*<@5>*/index = 52; index !== 0;) {
            // Select a random card
            let /*<@1>*/randomIndex = Math.floor(Math.random() * index);
            index--;
            // Swap the current card with the random card
            let /*<@3>*/tempCard = this._cards[index];
            this._cards[index] = this._cards[randomIndex];
            this._cards[randomIndex] = tempCard;
        }
    }
    /*<@12>*/dealOneCard() {
        return this._cards.shift();
    }
    static /*<@13>*/cardRank(/*<@3>*/card) {
        // This returns a numeric value for a card.
        // Ace is highest.
        let /*<@5>*/rankOfCard = card.codePointAt(0) & 0xf;
        if (rankOfCard == 0x1) // Make Aces higher than Kings
            rankOfCard = 0xf;
        return rankOfCard;
    }
    static /*<@14>*/cardName(/*<@15>*/card) {
        if (typeof (card) == "string")
            card = /*<@3>*/card.codePointAt(0);
        return this._rankNames[/*<@5>*/card & 0xf];
    }
}
CardDeck._rankNames = /*<@9>*/[
    "", "Ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "", "Queen", "King"
];
CardDeck._newDeck = /*<@9>*/[
    // Spades
    "\u{1f0a1}", "\u{1f0a2}", "\u{1f0a3}", "\u{1f0a4}", "\u{1f0a5}",
    "\u{1f0a6}", "\u{1f0a7}", "\u{1f0a8}", "\u{1f0a9}", "\u{1f0aa}",
    "\u{1f0ab}", "\u{1f0ad}", "\u{1f0ae}",
    // Hearts
    "\u{1f0b1}", "\u{1f0b2}", "\u{1f0b3}", "\u{1f0b4}", "\u{1f0b5}",
    "\u{1f0b6}", "\u{1f0b7}", "\u{1f0b8}", "\u{1f0b9}", "\u{1f0ba}",
    "\u{1f0bb}", "\u{1f0bd}", "\u{1f0be}",
    // Clubs
    "\u{1f0d1}", "\u{1f0d2}", "\u{1f0d3}", "\u{1f0d4}", "\u{1f0d5}",
    "\u{1f0d6}", "\u{1f0d7}", "\u{1f0d8}", "\u{1f0d9}", "\u{1f0da}",
    "\u{1f0db}", "\u{1f0dd}", "\u{1f0de}",
    // Diamonds
    "\u{1f0c1}", "\u{1f0c2}", "\u{1f0c3}", "\u{1f0c4}", "\u{1f0c5}",
    "\u{1f0c6}", "\u{1f0c7}", "\u{1f0c8}", "\u{1f0c9}", "\u{1f0ca}",
    "\u{1f0cb}", "\u{1f0cd}", "\u{1f0ce}"
];
class /*<@17>*/Hand {
    constructor() {
        this.clear();
    }
    /*<@18>*/clear() {
        this._cards = /*<@24>*/[];
        this._rank = 0;
    }
    /*<@19>*/takeCard(/*<@3>*/card) {
        this._cards.push(card);
    }
    /*<@20>*/score() {
        // Sort highest rank to lowest
        this._cards.sort(/*<@25>*/(/*<@3>*/a, /*<@3>*/b) => {
            return CardDeck.cardRank(b) - CardDeck.cardRank(a);
        });
        let /*<@3>*/handString = this._cards.join("");
        let /*<@27>*/flushResult = handString.match(Hand.FlushRegExp);
        let /*<@27>*/straightResult = handString.match(Hand.StraightRegExp);
        let /*<@27>*/ofAKindResult = handString.match(Hand.OfAKindRegExp);
        if (flushResult) {
            if (straightResult) {
                if (straightResult[1])
                    this._rank = Hand.RoyalFlush;
                else
                    this._rank = Hand.StraightFlush;
            }
            else
                this._rank = Hand.Flush;
            this._rank |= CardDeck.cardRank(this._cards[0]) << 16 | CardDeck.cardRank(this._cards[1]) << 12;
        }
        else if (straightResult)
            this._rank = Hand.Straight | CardDeck.cardRank(this._cards[0]) << 16 | CardDeck.cardRank(this._cards[1]) << 12;
        else if (ofAKindResult) {
            // When comparing lengths, a matched unicode character has a length of 2.
            // Therefore expected lengths are doubled, e.g a pair will have a match length of 4.
            if (ofAKindResult[0].length == 8)
                this._rank = Hand.FourOfAKind | CardDeck.cardRank(this._cards[0]);
            else {
                // Found pair or three of a kind.  Check for two pair or full house.
                let /*<@3>*/firstOfAKind = ofAKindResult[0];
                let /*<@1>*/remainingCardsIndex = handString.indexOf(firstOfAKind) + firstOfAKind.length;
                let /*<@27>*/secondOfAKindResult;
                if (remainingCardsIndex <= 6
                    && (secondOfAKindResult = handString.slice(remainingCardsIndex).match(Hand.OfAKindRegExp))) {
                    if ((firstOfAKind.length == 6 && secondOfAKindResult[0].length == 4)
                        || (firstOfAKind.length == 4 && secondOfAKindResult[0].length == 6)) {
                        let /*<@5>*/threeOfAKindCardRank;
                        let /*<@5>*/twoOfAKindCardRank;
                        if (firstOfAKind.length == 6) {
                            threeOfAKindCardRank = CardDeck.cardRank(firstOfAKind.slice(0, 2));
                            twoOfAKindCardRank = CardDeck.cardRank(secondOfAKindResult[0].slice(0, 2));
                        }
                        else {
                            threeOfAKindCardRank = CardDeck.cardRank(secondOfAKindResult[0].slice(0, 2));
                            twoOfAKindCardRank = CardDeck.cardRank(firstOfAKind.slice(0, 2));
                        }
                        this._rank = Hand.FullHouse | threeOfAKindCardRank << 16 | (threeOfAKindCardRank < 12) | threeOfAKindCardRank << 8 | twoOfAKindCardRank << 4 | twoOfAKindCardRank;
                    }
                    else if (firstOfAKind.length == 4 && secondOfAKindResult[0].length == 4) {
                        let /*<@5>*/firstPairCardRank = CardDeck.cardRank(firstOfAKind.slice(0, 2));
                        let /*<@5>*/SecondPairCardRank = CardDeck.cardRank(secondOfAKindResult[0].slice(0, 2));
                        let /*<@5>*/otherCardRank;
                        // Due to sorting, the other card is at index 0, 4 or 8
                        if (firstOfAKind.codePointAt(0) == handString.codePointAt(0)) {
                            if (secondOfAKindResult[0].codePointAt(0) == handString.codePointAt(4))
                                otherCardRank = CardDeck.cardRank(handString.slice(8, 10));
                            else
                                otherCardRank = CardDeck.cardRank(handString.slice(4, 6));
                        }
                        else
                            otherCardRank = CardDeck.cardRank(handString.slice(0, 2));
                        this._rank = Hand.TwoPair | firstPairCardRank << 16 | firstPairCardRank << 12 | SecondPairCardRank << 8 | SecondPairCardRank << 4 | otherCardRank;
                    }
                }
                else {
                    let /*<@5>*/ofAKindCardRank = CardDeck.cardRank(firstOfAKind.slice(0, 2));
                    let /*<@5>*/otherCardsRank = 0;
                    for (let /*<@3>*/card of this._cards) {
                        let /*<@5>*/cardRank = CardDeck.cardRank(card);
                        if (cardRank != ofAKindCardRank)
                            otherCardsRank = (otherCardsRank << 4) | cardRank;
                    }
                    if (firstOfAKind.length == 6)
                        this._rank = Hand.ThreeOfAKind | ofAKindCardRank << 16 | ofAKindCardRank << 12 | ofAKindCardRank << 8 | otherCardsRank;
                    else
                        this._rank = Hand.Pair | ofAKindCardRank << 16 | ofAKindCardRank << 12 | otherCardsRank;
                }
            }
        }
        else {
            this._rank = 0;
            for (let /*<@3>*/card of this._cards) {
                let /*<@5>*/cardRank = CardDeck.cardRank(card);
                this._rank = (this._rank << 4) | cardRank;
            }
        }
    }
    get /*<@21>*/rank() {
        return this._rank;
    }
    /*<@22>*/toString() {
        return this._cards.join("");
    }
}
Hand.FlushRegExp = new RegExp("([\u{1f0a1}-\u{1f0ae}]{5})|([\u{1f0b1}-\u{1f0be}]{5})|([\u{1f0c1}-\u{1f0ce}]{5})|([\u{1f0d1}-\u{1f0de}]{5})", "u");
Hand.StraightRegExp = new RegExp("([\u{1f0a1}\u{1f0b1}\u{1f0d1}\u{1f0c1}][\u{1f0ae}\u{1f0be}\u{1f0de}\u{1f0ce}][\u{1f0ad}\u{1f0bd}\u{1f0dd}\u{1f0cd}][\u{1f0ab}\u{1f0bb}\u{1f0db}\u{1f0cb}][\u{1f0aa}\u{1f0ba}\u{1f0da}\u{1f0ca}])|[\u{1f0ae}\u{1f0be}\u{1f0de}\u{1f0ce}][\u{1f0ad}\u{1f0bd}\u{1f0dd}\u{1f0cd}][\u{1f0ab}\u{1f0bb}\u{1f0db}\u{1f0cb}][\u{1f0aa}\u{1f0ba}\u{1f0da}\u{1f0ca}][\u{1f0a9}\u{1f0b9}\u{1f0d9}\u{1f0c9}]|[\u{1f0ad}\u{1f0bd}\u{1f0dd}\u{1f0cd}][\u{1f0ab}\u{1f0bb}\u{1f0db}\u{1f0cb}][\u{1f0aa}\u{1f0ba}\u{1f0da}\u{1f0ca}][\u{1f0a9}\u{1f0b9}\u{1f0d9}\u{1f0c9}][\u{1f0a8}\u{1f0b8}\u{1f0d8}\u{1f0c8}]|[\u{1f0ab}\u{1f0bb}\u{1f0db}\u{1f0cb}][\u{1f0aa}\u{1f0ba}\u{1f0da}\u{1f0ca}][\u{1f0a9}\u{1f0b9}\u{1f0d9}\u{1f0c9}][\u{1f0a8}\u{1f0b8}\u{1f0d8}\u{1f0c8}][\u{1f0a7}\u{1f0b7}\u{1f0d7}\u{1f0c7}]|[\u{1f0aa}\u{1f0ba}\u{1f0da}\u{1f0ca}][\u{1f0a9}\u{1f0b9}\u{1f0d9}\u{1f0c9}][\u{1f0a8}\u{1f0b8}\u{1f0d8}\u{1f0c8}][\u{1f0a7}\u{1f0b7}\u{1f0d7}\u{1f0c7}][\u{1f0a6}\u{1f0b6}\u{1f0d6}\u{1f0c6}]|[\u{1f0a9}\u{1f0b9}\u{1f0d9}\u{1f0c9}][\u{1f0a8}\u{1f0b8}\u{1f0d8}\u{1f0c8}][\u{1f0a7}\u{1f0b7}\u{1f0d7}\u{1f0c7}][\u{1f0a6}\u{1f0b6}\u{1f0d6}\u{1f0c6}][\u{1f0a5}\u{1f0b5}\u{1f0d5}\u{1f0c5}]|[\u{1f0a8}\u{1f0b8}\u{1f0d8}\u{1f0c8}][\u{1f0a7}\u{1f0b7}\u{1f0d7}\u{1f0c7}][\u{1f0a6}\u{1f0b6}\u{1f0d6}\u{1f0c6}][\u{1f0a5}\u{1f0b5}\u{1f0d5}\u{1f0c5}][\u{1f0a4}\u{1f0b4}\u{1f0d4}\u{1f0c4}]|[\u{1f0a7}\u{1f0b7}\u{1f0d7}\u{1f0c7}][\u{1f0a6}\u{1f0b6}\u{1f0d6}\u{1f0c6}][\u{1f0a5}\u{1f0b5}\u{1f0d5}\u{1f0c5}][\u{1f0a4}\u{1f0b4}\u{1f0d4}\u{1f0c4}][\u{1f0a3}\u{1f0b3}\u{1f0d3}\u{1f0c3}]|[\u{1f0a6}\u{1f0b6}\u{1f0d6}\u{1f0c6}][\u{1f0a5}\u{1f0b5}\u{1f0d5}\u{1f0c5}][\u{1f0a4}\u{1f0b4}\u{1f0d4}\u{1f0c4}][\u{1f0a3}\u{1f0b3}\u{1f0d3}\u{1f0c3}][\u{1f0a2}\u{1f0b2}\u{1f0d2}\u{1f0c2}]|[\u{1f0a1}\u{1f0b1}\u{1f0d1}\u{1f0c1}][\u{1f0a5}\u{1f0b5}\u{1f0d5}\u{1f0c5}][\u{1f0a4}\u{1f0b4}\u{1f0d4}\u{1f0c4}][\u{1f0a3}\u{1f0b3}\u{1f0d3}\u{1f0c3}][\u{1f0a2}\u{1f0b2}\u{1f0d2}\u{1f0c2}]", "u");
Hand.OfAKindRegExp = new RegExp("(?:[\u{1f0a1}\u{1f0b1}\u{1f0d1}\u{1f0c1}]{2,4})|(?:[\u{1f0ae}\u{1f0be}\u{1f0de}\u{1f0ce}]{2,4})|(?:[\u{1f0ad}\u{1f0bd}\u{1f0dd}\u{1f0cd}]{2,4})|(?:[\u{1f0ab}\u{1f0bb}\u{1f0db}\u{1f0cb}]{2,4})|(?:[\u{1f0aa}\u{1f0ba}\u{1f0da}\u{1f0ca}]{2,4})|(?:[\u{1f0a9}\u{1f0b9}\u{1f0d9}\u{1f0c9}]{2,4})|(?:[\u{1f0a8}\u{1f0b8}\u{1f0d8}\u{1f0c8}]{2,4})|(?:[\u{1f0a7}\u{1f0b7}\u{1f0d7}\u{1f0c7}]{2,4})|(?:[\u{1f0a6}\u{1f0b6}\u{1f0d6}\u{1f0c6}]{2,4})|(?:[\u{1f0a5}\u{1f0b5}\u{1f0d5}\u{1f0c5}]{2,4})|(?:[\u{1f0a4}\u{1f0b4}\u{1f0d4}\u{1f0c4}]{2,4})|(?:[\u{1f0a3}\u{1f0b3}\u{1f0d3}\u{1f0c3}]{2,4})|(?:[\u{1f0a2}\u{1f0b2}\u{1f0d2}\u{1f0c2}]{2,4})", "u");
Hand.RoyalFlush = 0x900000;
Hand.StraightFlush = 0x800000;
Hand.FourOfAKind = 0x700000;
Hand.FullHouse = 0x600000;
Hand.Flush = 0x500000;
Hand.Straight = 0x400000;
Hand.ThreeOfAKind = 0x300000;
Hand.TwoPair = 0x200000;
Hand.Pair = 0x100000;
class /*<@30>*/Player extends Hand {
    constructor(/*<@3>*/name) {
        super();
        this._name = name;
        this._wins = 0;
        this._handTypeCounts = /*<@31>*/[0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
    }
    /*<@32>*/scoreHand() {
        this.score();
        let /*<@5>*/handType = this.rank >> 20;
        this._handTypeCounts[handType]++;
    }
    /*<@33>*/wonHand() {
        this._wins++;
    }
    get /*<@34>*/name() {
        return this._name;
    }
    get /*<@35>*/hand() {
        return super.toString();
    }
    get /*<@36>*/wins() {
        return this._wins;
    }
    get /*<@37>*/handTypeCounts() {
        return this._handTypeCounts;
    }
}
function /*<@38>*/playHands(/*<@39>*/players) {
    let /*<@7>*/cardDeck = new CardDeck();
    let /*<@5>*/handsPlayed = 0;
    let /*<@5>*/highestRank = 0;
    do {
        cardDeck.shuffle();
        for (let /*<@29>*/player of players)
            player.clear();
        for (let /*<@5>*/i = 0; i < 5; i++) {
            for (let /*<@29>*/player of players)
                player.takeCard(cardDeck.dealOneCard());
        }
        for (let /*<@29>*/player of players)
            player.scoreHand();
        handsPlayed++;
        highestRank = 0;
        for (let /*<@29>*/player of players) {
            if (player.rank > highestRank)
                highestRank = player.rank;
        }
        for (let /*<@29>*/player of players) {
            // We count ties as wins for each player.
            if (player.rank == highestRank)
                player.wonHand();
        }
    } while (handsPlayed < 2000);
}
class /*<@41>*/PlayerExpectation {
    constructor(/*<@5>*/wins, /*<@31>*/handTypeCounts) {
        this._wins = wins;
        this._handTypeCounts = handTypeCounts;
    }
    /*<@42>*/validate(/*<@29>*/player) {
        if (player.wins != this._wins)
            throw "Expected " + player.name + " to have " + this._wins + ", but they have " + player.wins;
        let /*<@31>*/actualHandTypeCounts = player.handTypeCounts;
        if (this._handTypeCounts.length != actualHandTypeCounts.length)
            throw "Expected " + player.name + " to have " + this._handTypeCounts.length + " hand types, but they have " + actualHandTypeCounts.length;
        for (let /*<@5>*/handTypeIdx = 0; handTypeIdx < this._handTypeCounts.length; handTypeIdx++) {
            if (this._handTypeCounts[handTypeIdx] != actualHandTypeCounts[handTypeIdx]) {
                throw "Expected " + player.name + " to have " + this._handTypeCounts[handTypeIdx] + " " + PlayerExpectation._handTypes[handTypeIdx] + " hands, but they have " + actualHandTypeCounts[handTypeIdx];
            }
        }
    }
}
PlayerExpectation._handTypes = /*<@9>*/[
    "High Cards",
    "Pairs",
    "Two Pairs",
    "Three of a Kinds",
    "Straights",
    "Flushes",
    "Full Houses",
    "Four of a Kinds",
    "Straight Flushes",
    "Royal Flushes"
];
var /*<@43>*/playerExpectations = /*<@43>*/[];
playerExpectations.push(new PlayerExpectation(59864, /*<@31>*/[120476, 101226, 11359, 5083, 982, 456, 370, 45, 3, 0]));
playerExpectations.push(new PlayerExpectation(60020, /*<@31>*/[120166, 101440, 11452, 5096, 942, 496, 333, 67, 8, 0]));
playerExpectations.push(new PlayerExpectation(60065, /*<@31>*/[120262, 101345, 11473, 5093, 941, 472, 335, 76, 3, 0]));
playerExpectations.push(new PlayerExpectation(60064, /*<@31>*/[120463, 101218, 11445, 5065, 938, 446, 364, 58, 3, 0]));
class /*<@45>*/Benchmark {
    constructor() {
        this._players = /*<@24>*/[];
        this._players.push(new Player("Player 1"));
        this._players.push(new Player("Player 2"));
        this._players.push(new Player("Player 3"));
        this._players.push(new Player("Player 4"));
    }
    /*<@46>*/runIteration() {
        playHands(this._players);
    }
    /*<@47>*/validate() {
        if (this._players.length != playerExpectations.length)
            throw "Expect " + playerExpectations.length + ", but actually have " + this._players.length;
        for (let /*<@5>*/playerIdx = 0; playerIdx < playerExpectations.length; playerIdx++)
            playerExpectations[playerIdx].validate(this._players[playerIdx]);
    }
    /*<@48>*/runIterations(/*<@5>*/numIterations, /*<@49>*/results) {
        for (let /*<@5>*/iteration = 0; iteration < numIterations; ++iteration) {
            let /*<@1>*/before = Date.now();
            this.runIteration();
            let /*<@1>*/after = Date.now();
            results.push(after - before);
        }
    }
}
let /*<@1>*/worst4;
let /*<@1>*/average;
let /*<@1>*/firstIteration;
let /*<@1>*/total;
function /*<@50>*/summation(/*<@51>*/values) {
    assert(values instanceof Array);
    let /*<@1>*/sum = 0;
    for (let /*<@28>*/x of values)
        sum = sum + /*<@1>*/x;
    return sum;
}
function /*<@52>*/toScore(/*<@28>*/timeValue) {
    return /*<@1>*/timeValue;
}
function /*<@53>*/mean(/*<@51>*/values) {
    assert(values instanceof Array);
    let /*<@1>*/sum = 0;
    for (let /*<@28>*/x of values)
        sum = sum + /*<@1>*/x;
    return sum / values.length;
}
function /*<@54>*/assert(/*<@2>*/condition) {
    if (!condition) {
        throw new Error("assert false");
    }
}
function /*<@56>*/processResults(/*<@51>*/results) {
    function /*<@57>*/copyArray(/*<@51>*/a) {
        let /*<@24>*/result = /*<@24>*/[];
        for (let /*<@28>*/x of a)
            result.push(x);
        return result;
    }
    results = copyArray(results);
    firstIteration = toScore(results[0]);
    total = summation(results);
    // results = results.slice(1);
    results.sort(/*<@58>*/(/*<@28>*/a, /*<@28>*/b) => a < b ? 1 : -1);
    for (let /*<@5>*/i = 0; i + 1 < results.length; ++i)
        assert(results[i] >= results[i + 1]);
    let /*<@51>*/worstCase = /*<@51>*/[];
    for (let /*<@5>*/i = 0; i < 4; ++i)
        worstCase.push(results[i]);
    worst4 = toScore(mean(worstCase));
    average = toScore(mean(results));
}
function /*<@59>*/printScore() {
    // print("First: " + firstIteration);
    // print("worst4: " + worst4);
    print("average: " + average);
    // print("total: " + total);
}
function /*<@60>*/main() {
    let /*<@44>*/__benchmark = new Benchmark();
    let /*<@24>*/results = /*<@24>*/[];
    for (let /*<@5>*/i = 0; i < 120; i++) {
        let /*<@1>*/start = performance.now();
        __benchmark.runIteration();
        let /*<@1>*/end = performance.now();
        results.push(end - start);
    }
    processResults(results);
    printScore();
}
main();
