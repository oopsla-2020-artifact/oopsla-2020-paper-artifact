/*<@type>{
    "header": {
        "version": "3.0.1",
        "filename": "air.js"
    },
    "types": [
        "any",
        "number",
        "boolean",
        "string",
        "void",
        "int",
        "object",
        {
            "index": 7,
            "bname": "Symbol"
        },
        {
            "index": 8,
            "fname": "relCondCode",
            "params": {
                "cond": 7
            },
            "ret": 5
        },
        {
            "index": 9,
            "fname": "resCondCode",
            "params": {
                "cond": 7
            },
            "ret": 5
        },
        {
            "index": 10,
            "fname": "doubleCondCode",
            "params": {
                "cond": 7
            },
            "ret": 5
        },
        {
            "index": 11,
            "fname": "isRepresentableAsInt32",
            "params": {
                "value": 5
            },
            "ret": 2
        },
        {
            "index": 12,
            "fname": "addBasicBlockIndexed",
            "params": {
                "list": 203,
                "cons": 14,
                "frequency": 5
            },
            "ret": 13
        },
        {
            "index": 13,
            "cname": "BasicBlock",
            "fields": {
                "_index": -5,
                "_frequency": -5,
                "_insts": -198,
                "_successors": -202,
                "_predecessors": -203
            },
            "methods": [
                14,
                204,
                205,
                206,
                208,
                209,
                211,
                212,
                213,
                214,
                215,
                216,
                217,
                218,
                219,
                220,
                221,
                222,
                223,
                224,
                225,
                226
            ]
        },
        {
            "index": 14,
            "fname": "constructor",
            "params": {
                "index": 5,
                "frequency": 5
            },
            "ret": 13
        },
        {
            "index": 15,
            "cname": "Inst",
            "fields": {
                "_opcode": -7,
                "_args": -179,
                "cCallType": 7,
                "cCallArgTypes": 180,
                "patchHasNonArgEffects": 2,
                "extraEarlyClobberedRegs": 181,
                "extraClobberedRegs": 181,
                "patchArgData": 183
            },
            "sfields": {
                "const forEachDef": 193,
                "const forEachDefWithExtraClobberedRegs": 194
            },
            "methods": [
                16,
                184,
                185,
                186,
                187,
                188,
                189,
                190,
                191,
                192,
                195,
                196,
                197
            ]
        },
        {
            "index": 16,
            "fname": "constructor",
            "params": {
                "opcode": 7,
                "args": 179
            },
            "ret": 15
        },
        {
            "index": 17,
            "cname": "Arg",
            "fields": {
                "_kind": -7,
                "_condition": 7,
                "_tmp": 19,
                "_value": 5,
                "_lowValue": 5,
                "_highValue": 5,
                "_base": 19,
                "_offset": 5,
                "_slot": 47,
                "_index": 19,
                "_scale": 5,
                "_width": 5
            },
            "sfields": {
                "static Invalid": 7,
                "static Tmp": 7,
                "static Imm": 7,
                "static BigImm": 7,
                "static BitImm": 7,
                "static BitImm64": 7,
                "static Addr": 7,
                "static Stack": 7,
                "static CallArg": 7,
                "static Index": 7,
                "static RelCond": 7,
                "static ResCond": 7,
                "static DoubleCond": 7,
                "static Special": 7,
                "static Width": 7,
                "static Use": 7,
                "static ColdUse": 7,
                "static LateUse": 7,
                "static LateColdUse": 7,
                "static Def": 7,
                "static ZDef": 7,
                "static UseDef": 7,
                "static UseZDef": 7,
                "static EarlyDef": 7,
                "static Scratch": 7,
                "static UseAddr": 7,
                "static DoubleCold": 7,
                "static WidthArg": 7,
                "static GP": 7,
                "static FP": 7,
                "const isAnyUse": 64,
                "const isColdUse": 65,
                "const isWarmUse": 66,
                "const cooled": 67,
                "const isEarlyUse": 68,
                "const isLateUse": 69,
                "const isAnyDef": 70,
                "const isEarlyDef": 71,
                "const isLateDef": 72,
                "const isZDef": 73,
                "const typeForB3Type": 74,
                "const widthForB3Type": 75,
                "const conservativeWidth": 76,
                "const minimumWidth": 77,
                "const bytes": 78,
                "const widthForBytes": 79,
                "const createTmp": 80,
                "const fromReg": 81,
                "const createImm": 82,
                "const createBigImm": 83,
                "const createBitImm": 84,
                "const createBitImm64": 85,
                "const createAddr": 86,
                "const createStack": 87,
                "const createCallArg": 88,
                "const createStackAddr": 89,
                "const isValidScale": 90,
                "const logScale": 91,
                "const createIndex": 92,
                "const createRelCond": 93,
                "const createResCond": 94,
                "const createDoubleCond": 95,
                "const createWidth": 96,
                "const createSpecial": 97,
                "const isValidImmForm": 145,
                "const isValidBitImmForm": 146,
                "const isValidBitImm64Form": 147,
                "const isValidAddrForm": 148,
                "const isValidIndexForm": 149,
                "const extract": 171,
                "const forEachFast": 172,
                "const forEach": 173,
                "const kindCode": 176
            },
            "methods": [
                18,
                98,
                99,
                100,
                101,
                102,
                103,
                104,
                105,
                106,
                107,
                108,
                109,
                110,
                111,
                112,
                113,
                114,
                115,
                116,
                117,
                118,
                119,
                120,
                121,
                122,
                123,
                124,
                125,
                126,
                127,
                128,
                129,
                130,
                131,
                132,
                133,
                134,
                135,
                136,
                137,
                138,
                139,
                140,
                141,
                142,
                143,
                144,
                150,
                151,
                152,
                153,
                154,
                167,
                169,
                170,
                174,
                175,
                177,
                178
            ]
        },
        {
            "index": 18,
            "fname": "constructor",
            "ret": 17
        },
        {
            "index": 19,
            "cname": "Reg",
            "supers": {
                "TmpBase": 37
            },
            "fields": {
                "_index": -5,
                "_type": -7,
                "_name": -3,
                "_isCalleeSave": -2
            },
            "sfields": {
                "static regs": 22,
                "static rax": 19,
                "static rcx": 19,
                "static rdx": 19,
                "static rbx": 19,
                "static rsp": 19,
                "static rbp": 19,
                "static rsi": 19,
                "static rdi": 19,
                "static gprs": 22,
                "static fprs": 22,
                "static calleeSaveGPRs": 22,
                "static calleeSaveFPRs": 22,
                "static calleeSaves": 22,
                "static callFrameRegister": 19,
                "static stackPointerRegister": 19,
                "static r8": 19,
                "static r9": 19,
                "static r10": 19,
                "static r11": 19,
                "static r12": 19,
                "static r13": 19,
                "static r14": 19,
                "static r15": 19,
                "static xmm0": 19,
                "static xmm1": 19,
                "static xmm2": 19,
                "static xmm3": 19,
                "static xmm4": 19,
                "static xmm5": 19,
                "static xmm6": 19,
                "static xmm7": 19,
                "static xmm8": 19,
                "static xmm9": 19,
                "static xmm10": 19,
                "static xmm11": 19,
                "static xmm12": 19,
                "static xmm13": 19,
                "static xmm14": 19,
                "static xmm15": 19,
                "const fromReg": 23,
                "const extract": 31,
                "const forEachFast": 33,
                "const forEach": 35
            },
            "methods": [
                20,
                24,
                25,
                26,
                27,
                28,
                29,
                30
            ]
        },
        {
            "index": 20,
            "fname": "constructor",
            "params": {
                "index": 5,
                "type": 7,
                "name": 3,
                "isCalleeSave": 21
            },
            "ret": 19,
            "hobj": 1
        },
        {
            "index": 21,
            "uname": "",
            "types": [
                2,
                4
            ]
        },
        {
            "index": 22,
            "aname": "",
            "element": 19,
            "mode": "normal"
        },
        {
            "index": 23,
            "fname": "static fromReg",
            "params": {
                "reg": 19
            },
            "ret": 19
        },
        {
            "index": 24,
            "fname": "get index",
            "ret": 5
        },
        {
            "index": 25,
            "fname": "get type",
            "ret": 7
        },
        {
            "index": 26,
            "fname": "get name",
            "ret": 3
        },
        {
            "index": 27,
            "fname": "get isCalleeSave",
            "ret": 2
        },
        {
            "index": 28,
            "fname": "get isReg",
            "ret": 2
        },
        {
            "index": 29,
            "fname": "hash",
            "ret": 5
        },
        {
            "index": 30,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 31,
            "fname": "static extract",
            "params": {
                "arg": 17
            },
            "ret": 32
        },
        {
            "index": 32,
            "uname": "",
            "types": [
                4,
                19
            ]
        },
        {
            "index": 33,
            "fname": "static forEachFast",
            "params": {
                "arg": 17,
                "func": 0
            },
            "ret": 34
        },
        {
            "index": 34,
            "uname": "",
            "types": [
                4,
                17
            ]
        },
        {
            "index": 35,
            "fname": "static forEach",
            "params": {
                "arg": 17,
                "argRole": 7,
                "argType": 7,
                "argWidth": 5,
                "func": 0
            },
            "ret": 34
        },
        {
            "index": 36,
            "cname": "TmpBase",
            "fields": {
                "_type": 7,
                "_isReg": 2
            },
            "methods": [
                37,
                38,
                39,
                40,
                41,
                42,
                43,
                44,
                45,
                46
            ]
        },
        {
            "index": 37,
            "fname": "constructor",
            "ret": 36
        },
        {
            "index": 38,
            "fname": "get isGP",
            "ret": 2
        },
        {
            "index": 39,
            "fname": "get isFP",
            "ret": 2
        },
        {
            "index": 40,
            "fname": "get isGPR",
            "ret": 2
        },
        {
            "index": 41,
            "fname": "get isFPR",
            "ret": 2
        },
        {
            "index": 42,
            "fname": "get reg",
            "ret": 36
        },
        {
            "index": 43,
            "fname": "get gpr",
            "ret": 36
        },
        {
            "index": 44,
            "fname": "get fpr",
            "ret": 36
        },
        {
            "index": 45,
            "fname": "get type",
            "ret": 7
        },
        {
            "index": 46,
            "fname": "get isReg",
            "ret": 2
        },
        {
            "index": 47,
            "cname": "StackSlot",
            "fields": {
                "_index": -5,
                "_byteSize": -5,
                "_kind": -7,
                "_offsetFromFP": 5
            },
            "sfields": {
                "static _offset": 5,
                "const extract": 60,
                "const forEachFast": 62,
                "const forEach": 63
            },
            "methods": [
                48,
                49,
                50,
                51,
                52,
                53,
                54,
                55,
                56,
                57,
                58,
                59
            ]
        },
        {
            "index": 48,
            "fname": "constructor",
            "params": {
                "index": 5,
                "byteSize": 5,
                "kind": 7
            },
            "ret": 47
        },
        {
            "index": 49,
            "fname": "get byteSize",
            "ret": 5
        },
        {
            "index": 50,
            "fname": "get kind",
            "ret": 7
        },
        {
            "index": 51,
            "fname": "get isLocked",
            "ret": 2
        },
        {
            "index": 52,
            "fname": "get isSpill",
            "ret": 2
        },
        {
            "index": 53,
            "fname": "get index",
            "ret": 5
        },
        {
            "index": 54,
            "fname": "ensureSize",
            "params": {
                "size": 5
            }
        },
        {
            "index": 55,
            "fname": "get alignment",
            "ret": 5
        },
        {
            "index": 56,
            "fname": "get offsetFromFP",
            "ret": 5
        },
        {
            "index": 57,
            "fname": "setOffsetFromFP",
            "params": {
                "value": 5
            }
        },
        {
            "index": 58,
            "fname": "hash",
            "ret": 1
        },
        {
            "index": 59,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 60,
            "fname": "static extract",
            "params": {
                "arg": 17
            },
            "ret": 61
        },
        {
            "index": 61,
            "uname": "",
            "types": [
                4,
                47
            ]
        },
        {
            "index": 62,
            "fname": "static forEachFast",
            "params": {
                "arg": 17,
                "func": 0
            },
            "ret": 34
        },
        {
            "index": 63,
            "fname": "static forEach",
            "params": {
                "arg": 17,
                "role": 7,
                "type": 7,
                "width": 5,
                "func": 0
            },
            "ret": 34
        },
        {
            "index": 64,
            "fname": "static isAnyUse",
            "params": {
                "role": 7
            },
            "ret": 2
        },
        {
            "index": 65,
            "fname": "static isColdUse",
            "params": {
                "role": 7
            },
            "ret": 2
        },
        {
            "index": 66,
            "fname": "static isWarmUse",
            "params": {
                "role": 7
            },
            "ret": 2
        },
        {
            "index": 67,
            "fname": "static cooled",
            "params": {
                "role": 7
            },
            "ret": 7
        },
        {
            "index": 68,
            "fname": "static isEarlyUse",
            "params": {
                "role": 7
            },
            "ret": 2
        },
        {
            "index": 69,
            "fname": "static isLateUse",
            "params": {
                "role": 7
            },
            "ret": 2
        },
        {
            "index": 70,
            "fname": "static isAnyDef",
            "params": {
                "role": 7
            },
            "ret": 2
        },
        {
            "index": 71,
            "fname": "static isEarlyDef",
            "params": {
                "role": 7
            },
            "ret": 2
        },
        {
            "index": 72,
            "fname": "static isLateDef",
            "params": {
                "role": 7
            },
            "ret": 2
        },
        {
            "index": 73,
            "fname": "static isZDef",
            "params": {
                "role": 7
            },
            "ret": 2
        },
        {
            "index": 74,
            "fname": "static typeForB3Type",
            "params": {
                "type": 7
            },
            "ret": 7
        },
        {
            "index": 75,
            "fname": "static widthForB3Type",
            "params": {
                "type": 7
            },
            "ret": 5
        },
        {
            "index": 76,
            "fname": "static conservativeWidth",
            "params": {
                "type": 7
            },
            "ret": 5
        },
        {
            "index": 77,
            "fname": "static minimumWidth",
            "params": {
                "type": 7
            },
            "ret": 5
        },
        {
            "index": 78,
            "fname": "static bytes",
            "params": {
                "width": 5
            },
            "ret": 1
        },
        {
            "index": 79,
            "fname": "static widthForBytes",
            "params": {
                "bytes": 5
            },
            "ret": 5
        },
        {
            "index": 80,
            "fname": "static createTmp",
            "params": {
                "tmp": 19
            },
            "ret": 17
        },
        {
            "index": 81,
            "fname": "static fromReg",
            "params": {
                "reg": 19
            },
            "ret": 17
        },
        {
            "index": 82,
            "fname": "static createImm",
            "params": {
                "value": 5
            },
            "ret": 17
        },
        {
            "index": 83,
            "fname": "static createBigImm",
            "params": {
                "lowValue": 5,
                "highValue": 5
            },
            "ret": 17
        },
        {
            "index": 84,
            "fname": "static createBitImm",
            "params": {
                "value": 5
            },
            "ret": 17
        },
        {
            "index": 85,
            "fname": "static createBitImm64",
            "params": {
                "lowValue": 5,
                "highValue": 5
            },
            "ret": 17
        },
        {
            "index": 86,
            "fname": "static createAddr",
            "params": {
                "base": 19,
                "offset": 5
            },
            "ret": 17
        },
        {
            "index": 87,
            "fname": "static createStack",
            "params": {
                "slot": 47,
                "offset": 5
            },
            "ret": 17
        },
        {
            "index": 88,
            "fname": "static createCallArg",
            "params": {
                "offset": 5
            },
            "ret": 17
        },
        {
            "index": 89,
            "fname": "static createStackAddr",
            "params": {
                "offsetFromFP": 5,
                "frameSize": 5,
                "width": 5
            },
            "ret": 17
        },
        {
            "index": 90,
            "fname": "static isValidScale",
            "params": {
                "scale": 5,
                "width": 5
            },
            "ret": 2
        },
        {
            "index": 91,
            "fname": "static logScale",
            "params": {
                "scale": 5
            },
            "ret": 5
        },
        {
            "index": 92,
            "fname": "static createIndex",
            "params": {
                "base": 19,
                "index": 19,
                "scale": 5,
                "offset": 5
            },
            "ret": 17
        },
        {
            "index": 93,
            "fname": "static createRelCond",
            "params": {
                "condition": 7
            },
            "ret": 17
        },
        {
            "index": 94,
            "fname": "static createResCond",
            "params": {
                "condition": 7
            },
            "ret": 17
        },
        {
            "index": 95,
            "fname": "static createDoubleCond",
            "params": {
                "condition": 7
            },
            "ret": 17
        },
        {
            "index": 96,
            "fname": "static createWidth",
            "params": {
                "width": 5
            },
            "ret": 17
        },
        {
            "index": 97,
            "fname": "static createSpecial",
            "ret": 17
        },
        {
            "index": 98,
            "fname": "get kind",
            "ret": 7
        },
        {
            "index": 99,
            "fname": "get isTmp",
            "ret": 2
        },
        {
            "index": 100,
            "fname": "get isImm",
            "ret": 2
        },
        {
            "index": 101,
            "fname": "get isBigImm",
            "ret": 2
        },
        {
            "index": 102,
            "fname": "get isBitImm",
            "ret": 2
        },
        {
            "index": 103,
            "fname": "get isBitImm64",
            "ret": 2
        },
        {
            "index": 104,
            "fname": "get isSomeImm",
            "ret": 2
        },
        {
            "index": 105,
            "fname": "get isSomeBigImm",
            "ret": 2
        },
        {
            "index": 106,
            "fname": "get isAddr",
            "ret": 2
        },
        {
            "index": 107,
            "fname": "get isStack",
            "ret": 2
        },
        {
            "index": 108,
            "fname": "get isCallArg",
            "ret": 2
        },
        {
            "index": 109,
            "fname": "get isIndex",
            "ret": 2
        },
        {
            "index": 110,
            "fname": "get isMemory",
            "ret": 2
        },
        {
            "index": 111,
            "fname": "get isStackMemory",
            "ret": 2
        },
        {
            "index": 112,
            "fname": "get isRelCond",
            "ret": 2
        },
        {
            "index": 113,
            "fname": "get isResCond",
            "ret": 2
        },
        {
            "index": 114,
            "fname": "get isDoubleCond",
            "ret": 2
        },
        {
            "index": 115,
            "fname": "get isCondition",
            "ret": 2
        },
        {
            "index": 116,
            "fname": "get isWidth",
            "ret": 2
        },
        {
            "index": 117,
            "fname": "get isSpecial",
            "ret": 2
        },
        {
            "index": 118,
            "fname": "get isAlive",
            "ret": 2
        },
        {
            "index": 119,
            "fname": "get tmp",
            "ret": 19
        },
        {
            "index": 120,
            "fname": "get value",
            "ret": 5
        },
        {
            "index": 121,
            "fname": "get lowValue",
            "ret": 5
        },
        {
            "index": 122,
            "fname": "get highValue",
            "ret": 5
        },
        {
            "index": 123,
            "fname": "get base",
            "ret": 19
        },
        {
            "index": 124,
            "fname": "get hasOffset",
            "ret": 2
        },
        {
            "index": 125,
            "fname": "get offset",
            "ret": 5
        },
        {
            "index": 126,
            "fname": "get stackSlot",
            "ret": 47
        },
        {
            "index": 127,
            "fname": "get index",
            "ret": 19
        },
        {
            "index": 128,
            "fname": "get scale",
            "ret": 5
        },
        {
            "index": 129,
            "fname": "get logScale",
            "ret": 5
        },
        {
            "index": 130,
            "fname": "get width",
            "ret": 5
        },
        {
            "index": 131,
            "fname": "get isGPTmp",
            "ret": 2
        },
        {
            "index": 132,
            "fname": "get isFPTmp",
            "ret": 2
        },
        {
            "index": 133,
            "fname": "get isGP",
            "ret": 2
        },
        {
            "index": 134,
            "fname": "get isFP",
            "ret": 2
        },
        {
            "index": 135,
            "fname": "get hasType",
            "ret": 2
        },
        {
            "index": 136,
            "fname": "get type",
            "ret": 7
        },
        {
            "index": 137,
            "fname": "isType",
            "params": {
                "type": 7
            },
            "ret": 2
        },
        {
            "index": 138,
            "fname": "isCompatibleType",
            "params": {
                "other": 17
            },
            "ret": 2
        },
        {
            "index": 139,
            "fname": "get isGPR",
            "ret": 2
        },
        {
            "index": 140,
            "fname": "get gpr",
            "ret": 19
        },
        {
            "index": 141,
            "fname": "get isFPR",
            "ret": 2
        },
        {
            "index": 142,
            "fname": "get fpr",
            "ret": 19
        },
        {
            "index": 143,
            "fname": "get isReg",
            "ret": 2
        },
        {
            "index": 144,
            "fname": "get reg",
            "ret": 19
        },
        {
            "index": 145,
            "fname": "static isValidImmForm",
            "params": {
                "value": 5
            },
            "ret": 2
        },
        {
            "index": 146,
            "fname": "static isValidBitImmForm",
            "params": {
                "value": 5
            },
            "ret": 2
        },
        {
            "index": 147,
            "fname": "static isValidBitImm64Form",
            "params": {
                "value": 5
            },
            "ret": 2
        },
        {
            "index": 148,
            "fname": "static isValidAddrForm",
            "params": {
                "offset": 5,
                "width": 5
            },
            "ret": 2
        },
        {
            "index": 149,
            "fname": "static isValidIndexForm",
            "params": {
                "scale": 5,
                "offset": 5,
                "width": 5
            },
            "ret": 2
        },
        {
            "index": 150,
            "fname": "isValidForm",
            "params": {
                "width": 5
            },
            "ret": 2
        },
        {
            "index": 151,
            "fname": "forEachTmpFast",
            "params": {
                "func": 0
            },
            "ret": 34
        },
        {
            "index": 152,
            "fname": "usesTmp",
            "params": {
                "expectedTmp": 19
            },
            "ret": 2
        },
        {
            "index": 153,
            "fname": "forEachTmp",
            "params": {
                "role": 7,
                "type": 7,
                "width": 5,
                "func": 0
            },
            "ret": 34
        },
        {
            "index": 154,
            "fname": "is",
            "params": {
                "thing": 166
            },
            "ret": 2
        },
        {
            "index": 155,
            "cname": "Tmp",
            "supers": {
                "TmpBase": 37
            },
            "fields": {
                "_index": -5,
                "_type": -7
            },
            "sfields": {
                "const fromReg": 157,
                "const extract": 163,
                "const forEachFast": 164,
                "const forEach": 165
            },
            "methods": [
                156,
                158,
                159,
                160,
                161,
                162
            ]
        },
        {
            "index": 156,
            "fname": "constructor",
            "params": {
                "index": 5,
                "type": 7
            },
            "ret": 155,
            "hobj": 1
        },
        {
            "index": 157,
            "fname": "static fromReg",
            "params": {
                "reg": 19
            },
            "ret": 19
        },
        {
            "index": 158,
            "fname": "get index",
            "ret": 5
        },
        {
            "index": 159,
            "fname": "get type",
            "ret": 7
        },
        {
            "index": 160,
            "fname": "get isReg",
            "ret": 2
        },
        {
            "index": 161,
            "fname": "hash",
            "ret": 5
        },
        {
            "index": 162,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 163,
            "fname": "static extract",
            "params": {
                "arg": 17
            },
            "ret": 32
        },
        {
            "index": 164,
            "fname": "static forEachFast",
            "params": {
                "arg": 17,
                "func": 0
            },
            "ret": 34
        },
        {
            "index": 165,
            "fname": "static forEach",
            "params": {
                "arg": 17,
                "role": 7,
                "type": 7,
                "width": 5,
                "func": 0
            },
            "ret": 34
        },
        {
            "index": 166,
            "uname": "",
            "types": [
                18,
                20,
                48,
                156
            ]
        },
        {
            "index": 167,
            "fname": "as",
            "params": {
                "thing": 166
            },
            "ret": 168
        },
        {
            "index": 168,
            "uname": "",
            "types": [
                4,
                17,
                19,
                47
            ]
        },
        {
            "index": 169,
            "fname": "forEachFast",
            "params": {
                "thing": 48,
                "func": 0
            },
            "ret": 34
        },
        {
            "index": 170,
            "fname": "forEach",
            "params": {
                "thing": 48,
                "role": 7,
                "type": 7,
                "width": 5,
                "func": 0
            },
            "ret": 34
        },
        {
            "index": 171,
            "fname": "static extract",
            "params": {
                "arg": 17
            },
            "ret": 17
        },
        {
            "index": 172,
            "fname": "static forEachFast",
            "params": {
                "arg": 17,
                "func": 0
            },
            "ret": 17
        },
        {
            "index": 173,
            "fname": "static forEach",
            "params": {
                "arg": 17,
                "role": 7,
                "type": 7,
                "width": 5,
                "func": 0
            },
            "ret": 17
        },
        {
            "index": 174,
            "fname": "get condition",
            "ret": 7
        },
        {
            "index": 175,
            "fname": "get isInvertible",
            "ret": 2
        },
        {
            "index": 176,
            "fname": "static kindCode",
            "params": {
                "kind": 7
            },
            "ret": 5
        },
        {
            "index": 177,
            "fname": "hash",
            "ret": 1
        },
        {
            "index": 178,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 179,
            "aname": "",
            "element": 17,
            "mode": "normal"
        },
        {
            "index": 180,
            "aname": "",
            "element": 7,
            "mode": "normal"
        },
        {
            "index": 181,
            "bname": "Set"
        },
        {
            "index": 182,
            "oname": "",
            "fields": {
                "role": -7,
                "type": -7,
                "width": -5
            }
        },
        {
            "index": 183,
            "aname": "",
            "element": 182,
            "mode": "normal"
        },
        {
            "index": 184,
            "fname": "append",
            "params": {
                "args": 179
            }
        },
        {
            "index": 185,
            "fname": "clear"
        },
        {
            "index": 186,
            "fname": "get opcode",
            "ret": 7
        },
        {
            "index": 187,
            "fname": "get args",
            "ret": 179
        },
        {
            "index": 188,
            "fname": "visitArg",
            "params": {
                "index": 5,
                "func": 0,
                "r": 7,
                "t": 7,
                "w": 5
            }
        },
        {
            "index": 189,
            "fname": "forEachTmpFast",
            "params": {
                "func": 0
            }
        },
        {
            "index": 190,
            "fname": "forEachArg",
            "params": {
                "func": 0
            }
        },
        {
            "index": 191,
            "fname": "forEachTmp",
            "params": {
                "func": 0
            }
        },
        {
            "index": 192,
            "fname": "forEach",
            "params": {
                "thing": 48,
                "func": 0
            }
        },
        {
            "index": 193,
            "fname": "static forEachDef",
            "params": {
                "thing": 48,
                "prevInst": 15,
                "nextInst": 15,
                "func": 0
            }
        },
        {
            "index": 194,
            "fname": "static forEachDefWithExtraClobberedRegs",
            "params": {
                "thing": 48,
                "prevInst": 15,
                "nextInst": 15,
                "func": 0
            }
        },
        {
            "index": 195,
            "fname": "get hasNonArgEffects",
            "ret": 2
        },
        {
            "index": 196,
            "fname": "hash",
            "ret": 1
        },
        {
            "index": 197,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 198,
            "aname": "",
            "element": 15,
            "mode": "normal"
        },
        {
            "index": 199,
            "cname": "FrequentedBlock",
            "fields": {
                "block": -13,
                "frequency": -7
            },
            "methods": [
                200,
                201
            ]
        },
        {
            "index": 200,
            "fname": "constructor",
            "params": {
                "block": 13,
                "frequency": 7
            },
            "ret": 199
        },
        {
            "index": 201,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 202,
            "aname": "",
            "element": 199,
            "mode": "normal"
        },
        {
            "index": 203,
            "aname": "",
            "element": 13,
            "mode": "normal"
        },
        {
            "index": 204,
            "fname": "get index",
            "ret": 5
        },
        {
            "index": 205,
            "fname": "get size",
            "ret": 5
        },
        {
            "index": 206,
            "fname": "[Symbol.iterator]",
            "ret": 207
        },
        {
            "index": 207,
            "bname": "IterableIterator"
        },
        {
            "index": 208,
            "fname": "at",
            "params": {
                "index": 5
            },
            "ret": 15
        },
        {
            "index": 209,
            "fname": "get",
            "params": {
                "index": 5
            },
            "ret": 210
        },
        {
            "index": 210,
            "uname": "",
            "types": [
                4,
                15
            ]
        },
        {
            "index": 211,
            "fname": "get last",
            "ret": 15
        },
        {
            "index": 212,
            "fname": "get insts",
            "ret": 198
        },
        {
            "index": 213,
            "fname": "append",
            "params": {
                "inst": 15
            }
        },
        {
            "index": 214,
            "fname": "get numSuccessors",
            "ret": 1
        },
        {
            "index": 215,
            "fname": "successor",
            "params": {
                "index": 5
            },
            "ret": 199
        },
        {
            "index": 216,
            "fname": "get successors",
            "ret": 202
        },
        {
            "index": 217,
            "fname": "successorBlock",
            "params": {
                "index": 5
            },
            "ret": 13
        },
        {
            "index": 218,
            "fname": "get successorBlocks",
            "ret": 203
        },
        {
            "index": 219,
            "fname": "get numPredecessors",
            "ret": 1
        },
        {
            "index": 220,
            "fname": "predecessor",
            "params": {
                "index": 5
            },
            "ret": 13
        },
        {
            "index": 221,
            "fname": "get predecessors",
            "ret": 203
        },
        {
            "index": 222,
            "fname": "get frequency",
            "ret": 5
        },
        {
            "index": 223,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 224,
            "fname": "get headerString",
            "ret": 3
        },
        {
            "index": 225,
            "fname": "get footerString",
            "ret": 3
        },
        {
            "index": 226,
            "fname": "toStringDeep",
            "ret": 3
        },
        {
            "index": 227,
            "fname": "addStackSlotIndexed",
            "params": {
                "list": 228,
                "cons": 48,
                "byteSize": 5,
                "kind": 7
            },
            "ret": 47
        },
        {
            "index": 228,
            "aname": "",
            "element": 47,
            "mode": "normal"
        },
        {
            "index": 229,
            "fname": "addTmpIndexed",
            "params": {
                "list": 230,
                "cons": 156,
                "type": 7
            },
            "ret": 155
        },
        {
            "index": 230,
            "aname": "",
            "element": 155,
            "mode": "normal"
        },
        {
            "index": 231,
            "fname": "roundUpToMultipleOf",
            "params": {
                "amount": 5,
                "value": 5
            },
            "ret": 5
        },
        {
            "index": 232,
            "fname": "symbolName",
            "params": {
                "symbol": 7
            },
            "ret": 3
        },
        {
            "index": 233,
            "fname": "lowerSymbolName",
            "params": {
                "symbol": 7
            },
            "ret": 3
        },
        {
            "index": 234,
            "fname": "setToString",
            "params": {
                "set": 181
            },
            "ret": 3
        },
        {
            "index": 235,
            "fname": "mergeIntoSet",
            "params": {
                "target": 181,
                "source": 181
            },
            "ret": 2
        },
        {
            "index": 236,
            "uname": "",
            "types": [
                17,
                47
            ]
        },
        {
            "index": 237,
            "fname": "nonEmptyRangesOverlap",
            "params": {
                "leftMin": 5,
                "leftMax": 5,
                "rightMin": 5,
                "rightMax": 5
            },
            "ret": 2
        },
        {
            "index": 238,
            "fname": "rangesOverlap",
            "params": {
                "leftMin": 5,
                "leftMax": 5,
                "rightMin": 5,
                "rightMax": 5
            },
            "ret": 2
        },
        {
            "index": 239,
            "fname": "removeAllMatching",
            "params": {
                "array": 198,
                "func": 0
            }
        },
        {
            "index": 240,
            "fname": "bubbleSort",
            "params": {
                "array": 247,
                "lessThan": 0
            }
        },
        {
            "index": 241,
            "cname": "Insertion",
            "fields": {
                "_index": -5,
                "_element": -243
            },
            "methods": [
                242,
                244,
                245,
                246
            ]
        },
        {
            "index": 242,
            "fname": "constructor",
            "params": {
                "index": 5,
                "element": 243
            },
            "ret": 241
        },
        {
            "index": 243,
            "bname": "Object"
        },
        {
            "index": 244,
            "fname": "get index",
            "ret": 5
        },
        {
            "index": 245,
            "fname": "get element",
            "ret": 243
        },
        {
            "index": 246,
            "fname": "lessThan",
            "params": {
                "other": 241
            },
            "ret": 2
        },
        {
            "index": 247,
            "aname": "",
            "element": 241,
            "mode": "normal"
        },
        {
            "index": 248,
            "fname": "swap",
            "params": {
                "i": 5,
                "j": 5
            }
        },
        {
            "index": 249,
            "fname": "bubble",
            "params": {
                "i": 5,
                "j": 5
            }
        },
        {
            "index": 250,
            "cname": "InsertionSet",
            "fields": {
                "_insertions": -247
            },
            "methods": [
                251,
                252,
                253,
                254
            ]
        },
        {
            "index": 251,
            "fname": "constructor",
            "ret": 250
        },
        {
            "index": 252,
            "fname": "appendInsertion",
            "params": {
                "insertion": 241
            }
        },
        {
            "index": 253,
            "fname": "append",
            "params": {
                "index": 5,
                "element": 243
            }
        },
        {
            "index": 254,
            "fname": "execute",
            "params": {
                "target": 255
            },
            "ret": 5
        },
        {
            "index": 255,
            "aname": "",
            "element": 243,
            "mode": "normal"
        },
        {
            "index": 256,
            "aname": "",
            "element": 0,
            "mode": "normal"
        },
        {
            "index": 257,
            "fname": "",
            "params": {
                "a": 241,
                "b": 241
            },
            "ret": 2
        },
        {
            "index": 258,
            "cname": "Code",
            "fields": {
                "_blocks": -203,
                "_stackSlots": -228,
                "_gpTmps": -230,
                "_fpTmps": -230,
                "_callArgAreaSize": -5,
                "_frameSize": -5
            },
            "methods": [
                259,
                260,
                261,
                262,
                263,
                264,
                265,
                266,
                267,
                268,
                269,
                270,
                271,
                272,
                273,
                274
            ]
        },
        {
            "index": 259,
            "fname": "constructor",
            "ret": 258
        },
        {
            "index": 260,
            "fname": "addBlock",
            "params": {
                "frequency": 5
            },
            "ret": 13
        },
        {
            "index": 261,
            "fname": "addStackSlot",
            "params": {
                "byteSize": 5,
                "kind": 7
            },
            "ret": 47
        },
        {
            "index": 262,
            "fname": "newTmp",
            "params": {
                "type": 7
            },
            "ret": 155
        },
        {
            "index": 263,
            "fname": "get size",
            "ret": 5
        },
        {
            "index": 264,
            "fname": "at",
            "params": {
                "index": 5
            },
            "ret": 13
        },
        {
            "index": 265,
            "fname": "[Symbol.iterator]",
            "ret": 207
        },
        {
            "index": 266,
            "fname": "get blocks",
            "ret": 203
        },
        {
            "index": 267,
            "fname": "get stackSlots",
            "ret": 228
        },
        {
            "index": 268,
            "fname": "tmps",
            "params": {
                "type": 7
            },
            "ret": 230
        },
        {
            "index": 269,
            "fname": "get callArgAreaSize",
            "ret": 5
        },
        {
            "index": 270,
            "fname": "requestCallArgAreaSize",
            "params": {
                "size": 5
            }
        },
        {
            "index": 271,
            "fname": "get frameSize",
            "ret": 5
        },
        {
            "index": 272,
            "fname": "setFrameSize",
            "params": {
                "frameSize": 5
            }
        },
        {
            "index": 273,
            "fname": "hash",
            "ret": 1
        },
        {
            "index": 274,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 275,
            "uname": "",
            "types": [
                181,
                203
            ]
        },
        {
            "index": 276,
            "fname": "createPayloadTypescriptScanIdentifier",
            "ret": 258
        },
        {
            "index": 277,
            "fname": "Inst_forEachArg",
            "params": {
                "inst": 15,
                "func": 0
            }
        },
        {
            "index": 278,
            "fname": "Inst_hasNonArgEffects",
            "params": {
                "inst": 15
            },
            "ret": 2
        },
        {
            "index": 279,
            "fname": "opcodeCode",
            "params": {
                "opcode": 7
            },
            "ret": 5
        },
        {
            "index": 280,
            "fname": "get",
            "params": {
                "target": 202,
                "property": 281
            },
            "ret": 282
        },
        {
            "index": 281,
            "uname": "",
            "types": [
                1,
                3,
                7
            ]
        },
        {
            "index": 282,
            "uname": "",
            "types": [
                13,
                199
            ]
        },
        {
            "index": 283,
            "fname": "set",
            "params": {
                "target": 202,
                "property": 281,
                "value": 13
            },
            "ret": 2
        },
        {
            "index": 284,
            "oname": "",
            "fields": {
                "get": -280,
                "set": -283
            }
        },
        {
            "index": 285,
            "cname": "LocalCalc",
            "fields": {
                "_liveness": -287,
                "_block": -13,
                "_liveSet": -181
            },
            "methods": [
                286,
                295,
                296
            ]
        },
        {
            "index": 286,
            "fname": "constructor",
            "params": {
                "liveness": 287,
                "block": 13
            },
            "ret": 285
        },
        {
            "index": 287,
            "cname": "Liveness",
            "fields": {
                "_thing": -48,
                "_code": -258,
                "_liveAtHead": -289,
                "_liveAtTail": -289
            },
            "methods": [
                288,
                290,
                291,
                292,
                293,
                294
            ]
        },
        {
            "index": 288,
            "fname": "constructor",
            "params": {
                "thing": 48,
                "code": 258
            },
            "ret": 287
        },
        {
            "index": 289,
            "bname": "Map"
        },
        {
            "index": 290,
            "fname": "get thing",
            "ret": 48
        },
        {
            "index": 291,
            "fname": "get code",
            "ret": 258
        },
        {
            "index": 292,
            "fname": "get liveAtHead",
            "ret": 289
        },
        {
            "index": 293,
            "fname": "get liveAtTail",
            "ret": 289
        },
        {
            "index": 294,
            "fname": "localCalc",
            "params": {
                "block": 13
            },
            "ret": 285
        },
        {
            "index": 295,
            "fname": "get liveSet",
            "ret": 181
        },
        {
            "index": 296,
            "fname": "execute",
            "params": {
                "instIndex": 5
            }
        },
        {
            "index": 297,
            "fname": "",
            "params": {
                "value": 47,
                "role": 7,
                "type": 7,
                "width": 5
            }
        },
        {
            "index": 298,
            "fname": "",
            "params": {
                "value": 47,
                "role": 7,
                "type": 7,
                "width": 5
            }
        },
        {
            "index": 299,
            "fname": "",
            "params": {
                "value": 47,
                "role": 7,
                "type": 7,
                "width": 5
            }
        },
        {
            "index": 300,
            "fname": "",
            "params": {
                "value": 47,
                "role": 7,
                "type": 7,
                "width": 5
            }
        },
        {
            "index": 301,
            "fname": "",
            "params": {
                "value": 47,
                "role": 7,
                "type": 7,
                "width": 5
            }
        },
        {
            "index": 302,
            "fname": "",
            "params": {
                "value": 47,
                "role": 7,
                "type": 7,
                "width": 5
            }
        },
        {
            "index": 303,
            "fname": "forEachArg",
            "params": {
                "inst": 15,
                "func": 0
            }
        },
        {
            "index": 304,
            "fname": "hasNonArgNonControlEffects",
            "params": {
                "inst": 15
            },
            "ret": 2
        },
        {
            "index": 305,
            "oname": "",
            "fields": {
                "forEachArg": -303,
                "hasNonArgNonControlEffects": -304
            }
        },
        {
            "index": 306,
            "fname": "forEachArg",
            "params": {
                "inst": 15,
                "func": 0
            }
        },
        {
            "index": 307,
            "fname": "hasNonArgNonControlEffects",
            "params": {
                "inst": 15
            },
            "ret": 2
        },
        {
            "index": 308,
            "oname": "",
            "fields": {
                "forEachArg": -306,
                "hasNonArgNonControlEffects": -307
            }
        },
        {
            "index": 309,
            "fname": "forEachArg",
            "params": {
                "inst": 15,
                "func": 0
            }
        },
        {
            "index": 310,
            "fname": "hasNonArgNonControlEffects",
            "params": {
                "inst": 15
            },
            "ret": 2
        },
        {
            "index": 311,
            "oname": "",
            "fields": {
                "forEachArg": -309,
                "hasNonArgNonControlEffects": -310
            }
        },
        {
            "index": 312,
            "fname": "forEachArg",
            "params": {
                "inst": 15,
                "func": 0
            }
        },
        {
            "index": 313,
            "fname": "hasNonArgNonControlEffects",
            "params": {
                "inst": 15
            },
            "ret": 2
        },
        {
            "index": 314,
            "oname": "",
            "fields": {
                "forEachArg": -312,
                "hasNonArgNonControlEffects": -313
            }
        },
        {
            "index": 315,
            "fname": "",
            "params": {
                "arg": 17,
                "role": 7,
                "type": 7,
                "width": 5
            },
            "ret": 34
        },
        {
            "index": 316,
            "fname": "",
            "params": {
                "arg": 17,
                "role": 7,
                "type": 7,
                "width": 5
            },
            "ret": 34
        },
        {
            "index": 317,
            "fname": "",
            "params": {
                "arg": 17,
                "role": 7,
                "type": 7,
                "width": 5
            },
            "ret": 34
        },
        {
            "index": 318,
            "fname": "",
            "params": {
                "value": 47,
                "role": 7,
                "type": 7,
                "width": 5
            },
            "ret": 61
        },
        {
            "index": 319,
            "fname": "",
            "params": {
                "value": 47,
                "role": 7,
                "type": 7,
                "width": 5
            },
            "ret": 61
        },
        {
            "index": 320,
            "fname": "",
            "params": {
                "reg": 19
            }
        },
        {
            "index": 321,
            "fname": "createPayloadImagingGaussianBlurGaussianBlur",
            "ret": 258
        },
        {
            "index": 322,
            "fname": "",
            "params": {
                "tmp": 19
            }
        },
        {
            "index": 323,
            "fname": "allocateStack",
            "params": {
                "code": 258
            }
        },
        {
            "index": 324,
            "fname": "attemptAssignment",
            "params": {
                "slot": 47,
                "offsetFromFP": 5,
                "otherSlots": 228
            },
            "ret": 2
        },
        {
            "index": 325,
            "fname": "assign",
            "params": {
                "slot": 47,
                "otherSlots": 228
            }
        },
        {
            "index": 326,
            "fname": "interfere",
            "params": {
                "instIndex": 5
            }
        },
        {
            "index": 327,
            "fname": "",
            "params": {
                "slot": 47,
                "role": 7,
                "type": 7,
                "width": 5
            }
        },
        {
            "index": 328,
            "fname": "",
            "params": {
                "arg": 17,
                "role": 7,
                "type": 7,
                "width": 5
            }
        },
        {
            "index": 329,
            "fname": "",
            "params": {
                "inst": 15
            },
            "ret": 2
        },
        {
            "index": 330,
            "fname": "",
            "params": {
                "arg": 17,
                "role": 7,
                "type": 7,
                "width": 5
            },
            "ret": 34
        },
        {
            "index": 331,
            "fname": "stackAddr",
            "params": {
                "offset": 5
            },
            "ret": 17
        },
        {
            "index": 332,
            "fname": "createPayloadAirJSACLj8C",
            "ret": 258
        },
        {
            "index": 333,
            "fname": "",
            "params": {
                "tmp": 19
            },
            "ret": 32
        },
        {
            "index": 334,
            "fname": "",
            "params": {
                "tmp": 19,
                "role": 7,
                "type": 7,
                "width": 5
            },
            "ret": 32
        },
        {
            "index": 335,
            "fname": "newReg",
            "params": {
                "index": 5,
                "type": 7,
                "name": 3,
                "isCalleeSave": 21
            },
            "ret": 19
        },
        {
            "index": 336,
            "fname": "newGPR",
            "params": {
                "name": 3,
                "isCalleeSave": 21
            },
            "ret": 19
        },
        {
            "index": 337,
            "fname": "createPayloadGbemuExecuteIteration",
            "ret": 258
        },
        {
            "index": 338,
            "uname": "",
            "types": [
                3,
                258
            ]
        },
        {
            "index": 339,
            "cname": "Benchmark",
            "fields": {
                "_verbose": -2,
                "_payloads": -342
            },
            "methods": [
                340,
                343
            ]
        },
        {
            "index": 340,
            "fname": "constructor",
            "params": {
                "verbose": 5
            },
            "ret": 339
        },
        {
            "index": 341,
            "oname": "",
            "fields": {
                "generate": -0,
                "earlyHash": -1,
                "lateHash": -1
            }
        },
        {
            "index": 342,
            "aname": "",
            "element": 341,
            "mode": "normal"
        },
        {
            "index": 343,
            "fname": "runIteration"
        },
        {
            "index": 344,
            "oname": "",
            "fields": {
                "generate": -337,
                "earlyHash": -5,
                "lateHash": -5
            }
        },
        {
            "index": 345,
            "oname": "",
            "fields": {
                "generate": -321,
                "earlyHash": -1,
                "lateHash": -5
            }
        },
        {
            "index": 346,
            "oname": "",
            "fields": {
                "generate": -276,
                "earlyHash": -5,
                "lateHash": -5
            }
        },
        {
            "index": 347,
            "oname": "",
            "fields": {
                "generate": -332,
                "earlyHash": -5,
                "lateHash": -1
            }
        },
        {
            "index": 348,
            "fname": "static now",
            "ret": 1
        },
        {
            "index": 349,
            "fname": "summation",
            "params": {
                "values": 255
            },
            "ret": 5
        },
        {
            "index": 350,
            "fname": "toScore",
            "params": {
                "timeValue": 243
            },
            "ret": 1
        },
        {
            "index": 351,
            "fname": "mean",
            "params": {
                "values": 255
            },
            "ret": 1
        },
        {
            "index": 352,
            "fname": "assert",
            "params": {
                "condition": 2
            }
        },
        {
            "index": 353,
            "fname": "processResults",
            "params": {
                "results": 255
            }
        },
        {
            "index": 354,
            "fname": "copyArray",
            "params": {
                "a": 255
            },
            "ret": 255
        },
        {
            "index": 355,
            "fname": "",
            "params": {
                "a": 243,
                "b": 243
            },
            "ret": 5
        },
        {
            "index": 356,
            "fname": "printScore"
        },
        {
            "index": 357,
            "fname": "main"
        }
    ]
}*/
"use strict";
/*
 * Copyright (C) 2016 Apple Inc. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY APPLE INC. ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE INC. OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
var air;
(function (air) {
    // This file is for misc symbols.
    // B3 types
    const /*<@7>*/Void = Symbol("Void");
    const /*<@7>*/Int32 = Symbol("Int32");
    const /*<@7>*/Int64 = Symbol("Int64");
    const /*<@7>*/Float = Symbol("Float");
    const /*<@7>*/Double = Symbol("Double");
    // Arg type
    const /*<@7>*/GP = Symbol("GP");
    const /*<@7>*/FP = Symbol("FP");
    // Stack slot kind
    const /*<@7>*/Locked = Symbol("Locked");
    const /*<@7>*/Spill = Symbol("Spill");
    // Frequency class
    const /*<@7>*/Normal = Symbol("Normal");
    const /*<@7>*/Rare = Symbol("Rare");
    // Relational conditions
    const /*<@7>*/Equal = Symbol("Equal");
    const /*<@7>*/NotEqual = Symbol("NotEqual");
    const /*<@7>*/Above = Symbol("Above");
    const /*<@7>*/AboveOrEqual = Symbol("AboveOrEqual");
    const /*<@7>*/Below = Symbol("Below");
    const /*<@7>*/BelowOrEqual = Symbol("BelowOrEqual");
    const /*<@7>*/GreaterThan = Symbol("GreaterThan");
    const /*<@7>*/GreaterThanOrEqual = Symbol("GreaterThanOrEqual");
    const /*<@7>*/LessThan = Symbol("LessThan");
    const /*<@7>*/LessThanOrEqual = Symbol("LessThanOrEqual");
    function /*<@8>*/relCondCode(/*<@7>*/cond) {
        switch (cond) {
            case Equal:
                return 4;
            case NotEqual:
                return 5;
            case Above:
                return 7;
            case AboveOrEqual:
                return 3;
            case Below:
                return 2;
            case BelowOrEqual:
                return 6;
            case GreaterThan:
                return 15;
            case GreaterThanOrEqual:
                return 13;
            case LessThan:
                return 12;
            case LessThanOrEqual:
                return 14;
            default:
                throw new Error("Bad rel cond");
        }
    }
    // Result conditions
    const /*<@7>*/Overflow = Symbol("Overflow");
    const /*<@7>*/Signed = Symbol("Signed");
    const /*<@7>*/PositiveOrZero = Symbol("PositiveOrZero");
    const /*<@7>*/Zero = Symbol("Zero");
    const /*<@7>*/NonZero = Symbol("NonZero");
    function /*<@9>*/resCondCode(/*<@7>*/cond) {
        switch (cond) {
            case Overflow:
                return 0;
            case Signed:
                return 8;
            case PositiveOrZero:
                return 9;
            case Zero:
                return 4;
            case NonZero:
                return 5;
            default:
                throw new Error("Bad res cond: " + cond.toString());
        }
    }
    // Double conditions
    const /*<@7>*/DoubleEqual = Symbol("DoubleEqual");
    const /*<@7>*/DoubleNotEqual = Symbol("DoubleNotEqual");
    const /*<@7>*/DoubleGreaterThan = Symbol("DoubleGreaterThan");
    const /*<@7>*/DoubleGreaterThanOrEqual = Symbol("DoubleGreaterThanOrEqual");
    const /*<@7>*/DoubleLessThan = Symbol("DoubleLessThan");
    const /*<@7>*/DoubleLessThanOrEqual = Symbol("DoubleLessThanOrEqual");
    const /*<@7>*/DoubleEqualOrUnordered = Symbol("DoubleEqualOrUnordered");
    const /*<@7>*/DoubleNotEqualOrUnordered = Symbol("DoubleNotEqualOrUnordered");
    const /*<@7>*/DoubleGreaterThanOrUnordered = Symbol("DoubleGreaterThanOrUnordered");
    const /*<@7>*/DoubleGreaterThanOrEqualOrUnordered = Symbol("DoubleGreaterThanOrEqualOrUnordered");
    const /*<@7>*/DoubleLessThanOrUnordered = Symbol("DoubleLessThanOrUnordered");
    const /*<@7>*/DoubleLessThanOrEqualOrUnordered = Symbol("DoubleLessThanOrEqualOrUnordered");
    function /*<@10>*/doubleCondCode(/*<@7>*/cond) {
        const /*<@5>*/bitInvert = 0x10;
        const /*<@5>*/bitSpecial = 0x20;
        switch (cond) {
            case DoubleEqual:
                return 4 | bitSpecial;
            case DoubleNotEqual:
                return 5;
            case DoubleGreaterThan:
                return 7;
            case DoubleGreaterThanOrEqual:
                return 3;
            case DoubleLessThan:
                return 7 | bitInvert;
            case DoubleLessThanOrEqual:
                return 3 | bitInvert;
            case DoubleEqualOrUnordered:
                return 4;
            case DoubleNotEqualOrUnordered:
                return 5 | bitSpecial;
            case DoubleGreaterThanOrUnordered:
                return 2 | bitInvert;
            case DoubleGreaterThanOrEqualOrUnordered:
                return 6 | bitInvert;
            case DoubleLessThanOrUnordered:
                return 2;
            case DoubleLessThanOrEqualOrUnordered:
                return 6;
            default:
                throw new Error("Bad cond");
        }
    }
    // Define pointerType()
    const /*<@5>*/Ptr = 64;
    function /*<@11>*/isRepresentableAsInt32(/*<@5>*/value) {
        return (value | 0) === value;
    }
    /*
    function addIndexed(list: (BasicBlock | StackSlot | Tmp)[], cons: typeof BasicBlock | typeof StackSlot | typeof Tmp, ...args: Object[])
    {
        let result = new cons(list.length, ...args);
        list.push(result);
        return result;
    }
    */
    function /*<@12>*/addBasicBlockIndexed(/*<@203>*/list, /*<@14>*/cons, /*<@5>*/frequency) {
        let /*<@13>*/result = new cons(list.length, frequency);
        list.push(result);
        return result;
    }
    function /*<@227>*/addStackSlotIndexed(/*<@228>*/list, /*<@48>*/cons, /*<@5>*/byteSize, /*<@7>*/kind) {
        let /*<@47>*/result = new cons(list.length, byteSize, kind);
        list.push(result);
        return result;
    }
    function /*<@229>*/addTmpIndexed(/*<@230>*/list, /*<@156>*/cons, /*<@7>*/type) {
        let /*<@155>*/result = new cons(list.length, type);
        list.push(result);
        return result;
    }
    const /*<@5>*/stackAlignmentBytes = 16;
    function /*<@231>*/roundUpToMultipleOf(/*<@5>*/amount, /*<@5>*/value) {
        return Math.ceil(value / amount) * amount;
    }
    function /*<@232>*/symbolName(/*<@7>*/symbol) {
        let /*<@3>*/fullString = symbol.toString();
        return fullString.substring("Symbol(".length, fullString.length - ")".length);
    }
    function /*<@233>*/lowerSymbolName(/*<@7>*/symbol) {
        return symbolName(symbol).toLowerCase();
    }
    function /*<@234>*/setToString(/*<@181>*/set) {
        let /*<@3>*/result = "";
        for (let /*<@3>*/value of set) {
            if (result)
                result += ", ";
            result += value;
        }
        return result;
    }
    function /*<@235>*/mergeIntoSet(/*<@181>*/target, /*<@181>*/source) {
        let /*<@2>*/didAdd = false;
        for (let /*<@236>*/value of source) {
            if (target.has(value))
                continue;
            target.add(value);
            didAdd = true;
        }
        return didAdd;
    }
    function /*<@237>*/nonEmptyRangesOverlap(/*<@5>*/leftMin, /*<@5>*/leftMax, /*<@5>*/rightMin, /*<@5>*/rightMax) {
        if (leftMin >= leftMax)
            throw new Error("Bad left range");
        if (rightMin >= rightMax)
            throw new Error("Bad right range");
        if (leftMin <= rightMin && leftMax > rightMin)
            return true;
        if (rightMin <= leftMin && rightMax > leftMin)
            return true;
        return false;
    }
    function /*<@238>*/rangesOverlap(/*<@5>*/leftMin, /*<@5>*/leftMax, /*<@5>*/rightMin, /*<@5>*/rightMax) {
        if (leftMin > leftMax)
            throw new Error("Bad left range");
        if (rightMin > rightMax)
            throw new Error("Bad right range");
        if (leftMin == leftMax)
            return false;
        if (rightMin == rightMax)
            return false;
        return nonEmptyRangesOverlap(leftMin, leftMax, rightMin, rightMax);
    }
    function /*<@239>*/removeAllMatching(/*<@198>*/array, func) {
        let /*<@5>*/srcIndex = 0;
        let /*<@5>*/dstIndex = 0;
        while (srcIndex < array.length) {
            let /*<@15>*/value = array[srcIndex++];
            if (!func(value))
                array[dstIndex++] = value;
        }
        array.length = dstIndex;
    }
    function /*<@240>*/bubbleSort(/*<@247>*/array, lessThan) {
        function /*<@248>*/swap(/*<@5>*/i, /*<@5>*/j) {
            var /*<@241>*/tmp = array[i];
            array[i] = array[j];
            array[j] = tmp;
        }
        let /*<@5>*/begin = 0;
        let /*<@5>*/end = array./*<@5>*/length;
        for (;;) {
            let /*<@2>*/changed = false;
            function /*<@249>*/bubble(/*<@5>*/i, /*<@5>*/j) {
                if (lessThan(array[i], array[j])) {
                    swap(i, j);
                    changed = true;
                }
            }
            if (end < begin)
                throw new Error("Begin and end are messed up");
            let /*<@5>*/limit = end - begin;
            for (let /*<@5>*/i = limit; i-- > 1;)
                bubble(begin + i, begin + i - 1);
            if (!changed)
                return;
            // After one run, the first element in the list is guaranteed to be the smallest.
            begin++;
            // Now go in the other direction. This eliminates most sorting pathologies.
            changed = false;
            if (end < begin)
                throw new Error("Begin and end are messed up");
            limit = end - begin;
            for (let /*<@5>*/i = 1; i < limit; ++i)
                bubble(begin + i, begin + i - 1);
            if (!changed)
                return;
            // Now the last element is guaranteed to be the largest.
            end--;
        }
    }
    /*
     * Copyright (C) 2016 Apple Inc. All rights reserved.
     *
     * Redistribution and use in source and binary forms, with or without
     * modification, are permitted provided that the following conditions
     * are met:
     * 1. Redistributions of source code must retain the above copyright
     *    notice, this list of conditions and the following disclaimer.
     * 2. Redistributions in binary form must reproduce the above copyright
     *    notice, this list of conditions and the following disclaimer in the
     *    documentation and/or other materials provided with the distribution.
     *
     * THIS SOFTWARE IS PROVIDED BY APPLE INC. ``AS IS'' AND ANY
     * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
     * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
     * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE INC. OR
     * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
     * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
     * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
     * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
     * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
     * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
     * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
     */
    class /*<@242>*/Insertion {
        constructor(/*<@5>*/index, /*<@243>*/element) {
            this._index = index;
            this._element = element;
        }
        get /*<@244>*/index() { return this._index; }
        get /*<@245>*/element() { return this._element; }
        /*<@246>*/lessThan(/*<@241>*/other) {
            return this._index < other._index;
        }
    }
    class /*<@251>*/InsertionSet {
        constructor() {
            this._insertions = /*<@256>*/[];
        }
        /*<@252>*/appendInsertion(/*<@241>*/insertion) {
            this._insertions.push(insertion);
        }
        /*<@253>*/append(/*<@5>*/index, /*<@243>*/element) {
            this.appendInsertion(new Insertion(index, element));
        }
        /*<@254>*/execute(/*<@255>*/target) {
            // We bubble-sort because that's what the C++ code, and for the same reason as we do it:
            // the stdlib doesn't have a stable sort and mergesort is slower in the common case of the
            // array usually being sorted. This array is usually sorted.
            bubbleSort(this._insertions, /*<@257>*/(/*<@241>*/a, /*<@241>*/b) => (a.lessThan(b)));
            let /*<@5>*/numInsertions = this._insertions./*<@5>*/length;
            if (!numInsertions)
                return 0;
            let /*<@5>*/originalTargetSize = target./*<@5>*/length;
            target.length += numInsertions;
            let /*<@5>*/lastIndex = target./*<@5>*/length;
            for (let /*<@5>*/indexInInsertions = numInsertions; indexInInsertions--;) {
                let /*<@241>*/insertion = this._insertions[indexInInsertions];
                if (indexInInsertions && insertion.index < this._insertions[indexInInsertions - 1].index)
                    throw new Error("Insertions out of order");
                if (insertion.index > originalTargetSize)
                    throw new Error("Out-of-bounds insertion");
                let /*<@5>*/firstIndex = insertion.index + indexInInsertions;
                let /*<@5>*/indexOffset = indexInInsertions + 1;
                for (let /*<@5>*/i = lastIndex; --i > firstIndex;)
                    target[i] = target[i - indexOffset];
                target[firstIndex] = insertion.element;
                lastIndex = firstIndex;
            }
            this._insertions = /*<@256>*/[];
            return numInsertions;
        }
    }
    class /*<@37>*/TmpBase {
        get /*<@38>*/isGP() { return this.type == GP; }
        get /*<@39>*/isFP() { return this.type == FP; }
        get /*<@40>*/isGPR() { return this.isReg && this.isGP; }
        get /*<@41>*/isFPR() { return this.isReg && this.isFP; }
        get /*<@42>*/reg() {
            if (!this.isReg)
                throw new Error("Called .reg on non-Reg");
            return this;
        }
        get /*<@43>*/gpr() {
            if (!this.isGPR)
                throw new Error("Called .gpr on non-GPR");
            return this;
        }
        get /*<@44>*/fpr() {
            if (!this.isFPR)
                throw new Error("Called .fpr on non-FPR");
            return this;
        }
        get /*<@45>*/type() {
            return this._type;
        }
        get /*<@46>*/isReg() {
            return this._isReg;
        }
    }
    class /*<@156>*/Tmp extends TmpBase {
        constructor(/*<@5>*/index, /*<@7>*/type) {
            super();
            this._index = index;
            this._type = type;
        }
        static /*<@157>*/fromReg(/*<@19>*/reg) {
            return reg;
        }
        get /*<@158>*/index() { return this._index; }
        get /*<@159>*/type() { return this._type; }
        get /*<@160>*/isReg() { return false; }
        /*<@161>*/hash() {
            if (this.isGP)
                return Reg.gprs[Reg.gprs.length - 1].hash() + 1 + this._index;
            return Reg.fprs[Reg.fprs.length - 1].hash() - 1 - this._index;
        }
        /*<@162>*/toString() {
            return "%" + (this.isGP ? "" : "f") + "tmp" + this._index;
        }
        static /*<@163>*/extract(/*<@17>*/arg) {
            if (arg.isTmp)
                return arg.tmp;
            return null;
        }
        static /*<@164>*/forEachFast(/*<@17>*/arg, func) { return arg.forEachTmpFast(func); }
        static /*<@165>*/forEach(/*<@17>*/arg, /*<@7>*/role, /*<@7>*/type, /*<@5>*/width, func) { return arg.forEachTmp(role, type, width, func); }
    }
    class /*<@259>*/Code {
        constructor() {
            this._blocks = /*<@256>*/[];
            this._stackSlots = /*<@256>*/[];
            this._gpTmps = /*<@256>*/[];
            this._fpTmps = /*<@256>*/[];
            this._callArgAreaSize = 0;
            this._frameSize = 0;
        }
        /*<@260>*/addBlock(/*<@5>*/frequency = 1) {
            return addBasicBlockIndexed(this._blocks, BasicBlock, frequency);
        }
        /*<@261>*/addStackSlot(/*<@5>*/byteSize, /*<@7>*/kind) {
            return addStackSlotIndexed(this._stackSlots, StackSlot, byteSize, kind);
        }
        /*<@262>*/newTmp(/*<@7>*/type) {
            return addTmpIndexed(/*<@243>*/this[(`_${lowerSymbolName(type)}Tmps`)], Tmp, type);
        }
        get /*<@263>*/size() { return this._blocks./*<@5>*/length; }
        /*<@264>*/at(/*<@5>*/index) { return this._blocks[index]; }
        [Symbol.iterator]() {
            return this._blocks[Symbol.iterator]();
        }
        get /*<@266>*/blocks() { return this._blocks; }
        get /*<@267>*/stackSlots() { return this._stackSlots; }
        /*<@268>*/tmps(/*<@7>*/type) { return this[`_${lowerSymbolName(type)}Tmps`]; }
        get /*<@269>*/callArgAreaSize() { return this._callArgAreaSize; }
        /*<@270>*/requestCallArgAreaSize(/*<@5>*/size) {
            this._callArgAreaSize = Math.max(this._callArgAreaSize, roundUpToMultipleOf(stackAlignmentBytes, size));
        }
        get /*<@271>*/frameSize() { return this._frameSize; }
        /*<@272>*/setFrameSize(/*<@5>*/frameSize) { this._frameSize = frameSize; }
        /*<@273>*/hash() {
            let /*<@5>*/result = 0;
            for (let /*<@13>*/block of this) {
                result *= 1000001;
                result |= 0;
                for (let /*<@15>*/inst of block) {
                    result *= 97;
                    result |= 0;
                    result += inst.hash();
                    result |= 0;
                }
                let /*<@275>*/successorBlocks = block.successorBlocks;
                for (let /*<@13>*/successor of successorBlocks) {
                    result *= 7;
                    result |= 0;
                    result += successor.index;
                    result |= 0;
                }
            }
            for (let /*<@47>*/slot of this.stackSlots) {
                result *= 101;
                result |= 0;
                result += slot.hash();
                result |= 0;
            }
            return result >>> 0;
        }
        /*<@274>*/toString() {
            let /*<@3>*/result = "";
            for (let /*<@13>*/block of this) {
                result += block.toStringDeep();
            }
            if (this.stackSlots.length) {
                result += "Stack slots:\n";
                for (let /*<@47>*/slot of this.stackSlots)
                    result += `    ${slot}\n`;
            }
            if (this._frameSize)
                result += `Frame size: ${this._frameSize}\n`;
            if (this._callArgAreaSize)
                result += `Call arg area size: ${this._callArgAreaSize}\n`;
            return result;
        }
    }
    /*
     * Copyright (C) 2016 Apple Inc. All rights reserved.
     *
     * Redistribution and use in source and binary forms, with or without
     * modification, are permitted provided that the following conditions
     * are met:
     * 1. Redistributions of source code must retain the above copyright
     *    notice, this list of conditions and the following disclaimer.
     * 2. Redistributions in binary form must reproduce the above copyright
     *    notice, this list of conditions and the following disclaimer in the
     *    documentation and/or other materials provided with the distribution.
     *
     * THIS SOFTWARE IS PROVIDED BY APPLE INC. ``AS IS'' AND ANY
     * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
     * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
     * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE INC. OR
     * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
     * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
     * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
     * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
     * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
     * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
     * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
     */
    class /*<@200>*/FrequentedBlock {
        constructor(/*<@13>*/block, /*<@7>*/frequency) {
            this.block = block;
            this.frequency = frequency;
        }
        /*<@201>*/toString() {
            return (this.frequency == Normal ? "" : "Rare:") + this.block;
        }
    }
    // Generated by Air::dumpAsJS from scanIdentifier#EPcFQe in Octane/typescript
    function /*<@276>*/createPayloadTypescriptScanIdentifier() {
        let /*<@258>*/code = new Code();
        let /*<@13>*/bb0 = code.addBlock();
        let /*<@13>*/bb1 = code.addBlock();
        let /*<@13>*/bb2 = code.addBlock();
        let /*<@13>*/bb3 = code.addBlock();
        let /*<@13>*/bb4 = code.addBlock();
        let /*<@13>*/bb5 = code.addBlock();
        let /*<@13>*/bb6 = code.addBlock();
        let /*<@13>*/bb7 = code.addBlock();
        let /*<@13>*/bb8 = code.addBlock();
        let /*<@13>*/bb9 = code.addBlock();
        let /*<@13>*/bb10 = code.addBlock();
        let /*<@13>*/bb11 = code.addBlock();
        let /*<@13>*/bb12 = code.addBlock();
        let /*<@13>*/bb13 = code.addBlock();
        let /*<@13>*/bb14 = code.addBlock();
        let /*<@13>*/bb15 = code.addBlock();
        let /*<@13>*/bb16 = code.addBlock();
        let /*<@13>*/bb17 = code.addBlock();
        let /*<@13>*/bb18 = code.addBlock();
        let /*<@13>*/bb19 = code.addBlock();
        let /*<@13>*/bb20 = code.addBlock();
        let /*<@13>*/bb21 = code.addBlock();
        let /*<@13>*/bb22 = code.addBlock();
        let /*<@13>*/bb23 = code.addBlock();
        let /*<@13>*/bb24 = code.addBlock();
        let /*<@13>*/bb25 = code.addBlock();
        let /*<@13>*/bb26 = code.addBlock();
        let /*<@13>*/bb27 = code.addBlock();
        let /*<@13>*/bb28 = code.addBlock();
        let /*<@13>*/bb29 = code.addBlock();
        let /*<@13>*/bb30 = code.addBlock();
        let /*<@13>*/bb31 = code.addBlock();
        let /*<@13>*/bb32 = code.addBlock();
        let /*<@13>*/bb33 = code.addBlock();
        let /*<@13>*/bb34 = code.addBlock();
        let /*<@47>*/slot0 = code.addStackSlot(56, Locked);
        let /*<@47>*/slot1 = code.addStackSlot(8, Spill);
        let /*<@47>*/slot2 = code.addStackSlot(8, Spill);
        let /*<@47>*/slot3 = code.addStackSlot(8, Spill);
        let /*<@47>*/slot4 = code.addStackSlot(8, Spill);
        let /*<@47>*/slot5 = code.addStackSlot(4, Spill);
        let /*<@47>*/slot6 = code.addStackSlot(8, Spill);
        let /*<@47>*/slot7 = code.addStackSlot(8, Spill);
        let /*<@47>*/slot8 = code.addStackSlot(8, Spill);
        let /*<@47>*/slot9 = code.addStackSlot(40, Locked);
        slot9.setOffsetFromFP(-40);
        let /*<@155>*/tmp98 = code.newTmp(GP);
        let /*<@155>*/tmp97 = code.newTmp(GP);
        let /*<@155>*/tmp96 = code.newTmp(GP);
        let /*<@155>*/tmp95 = code.newTmp(GP);
        let /*<@155>*/tmp94 = code.newTmp(GP);
        let /*<@155>*/tmp93 = code.newTmp(GP);
        let /*<@155>*/tmp92 = code.newTmp(GP);
        let /*<@155>*/tmp91 = code.newTmp(GP);
        let /*<@155>*/tmp90 = code.newTmp(GP);
        let /*<@155>*/tmp89 = code.newTmp(GP);
        let /*<@155>*/tmp88 = code.newTmp(GP);
        let /*<@155>*/tmp87 = code.newTmp(GP);
        let /*<@155>*/tmp86 = code.newTmp(GP);
        let /*<@155>*/tmp85 = code.newTmp(GP);
        let /*<@155>*/tmp84 = code.newTmp(GP);
        let /*<@155>*/tmp83 = code.newTmp(GP);
        let /*<@155>*/tmp82 = code.newTmp(GP);
        let /*<@155>*/tmp81 = code.newTmp(GP);
        let /*<@155>*/tmp80 = code.newTmp(GP);
        let /*<@155>*/tmp79 = code.newTmp(GP);
        let /*<@155>*/tmp78 = code.newTmp(GP);
        let /*<@155>*/tmp77 = code.newTmp(GP);
        let /*<@155>*/tmp76 = code.newTmp(GP);
        let /*<@155>*/tmp75 = code.newTmp(GP);
        let /*<@155>*/tmp74 = code.newTmp(GP);
        let /*<@155>*/tmp73 = code.newTmp(GP);
        let /*<@155>*/tmp72 = code.newTmp(GP);
        let /*<@155>*/tmp71 = code.newTmp(GP);
        let /*<@155>*/tmp70 = code.newTmp(GP);
        let /*<@155>*/tmp69 = code.newTmp(GP);
        let /*<@155>*/tmp68 = code.newTmp(GP);
        let /*<@155>*/tmp67 = code.newTmp(GP);
        let /*<@155>*/tmp66 = code.newTmp(GP);
        let /*<@155>*/tmp65 = code.newTmp(GP);
        let /*<@155>*/tmp64 = code.newTmp(GP);
        let /*<@155>*/tmp63 = code.newTmp(GP);
        let /*<@155>*/tmp62 = code.newTmp(GP);
        let /*<@155>*/tmp61 = code.newTmp(GP);
        let /*<@155>*/tmp60 = code.newTmp(GP);
        let /*<@155>*/tmp59 = code.newTmp(GP);
        let /*<@155>*/tmp58 = code.newTmp(GP);
        let /*<@155>*/tmp57 = code.newTmp(GP);
        let /*<@155>*/tmp56 = code.newTmp(GP);
        let /*<@155>*/tmp55 = code.newTmp(GP);
        let /*<@155>*/tmp54 = code.newTmp(GP);
        let /*<@155>*/tmp53 = code.newTmp(GP);
        let /*<@155>*/tmp52 = code.newTmp(GP);
        let /*<@155>*/tmp51 = code.newTmp(GP);
        let /*<@155>*/tmp50 = code.newTmp(GP);
        let /*<@155>*/tmp49 = code.newTmp(GP);
        let /*<@155>*/tmp48 = code.newTmp(GP);
        let /*<@155>*/tmp47 = code.newTmp(GP);
        let /*<@155>*/tmp46 = code.newTmp(GP);
        let /*<@155>*/tmp45 = code.newTmp(GP);
        let /*<@155>*/tmp44 = code.newTmp(GP);
        let /*<@155>*/tmp43 = code.newTmp(GP);
        let /*<@155>*/tmp42 = code.newTmp(GP);
        let /*<@155>*/tmp41 = code.newTmp(GP);
        let /*<@155>*/tmp40 = code.newTmp(GP);
        let /*<@155>*/tmp39 = code.newTmp(GP);
        let /*<@155>*/tmp38 = code.newTmp(GP);
        let /*<@155>*/tmp37 = code.newTmp(GP);
        let /*<@155>*/tmp36 = code.newTmp(GP);
        let /*<@155>*/tmp35 = code.newTmp(GP);
        let /*<@155>*/tmp34 = code.newTmp(GP);
        let /*<@155>*/tmp33 = code.newTmp(GP);
        let /*<@155>*/tmp32 = code.newTmp(GP);
        let /*<@155>*/tmp31 = code.newTmp(GP);
        let /*<@155>*/tmp30 = code.newTmp(GP);
        let /*<@155>*/tmp29 = code.newTmp(GP);
        let /*<@155>*/tmp28 = code.newTmp(GP);
        let /*<@155>*/tmp27 = code.newTmp(GP);
        let /*<@155>*/tmp26 = code.newTmp(GP);
        let /*<@155>*/tmp25 = code.newTmp(GP);
        let /*<@155>*/tmp24 = code.newTmp(GP);
        let /*<@155>*/tmp23 = code.newTmp(GP);
        let /*<@155>*/tmp22 = code.newTmp(GP);
        let /*<@155>*/tmp21 = code.newTmp(GP);
        let /*<@155>*/tmp20 = code.newTmp(GP);
        let /*<@155>*/tmp19 = code.newTmp(GP);
        let /*<@155>*/tmp18 = code.newTmp(GP);
        let /*<@155>*/tmp17 = code.newTmp(GP);
        let /*<@155>*/tmp16 = code.newTmp(GP);
        let /*<@155>*/tmp15 = code.newTmp(GP);
        let /*<@155>*/tmp14 = code.newTmp(GP);
        let /*<@155>*/tmp13 = code.newTmp(GP);
        let /*<@155>*/tmp12 = code.newTmp(GP);
        let /*<@155>*/tmp11 = code.newTmp(GP);
        let /*<@155>*/tmp10 = code.newTmp(GP);
        let /*<@155>*/tmp9 = code.newTmp(GP);
        let /*<@155>*/tmp8 = code.newTmp(GP);
        let /*<@155>*/tmp7 = code.newTmp(GP);
        let /*<@155>*/tmp6 = code.newTmp(GP);
        let /*<@155>*/tmp5 = code.newTmp(GP);
        let /*<@155>*/tmp4 = code.newTmp(GP);
        let /*<@155>*/tmp3 = code.newTmp(GP);
        let /*<@155>*/tmp2 = code.newTmp(GP);
        let /*<@155>*/tmp1 = code.newTmp(GP);
        let /*<@155>*/tmp0 = code.newTmp(GP);
        let /*<@15>*/inst;
        let /*<@17>*/arg;
        bb0.successors.push(new FrequentedBlock(bb5, Normal));
        bb0.successors.push(new FrequentedBlock(bb4, Normal));
        inst = new Inst(Move);
        arg = Arg.createBigImm(177329888, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rbp, 16);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbp);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.extraEarlyClobberedRegs.add(Reg.r11);
        inst.extraClobberedRegs.add(Reg.r11);
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Scratch, type: GP, width: 64 });
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rbp, 40);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(2, -65536);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r15);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r15);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb0.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(NotEqual);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rbx, 5);
        inst.args.push(arg);
        arg = Arg.createImm(21);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 8 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 8 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb0.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(NotEqual);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rbx, 0);
        inst.args.push(arg);
        arg = Arg.createImm(2540);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rbx, 72);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Compare32);
        arg = Arg.createRelCond(Equal);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createImm(92);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move32);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(154991936, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(NotEqual);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rcx, 0);
        inst.args.push(arg);
        arg = Arg.createImm(80);
        inst.args.push(arg);
        arg = Arg.createBigImm(154991936, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(154991944, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rcx, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move32);
        arg = Arg.createAddr(Reg.r12, -8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(AboveOrEqual);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        bb0.append(inst);
        inst = new Inst(Move32);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createIndex(Reg.r12, Reg.rax, 8, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createImm(10);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r13);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(MoveConditionallyTest64);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createImm(-1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r13);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Xor64);
        arg = Arg.createImm(6);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createImm(-2);
        inst.args.push(arg);
        arg = Arg.createStack(slot2, 0);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createImm(-2);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createImm(1);
        inst.args.push(arg);
        arg = Arg.createStack(slot1, 0);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(129987312, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createStack(slot4, 0);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(108418352, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(0, -65536);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r14);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createImm(1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(BranchTest64);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        bb0.append(inst);
        bb1.predecessors.push(bb6);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        bb1.append(inst);
        inst = new Inst(Oops);
        bb1.append(inst);
        bb2.predecessors.push(bb23);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        bb2.append(inst);
        inst = new Inst(Oops);
        bb2.append(inst);
        bb3.predecessors.push(bb32);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        bb3.append(inst);
        inst = new Inst(Oops);
        bb3.append(inst);
        bb4.predecessors.push(bb0);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        bb4.append(inst);
        inst = new Inst(Oops);
        bb4.append(inst);
        bb5.successors.push(new FrequentedBlock(bb8, Normal));
        bb5.successors.push(new FrequentedBlock(bb6, Rare));
        bb5.predecessors.push(bb0);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rbx, 56);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        bb5.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rbx, 8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb5.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rax, -24);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r10);
        inst.args.push(arg);
        bb5.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.r10, 16);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb5.append(inst);
        inst = new Inst(BranchTest64);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb5.append(inst);
        bb6.successors.push(new FrequentedBlock(bb1, Rare));
        bb6.successors.push(new FrequentedBlock(bb7, Normal));
        bb6.predecessors.push(bb5);
        inst = new Inst(Move32);
        arg = Arg.createImm(1);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rbp, 36);
        inst.args.push(arg);
        bb6.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.r10);
        inst.args.push(arg);
        arg = Arg.createStack(slot8, 0);
        inst.args.push(arg);
        bb6.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.r10);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        bb6.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r10);
        inst.args.push(arg);
        bb6.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        arg = Arg.createStack(slot7, 0);
        inst.args.push(arg);
        bb6.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createStack(slot6, 0);
        inst.args.push(arg);
        bb6.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rbp);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        bb6.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r10);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.extraClobberedRegs.add(Reg.rcx);
        inst.extraClobberedRegs.add(Reg.rsi);
        inst.extraClobberedRegs.add(Reg.rdi);
        inst.extraClobberedRegs.add(Reg.r8);
        inst.extraClobberedRegs.add(Reg.r9);
        inst.extraClobberedRegs.add(Reg.r10);
        inst.extraClobberedRegs.add(Reg.r11);
        inst.extraClobberedRegs.add(Reg.xmm1);
        inst.extraClobberedRegs.add(Reg.xmm2);
        inst.extraClobberedRegs.add(Reg.xmm3);
        inst.extraClobberedRegs.add(Reg.xmm4);
        inst.extraClobberedRegs.add(Reg.xmm5);
        inst.extraClobberedRegs.add(Reg.xmm6);
        inst.extraClobberedRegs.add(Reg.xmm7);
        inst.extraClobberedRegs.add(Reg.xmm8);
        inst.extraClobberedRegs.add(Reg.xmm9);
        inst.extraClobberedRegs.add(Reg.xmm10);
        inst.extraClobberedRegs.add(Reg.xmm11);
        inst.extraClobberedRegs.add(Reg.xmm12);
        inst.extraClobberedRegs.add(Reg.xmm13);
        inst.extraClobberedRegs.add(Reg.xmm14);
        inst.extraClobberedRegs.add(Reg.xmm15);
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Def, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Def, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Def, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        bb6.append(inst);
        inst = new Inst(Move);
        arg = Arg.createStack(slot8, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r10);
        inst.args.push(arg);
        bb6.append(inst);
        inst = new Inst(Move);
        arg = Arg.createStack(slot7, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        bb6.append(inst);
        inst = new Inst(Move);
        arg = Arg.createStack(slot6, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        bb6.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(129987312, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb6.append(inst);
        inst = new Inst(BranchTest64);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rcx, 0);
        inst.args.push(arg);
        arg = Arg.createImm(-1);
        inst.args.push(arg);
        bb6.append(inst);
        bb7.successors.push(new FrequentedBlock(bb11, Normal));
        bb7.predecessors.push(bb6);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rax, 8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb7.append(inst);
        inst = new Inst(Jump);
        bb7.append(inst);
        bb8.successors.push(new FrequentedBlock(bb11, Normal));
        bb8.predecessors.push(bb5);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rax, 8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb8.append(inst);
        inst = new Inst(Jump);
        bb8.append(inst);
        bb9.successors.push(new FrequentedBlock(bb11, Normal));
        bb9.predecessors.push(bb15);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.r9);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb9.append(inst);
        inst = new Inst(Jump);
        bb9.append(inst);
        bb10.successors.push(new FrequentedBlock(bb11, Normal));
        bb10.predecessors.push(bb18);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.r9);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb10.append(inst);
        inst = new Inst(Jump);
        bb10.append(inst);
        bb11.successors.push(new FrequentedBlock(bb12, Normal));
        bb11.successors.push(new FrequentedBlock(bb16, Normal));
        bb11.predecessors.push(bb7);
        bb11.predecessors.push(bb10);
        bb11.predecessors.push(bb9);
        bb11.predecessors.push(bb8);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r9);
        inst.args.push(arg);
        bb11.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rbx, 40);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb11.append(inst);
        inst = new Inst(Move32);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        bb11.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createResCond(Overflow);
        inst.args.push(arg);
        arg = Arg.createImm(1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.UseZDef, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        bb11.append(inst);
        inst = new Inst(Move32);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        bb11.append(inst);
        inst = new Inst(Add64);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r14);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r11);
        inst.args.push(arg);
        bb11.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.r11);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rbx, 40);
        inst.args.push(arg);
        bb11.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rbx, 32);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb11.append(inst);
        inst = new Inst(Move32);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb11.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createResCond(Overflow);
        inst.args.push(arg);
        arg = Arg.createImm(1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.UseZDef, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        bb11.append(inst);
        inst = new Inst(Move32);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb11.append(inst);
        inst = new Inst(Add64);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r14);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb11.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rbx, 32);
        inst.args.push(arg);
        bb11.append(inst);
        inst = new Inst(Branch32);
        arg = Arg.createRelCond(LessThan);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        bb11.append(inst);
        bb12.successors.push(new FrequentedBlock(bb13, Normal));
        bb12.successors.push(new FrequentedBlock(bb14, Normal));
        bb12.predecessors.push(bb11);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(AboveOrEqual);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.r10, 12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r10);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb12.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.r10, 16);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb12.append(inst);
        inst = new Inst(BranchTest32);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rax, 16);
        inst.args.push(arg);
        arg = Arg.createImm(8);
        inst.args.push(arg);
        bb12.append(inst);
        bb13.successors.push(new FrequentedBlock(bb15, Normal));
        bb13.predecessors.push(bb12);
        inst = new Inst(Load8);
        arg = Arg.createIndex(Reg.r9, Reg.rdx, 1, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb13.append(inst);
        inst = new Inst(Jump);
        bb13.append(inst);
        bb14.successors.push(new FrequentedBlock(bb15, Normal));
        bb14.predecessors.push(bb12);
        inst = new Inst(Load16);
        arg = Arg.createIndex(Reg.r9, Reg.rdx, 2, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb14.append(inst);
        inst = new Inst(Jump);
        bb14.append(inst);
        bb15.successors.push(new FrequentedBlock(bb9, Normal));
        bb15.successors.push(new FrequentedBlock(bb17, Normal));
        bb15.predecessors.push(bb14);
        bb15.predecessors.push(bb13);
        inst = new Inst(Move32);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        bb15.append(inst);
        inst = new Inst(Move32);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb15.append(inst);
        inst = new Inst(Add64);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r14);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb15.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rbx, 72);
        inst.args.push(arg);
        bb15.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(AboveOrEqual);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        bb15.append(inst);
        inst = new Inst(Move);
        arg = Arg.createIndex(Reg.r12, Reg.rax, 8, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb15.append(inst);
        inst = new Inst(MoveConditionallyTest64);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createImm(-1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r13);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        bb15.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb15.append(inst);
        inst = new Inst(Xor64);
        arg = Arg.createImm(6);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb15.append(inst);
        inst = new Inst(Move);
        arg = Arg.createImm(-2);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb15.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb15.append(inst);
        inst = new Inst(Move);
        arg = Arg.createImm(1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb15.append(inst);
        inst = new Inst(BranchTest64);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb15.append(inst);
        bb16.predecessors.push(bb11);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb16.append(inst);
        inst = new Inst(Oops);
        bb16.append(inst);
        bb17.successors.push(new FrequentedBlock(bb18, Normal));
        bb17.successors.push(new FrequentedBlock(bb19, Normal));
        bb17.predecessors.push(bb15);
        inst = new Inst(Branch32);
        arg = Arg.createRelCond(GreaterThanOrEqual);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createImm(48);
        inst.args.push(arg);
        bb17.append(inst);
        bb18.successors.push(new FrequentedBlock(bb10, Normal));
        bb18.successors.push(new FrequentedBlock(bb19, Normal));
        bb18.predecessors.push(bb17);
        inst = new Inst(Branch32);
        arg = Arg.createRelCond(LessThanOrEqual);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createImm(57);
        inst.args.push(arg);
        bb18.append(inst);
        bb19.successors.push(new FrequentedBlock(bb20, Normal));
        bb19.successors.push(new FrequentedBlock(bb21, Normal));
        bb19.predecessors.push(bb17);
        bb19.predecessors.push(bb18);
        inst = new Inst(Branch32);
        arg = Arg.createRelCond(GreaterThanOrEqual);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createImm(128);
        inst.args.push(arg);
        bb19.append(inst);
        bb20.predecessors.push(bb19);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb20.append(inst);
        inst = new Inst(Oops);
        bb20.append(inst);
        bb21.successors.push(new FrequentedBlock(bb22, Normal));
        bb21.successors.push(new FrequentedBlock(bb23, Normal));
        bb21.predecessors.push(bb19);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        bb21.append(inst);
        inst = new Inst(Branch32);
        arg = Arg.createRelCond(Equal);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createImm(92);
        inst.args.push(arg);
        bb21.append(inst);
        bb22.predecessors.push(bb21);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb22.append(inst);
        inst = new Inst(Oops);
        bb22.append(inst);
        bb23.successors.push(new FrequentedBlock(bb2, Rare));
        bb23.successors.push(new FrequentedBlock(bb24, Normal));
        bb23.predecessors.push(bb21);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rbx, 48);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb23.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(155021568, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb23.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createCallArg(8);
        inst.args.push(arg);
        bb23.append(inst);
        inst = new Inst(Move32);
        arg = Arg.createImm(3);
        inst.args.push(arg);
        arg = Arg.createCallArg(16);
        inst.args.push(arg);
        bb23.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.r10);
        inst.args.push(arg);
        arg = Arg.createCallArg(24);
        inst.args.push(arg);
        bb23.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createCallArg(32);
        inst.args.push(arg);
        bb23.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.r11);
        inst.args.push(arg);
        arg = Arg.createCallArg(40);
        inst.args.push(arg);
        bb23.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createCallArg(8);
        inst.args.push(arg);
        arg = Arg.createCallArg(16);
        inst.args.push(arg);
        arg = Arg.createCallArg(24);
        inst.args.push(arg);
        arg = Arg.createCallArg(32);
        inst.args.push(arg);
        arg = Arg.createCallArg(40);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r15);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r14);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.extraEarlyClobberedRegs.add(Reg.r11);
        inst.extraClobberedRegs.add(Reg.rcx);
        inst.extraClobberedRegs.add(Reg.rdx);
        inst.extraClobberedRegs.add(Reg.rsi);
        inst.extraClobberedRegs.add(Reg.rdi);
        inst.extraClobberedRegs.add(Reg.r8);
        inst.extraClobberedRegs.add(Reg.r9);
        inst.extraClobberedRegs.add(Reg.r10);
        inst.extraClobberedRegs.add(Reg.r11);
        inst.extraClobberedRegs.add(Reg.xmm0);
        inst.extraClobberedRegs.add(Reg.xmm1);
        inst.extraClobberedRegs.add(Reg.xmm2);
        inst.extraClobberedRegs.add(Reg.xmm3);
        inst.extraClobberedRegs.add(Reg.xmm4);
        inst.extraClobberedRegs.add(Reg.xmm5);
        inst.extraClobberedRegs.add(Reg.xmm6);
        inst.extraClobberedRegs.add(Reg.xmm7);
        inst.extraClobberedRegs.add(Reg.xmm8);
        inst.extraClobberedRegs.add(Reg.xmm9);
        inst.extraClobberedRegs.add(Reg.xmm10);
        inst.extraClobberedRegs.add(Reg.xmm11);
        inst.extraClobberedRegs.add(Reg.xmm12);
        inst.extraClobberedRegs.add(Reg.xmm13);
        inst.extraClobberedRegs.add(Reg.xmm14);
        inst.extraClobberedRegs.add(Reg.xmm15);
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Def, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        bb23.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        bb23.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb23.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(155041288, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb23.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rax, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb23.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rax, -1336);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r13);
        inst.args.push(arg);
        bb23.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r13);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r15);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r13);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r13);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb23.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.r13, 24);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb23.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createStack(slot0, 0);
        inst.args.push(arg);
        bb23.append(inst);
        inst = new Inst(Move32);
        arg = Arg.createImm(2);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rbp, 36);
        inst.args.push(arg);
        bb23.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(108356304, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb23.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createStack(slot3, 0);
        inst.args.push(arg);
        bb23.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        bb23.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        bb23.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rbp);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        bb23.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.extraClobberedRegs.add(Reg.rcx);
        inst.extraClobberedRegs.add(Reg.rsi);
        inst.extraClobberedRegs.add(Reg.rdi);
        inst.extraClobberedRegs.add(Reg.r8);
        inst.extraClobberedRegs.add(Reg.r9);
        inst.extraClobberedRegs.add(Reg.r10);
        inst.extraClobberedRegs.add(Reg.r11);
        inst.extraClobberedRegs.add(Reg.xmm1);
        inst.extraClobberedRegs.add(Reg.xmm2);
        inst.extraClobberedRegs.add(Reg.xmm3);
        inst.extraClobberedRegs.add(Reg.xmm4);
        inst.extraClobberedRegs.add(Reg.xmm5);
        inst.extraClobberedRegs.add(Reg.xmm6);
        inst.extraClobberedRegs.add(Reg.xmm7);
        inst.extraClobberedRegs.add(Reg.xmm8);
        inst.extraClobberedRegs.add(Reg.xmm9);
        inst.extraClobberedRegs.add(Reg.xmm10);
        inst.extraClobberedRegs.add(Reg.xmm11);
        inst.extraClobberedRegs.add(Reg.xmm12);
        inst.extraClobberedRegs.add(Reg.xmm13);
        inst.extraClobberedRegs.add(Reg.xmm14);
        inst.extraClobberedRegs.add(Reg.xmm15);
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Def, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Def, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Def, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        bb23.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(129987312, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb23.append(inst);
        inst = new Inst(BranchTest64);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rcx, 0);
        inst.args.push(arg);
        arg = Arg.createImm(-1);
        inst.args.push(arg);
        bb23.append(inst);
        bb24.successors.push(new FrequentedBlock(bb25, Normal));
        bb24.successors.push(new FrequentedBlock(bb26, Normal));
        bb24.predecessors.push(bb23);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r13);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb24.append(inst);
        inst = new Inst(BranchTest64);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r15);
        inst.args.push(arg);
        bb24.append(inst);
        bb25.successors.push(new FrequentedBlock(bb27, Normal));
        bb25.successors.push(new FrequentedBlock(bb26, Normal));
        bb25.predecessors.push(bb24);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb25.append(inst);
        inst = new Inst(And64);
        arg = Arg.createImm(-9);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb25.append(inst);
        inst = new Inst(Branch64);
        arg = Arg.createRelCond(Equal);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createImm(2);
        inst.args.push(arg);
        bb25.append(inst);
        bb26.successors.push(new FrequentedBlock(bb29, Normal));
        bb26.successors.push(new FrequentedBlock(bb28, Normal));
        bb26.predecessors.push(bb24);
        bb26.predecessors.push(bb25);
        inst = new Inst(BranchTest64);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r15);
        inst.args.push(arg);
        bb26.append(inst);
        bb27.successors.push(new FrequentedBlock(bb30, Normal));
        bb27.predecessors.push(bb25);
        inst = new Inst(Move);
        arg = Arg.createImm(2);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb27.append(inst);
        inst = new Inst(Jump);
        bb27.append(inst);
        bb28.successors.push(new FrequentedBlock(bb32, Normal));
        bb28.predecessors.push(bb26);
        inst = new Inst(Jump);
        bb28.append(inst);
        bb29.successors.push(new FrequentedBlock(bb30, Normal));
        bb29.predecessors.push(bb26);
        inst = new Inst(Jump);
        bb29.append(inst);
        bb30.successors.push(new FrequentedBlock(bb34, Normal));
        bb30.successors.push(new FrequentedBlock(bb31, Normal));
        bb30.predecessors.push(bb29);
        bb30.predecessors.push(bb27);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb30.append(inst);
        inst = new Inst(And64);
        arg = Arg.createImm(-9);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb30.append(inst);
        inst = new Inst(Branch64);
        arg = Arg.createRelCond(Equal);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createImm(2);
        inst.args.push(arg);
        bb30.append(inst);
        bb31.successors.push(new FrequentedBlock(bb32, Normal));
        bb31.predecessors.push(bb30);
        inst = new Inst(Jump);
        bb31.append(inst);
        bb32.successors.push(new FrequentedBlock(bb3, Rare));
        bb32.successors.push(new FrequentedBlock(bb33, Normal));
        bb32.predecessors.push(bb28);
        bb32.predecessors.push(bb31);
        inst = new Inst(Move32);
        arg = Arg.createImm(3);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rbp, 36);
        inst.args.push(arg);
        bb32.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(154991632, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb32.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        bb32.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        bb32.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rbp);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        bb32.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createBigImm(108356304, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.extraClobberedRegs.add(Reg.rcx);
        inst.extraClobberedRegs.add(Reg.rsi);
        inst.extraClobberedRegs.add(Reg.rdi);
        inst.extraClobberedRegs.add(Reg.r8);
        inst.extraClobberedRegs.add(Reg.r9);
        inst.extraClobberedRegs.add(Reg.r10);
        inst.extraClobberedRegs.add(Reg.r11);
        inst.extraClobberedRegs.add(Reg.xmm1);
        inst.extraClobberedRegs.add(Reg.xmm2);
        inst.extraClobberedRegs.add(Reg.xmm3);
        inst.extraClobberedRegs.add(Reg.xmm4);
        inst.extraClobberedRegs.add(Reg.xmm5);
        inst.extraClobberedRegs.add(Reg.xmm6);
        inst.extraClobberedRegs.add(Reg.xmm7);
        inst.extraClobberedRegs.add(Reg.xmm8);
        inst.extraClobberedRegs.add(Reg.xmm9);
        inst.extraClobberedRegs.add(Reg.xmm10);
        inst.extraClobberedRegs.add(Reg.xmm11);
        inst.extraClobberedRegs.add(Reg.xmm12);
        inst.extraClobberedRegs.add(Reg.xmm13);
        inst.extraClobberedRegs.add(Reg.xmm14);
        inst.extraClobberedRegs.add(Reg.xmm15);
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Def, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Def, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Def, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        bb32.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(129987312, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb32.append(inst);
        inst = new Inst(BranchTest64);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rcx, 0);
        inst.args.push(arg);
        arg = Arg.createImm(-1);
        inst.args.push(arg);
        bb32.append(inst);
        bb33.predecessors.push(bb32);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb33.append(inst);
        inst = new Inst(Ret64);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb33.append(inst);
        bb34.predecessors.push(bb30);
        inst = new Inst(Move);
        arg = Arg.createBigImm(153835296, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb34.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createCallArg(8);
        inst.args.push(arg);
        bb34.append(inst);
        inst = new Inst(Move32);
        arg = Arg.createImm(3);
        inst.args.push(arg);
        arg = Arg.createCallArg(16);
        inst.args.push(arg);
        bb34.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createCallArg(24);
        inst.args.push(arg);
        bb34.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createCallArg(32);
        inst.args.push(arg);
        bb34.append(inst);
        inst = new Inst(Move);
        arg = Arg.createImm(6);
        inst.args.push(arg);
        arg = Arg.createCallArg(40);
        inst.args.push(arg);
        bb34.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createCallArg(8);
        inst.args.push(arg);
        arg = Arg.createCallArg(16);
        inst.args.push(arg);
        arg = Arg.createCallArg(24);
        inst.args.push(arg);
        arg = Arg.createCallArg(32);
        inst.args.push(arg);
        arg = Arg.createCallArg(40);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r15);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r14);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.extraEarlyClobberedRegs.add(Reg.r11);
        inst.extraClobberedRegs.add(Reg.rcx);
        inst.extraClobberedRegs.add(Reg.rdx);
        inst.extraClobberedRegs.add(Reg.rsi);
        inst.extraClobberedRegs.add(Reg.rdi);
        inst.extraClobberedRegs.add(Reg.r8);
        inst.extraClobberedRegs.add(Reg.r9);
        inst.extraClobberedRegs.add(Reg.r10);
        inst.extraClobberedRegs.add(Reg.r11);
        inst.extraClobberedRegs.add(Reg.xmm0);
        inst.extraClobberedRegs.add(Reg.xmm1);
        inst.extraClobberedRegs.add(Reg.xmm2);
        inst.extraClobberedRegs.add(Reg.xmm3);
        inst.extraClobberedRegs.add(Reg.xmm4);
        inst.extraClobberedRegs.add(Reg.xmm5);
        inst.extraClobberedRegs.add(Reg.xmm6);
        inst.extraClobberedRegs.add(Reg.xmm7);
        inst.extraClobberedRegs.add(Reg.xmm8);
        inst.extraClobberedRegs.add(Reg.xmm9);
        inst.extraClobberedRegs.add(Reg.xmm10);
        inst.extraClobberedRegs.add(Reg.xmm11);
        inst.extraClobberedRegs.add(Reg.xmm12);
        inst.extraClobberedRegs.add(Reg.xmm13);
        inst.extraClobberedRegs.add(Reg.xmm14);
        inst.extraClobberedRegs.add(Reg.xmm15);
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Def, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        bb34.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb34.append(inst);
        inst = new Inst(Ret64);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb34.append(inst);
        return code;
    }
    // Generated by opcode_generator.rb from JavaScriptCore/b3/air/AirOpcode.opcodes -- do not edit!
    const /*<@7>*/Nop = Symbol("Nop");
    const /*<@7>*/Add32 = Symbol("Add32");
    const /*<@7>*/Add8 = Symbol("Add8");
    const /*<@7>*/Add16 = Symbol("Add16");
    const /*<@7>*/Add64 = Symbol("Add64");
    const /*<@7>*/AddDouble = Symbol("AddDouble");
    const /*<@7>*/AddFloat = Symbol("AddFloat");
    const /*<@7>*/Sub32 = Symbol("Sub32");
    const /*<@7>*/Sub64 = Symbol("Sub64");
    const /*<@7>*/SubDouble = Symbol("SubDouble");
    const /*<@7>*/SubFloat = Symbol("SubFloat");
    const /*<@7>*/Neg32 = Symbol("Neg32");
    const /*<@7>*/Neg64 = Symbol("Neg64");
    const /*<@7>*/NegateDouble = Symbol("NegateDouble");
    const /*<@7>*/Mul32 = Symbol("Mul32");
    const /*<@7>*/Mul64 = Symbol("Mul64");
    const /*<@7>*/MultiplyAdd32 = Symbol("MultiplyAdd32");
    const /*<@7>*/MultiplyAdd64 = Symbol("MultiplyAdd64");
    const /*<@7>*/MultiplySub32 = Symbol("MultiplySub32");
    const /*<@7>*/MultiplySub64 = Symbol("MultiplySub64");
    const /*<@7>*/MultiplyNeg32 = Symbol("MultiplyNeg32");
    const /*<@7>*/MultiplyNeg64 = Symbol("MultiplyNeg64");
    const /*<@7>*/Div32 = Symbol("Div32");
    const /*<@7>*/Div64 = Symbol("Div64");
    const /*<@7>*/MulDouble = Symbol("MulDouble");
    const /*<@7>*/MulFloat = Symbol("MulFloat");
    const /*<@7>*/DivDouble = Symbol("DivDouble");
    const /*<@7>*/DivFloat = Symbol("DivFloat");
    const /*<@7>*/X86ConvertToDoubleWord32 = Symbol("X86ConvertToDoubleWord32");
    const /*<@7>*/X86ConvertToQuadWord64 = Symbol("X86ConvertToQuadWord64");
    const /*<@7>*/X86Div32 = Symbol("X86Div32");
    const /*<@7>*/X86Div64 = Symbol("X86Div64");
    const /*<@7>*/Lea = Symbol("Lea");
    const /*<@7>*/And32 = Symbol("And32");
    const /*<@7>*/And64 = Symbol("And64");
    const /*<@7>*/AndDouble = Symbol("AndDouble");
    const /*<@7>*/AndFloat = Symbol("AndFloat");
    const /*<@7>*/XorDouble = Symbol("XorDouble");
    const /*<@7>*/XorFloat = Symbol("XorFloat");
    const /*<@7>*/Lshift32 = Symbol("Lshift32");
    const /*<@7>*/Lshift64 = Symbol("Lshift64");
    const /*<@7>*/Rshift32 = Symbol("Rshift32");
    const /*<@7>*/Rshift64 = Symbol("Rshift64");
    const /*<@7>*/Urshift32 = Symbol("Urshift32");
    const /*<@7>*/Urshift64 = Symbol("Urshift64");
    const /*<@7>*/Or32 = Symbol("Or32");
    const /*<@7>*/Or64 = Symbol("Or64");
    const /*<@7>*/Xor32 = Symbol("Xor32");
    const /*<@7>*/Xor64 = Symbol("Xor64");
    const /*<@7>*/Not32 = Symbol("Not32");
    const /*<@7>*/Not64 = Symbol("Not64");
    const /*<@7>*/AbsDouble = Symbol("AbsDouble");
    const /*<@7>*/AbsFloat = Symbol("AbsFloat");
    const /*<@7>*/CeilDouble = Symbol("CeilDouble");
    const /*<@7>*/CeilFloat = Symbol("CeilFloat");
    const /*<@7>*/FloorDouble = Symbol("FloorDouble");
    const /*<@7>*/FloorFloat = Symbol("FloorFloat");
    const /*<@7>*/SqrtDouble = Symbol("SqrtDouble");
    const /*<@7>*/SqrtFloat = Symbol("SqrtFloat");
    const /*<@7>*/ConvertInt32ToDouble = Symbol("ConvertInt32ToDouble");
    const /*<@7>*/ConvertInt64ToDouble = Symbol("ConvertInt64ToDouble");
    const /*<@7>*/ConvertInt32ToFloat = Symbol("ConvertInt32ToFloat");
    const /*<@7>*/ConvertInt64ToFloat = Symbol("ConvertInt64ToFloat");
    const /*<@7>*/CountLeadingZeros32 = Symbol("CountLeadingZeros32");
    const /*<@7>*/CountLeadingZeros64 = Symbol("CountLeadingZeros64");
    const /*<@7>*/ConvertDoubleToFloat = Symbol("ConvertDoubleToFloat");
    const /*<@7>*/ConvertFloatToDouble = Symbol("ConvertFloatToDouble");
    const /*<@7>*/Move = Symbol("Move");
    const /*<@7>*/Swap32 = Symbol("Swap32");
    const /*<@7>*/Swap64 = Symbol("Swap64");
    const /*<@7>*/Move32 = Symbol("Move32");
    const /*<@7>*/StoreZero32 = Symbol("StoreZero32");
    const /*<@7>*/SignExtend32ToPtr = Symbol("SignExtend32ToPtr");
    const /*<@7>*/ZeroExtend8To32 = Symbol("ZeroExtend8To32");
    const /*<@7>*/SignExtend8To32 = Symbol("SignExtend8To32");
    const /*<@7>*/ZeroExtend16To32 = Symbol("ZeroExtend16To32");
    const /*<@7>*/SignExtend16To32 = Symbol("SignExtend16To32");
    const /*<@7>*/MoveFloat = Symbol("MoveFloat");
    const /*<@7>*/MoveDouble = Symbol("MoveDouble");
    const /*<@7>*/MoveZeroToDouble = Symbol("MoveZeroToDouble");
    const /*<@7>*/Move64ToDouble = Symbol("Move64ToDouble");
    const /*<@7>*/Move32ToFloat = Symbol("Move32ToFloat");
    const /*<@7>*/MoveDoubleTo64 = Symbol("MoveDoubleTo64");
    const /*<@7>*/MoveFloatTo32 = Symbol("MoveFloatTo32");
    const /*<@7>*/Load8 = Symbol("Load8");
    const /*<@7>*/Store8 = Symbol("Store8");
    const /*<@7>*/Load8SignedExtendTo32 = Symbol("Load8SignedExtendTo32");
    const /*<@7>*/Load16 = Symbol("Load16");
    const /*<@7>*/Load16SignedExtendTo32 = Symbol("Load16SignedExtendTo32");
    const /*<@7>*/Store16 = Symbol("Store16");
    const /*<@7>*/Compare32 = Symbol("Compare32");
    const /*<@7>*/Compare64 = Symbol("Compare64");
    const /*<@7>*/Test32 = Symbol("Test32");
    const /*<@7>*/Test64 = Symbol("Test64");
    const /*<@7>*/CompareDouble = Symbol("CompareDouble");
    const /*<@7>*/CompareFloat = Symbol("CompareFloat");
    const /*<@7>*/Branch8 = Symbol("Branch8");
    const /*<@7>*/Branch32 = Symbol("Branch32");
    const /*<@7>*/Branch64 = Symbol("Branch64");
    const /*<@7>*/BranchTest8 = Symbol("BranchTest8");
    const /*<@7>*/BranchTest32 = Symbol("BranchTest32");
    const /*<@7>*/BranchTest64 = Symbol("BranchTest64");
    const /*<@7>*/BranchDouble = Symbol("BranchDouble");
    const /*<@7>*/BranchFloat = Symbol("BranchFloat");
    const /*<@7>*/BranchAdd32 = Symbol("BranchAdd32");
    const /*<@7>*/BranchAdd64 = Symbol("BranchAdd64");
    const /*<@7>*/BranchMul32 = Symbol("BranchMul32");
    const /*<@7>*/BranchMul64 = Symbol("BranchMul64");
    const /*<@7>*/BranchSub32 = Symbol("BranchSub32");
    const /*<@7>*/BranchSub64 = Symbol("BranchSub64");
    const /*<@7>*/BranchNeg32 = Symbol("BranchNeg32");
    const /*<@7>*/BranchNeg64 = Symbol("BranchNeg64");
    const /*<@7>*/MoveConditionally32 = Symbol("MoveConditionally32");
    const /*<@7>*/MoveConditionally64 = Symbol("MoveConditionally64");
    const /*<@7>*/MoveConditionallyTest32 = Symbol("MoveConditionallyTest32");
    const /*<@7>*/MoveConditionallyTest64 = Symbol("MoveConditionallyTest64");
    const /*<@7>*/MoveConditionallyDouble = Symbol("MoveConditionallyDouble");
    const /*<@7>*/MoveConditionallyFloat = Symbol("MoveConditionallyFloat");
    const /*<@7>*/MoveDoubleConditionally32 = Symbol("MoveDoubleConditionally32");
    const /*<@7>*/MoveDoubleConditionally64 = Symbol("MoveDoubleConditionally64");
    const /*<@7>*/MoveDoubleConditionallyTest32 = Symbol("MoveDoubleConditionallyTest32");
    const /*<@7>*/MoveDoubleConditionallyTest64 = Symbol("MoveDoubleConditionallyTest64");
    const /*<@7>*/MoveDoubleConditionallyDouble = Symbol("MoveDoubleConditionallyDouble");
    const /*<@7>*/MoveDoubleConditionallyFloat = Symbol("MoveDoubleConditionallyFloat");
    const /*<@7>*/Jump = Symbol("Jump");
    const /*<@7>*/Ret32 = Symbol("Ret32");
    const /*<@7>*/Ret64 = Symbol("Ret64");
    const /*<@7>*/RetFloat = Symbol("RetFloat");
    const /*<@7>*/RetDouble = Symbol("RetDouble");
    const /*<@7>*/Oops = Symbol("Oops");
    const /*<@7>*/Shuffle = Symbol("Shuffle");
    const /*<@7>*/Patch = Symbol("Patch");
    const /*<@7>*/CCall = Symbol("CCall");
    const /*<@7>*/ColdCCall = Symbol("ColdCCall");
    function /*<@277>*/Inst_forEachArg(/*<@15>*/inst, func) {
        let replacement;
        switch (inst.opcode) {
            case Nop:
                break;
                break;
            case Add32:
                switch (inst.args.length) {
                    case 3:
                        inst.visitArg(0, func, Arg.Use, GP, 32);
                        inst.visitArg(1, func, Arg.Use, GP, 32);
                        inst.visitArg(2, func, Arg.ZDef, GP, 32);
                        break;
                    case 2:
                        inst.visitArg(0, func, Arg.Use, GP, 32);
                        inst.visitArg(1, func, Arg.UseZDef, GP, 32);
                        break;
                    default:
                        throw new Error("Bad overload");
                        break;
                }
                break;
            case Add8:
                inst.visitArg(0, func, Arg.Use, GP, 8);
                inst.visitArg(1, func, Arg.UseDef, GP, 8);
                break;
                break;
            case Add16:
                inst.visitArg(0, func, Arg.Use, GP, 16);
                inst.visitArg(1, func, Arg.UseDef, GP, 16);
                break;
                break;
            case Add64:
                switch (inst.args.length) {
                    case 2:
                        inst.visitArg(0, func, Arg.Use, GP, 64);
                        inst.visitArg(1, func, Arg.UseDef, GP, 64);
                        break;
                    case 3:
                        inst.visitArg(0, func, Arg.Use, GP, 64);
                        inst.visitArg(1, func, Arg.Use, GP, 64);
                        inst.visitArg(2, func, Arg.Def, GP, 64);
                        break;
                    default:
                        throw new Error("Bad overload");
                        break;
                }
                break;
            case AddDouble:
                switch (inst.args.length) {
                    case 3:
                        inst.visitArg(0, func, Arg.Use, FP, 64);
                        inst.visitArg(1, func, Arg.Use, FP, 64);
                        inst.visitArg(2, func, Arg.Def, FP, 64);
                        break;
                    case 2:
                        inst.visitArg(0, func, Arg.Use, FP, 64);
                        inst.visitArg(1, func, Arg.UseDef, FP, 64);
                        break;
                    default:
                        throw new Error("Bad overload");
                        break;
                }
                break;
            case AddFloat:
                switch (inst.args.length) {
                    case 3:
                        inst.visitArg(0, func, Arg.Use, FP, 32);
                        inst.visitArg(1, func, Arg.Use, FP, 32);
                        inst.visitArg(2, func, Arg.Def, FP, 32);
                        break;
                    case 2:
                        inst.visitArg(0, func, Arg.Use, FP, 32);
                        inst.visitArg(1, func, Arg.UseDef, FP, 32);
                        break;
                    default:
                        throw new Error("Bad overload");
                        break;
                }
                break;
            case Sub32:
                inst.visitArg(0, func, Arg.Use, GP, 32);
                inst.visitArg(1, func, Arg.UseZDef, GP, 32);
                break;
                break;
            case Sub64:
                inst.visitArg(0, func, Arg.Use, GP, 64);
                inst.visitArg(1, func, Arg.UseDef, GP, 64);
                break;
                break;
            case SubDouble:
                switch (inst.args.length) {
                    case 3:
                        inst.visitArg(0, func, Arg.Use, FP, 64);
                        inst.visitArg(1, func, Arg.Use, FP, 64);
                        inst.visitArg(2, func, Arg.Def, FP, 64);
                        break;
                    case 2:
                        inst.visitArg(0, func, Arg.Use, FP, 64);
                        inst.visitArg(1, func, Arg.UseDef, FP, 64);
                        break;
                    default:
                        throw new Error("Bad overload");
                        break;
                }
                break;
            case SubFloat:
                switch (inst.args.length) {
                    case 3:
                        inst.visitArg(0, func, Arg.Use, FP, 32);
                        inst.visitArg(1, func, Arg.Use, FP, 32);
                        inst.visitArg(2, func, Arg.Def, FP, 32);
                        break;
                    case 2:
                        inst.visitArg(0, func, Arg.Use, FP, 32);
                        inst.visitArg(1, func, Arg.UseDef, FP, 32);
                        break;
                    default:
                        throw new Error("Bad overload");
                        break;
                }
                break;
            case Neg32:
                inst.visitArg(0, func, Arg.UseZDef, GP, 32);
                break;
                break;
            case Neg64:
                inst.visitArg(0, func, Arg.UseDef, GP, 64);
                break;
                break;
            case NegateDouble:
                inst.visitArg(0, func, Arg.Use, FP, 64);
                inst.visitArg(1, func, Arg.Def, FP, 64);
                break;
                break;
            case Mul32:
                switch (inst.args.length) {
                    case 2:
                        inst.visitArg(0, func, Arg.Use, GP, 32);
                        inst.visitArg(1, func, Arg.UseZDef, GP, 32);
                        break;
                    case 3:
                        inst.visitArg(0, func, Arg.Use, GP, 32);
                        inst.visitArg(1, func, Arg.Use, GP, 32);
                        inst.visitArg(2, func, Arg.ZDef, GP, 32);
                        break;
                    default:
                        throw new Error("Bad overload");
                        break;
                }
                break;
            case Mul64:
                switch (inst.args.length) {
                    case 2:
                        inst.visitArg(0, func, Arg.Use, GP, 64);
                        inst.visitArg(1, func, Arg.UseDef, GP, 64);
                        break;
                    case 3:
                        inst.visitArg(0, func, Arg.Use, GP, 64);
                        inst.visitArg(1, func, Arg.Use, GP, 64);
                        inst.visitArg(2, func, Arg.Def, GP, 64);
                        break;
                    default:
                        throw new Error("Bad overload");
                        break;
                }
                break;
            case MultiplyAdd32:
                inst.visitArg(0, func, Arg.Use, GP, 32);
                inst.visitArg(1, func, Arg.Use, GP, 32);
                inst.visitArg(2, func, Arg.Use, GP, 32);
                inst.visitArg(3, func, Arg.ZDef, GP, 32);
                break;
                break;
            case MultiplyAdd64:
                inst.visitArg(0, func, Arg.Use, GP, 64);
                inst.visitArg(1, func, Arg.Use, GP, 64);
                inst.visitArg(2, func, Arg.Use, GP, 64);
                inst.visitArg(3, func, Arg.Def, GP, 64);
                break;
                break;
            case MultiplySub32:
                inst.visitArg(0, func, Arg.Use, GP, 32);
                inst.visitArg(1, func, Arg.Use, GP, 32);
                inst.visitArg(2, func, Arg.Use, GP, 32);
                inst.visitArg(3, func, Arg.ZDef, GP, 32);
                break;
                break;
            case MultiplySub64:
                inst.visitArg(0, func, Arg.Use, GP, 64);
                inst.visitArg(1, func, Arg.Use, GP, 64);
                inst.visitArg(2, func, Arg.Use, GP, 64);
                inst.visitArg(3, func, Arg.Def, GP, 64);
                break;
                break;
            case MultiplyNeg32:
                inst.visitArg(0, func, Arg.Use, GP, 32);
                inst.visitArg(1, func, Arg.Use, GP, 32);
                inst.visitArg(2, func, Arg.ZDef, GP, 32);
                break;
                break;
            case MultiplyNeg64:
                inst.visitArg(0, func, Arg.Use, GP, 64);
                inst.visitArg(1, func, Arg.Use, GP, 64);
                inst.visitArg(2, func, Arg.ZDef, GP, 64);
                break;
                break;
            case Div32:
                inst.visitArg(0, func, Arg.Use, GP, 32);
                inst.visitArg(1, func, Arg.Use, GP, 32);
                inst.visitArg(2, func, Arg.ZDef, GP, 32);
                break;
                break;
            case Div64:
                inst.visitArg(0, func, Arg.Use, GP, 64);
                inst.visitArg(1, func, Arg.Use, GP, 64);
                inst.visitArg(2, func, Arg.Def, GP, 64);
                break;
                break;
            case MulDouble:
                switch (inst.args.length) {
                    case 3:
                        inst.visitArg(0, func, Arg.Use, FP, 64);
                        inst.visitArg(1, func, Arg.Use, FP, 64);
                        inst.visitArg(2, func, Arg.Def, FP, 64);
                        break;
                    case 2:
                        inst.visitArg(0, func, Arg.Use, FP, 64);
                        inst.visitArg(1, func, Arg.UseDef, FP, 64);
                        break;
                    default:
                        throw new Error("Bad overload");
                        break;
                }
                break;
            case MulFloat:
                switch (inst.args.length) {
                    case 3:
                        inst.visitArg(0, func, Arg.Use, FP, 32);
                        inst.visitArg(1, func, Arg.Use, FP, 32);
                        inst.visitArg(2, func, Arg.Def, FP, 32);
                        break;
                    case 2:
                        inst.visitArg(0, func, Arg.Use, FP, 32);
                        inst.visitArg(1, func, Arg.UseDef, FP, 32);
                        break;
                    default:
                        throw new Error("Bad overload");
                        break;
                }
                break;
            case DivDouble:
                switch (inst.args.length) {
                    case 3:
                        inst.visitArg(0, func, Arg.Use, FP, 64);
                        inst.visitArg(1, func, Arg.Use, FP, 32);
                        inst.visitArg(2, func, Arg.Def, FP, 64);
                        break;
                    case 2:
                        inst.visitArg(0, func, Arg.Use, FP, 64);
                        inst.visitArg(1, func, Arg.UseDef, FP, 64);
                        break;
                    default:
                        throw new Error("Bad overload");
                        break;
                }
                break;
            case DivFloat:
                switch (inst.args.length) {
                    case 3:
                        inst.visitArg(0, func, Arg.Use, FP, 32);
                        inst.visitArg(1, func, Arg.Use, FP, 32);
                        inst.visitArg(2, func, Arg.Def, FP, 32);
                        break;
                    case 2:
                        inst.visitArg(0, func, Arg.Use, FP, 32);
                        inst.visitArg(1, func, Arg.UseDef, FP, 32);
                        break;
                    default:
                        throw new Error("Bad overload");
                        break;
                }
                break;
            case X86ConvertToDoubleWord32:
                inst.visitArg(0, func, Arg.Use, GP, 32);
                inst.visitArg(1, func, Arg.ZDef, GP, 32);
                break;
                break;
            case X86ConvertToQuadWord64:
                inst.visitArg(0, func, Arg.Use, GP, 64);
                inst.visitArg(1, func, Arg.Def, GP, 64);
                break;
                break;
            case X86Div32:
                inst.visitArg(0, func, Arg.UseZDef, GP, 32);
                inst.visitArg(1, func, Arg.UseZDef, GP, 32);
                inst.visitArg(2, func, Arg.Use, GP, 32);
                break;
                break;
            case X86Div64:
                inst.visitArg(0, func, Arg.UseZDef, GP, 64);
                inst.visitArg(1, func, Arg.UseZDef, GP, 64);
                inst.visitArg(2, func, Arg.Use, GP, 64);
                break;
                break;
            case Lea:
                inst.visitArg(0, func, Arg.UseAddr, GP, Ptr);
                inst.visitArg(1, func, Arg.Def, GP, Ptr);
                break;
                break;
            case And32:
                switch (inst.args.length) {
                    case 3:
                        inst.visitArg(0, func, Arg.Use, GP, 32);
                        inst.visitArg(1, func, Arg.Use, GP, 32);
                        inst.visitArg(2, func, Arg.ZDef, GP, 32);
                        break;
                    case 2:
                        inst.visitArg(0, func, Arg.Use, GP, 32);
                        inst.visitArg(1, func, Arg.UseZDef, GP, 32);
                        break;
                    default:
                        throw new Error("Bad overload");
                        break;
                }
                break;
            case And64:
                switch (inst.args.length) {
                    case 3:
                        inst.visitArg(0, func, Arg.Use, GP, 64);
                        inst.visitArg(1, func, Arg.Use, GP, 64);
                        inst.visitArg(2, func, Arg.Def, GP, 64);
                        break;
                    case 2:
                        inst.visitArg(0, func, Arg.Use, GP, 64);
                        inst.visitArg(1, func, Arg.UseDef, GP, 64);
                        break;
                    default:
                        throw new Error("Bad overload");
                        break;
                }
                break;
            case AndDouble:
                switch (inst.args.length) {
                    case 3:
                        inst.visitArg(0, func, Arg.Use, FP, 64);
                        inst.visitArg(1, func, Arg.Use, FP, 64);
                        inst.visitArg(2, func, Arg.Def, FP, 64);
                        break;
                    case 2:
                        inst.visitArg(0, func, Arg.Use, FP, 64);
                        inst.visitArg(1, func, Arg.UseDef, FP, 64);
                        break;
                    default:
                        throw new Error("Bad overload");
                        break;
                }
                break;
            case AndFloat:
                switch (inst.args.length) {
                    case 3:
                        inst.visitArg(0, func, Arg.Use, FP, 32);
                        inst.visitArg(1, func, Arg.Use, FP, 32);
                        inst.visitArg(2, func, Arg.Def, FP, 32);
                        break;
                    case 2:
                        inst.visitArg(0, func, Arg.Use, FP, 32);
                        inst.visitArg(1, func, Arg.UseDef, FP, 32);
                        break;
                    default:
                        throw new Error("Bad overload");
                        break;
                }
                break;
            case XorDouble:
                switch (inst.args.length) {
                    case 3:
                        inst.visitArg(0, func, Arg.Use, FP, 64);
                        inst.visitArg(1, func, Arg.Use, FP, 64);
                        inst.visitArg(2, func, Arg.Def, FP, 64);
                        break;
                    case 2:
                        inst.visitArg(0, func, Arg.Use, FP, 64);
                        inst.visitArg(1, func, Arg.UseDef, FP, 64);
                        break;
                    default:
                        throw new Error("Bad overload");
                        break;
                }
                break;
            case XorFloat:
                switch (inst.args.length) {
                    case 3:
                        inst.visitArg(0, func, Arg.Use, FP, 32);
                        inst.visitArg(1, func, Arg.Use, FP, 32);
                        inst.visitArg(2, func, Arg.Def, FP, 32);
                        break;
                    case 2:
                        inst.visitArg(0, func, Arg.Use, FP, 32);
                        inst.visitArg(1, func, Arg.UseDef, FP, 32);
                        break;
                    default:
                        throw new Error("Bad overload");
                        break;
                }
                break;
            case Lshift32:
                switch (inst.args.length) {
                    case 3:
                        inst.visitArg(0, func, Arg.Use, GP, 32);
                        inst.visitArg(1, func, Arg.Use, GP, 32);
                        inst.visitArg(2, func, Arg.ZDef, GP, 32);
                        break;
                    case 2:
                        inst.visitArg(0, func, Arg.Use, GP, 32);
                        inst.visitArg(1, func, Arg.UseZDef, GP, 32);
                        break;
                    default:
                        throw new Error("Bad overload");
                        break;
                }
                break;
            case Lshift64:
                switch (inst.args.length) {
                    case 3:
                        inst.visitArg(0, func, Arg.Use, GP, 64);
                        inst.visitArg(1, func, Arg.Use, GP, 64);
                        inst.visitArg(2, func, Arg.ZDef, GP, 64);
                        break;
                    case 2:
                        inst.visitArg(0, func, Arg.Use, GP, 64);
                        inst.visitArg(1, func, Arg.UseDef, GP, 64);
                        break;
                    default:
                        throw new Error("Bad overload");
                        break;
                }
                break;
            case Rshift32:
                switch (inst.args.length) {
                    case 3:
                        inst.visitArg(0, func, Arg.Use, GP, 32);
                        inst.visitArg(1, func, Arg.Use, GP, 32);
                        inst.visitArg(2, func, Arg.ZDef, GP, 32);
                        break;
                    case 2:
                        inst.visitArg(0, func, Arg.Use, GP, 32);
                        inst.visitArg(1, func, Arg.UseZDef, GP, 32);
                        break;
                    default:
                        throw new Error("Bad overload");
                        break;
                }
                break;
            case Rshift64:
                switch (inst.args.length) {
                    case 3:
                        inst.visitArg(0, func, Arg.Use, GP, 64);
                        inst.visitArg(1, func, Arg.Use, GP, 64);
                        inst.visitArg(2, func, Arg.ZDef, GP, 64);
                        break;
                    case 2:
                        inst.visitArg(0, func, Arg.Use, GP, 64);
                        inst.visitArg(1, func, Arg.UseDef, GP, 64);
                        break;
                    default:
                        throw new Error("Bad overload");
                        break;
                }
                break;
            case Urshift32:
                switch (inst.args.length) {
                    case 3:
                        inst.visitArg(0, func, Arg.Use, GP, 32);
                        inst.visitArg(1, func, Arg.Use, GP, 32);
                        inst.visitArg(2, func, Arg.ZDef, GP, 32);
                        break;
                    case 2:
                        inst.visitArg(0, func, Arg.Use, GP, 32);
                        inst.visitArg(1, func, Arg.UseZDef, GP, 32);
                        break;
                    default:
                        throw new Error("Bad overload");
                        break;
                }
                break;
            case Urshift64:
                switch (inst.args.length) {
                    case 3:
                        inst.visitArg(0, func, Arg.Use, GP, 64);
                        inst.visitArg(1, func, Arg.Use, GP, 64);
                        inst.visitArg(2, func, Arg.ZDef, GP, 64);
                        break;
                    case 2:
                        inst.visitArg(0, func, Arg.Use, GP, 64);
                        inst.visitArg(1, func, Arg.UseDef, GP, 64);
                        break;
                    default:
                        throw new Error("Bad overload");
                        break;
                }
                break;
            case Or32:
                switch (inst.args.length) {
                    case 3:
                        inst.visitArg(0, func, Arg.Use, GP, 32);
                        inst.visitArg(1, func, Arg.Use, GP, 32);
                        inst.visitArg(2, func, Arg.ZDef, GP, 32);
                        break;
                    case 2:
                        inst.visitArg(0, func, Arg.Use, GP, 32);
                        inst.visitArg(1, func, Arg.UseZDef, GP, 32);
                        break;
                    default:
                        throw new Error("Bad overload");
                        break;
                }
                break;
            case Or64:
                switch (inst.args.length) {
                    case 3:
                        inst.visitArg(0, func, Arg.Use, GP, 64);
                        inst.visitArg(1, func, Arg.Use, GP, 64);
                        inst.visitArg(2, func, Arg.Def, GP, 64);
                        break;
                    case 2:
                        inst.visitArg(0, func, Arg.Use, GP, 64);
                        inst.visitArg(1, func, Arg.UseDef, GP, 64);
                        break;
                    default:
                        throw new Error("Bad overload");
                        break;
                }
                break;
            case Xor32:
                switch (inst.args.length) {
                    case 3:
                        inst.visitArg(0, func, Arg.Use, GP, 32);
                        inst.visitArg(1, func, Arg.Use, GP, 32);
                        inst.visitArg(2, func, Arg.ZDef, GP, 32);
                        break;
                    case 2:
                        inst.visitArg(0, func, Arg.Use, GP, 32);
                        inst.visitArg(1, func, Arg.UseZDef, GP, 32);
                        break;
                    default:
                        throw new Error("Bad overload");
                        break;
                }
                break;
            case Xor64:
                switch (inst.args.length) {
                    case 3:
                        inst.visitArg(0, func, Arg.Use, GP, 64);
                        inst.visitArg(1, func, Arg.Use, GP, 64);
                        inst.visitArg(2, func, Arg.Def, GP, 64);
                        break;
                    case 2:
                        inst.visitArg(0, func, Arg.Use, GP, 64);
                        inst.visitArg(1, func, Arg.UseDef, GP, 64);
                        break;
                    default:
                        throw new Error("Bad overload");
                        break;
                }
                break;
            case Not32:
                switch (inst.args.length) {
                    case 2:
                        inst.visitArg(0, func, Arg.Use, GP, 32);
                        inst.visitArg(1, func, Arg.ZDef, GP, 32);
                        break;
                    case 1:
                        inst.visitArg(0, func, Arg.UseZDef, GP, 32);
                        break;
                    default:
                        throw new Error("Bad overload");
                        break;
                }
                break;
            case Not64:
                switch (inst.args.length) {
                    case 2:
                        inst.visitArg(0, func, Arg.Use, GP, 64);
                        inst.visitArg(1, func, Arg.Def, GP, 64);
                        break;
                    case 1:
                        inst.visitArg(0, func, Arg.UseDef, GP, 64);
                        break;
                    default:
                        throw new Error("Bad overload");
                        break;
                }
                break;
            case AbsDouble:
                inst.visitArg(0, func, Arg.Use, FP, 64);
                inst.visitArg(1, func, Arg.Def, FP, 64);
                break;
                break;
            case AbsFloat:
                inst.visitArg(0, func, Arg.Use, FP, 32);
                inst.visitArg(1, func, Arg.Def, FP, 32);
                break;
                break;
            case CeilDouble:
                inst.visitArg(0, func, Arg.Use, FP, 64);
                inst.visitArg(1, func, Arg.Def, FP, 64);
                break;
                break;
            case CeilFloat:
                inst.visitArg(0, func, Arg.Use, FP, 32);
                inst.visitArg(1, func, Arg.Def, FP, 32);
                break;
                break;
            case FloorDouble:
                inst.visitArg(0, func, Arg.Use, FP, 64);
                inst.visitArg(1, func, Arg.Def, FP, 64);
                break;
                break;
            case FloorFloat:
                inst.visitArg(0, func, Arg.Use, FP, 32);
                inst.visitArg(1, func, Arg.Def, FP, 32);
                break;
                break;
            case SqrtDouble:
                inst.visitArg(0, func, Arg.Use, FP, 64);
                inst.visitArg(1, func, Arg.Def, FP, 64);
                break;
                break;
            case SqrtFloat:
                inst.visitArg(0, func, Arg.Use, FP, 32);
                inst.visitArg(1, func, Arg.Def, FP, 32);
                break;
                break;
            case ConvertInt32ToDouble:
                inst.visitArg(0, func, Arg.Use, GP, 32);
                inst.visitArg(1, func, Arg.Def, FP, 64);
                break;
                break;
            case ConvertInt64ToDouble:
                inst.visitArg(0, func, Arg.Use, GP, 64);
                inst.visitArg(1, func, Arg.Def, FP, 64);
                break;
                break;
            case ConvertInt32ToFloat:
                inst.visitArg(0, func, Arg.Use, GP, 32);
                inst.visitArg(1, func, Arg.Def, FP, 32);
                break;
                break;
            case ConvertInt64ToFloat:
                inst.visitArg(0, func, Arg.Use, GP, 64);
                inst.visitArg(1, func, Arg.Def, FP, 32);
                break;
                break;
            case CountLeadingZeros32:
                inst.visitArg(0, func, Arg.Use, GP, 32);
                inst.visitArg(1, func, Arg.ZDef, GP, 32);
                break;
                break;
            case CountLeadingZeros64:
                inst.visitArg(0, func, Arg.Use, GP, 64);
                inst.visitArg(1, func, Arg.Def, GP, 64);
                break;
                break;
            case ConvertDoubleToFloat:
                inst.visitArg(0, func, Arg.Use, FP, 64);
                inst.visitArg(1, func, Arg.Def, FP, 32);
                break;
                break;
            case ConvertFloatToDouble:
                inst.visitArg(0, func, Arg.Use, FP, 32);
                inst.visitArg(1, func, Arg.Def, FP, 64);
                break;
                break;
            case Move:
                inst.visitArg(0, func, Arg.Use, GP, Ptr);
                inst.visitArg(1, func, Arg.Def, GP, Ptr);
                break;
                break;
            case Swap32:
                inst.visitArg(0, func, Arg.UseDef, GP, 32);
                inst.visitArg(1, func, Arg.UseDef, GP, 32);
                break;
                break;
            case Swap64:
                inst.visitArg(0, func, Arg.UseDef, GP, 64);
                inst.visitArg(1, func, Arg.UseDef, GP, 64);
                break;
                break;
            case Move32:
                inst.visitArg(0, func, Arg.Use, GP, 32);
                inst.visitArg(1, func, Arg.ZDef, GP, 32);
                break;
                break;
            case StoreZero32:
                inst.visitArg(0, func, Arg.Use, GP, 32);
                break;
                break;
            case SignExtend32ToPtr:
                inst.visitArg(0, func, Arg.Use, GP, 32);
                inst.visitArg(1, func, Arg.Def, GP, Ptr);
                break;
                break;
            case ZeroExtend8To32:
                inst.visitArg(0, func, Arg.Use, GP, 8);
                inst.visitArg(1, func, Arg.ZDef, GP, 32);
                break;
                break;
            case SignExtend8To32:
                inst.visitArg(0, func, Arg.Use, GP, 8);
                inst.visitArg(1, func, Arg.ZDef, GP, 32);
                break;
                break;
            case ZeroExtend16To32:
                inst.visitArg(0, func, Arg.Use, GP, 16);
                inst.visitArg(1, func, Arg.ZDef, GP, 32);
                break;
                break;
            case SignExtend16To32:
                inst.visitArg(0, func, Arg.Use, GP, 16);
                inst.visitArg(1, func, Arg.ZDef, GP, 32);
                break;
                break;
            case MoveFloat:
                inst.visitArg(0, func, Arg.Use, FP, 32);
                inst.visitArg(1, func, Arg.Def, FP, 32);
                break;
                break;
            case MoveDouble:
                inst.visitArg(0, func, Arg.Use, FP, 64);
                inst.visitArg(1, func, Arg.Def, FP, 64);
                break;
                break;
            case MoveZeroToDouble:
                inst.visitArg(0, func, Arg.Def, FP, 64);
                break;
                break;
            case Move64ToDouble:
                inst.visitArg(0, func, Arg.Use, GP, 64);
                inst.visitArg(1, func, Arg.Def, FP, 64);
                break;
                break;
            case Move32ToFloat:
                inst.visitArg(0, func, Arg.Use, GP, 32);
                inst.visitArg(1, func, Arg.Def, FP, 32);
                break;
                break;
            case MoveDoubleTo64:
                inst.visitArg(0, func, Arg.Use, FP, 64);
                inst.visitArg(1, func, Arg.Def, GP, 64);
                break;
                break;
            case MoveFloatTo32:
                inst.visitArg(0, func, Arg.Use, FP, 32);
                inst.visitArg(1, func, Arg.Def, GP, 32);
                break;
                break;
            case Load8:
                inst.visitArg(0, func, Arg.Use, GP, 8);
                inst.visitArg(1, func, Arg.ZDef, GP, 32);
                break;
                break;
            case Store8:
                inst.visitArg(0, func, Arg.Use, GP, 8);
                inst.visitArg(1, func, Arg.Def, GP, 8);
                break;
                break;
            case Load8SignedExtendTo32:
                inst.visitArg(0, func, Arg.Use, GP, 8);
                inst.visitArg(1, func, Arg.ZDef, GP, 32);
                break;
                break;
            case Load16:
                inst.visitArg(0, func, Arg.Use, GP, 16);
                inst.visitArg(1, func, Arg.ZDef, GP, 32);
                break;
                break;
            case Load16SignedExtendTo32:
                inst.visitArg(0, func, Arg.Use, GP, 16);
                inst.visitArg(1, func, Arg.ZDef, GP, 32);
                break;
                break;
            case Store16:
                inst.visitArg(0, func, Arg.Use, GP, 16);
                inst.visitArg(1, func, Arg.Def, GP, 16);
                break;
                break;
            case Compare32:
                inst.visitArg(0, func, Arg.Use, GP, 32);
                inst.visitArg(1, func, Arg.Use, GP, 32);
                inst.visitArg(2, func, Arg.Use, GP, 32);
                inst.visitArg(3, func, Arg.ZDef, GP, 32);
                break;
                break;
            case Compare64:
                inst.visitArg(0, func, Arg.Use, GP, 32);
                inst.visitArg(1, func, Arg.Use, GP, 64);
                inst.visitArg(2, func, Arg.Use, GP, 64);
                inst.visitArg(3, func, Arg.ZDef, GP, 32);
                break;
                break;
            case Test32:
                inst.visitArg(0, func, Arg.Use, GP, 32);
                inst.visitArg(1, func, Arg.Use, GP, 32);
                inst.visitArg(2, func, Arg.Use, GP, 32);
                inst.visitArg(3, func, Arg.ZDef, GP, 32);
                break;
                break;
            case Test64:
                inst.visitArg(0, func, Arg.Use, GP, 32);
                inst.visitArg(1, func, Arg.Use, GP, 64);
                inst.visitArg(2, func, Arg.Use, GP, 64);
                inst.visitArg(3, func, Arg.ZDef, GP, 32);
                break;
                break;
            case CompareDouble:
                inst.visitArg(0, func, Arg.Use, GP, 32);
                inst.visitArg(1, func, Arg.Use, FP, 64);
                inst.visitArg(2, func, Arg.Use, FP, 64);
                inst.visitArg(3, func, Arg.ZDef, GP, 32);
                break;
                break;
            case CompareFloat:
                inst.visitArg(0, func, Arg.Use, GP, 32);
                inst.visitArg(1, func, Arg.Use, FP, 32);
                inst.visitArg(2, func, Arg.Use, FP, 32);
                inst.visitArg(3, func, Arg.ZDef, GP, 32);
                break;
                break;
            case Branch8:
                inst.visitArg(0, func, Arg.Use, GP, 32);
                inst.visitArg(1, func, Arg.Use, GP, 8);
                inst.visitArg(2, func, Arg.Use, GP, 8);
                break;
                break;
            case Branch32:
                inst.visitArg(0, func, Arg.Use, GP, 32);
                inst.visitArg(1, func, Arg.Use, GP, 32);
                inst.visitArg(2, func, Arg.Use, GP, 32);
                break;
                break;
            case Branch64:
                inst.visitArg(0, func, Arg.Use, GP, 32);
                inst.visitArg(1, func, Arg.Use, GP, 64);
                inst.visitArg(2, func, Arg.Use, GP, 64);
                break;
                break;
            case BranchTest8:
                inst.visitArg(0, func, Arg.Use, GP, 32);
                inst.visitArg(1, func, Arg.Use, GP, 8);
                inst.visitArg(2, func, Arg.Use, GP, 8);
                break;
                break;
            case BranchTest32:
                inst.visitArg(0, func, Arg.Use, GP, 32);
                inst.visitArg(1, func, Arg.Use, GP, 32);
                inst.visitArg(2, func, Arg.Use, GP, 32);
                break;
                break;
            case BranchTest64:
                inst.visitArg(0, func, Arg.Use, GP, 32);
                inst.visitArg(1, func, Arg.Use, GP, 64);
                inst.visitArg(2, func, Arg.Use, GP, 64);
                break;
                break;
            case BranchDouble:
                inst.visitArg(0, func, Arg.Use, GP, 32);
                inst.visitArg(1, func, Arg.Use, FP, 64);
                inst.visitArg(2, func, Arg.Use, FP, 64);
                break;
                break;
            case BranchFloat:
                inst.visitArg(0, func, Arg.Use, GP, 32);
                inst.visitArg(1, func, Arg.Use, FP, 32);
                inst.visitArg(2, func, Arg.Use, FP, 32);
                break;
                break;
            case BranchAdd32:
                switch (inst.args.length) {
                    case 4:
                        inst.visitArg(0, func, Arg.Use, GP, 32);
                        inst.visitArg(1, func, Arg.Use, GP, 32);
                        inst.visitArg(2, func, Arg.Use, GP, 32);
                        inst.visitArg(3, func, Arg.ZDef, GP, 32);
                        break;
                    case 3:
                        inst.visitArg(0, func, Arg.Use, GP, 32);
                        inst.visitArg(1, func, Arg.Use, GP, 32);
                        inst.visitArg(2, func, Arg.UseZDef, GP, 32);
                        break;
                    default:
                        throw new Error("Bad overload");
                        break;
                }
                break;
            case BranchAdd64:
                switch (inst.args.length) {
                    case 4:
                        inst.visitArg(0, func, Arg.Use, GP, 32);
                        inst.visitArg(1, func, Arg.Use, GP, 64);
                        inst.visitArg(2, func, Arg.Use, GP, 64);
                        inst.visitArg(3, func, Arg.ZDef, GP, 64);
                        break;
                    case 3:
                        inst.visitArg(0, func, Arg.Use, GP, 32);
                        inst.visitArg(1, func, Arg.Use, GP, 64);
                        inst.visitArg(2, func, Arg.UseDef, GP, 64);
                        break;
                    default:
                        throw new Error("Bad overload");
                        break;
                }
                break;
            case BranchMul32:
                switch (inst.args.length) {
                    case 3:
                        inst.visitArg(0, func, Arg.Use, GP, 32);
                        inst.visitArg(1, func, Arg.Use, GP, 32);
                        inst.visitArg(2, func, Arg.UseZDef, GP, 32);
                        break;
                    case 4:
                        inst.visitArg(0, func, Arg.Use, GP, 32);
                        inst.visitArg(1, func, Arg.Use, GP, 32);
                        inst.visitArg(2, func, Arg.Use, GP, 32);
                        inst.visitArg(3, func, Arg.ZDef, GP, 32);
                        break;
                    case 6:
                        inst.visitArg(0, func, Arg.Use, GP, 32);
                        inst.visitArg(1, func, Arg.Use, GP, 32);
                        inst.visitArg(2, func, Arg.Use, GP, 32);
                        inst.visitArg(3, func, Arg.Scratch, GP, 32);
                        inst.visitArg(4, func, Arg.Scratch, GP, 32);
                        inst.visitArg(5, func, Arg.ZDef, GP, 32);
                        break;
                    default:
                        throw new Error("Bad overload");
                        break;
                }
                break;
            case BranchMul64:
                switch (inst.args.length) {
                    case 3:
                        inst.visitArg(0, func, Arg.Use, GP, 32);
                        inst.visitArg(1, func, Arg.Use, GP, 64);
                        inst.visitArg(2, func, Arg.UseZDef, GP, 64);
                        break;
                    case 6:
                        inst.visitArg(0, func, Arg.Use, GP, 32);
                        inst.visitArg(1, func, Arg.Use, GP, 64);
                        inst.visitArg(2, func, Arg.Use, GP, 64);
                        inst.visitArg(3, func, Arg.Scratch, GP, 64);
                        inst.visitArg(4, func, Arg.Scratch, GP, 64);
                        inst.visitArg(5, func, Arg.ZDef, GP, 64);
                        break;
                    default:
                        throw new Error("Bad overload");
                        break;
                }
                break;
            case BranchSub32:
                inst.visitArg(0, func, Arg.Use, GP, 32);
                inst.visitArg(1, func, Arg.Use, GP, 32);
                inst.visitArg(2, func, Arg.UseZDef, GP, 32);
                break;
                break;
            case BranchSub64:
                inst.visitArg(0, func, Arg.Use, GP, 32);
                inst.visitArg(1, func, Arg.Use, GP, 64);
                inst.visitArg(2, func, Arg.UseDef, GP, 64);
                break;
                break;
            case BranchNeg32:
                inst.visitArg(0, func, Arg.Use, GP, 32);
                inst.visitArg(1, func, Arg.UseZDef, GP, 32);
                break;
                break;
            case BranchNeg64:
                inst.visitArg(0, func, Arg.Use, GP, 32);
                inst.visitArg(1, func, Arg.UseZDef, GP, 64);
                break;
                break;
            case MoveConditionally32:
                switch (inst.args.length) {
                    case 5:
                        inst.visitArg(0, func, Arg.Use, GP, 32);
                        inst.visitArg(1, func, Arg.Use, GP, 32);
                        inst.visitArg(2, func, Arg.Use, GP, 32);
                        inst.visitArg(3, func, Arg.Use, GP, Ptr);
                        inst.visitArg(4, func, Arg.UseDef, GP, Ptr);
                        break;
                    case 6:
                        inst.visitArg(0, func, Arg.Use, GP, 32);
                        inst.visitArg(1, func, Arg.Use, GP, 32);
                        inst.visitArg(2, func, Arg.Use, GP, 32);
                        inst.visitArg(3, func, Arg.Use, GP, Ptr);
                        inst.visitArg(4, func, Arg.Use, GP, Ptr);
                        inst.visitArg(5, func, Arg.Def, GP, Ptr);
                        break;
                    default:
                        throw new Error("Bad overload");
                        break;
                }
                break;
            case MoveConditionally64:
                switch (inst.args.length) {
                    case 5:
                        inst.visitArg(0, func, Arg.Use, GP, 32);
                        inst.visitArg(1, func, Arg.Use, GP, 64);
                        inst.visitArg(2, func, Arg.Use, GP, 64);
                        inst.visitArg(3, func, Arg.Use, GP, Ptr);
                        inst.visitArg(4, func, Arg.UseDef, GP, Ptr);
                        break;
                    case 6:
                        inst.visitArg(0, func, Arg.Use, GP, 32);
                        inst.visitArg(1, func, Arg.Use, GP, 64);
                        inst.visitArg(2, func, Arg.Use, GP, 64);
                        inst.visitArg(3, func, Arg.Use, GP, Ptr);
                        inst.visitArg(4, func, Arg.Use, GP, Ptr);
                        inst.visitArg(5, func, Arg.Def, GP, Ptr);
                        break;
                    default:
                        throw new Error("Bad overload");
                        break;
                }
                break;
            case MoveConditionallyTest32:
                switch (inst.args.length) {
                    case 5:
                        inst.visitArg(0, func, Arg.Use, GP, 32);
                        inst.visitArg(1, func, Arg.Use, GP, 32);
                        inst.visitArg(2, func, Arg.Use, GP, 32);
                        inst.visitArg(3, func, Arg.Use, GP, Ptr);
                        inst.visitArg(4, func, Arg.UseDef, GP, Ptr);
                        break;
                    case 6:
                        inst.visitArg(0, func, Arg.Use, GP, 32);
                        inst.visitArg(1, func, Arg.Use, GP, 32);
                        inst.visitArg(2, func, Arg.Use, GP, 32);
                        inst.visitArg(3, func, Arg.Use, GP, Ptr);
                        inst.visitArg(4, func, Arg.Use, GP, Ptr);
                        inst.visitArg(5, func, Arg.Def, GP, Ptr);
                        break;
                    default:
                        throw new Error("Bad overload");
                        break;
                }
                break;
            case MoveConditionallyTest64:
                switch (inst.args.length) {
                    case 5:
                        inst.visitArg(0, func, Arg.Use, GP, 32);
                        inst.visitArg(1, func, Arg.Use, GP, 64);
                        inst.visitArg(2, func, Arg.Use, GP, 64);
                        inst.visitArg(3, func, Arg.Use, GP, Ptr);
                        inst.visitArg(4, func, Arg.UseDef, GP, Ptr);
                        break;
                    case 6:
                        inst.visitArg(0, func, Arg.Use, GP, 32);
                        inst.visitArg(1, func, Arg.Use, GP, 32);
                        inst.visitArg(2, func, Arg.Use, GP, 32);
                        inst.visitArg(3, func, Arg.Use, GP, Ptr);
                        inst.visitArg(4, func, Arg.Use, GP, Ptr);
                        inst.visitArg(5, func, Arg.Def, GP, Ptr);
                        break;
                    default:
                        throw new Error("Bad overload");
                        break;
                }
                break;
            case MoveConditionallyDouble:
                switch (inst.args.length) {
                    case 6:
                        inst.visitArg(0, func, Arg.Use, GP, 32);
                        inst.visitArg(1, func, Arg.Use, FP, 64);
                        inst.visitArg(2, func, Arg.Use, FP, 64);
                        inst.visitArg(3, func, Arg.Use, GP, Ptr);
                        inst.visitArg(4, func, Arg.Use, GP, Ptr);
                        inst.visitArg(5, func, Arg.Def, GP, Ptr);
                        break;
                    case 5:
                        inst.visitArg(0, func, Arg.Use, GP, 32);
                        inst.visitArg(1, func, Arg.Use, FP, 64);
                        inst.visitArg(2, func, Arg.Use, FP, 64);
                        inst.visitArg(3, func, Arg.Use, GP, Ptr);
                        inst.visitArg(4, func, Arg.UseDef, GP, Ptr);
                        break;
                    default:
                        throw new Error("Bad overload");
                        break;
                }
                break;
            case MoveConditionallyFloat:
                switch (inst.args.length) {
                    case 6:
                        inst.visitArg(0, func, Arg.Use, GP, 32);
                        inst.visitArg(1, func, Arg.Use, FP, 32);
                        inst.visitArg(2, func, Arg.Use, FP, 32);
                        inst.visitArg(3, func, Arg.Use, GP, Ptr);
                        inst.visitArg(4, func, Arg.Use, GP, Ptr);
                        inst.visitArg(5, func, Arg.Def, GP, Ptr);
                        break;
                    case 5:
                        inst.visitArg(0, func, Arg.Use, GP, 32);
                        inst.visitArg(1, func, Arg.Use, FP, 32);
                        inst.visitArg(2, func, Arg.Use, FP, 32);
                        inst.visitArg(3, func, Arg.Use, GP, Ptr);
                        inst.visitArg(4, func, Arg.UseDef, GP, Ptr);
                        break;
                    default:
                        throw new Error("Bad overload");
                        break;
                }
                break;
            case MoveDoubleConditionally32:
                inst.visitArg(0, func, Arg.Use, GP, 32);
                inst.visitArg(1, func, Arg.Use, GP, 32);
                inst.visitArg(2, func, Arg.Use, GP, 32);
                inst.visitArg(3, func, Arg.Use, FP, 64);
                inst.visitArg(4, func, Arg.Use, FP, 64);
                inst.visitArg(5, func, Arg.Def, FP, 64);
                break;
                break;
            case MoveDoubleConditionally64:
                inst.visitArg(0, func, Arg.Use, GP, 32);
                inst.visitArg(1, func, Arg.Use, GP, 64);
                inst.visitArg(2, func, Arg.Use, GP, 64);
                inst.visitArg(3, func, Arg.Use, FP, 64);
                inst.visitArg(4, func, Arg.Use, FP, 64);
                inst.visitArg(5, func, Arg.Def, FP, 64);
                break;
                break;
            case MoveDoubleConditionallyTest32:
                inst.visitArg(0, func, Arg.Use, GP, 32);
                inst.visitArg(1, func, Arg.Use, GP, 32);
                inst.visitArg(2, func, Arg.Use, GP, 32);
                inst.visitArg(3, func, Arg.Use, FP, 64);
                inst.visitArg(4, func, Arg.Use, FP, 64);
                inst.visitArg(5, func, Arg.Def, FP, 64);
                break;
                break;
            case MoveDoubleConditionallyTest64:
                inst.visitArg(0, func, Arg.Use, GP, 32);
                inst.visitArg(1, func, Arg.Use, GP, 64);
                inst.visitArg(2, func, Arg.Use, GP, 64);
                inst.visitArg(3, func, Arg.Use, FP, 64);
                inst.visitArg(4, func, Arg.Use, FP, 64);
                inst.visitArg(5, func, Arg.Def, FP, 64);
                break;
                break;
            case MoveDoubleConditionallyDouble:
                inst.visitArg(0, func, Arg.Use, GP, 32);
                inst.visitArg(1, func, Arg.Use, FP, 64);
                inst.visitArg(2, func, Arg.Use, FP, 64);
                inst.visitArg(3, func, Arg.Use, FP, 64);
                inst.visitArg(4, func, Arg.Use, FP, 64);
                inst.visitArg(5, func, Arg.Def, FP, 64);
                break;
                break;
            case MoveDoubleConditionallyFloat:
                inst.visitArg(0, func, Arg.Use, GP, 32);
                inst.visitArg(1, func, Arg.Use, FP, 32);
                inst.visitArg(2, func, Arg.Use, FP, 32);
                inst.visitArg(3, func, Arg.Use, FP, 64);
                inst.visitArg(4, func, Arg.Use, FP, 64);
                inst.visitArg(5, func, Arg.Def, FP, 64);
                break;
                break;
            case Jump:
                break;
                break;
            case Ret32:
                inst.visitArg(0, func, Arg.Use, GP, 32);
                break;
                break;
            case Ret64:
                inst.visitArg(0, func, Arg.Use, GP, 64);
                break;
                break;
            case RetFloat:
                inst.visitArg(0, func, Arg.Use, FP, 32);
                break;
                break;
            case RetDouble:
                inst.visitArg(0, func, Arg.Use, FP, 64);
                break;
                break;
            case Oops:
                break;
                break;
            case Shuffle:
                ShuffleCustom.forEachArg(inst, func);
                break;
            case Patch:
                PatchCustom.forEachArg(inst, func);
                break;
            case CCall:
                CCallCustom.forEachArg(inst, func);
                break;
            case ColdCCall:
                ColdCCallCustom.forEachArg(inst, func);
                break;
            default:
                throw "Bad opcode";
        }
    }
    function /*<@278>*/Inst_hasNonArgEffects(/*<@15>*/inst) {
        switch (inst.opcode) {
            case Branch8:
            case Branch32:
            case Branch64:
            case BranchTest8:
            case BranchTest32:
            case BranchTest64:
            case BranchDouble:
            case BranchFloat:
            case BranchAdd32:
            case BranchAdd64:
            case BranchMul32:
            case BranchMul64:
            case BranchSub32:
            case BranchSub64:
            case BranchNeg32:
            case BranchNeg64:
            case Jump:
            case Ret32:
            case Ret64:
            case RetFloat:
            case RetDouble:
            case Oops:
                return true;
            case Shuffle:
                return ShuffleCustom.hasNonArgNonControlEffects(inst);
            case Patch:
                return PatchCustom.hasNonArgNonControlEffects(inst);
            case CCall:
                return CCallCustom.hasNonArgNonControlEffects(inst);
            case ColdCCall:
                return ColdCCallCustom.hasNonArgNonControlEffects(inst);
            default:
                return false;
        }
    }
    function /*<@279>*/opcodeCode(/*<@7>*/opcode) {
        switch (opcode) {
            case AbsDouble:
                return 0;
            case AbsFloat:
                return 1;
            case Add16:
                return 2;
            case Add32:
                return 3;
            case Add64:
                return 4;
            case Add8:
                return 5;
            case AddDouble:
                return 6;
            case AddFloat:
                return 7;
            case And32:
                return 8;
            case And64:
                return 9;
            case AndDouble:
                return 10;
            case AndFloat:
                return 11;
            case Branch32:
                return 12;
            case Branch64:
                return 13;
            case Branch8:
                return 14;
            case BranchAdd32:
                return 15;
            case BranchAdd64:
                return 16;
            case BranchDouble:
                return 17;
            case BranchFloat:
                return 18;
            case BranchMul32:
                return 19;
            case BranchMul64:
                return 20;
            case BranchNeg32:
                return 21;
            case BranchNeg64:
                return 22;
            case BranchSub32:
                return 23;
            case BranchSub64:
                return 24;
            case BranchTest32:
                return 25;
            case BranchTest64:
                return 26;
            case BranchTest8:
                return 27;
            case CCall:
                return 28;
            case CeilDouble:
                return 29;
            case CeilFloat:
                return 30;
            case ColdCCall:
                return 31;
            case Compare32:
                return 32;
            case Compare64:
                return 33;
            case CompareDouble:
                return 34;
            case CompareFloat:
                return 35;
            case ConvertDoubleToFloat:
                return 36;
            case ConvertFloatToDouble:
                return 37;
            case ConvertInt32ToDouble:
                return 38;
            case ConvertInt32ToFloat:
                return 39;
            case ConvertInt64ToDouble:
                return 40;
            case ConvertInt64ToFloat:
                return 41;
            case CountLeadingZeros32:
                return 42;
            case CountLeadingZeros64:
                return 43;
            case Div32:
                return 44;
            case Div64:
                return 45;
            case DivDouble:
                return 46;
            case DivFloat:
                return 47;
            case FloorDouble:
                return 48;
            case FloorFloat:
                return 49;
            case Jump:
                return 50;
            case Lea:
                return 51;
            case Load16:
                return 52;
            case Load16SignedExtendTo32:
                return 53;
            case Load8:
                return 54;
            case Load8SignedExtendTo32:
                return 55;
            case Lshift32:
                return 56;
            case Lshift64:
                return 57;
            case Move:
                return 58;
            case Move32:
                return 59;
            case Move32ToFloat:
                return 60;
            case Move64ToDouble:
                return 61;
            case MoveConditionally32:
                return 62;
            case MoveConditionally64:
                return 63;
            case MoveConditionallyDouble:
                return 64;
            case MoveConditionallyFloat:
                return 65;
            case MoveConditionallyTest32:
                return 66;
            case MoveConditionallyTest64:
                return 67;
            case MoveDouble:
                return 68;
            case MoveDoubleConditionally32:
                return 69;
            case MoveDoubleConditionally64:
                return 70;
            case MoveDoubleConditionallyDouble:
                return 71;
            case MoveDoubleConditionallyFloat:
                return 72;
            case MoveDoubleConditionallyTest32:
                return 73;
            case MoveDoubleConditionallyTest64:
                return 74;
            case MoveDoubleTo64:
                return 75;
            case MoveFloat:
                return 76;
            case MoveFloatTo32:
                return 77;
            case MoveZeroToDouble:
                return 78;
            case Mul32:
                return 79;
            case Mul64:
                return 80;
            case MulDouble:
                return 81;
            case MulFloat:
                return 82;
            case MultiplyAdd32:
                return 83;
            case MultiplyAdd64:
                return 84;
            case MultiplyNeg32:
                return 85;
            case MultiplyNeg64:
                return 86;
            case MultiplySub32:
                return 87;
            case MultiplySub64:
                return 88;
            case Neg32:
                return 89;
            case Neg64:
                return 90;
            case NegateDouble:
                return 91;
            case Nop:
                return 92;
            case Not32:
                return 93;
            case Not64:
                return 94;
            case Oops:
                return 95;
            case Or32:
                return 96;
            case Or64:
                return 97;
            case Patch:
                return 98;
            case Ret32:
                return 99;
            case Ret64:
                return 100;
            case RetDouble:
                return 101;
            case RetFloat:
                return 102;
            case Rshift32:
                return 103;
            case Rshift64:
                return 104;
            case Shuffle:
                return 105;
            case SignExtend16To32:
                return 106;
            case SignExtend32ToPtr:
                return 107;
            case SignExtend8To32:
                return 108;
            case SqrtDouble:
                return 109;
            case SqrtFloat:
                return 110;
            case Store16:
                return 111;
            case Store8:
                return 112;
            case StoreZero32:
                return 113;
            case Sub32:
                return 114;
            case Sub64:
                return 115;
            case SubDouble:
                return 116;
            case SubFloat:
                return 117;
            case Swap32:
                return 118;
            case Swap64:
                return 119;
            case Test32:
                return 120;
            case Test64:
                return 121;
            case Urshift32:
                return 122;
            case Urshift64:
                return 123;
            case X86ConvertToDoubleWord32:
                return 124;
            case X86ConvertToQuadWord64:
                return 125;
            case X86Div32:
                return 126;
            case X86Div64:
                return 127;
            case Xor32:
                return 128;
            case Xor64:
                return 129;
            case XorDouble:
                return 130;
            case XorFloat:
                return 131;
            case ZeroExtend16To32:
                return 132;
            case ZeroExtend8To32:
                return 133;
            default:
                throw new Error("bad opcode");
        }
    }
    /*
     * Copyright (C) 2016 Apple Inc. All rights reserved.
     *
     * Redistribution and use in source and binary forms, with or without
     * modification, are permitted provided that the following conditions
     * are met:
     * 1. Redistributions of source code must retain the above copyright
     *    notice, this list of conditions and the following disclaimer.
     * 2. Redistributions in binary form must reproduce the above copyright
     *    notice, this list of conditions and the following disclaimer in the
     *    documentation and/or other materials provided with the distribution.
     *
     * THIS SOFTWARE IS PROVIDED BY APPLE INC. ``AS IS'' AND ANY
     * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
     * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
     * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE INC. OR
     * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
     * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
     * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
     * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
     * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
     * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
     * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
     */
    class /*<@14>*/BasicBlock {
        constructor(/*<@5>*/index, /*<@5>*/frequency) {
            this._index = index;
            this._frequency = frequency;
            this._insts = /*<@256>*/[];
            this._successors = /*<@256>*/[];
            this._predecessors = /*<@256>*/[];
        }
        get /*<@204>*/index() { return this._index; }
        get /*<@205>*/size() { return this._insts./*<@5>*/length; }
        [Symbol.iterator]() {
            return this._insts[Symbol.iterator]();
        }
        /*<@208>*/at(/*<@5>*/index) {
            if (index >= this._insts./*<@5>*/length)
                throw new Error("Out of bounds access");
            return this._insts[index];
        }
        /*<@209>*/get(/*<@5>*/index) {
            if (index < 0 || index >= this._insts./*<@5>*/length)
                return null;
            return this._insts[index];
        }
        get /*<@211>*/last() {
            return this._insts[this._insts./*<@5>*/length - 1];
        }
        get /*<@212>*/insts() { return this._insts; }
        /*<@213>*/append(/*<@15>*/inst) { this._insts.push(inst); }
        get /*<@214>*/numSuccessors() { return this._successors.length; }
        /*<@215>*/successor(/*<@5>*/index) { return this._successors[index]; }
        get /*<@216>*/successors() { return this._successors; }
        /*<@217>*/successorBlock(/*<@5>*/index) { return this._successors[index].block; }
        get /*<@218>*/successorBlocks() {
            return new Proxy(this._successors, /*<@284>*/{
                /*<@280>*/get(/*<@202>*/target, /*<@281>*/property) {
                    if (typeof property == "string"
                        && (/*<@243>*/property | 0) == /*<@243>*/property)
                        return target[/*<@243>*/property].block;
                    return target[/*<@243>*/property];
                },
                /*<@283>*/set(/*<@202>*/target, /*<@281>*/property, /*<@13>*/value) {
                    if (typeof property == "string"
                        && (/*<@243>*/property | 0) == /*<@243>*/property) {
                        var /*<@199>*/oldValue = target[/*<@243>*/property];
                        target[/*<@243>*/property] = new FrequentedBlock(value, oldValue ? oldValue.frequency : Normal);
                        return true;
                    }
                    target[/*<@243>*/property] = /*<@243>*/value;
                    return true;
                }
            });
        }
        get /*<@219>*/numPredecessors() { return this._predecessors.length; }
        /*<@220>*/predecessor(/*<@5>*/index) { return this._predecessors[index]; }
        get /*<@221>*/predecessors() { return this._predecessors; }
        get /*<@222>*/frequency() { return this._frequency; }
        /*<@223>*/toString() {
            return "#" + this._index;
        }
        get /*<@224>*/headerString() {
            let /*<@3>*/result = "";
            result += `BB${this}: ; frequency = ${this._frequency}\n`;
            if (this._predecessors.length)
                result += "  Predecessors: " + this._predecessors.join(", ") + "\n";
            return result;
        }
        get /*<@225>*/footerString() {
            let /*<@3>*/result = "";
            if (this._successors.length)
                result += "  Successors: " + this._successors.join(", ") + "\n";
            return result;
        }
        /*<@226>*/toStringDeep() {
            let /*<@3>*/result = "";
            result += this.headerString;
            for (let /*<@15>*/inst of this)
                result += `    ${inst}\n`;
            result += this.footerString;
            return result;
        }
    }
    /*
     * Copyright (C) 2016 Apple Inc. All rights reserved.
     *
     * Redistribution and use in source and binary forms, with or without
     * modification, are permitted provided that the following conditions
     * are met:
     * 1. Redistributions of source code must retain the above copyright
     *    notice, this list of conditions and the following disclaimer.
     * 2. Redistributions in binary form must reproduce the above copyright
     *    notice, this list of conditions and the following disclaimer in the
     *    documentation and/or other materials provided with the distribution.
     *
     * THIS SOFTWARE IS PROVIDED BY APPLE INC. ``AS IS'' AND ANY
     * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
     * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
     * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE INC. OR
     * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
     * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
     * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
     * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
     * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
     * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
     * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
     */
    class /*<@286>*/LocalCalc {
        constructor(/*<@287>*/liveness, /*<@13>*/block) {
            this._liveness = liveness;
            this._block = block;
            this._liveSet = new Set(liveness.liveAtTail.get(block));
        }
        get /*<@295>*/liveSet() { return this._liveSet; }
        /*<@296>*/execute(/*<@5>*/instIndex) {
            let /*<@15>*/inst = this._block.at(instIndex);
            // First handle the early defs of the next instruction.
            if (instIndex + 1 < this._block.size) {
                this._block.at(instIndex + 1).forEach(this._liveness.thing, /*<@297>*/(/*<@47>*/value, /*<@7>*/role, /*<@7>*/type, /*<@5>*/width) => {
                    if (Arg.isEarlyDef(role))
                        this._liveSet.delete(value);
                });
            }
            // Then handle defs.
            inst.forEach(this._liveness.thing, /*<@298>*/(/*<@47>*/value, /*<@7>*/role, /*<@7>*/type, /*<@5>*/width) => {
                if (Arg.isLateDef(role))
                    this._liveSet.delete(value);
            });
            // Then handle uses.
            inst.forEach(this._liveness.thing, /*<@299>*/(/*<@47>*/value, /*<@7>*/role, /*<@7>*/type, /*<@5>*/width) => {
                if (Arg.isEarlyUse(role))
                    this._liveSet.add(value);
            });
            // Finally handle the late uses of the previous instruction.
            if (instIndex - 1 >= 0) {
                this._block.at(instIndex - 1).forEach(this._liveness.thing, /*<@300>*/(/*<@47>*/value, /*<@7>*/role, /*<@7>*/type, /*<@5>*/width) => {
                    if (Arg.isLateUse(role))
                        this._liveSet.add(value);
                });
            }
        }
    }
    class /*<@288>*/Liveness {
        constructor(/*<@48>*/thing, /*<@258>*/code) {
            this._thing = thing;
            this._code = code;
            this._liveAtHead = new Map();
            this._liveAtTail = new Map();
            for (let /*<@13>*/block of code) {
                this._liveAtHead.set(block, new Set());
                let /*<@181>*/liveAtTail = new Set();
                this._liveAtTail.set(block, liveAtTail);
                block.last.forEach(thing, /*<@301>*/(/*<@47>*/value, /*<@7>*/role, /*<@7>*/type, /*<@5>*/width) => {
                    if (Arg.isLateUse(role))
                        liveAtTail.add(value);
                });
            }
            let /*<@181>*/dirtyBlocks = new Set(code);
            let /*<@2>*/changed;
            do {
                changed = false;
                for (let /*<@5>*/blockIndex = code.size; blockIndex--;) {
                    let /*<@13>*/block = code.at(blockIndex);
                    if (!block)
                        continue;
                    if (!dirtyBlocks.delete(block))
                        continue;
                    let /*<@285>*/localCalc = this.localCalc(block);
                    for (let /*<@5>*/instIndex = block.size; instIndex--;)
                        localCalc.execute(instIndex);
                    // Handle the early def's of the first instruction.
                    block.at(0).forEach(thing, /*<@302>*/(/*<@47>*/value, /*<@7>*/role, /*<@7>*/type, /*<@5>*/width) => {
                        if (Arg.isEarlyDef(role))
                            localCalc.liveSet.delete(value);
                    });
                    let /*<@181>*/liveAtHead = this._liveAtHead.get(block);
                    if (!mergeIntoSet(liveAtHead, localCalc.liveSet))
                        continue;
                    for (let /*<@13>*/predecessor of block.predecessors) {
                        if (mergeIntoSet(this._liveAtTail.get(predecessor), liveAtHead)) {
                            dirtyBlocks.add(predecessor);
                            changed = true;
                        }
                    }
                }
            } while (changed);
        }
        get /*<@290>*/thing() { return this._thing; }
        get /*<@291>*/code() { return this._code; }
        get /*<@292>*/liveAtHead() { return this._liveAtHead; }
        get /*<@293>*/liveAtTail() { return this._liveAtTail; }
        /*<@294>*/localCalc(/*<@13>*/block) {
            let /*<@287>*/liveness = this;
            return new LocalCalc(liveness, block);
        }
    }
    /*
     * Copyright (C) 2016 Apple Inc. All rights reserved.
     *
     * Redistribution and use in source and binary forms, with or without
     * modification, are permitted provided that the following conditions
     * are met:
     * 1. Redistributions of source code must retain the above copyright
     *    notice, this list of conditions and the following disclaimer.
     * 2. Redistributions in binary form must reproduce the above copyright
     *    notice, this list of conditions and the following disclaimer in the
     *    documentation and/or other materials provided with the distribution.
     *
     * THIS SOFTWARE IS PROVIDED BY APPLE INC. ``AS IS'' AND ANY
     * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
     * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
     * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE INC. OR
     * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
     * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
     * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
     * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
     * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
     * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
     * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
     */
    const /*<@305>*/ShuffleCustom = /*<@305>*/{
        /*<@303>*/forEachArg(/*<@15>*/inst, func) {
            var /*<@5>*/limit = Math.floor(inst.args.length / 3) * 3;
            for (let /*<@5>*/i = 0; i < limit; i += 3) {
                let /*<@17>*/src = inst.args[i + 0];
                let /*<@17>*/dst = inst.args[i + 1];
                let /*<@17>*/widthArg = inst.args[i + 2];
                let /*<@5>*/width = widthArg.width;
                let /*<@7>*/type = src.isGP && dst.isGP ? GP : FP;
                inst.visitArg(i + 0, func, Arg.Use, type, width);
                inst.visitArg(i + 1, func, Arg.Def, type, width);
                inst.visitArg(i + 2, func, Arg.Use, GP, 8);
            }
        },
        /*<@304>*/hasNonArgNonControlEffects(/*<@15>*/inst) {
            return false;
        }
    };
    const /*<@308>*/PatchCustom = /*<@308>*/{
        /*<@306>*/forEachArg(/*<@15>*/inst, func) {
            for (let /*<@5>*/i = 0; i < inst.args.length; ++i) {
                let { type, role, /*<@5>*/width } = inst.patchArgData[i];
                inst.visitArg(i, func, role, type, width);
            }
        },
        /*<@307>*/hasNonArgNonControlEffects(/*<@15>*/inst) {
            return inst.patchHasNonArgEffects;
        }
    };
    const /*<@311>*/CCallCustom = /*<@311>*/{
        /*<@309>*/forEachArg(/*<@15>*/inst, func) {
            let /*<@5>*/index = 0;
            inst.visitArg(index++, func, Arg.Use, GP, Ptr); // callee
            if (inst.cCallType != Void) {
                inst.visitArg(index++, func, Arg.Def, Arg.typeForB3Type(inst.cCallType), Arg.widthForB3Type(inst.cCallType));
            }
            for (let /*<@7>*/type of inst.cCallArgTypes) {
                inst.visitArg(index++, func, Arg.Use, Arg.typeForB3Type(type), Arg.widthForB3Type(type));
            }
        },
        /*<@310>*/hasNonArgNonControlEffects(/*<@15>*/inst) {
            return true;
        }
    };
    const /*<@314>*/ColdCCallCustom = /*<@314>*/{
        /*<@312>*/forEachArg(/*<@15>*/inst, func) {
            CCallCustom.forEachArg(inst, /*<@315>*/(/*<@17>*/arg, /*<@7>*/role, /*<@7>*/type, /*<@5>*/width) => {
                return func(arg, Arg.cooled(role), type, width);
            });
        },
        /*<@313>*/hasNonArgNonControlEffects(/*<@15>*/inst) {
            return true;
        }
    };
    class /*<@16>*/Inst {
        constructor(/*<@7>*/opcode, /*<@179>*/args = /*<@179>*/[]) {
            this._opcode = opcode;
            this._args = args;
        }
        /*<@184>*/append(.../*<@179>*/args) {
            this._args.push(...args);
        }
        /*<@185>*/clear() {
            this._opcode = Nop;
            this._args = /*<@256>*/[];
        }
        get /*<@186>*/opcode() { return this._opcode; }
        get /*<@187>*/args() { return this._args; }
        /*<@188>*/visitArg(/*<@5>*/index, func, /*<@7>*/r, /*<@7>*/t, /*<@5>*/w) {
            let /*<@34>*/replacement = func(this._args[index], r, t, w);
            if (replacement)
                this._args[index] = replacement;
        }
        /*<@189>*/forEachTmpFast(func) {
            for (let /*<@5>*/i = 0; i < this._args.length; ++i) {
                let /*<@17>*/replacement;
                if (replacement = this._args[i].forEachTmpFast(func))
                    this._args[i] = replacement;
            }
        }
        /*<@190>*/forEachArg(func) {
            Inst_forEachArg(this, func);
        }
        /*<@191>*/forEachTmp(func) {
            this.forEachArg(/*<@316>*/(/*<@17>*/arg, /*<@7>*/role, /*<@7>*/type, /*<@5>*/width) => {
                return arg.forEachTmp(role, type, width, func);
            });
        }
        /*<@192>*/forEach(/*<@48>*/thing, func) {
            this.forEachArg(/*<@317>*/(/*<@17>*/arg, /*<@7>*/role, /*<@7>*/type, /*<@5>*/width) => {
                return arg.forEach(thing, role, type, width, func);
            });
        }
        static /*<@193>*/forEachDef(/*<@48>*/thing, /*<@15>*/prevInst, /*<@15>*/nextInst, func) {
            if (prevInst) {
                prevInst.forEach(thing, /*<@318>*/(/*<@47>*/value, /*<@7>*/role, /*<@7>*/type, /*<@5>*/width) => {
                    if (Arg.isLateDef(role))
                        return func(value, role, type, width);
                });
            }
            if (nextInst) {
                nextInst.forEach(thing, /*<@319>*/(/*<@47>*/value, /*<@7>*/role, /*<@7>*/type, /*<@5>*/width) => {
                    if (Arg.isEarlyDef(role))
                        return func(value, role, type, width);
                });
            }
        }
        static /*<@194>*/forEachDefWithExtraClobberedRegs(/*<@48>*/thing, /*<@15>*/prevInst, /*<@15>*/nextInst, func) {
            Inst.forEachDef(thing, prevInst, nextInst, func);
            let /*<@7>*/regDefRole;
            let /*<@320>*/reportReg = /*<@320>*/(/*<@19>*/reg) => {
                let /*<@7>*/type = reg.isGPR ? GP : FP;
                func(thing.fromReg(reg), regDefRole, type, Arg.conservativeWidth(type));
            };
            if (prevInst && prevInst.opcode == Patch) {
                regDefRole = Arg.Def;
                prevInst.extraClobberedRegs.forEach(reportReg);
            }
            if (nextInst && nextInst.opcode == Patch) {
                regDefRole = Arg.EarlyDef;
                nextInst.extraEarlyClobberedRegs.forEach(reportReg);
            }
        }
        get /*<@195>*/hasNonArgEffects() { return Inst_hasNonArgEffects(this); }
        /*<@196>*/hash() {
            let /*<@5>*/result = opcodeCode(this.opcode);
            for (let /*<@17>*/arg of this.args) {
                result += arg.hash();
                result |= 0;
            }
            return result >>> 0;
        }
        /*<@197>*/toString() {
            return "" + symbolName(this._opcode) + " " + this._args.join(", ");
        }
    }
    function /*<@321>*/createPayloadImagingGaussianBlurGaussianBlur() {
        let /*<@258>*/code = new Code();
        let /*<@13>*/bb0 = code.addBlock();
        let /*<@13>*/bb1 = code.addBlock();
        let /*<@13>*/bb2 = code.addBlock();
        let /*<@13>*/bb3 = code.addBlock();
        let /*<@13>*/bb4 = code.addBlock();
        let /*<@13>*/bb5 = code.addBlock();
        let /*<@13>*/bb6 = code.addBlock();
        let /*<@13>*/bb7 = code.addBlock();
        let /*<@13>*/bb8 = code.addBlock();
        let /*<@13>*/bb9 = code.addBlock();
        let /*<@13>*/bb10 = code.addBlock();
        let /*<@13>*/bb11 = code.addBlock();
        let /*<@13>*/bb12 = code.addBlock();
        let /*<@13>*/bb13 = code.addBlock();
        let /*<@13>*/bb14 = code.addBlock();
        let /*<@13>*/bb15 = code.addBlock();
        let /*<@13>*/bb16 = code.addBlock();
        let /*<@13>*/bb17 = code.addBlock();
        let /*<@13>*/bb18 = code.addBlock();
        let /*<@13>*/bb19 = code.addBlock();
        let /*<@13>*/bb20 = code.addBlock();
        let /*<@13>*/bb21 = code.addBlock();
        let /*<@13>*/bb22 = code.addBlock();
        let /*<@13>*/bb23 = code.addBlock();
        let /*<@13>*/bb24 = code.addBlock();
        let /*<@13>*/bb25 = code.addBlock();
        let /*<@13>*/bb26 = code.addBlock();
        let /*<@13>*/bb27 = code.addBlock();
        let /*<@13>*/bb28 = code.addBlock();
        let /*<@13>*/bb29 = code.addBlock();
        let /*<@13>*/bb30 = code.addBlock();
        let /*<@13>*/bb31 = code.addBlock();
        let /*<@13>*/bb32 = code.addBlock();
        let /*<@13>*/bb33 = code.addBlock();
        let /*<@13>*/bb34 = code.addBlock();
        let /*<@13>*/bb35 = code.addBlock();
        let /*<@13>*/bb36 = code.addBlock();
        let /*<@47>*/slot0 = code.addStackSlot(40, Locked);
        let /*<@47>*/slot1 = code.addStackSlot(8, Spill);
        let /*<@47>*/slot2 = code.addStackSlot(8, Spill);
        let /*<@47>*/slot3 = code.addStackSlot(4, Spill);
        let /*<@47>*/slot4 = code.addStackSlot(8, Spill);
        let /*<@47>*/slot5 = code.addStackSlot(8, Spill);
        let /*<@47>*/slot6 = code.addStackSlot(40, Locked);
        slot6.setOffsetFromFP(-40);
        let /*<@155>*/tmp141 = code.newTmp(GP);
        let /*<@155>*/tmp140 = code.newTmp(GP);
        let /*<@155>*/tmp139 = code.newTmp(GP);
        let /*<@155>*/tmp138 = code.newTmp(GP);
        let /*<@155>*/tmp137 = code.newTmp(GP);
        let /*<@155>*/tmp136 = code.newTmp(GP);
        let /*<@155>*/tmp135 = code.newTmp(GP);
        let /*<@155>*/tmp134 = code.newTmp(GP);
        let /*<@155>*/tmp133 = code.newTmp(GP);
        let /*<@155>*/tmp132 = code.newTmp(GP);
        let /*<@155>*/tmp131 = code.newTmp(GP);
        let /*<@155>*/tmp130 = code.newTmp(GP);
        let /*<@155>*/tmp129 = code.newTmp(GP);
        let /*<@155>*/tmp128 = code.newTmp(GP);
        let /*<@155>*/tmp127 = code.newTmp(GP);
        let /*<@155>*/tmp126 = code.newTmp(GP);
        let /*<@155>*/tmp125 = code.newTmp(GP);
        let /*<@155>*/tmp124 = code.newTmp(GP);
        let /*<@155>*/tmp123 = code.newTmp(GP);
        let /*<@155>*/tmp122 = code.newTmp(GP);
        let /*<@155>*/tmp121 = code.newTmp(GP);
        let /*<@155>*/tmp120 = code.newTmp(GP);
        let /*<@155>*/tmp119 = code.newTmp(GP);
        let /*<@155>*/tmp118 = code.newTmp(GP);
        let /*<@155>*/tmp117 = code.newTmp(GP);
        let /*<@155>*/tmp116 = code.newTmp(GP);
        let /*<@155>*/tmp115 = code.newTmp(GP);
        let /*<@155>*/tmp114 = code.newTmp(GP);
        let /*<@155>*/tmp113 = code.newTmp(GP);
        let /*<@155>*/tmp112 = code.newTmp(GP);
        let /*<@155>*/tmp111 = code.newTmp(GP);
        let /*<@155>*/tmp110 = code.newTmp(GP);
        let /*<@155>*/tmp109 = code.newTmp(GP);
        let /*<@155>*/tmp108 = code.newTmp(GP);
        let /*<@155>*/tmp107 = code.newTmp(GP);
        let /*<@155>*/tmp106 = code.newTmp(GP);
        let /*<@155>*/tmp105 = code.newTmp(GP);
        let /*<@155>*/tmp104 = code.newTmp(GP);
        let /*<@155>*/tmp103 = code.newTmp(GP);
        let /*<@155>*/tmp102 = code.newTmp(GP);
        let /*<@155>*/tmp101 = code.newTmp(GP);
        let /*<@155>*/tmp100 = code.newTmp(GP);
        let /*<@155>*/tmp99 = code.newTmp(GP);
        let /*<@155>*/tmp98 = code.newTmp(GP);
        let /*<@155>*/tmp97 = code.newTmp(GP);
        let /*<@155>*/tmp96 = code.newTmp(GP);
        let /*<@155>*/tmp95 = code.newTmp(GP);
        let /*<@155>*/tmp94 = code.newTmp(GP);
        let /*<@155>*/tmp93 = code.newTmp(GP);
        let /*<@155>*/tmp92 = code.newTmp(GP);
        let /*<@155>*/tmp91 = code.newTmp(GP);
        let /*<@155>*/tmp90 = code.newTmp(GP);
        let /*<@155>*/tmp89 = code.newTmp(GP);
        let /*<@155>*/tmp88 = code.newTmp(GP);
        let /*<@155>*/tmp87 = code.newTmp(GP);
        let /*<@155>*/tmp86 = code.newTmp(GP);
        let /*<@155>*/tmp85 = code.newTmp(GP);
        let /*<@155>*/tmp84 = code.newTmp(GP);
        let /*<@155>*/tmp83 = code.newTmp(GP);
        let /*<@155>*/tmp82 = code.newTmp(GP);
        let /*<@155>*/tmp81 = code.newTmp(GP);
        let /*<@155>*/tmp80 = code.newTmp(GP);
        let /*<@155>*/tmp79 = code.newTmp(GP);
        let /*<@155>*/tmp78 = code.newTmp(GP);
        let /*<@155>*/tmp77 = code.newTmp(GP);
        let /*<@155>*/tmp76 = code.newTmp(GP);
        let /*<@155>*/tmp75 = code.newTmp(GP);
        let /*<@155>*/tmp74 = code.newTmp(GP);
        let /*<@155>*/tmp73 = code.newTmp(GP);
        let /*<@155>*/tmp72 = code.newTmp(GP);
        let /*<@155>*/tmp71 = code.newTmp(GP);
        let /*<@155>*/tmp70 = code.newTmp(GP);
        let /*<@155>*/tmp69 = code.newTmp(GP);
        let /*<@155>*/tmp68 = code.newTmp(GP);
        let /*<@155>*/tmp67 = code.newTmp(GP);
        let /*<@155>*/tmp66 = code.newTmp(GP);
        let /*<@155>*/tmp65 = code.newTmp(GP);
        let /*<@155>*/tmp64 = code.newTmp(GP);
        let /*<@155>*/tmp63 = code.newTmp(GP);
        let /*<@155>*/tmp62 = code.newTmp(GP);
        let /*<@155>*/tmp61 = code.newTmp(GP);
        let /*<@155>*/tmp60 = code.newTmp(GP);
        let /*<@155>*/tmp59 = code.newTmp(GP);
        let /*<@155>*/tmp58 = code.newTmp(GP);
        let /*<@155>*/tmp57 = code.newTmp(GP);
        let /*<@155>*/tmp56 = code.newTmp(GP);
        let /*<@155>*/tmp55 = code.newTmp(GP);
        let /*<@155>*/tmp54 = code.newTmp(GP);
        let /*<@155>*/tmp53 = code.newTmp(GP);
        let /*<@155>*/tmp52 = code.newTmp(GP);
        let /*<@155>*/tmp51 = code.newTmp(GP);
        let /*<@155>*/tmp50 = code.newTmp(GP);
        let /*<@155>*/tmp49 = code.newTmp(GP);
        let /*<@155>*/tmp48 = code.newTmp(GP);
        let /*<@155>*/tmp47 = code.newTmp(GP);
        let /*<@155>*/tmp46 = code.newTmp(GP);
        let /*<@155>*/tmp45 = code.newTmp(GP);
        let /*<@155>*/tmp44 = code.newTmp(GP);
        let /*<@155>*/tmp43 = code.newTmp(GP);
        let /*<@155>*/tmp42 = code.newTmp(GP);
        let /*<@155>*/tmp41 = code.newTmp(GP);
        let /*<@155>*/tmp40 = code.newTmp(GP);
        let /*<@155>*/tmp39 = code.newTmp(GP);
        let /*<@155>*/tmp38 = code.newTmp(GP);
        let /*<@155>*/tmp37 = code.newTmp(GP);
        let /*<@155>*/tmp36 = code.newTmp(GP);
        let /*<@155>*/tmp35 = code.newTmp(GP);
        let /*<@155>*/tmp34 = code.newTmp(GP);
        let /*<@155>*/tmp33 = code.newTmp(GP);
        let /*<@155>*/tmp32 = code.newTmp(GP);
        let /*<@155>*/tmp31 = code.newTmp(GP);
        let /*<@155>*/tmp30 = code.newTmp(GP);
        let /*<@155>*/tmp29 = code.newTmp(GP);
        let /*<@155>*/tmp28 = code.newTmp(GP);
        let /*<@155>*/tmp27 = code.newTmp(GP);
        let /*<@155>*/tmp26 = code.newTmp(GP);
        let /*<@155>*/tmp25 = code.newTmp(GP);
        let /*<@155>*/tmp24 = code.newTmp(GP);
        let /*<@155>*/tmp23 = code.newTmp(GP);
        let /*<@155>*/tmp22 = code.newTmp(GP);
        let /*<@155>*/tmp21 = code.newTmp(GP);
        let /*<@155>*/tmp20 = code.newTmp(GP);
        let /*<@155>*/tmp19 = code.newTmp(GP);
        let /*<@155>*/tmp18 = code.newTmp(GP);
        let /*<@155>*/tmp17 = code.newTmp(GP);
        let /*<@155>*/tmp16 = code.newTmp(GP);
        let /*<@155>*/tmp15 = code.newTmp(GP);
        let /*<@155>*/tmp14 = code.newTmp(GP);
        let /*<@155>*/tmp13 = code.newTmp(GP);
        let /*<@155>*/tmp12 = code.newTmp(GP);
        let /*<@155>*/tmp11 = code.newTmp(GP);
        let /*<@155>*/tmp10 = code.newTmp(GP);
        let /*<@155>*/tmp9 = code.newTmp(GP);
        let /*<@155>*/tmp8 = code.newTmp(GP);
        let /*<@155>*/tmp7 = code.newTmp(GP);
        let /*<@155>*/tmp6 = code.newTmp(GP);
        let /*<@155>*/tmp5 = code.newTmp(GP);
        let /*<@155>*/tmp4 = code.newTmp(GP);
        let /*<@155>*/tmp3 = code.newTmp(GP);
        let /*<@155>*/tmp2 = code.newTmp(GP);
        let /*<@155>*/tmp1 = code.newTmp(GP);
        let /*<@155>*/tmp0 = code.newTmp(GP);
        let /*<@155>*/ftmp74 = code.newTmp(FP);
        let /*<@155>*/ftmp73 = code.newTmp(FP);
        let /*<@155>*/ftmp72 = code.newTmp(FP);
        let /*<@155>*/ftmp71 = code.newTmp(FP);
        let /*<@155>*/ftmp70 = code.newTmp(FP);
        let /*<@155>*/ftmp69 = code.newTmp(FP);
        let /*<@155>*/ftmp68 = code.newTmp(FP);
        let /*<@155>*/ftmp67 = code.newTmp(FP);
        let /*<@155>*/ftmp66 = code.newTmp(FP);
        let /*<@155>*/ftmp65 = code.newTmp(FP);
        let /*<@155>*/ftmp64 = code.newTmp(FP);
        let /*<@155>*/ftmp63 = code.newTmp(FP);
        let /*<@155>*/ftmp62 = code.newTmp(FP);
        let /*<@155>*/ftmp61 = code.newTmp(FP);
        let /*<@155>*/ftmp60 = code.newTmp(FP);
        let /*<@155>*/ftmp59 = code.newTmp(FP);
        let /*<@155>*/ftmp58 = code.newTmp(FP);
        let /*<@155>*/ftmp57 = code.newTmp(FP);
        let /*<@155>*/ftmp56 = code.newTmp(FP);
        let /*<@155>*/ftmp55 = code.newTmp(FP);
        let /*<@155>*/ftmp54 = code.newTmp(FP);
        let /*<@155>*/ftmp53 = code.newTmp(FP);
        let /*<@155>*/ftmp52 = code.newTmp(FP);
        let /*<@155>*/ftmp51 = code.newTmp(FP);
        let /*<@155>*/ftmp50 = code.newTmp(FP);
        let /*<@155>*/ftmp49 = code.newTmp(FP);
        let /*<@155>*/ftmp48 = code.newTmp(FP);
        let /*<@155>*/ftmp47 = code.newTmp(FP);
        let /*<@155>*/ftmp46 = code.newTmp(FP);
        let /*<@155>*/ftmp45 = code.newTmp(FP);
        let /*<@155>*/ftmp44 = code.newTmp(FP);
        let /*<@155>*/ftmp43 = code.newTmp(FP);
        let /*<@155>*/ftmp42 = code.newTmp(FP);
        let /*<@155>*/ftmp41 = code.newTmp(FP);
        let /*<@155>*/ftmp40 = code.newTmp(FP);
        let /*<@155>*/ftmp39 = code.newTmp(FP);
        let /*<@155>*/ftmp38 = code.newTmp(FP);
        let /*<@155>*/ftmp37 = code.newTmp(FP);
        let /*<@155>*/ftmp36 = code.newTmp(FP);
        let /*<@155>*/ftmp35 = code.newTmp(FP);
        let /*<@155>*/ftmp34 = code.newTmp(FP);
        let /*<@155>*/ftmp33 = code.newTmp(FP);
        let /*<@155>*/ftmp32 = code.newTmp(FP);
        let /*<@155>*/ftmp31 = code.newTmp(FP);
        let /*<@155>*/ftmp30 = code.newTmp(FP);
        let /*<@155>*/ftmp29 = code.newTmp(FP);
        let /*<@155>*/ftmp28 = code.newTmp(FP);
        let /*<@155>*/ftmp27 = code.newTmp(FP);
        let /*<@155>*/ftmp26 = code.newTmp(FP);
        let /*<@155>*/ftmp25 = code.newTmp(FP);
        let /*<@155>*/ftmp24 = code.newTmp(FP);
        let /*<@155>*/ftmp23 = code.newTmp(FP);
        let /*<@155>*/ftmp22 = code.newTmp(FP);
        let /*<@155>*/ftmp21 = code.newTmp(FP);
        let /*<@155>*/ftmp20 = code.newTmp(FP);
        let /*<@155>*/ftmp19 = code.newTmp(FP);
        let /*<@155>*/ftmp18 = code.newTmp(FP);
        let /*<@155>*/ftmp17 = code.newTmp(FP);
        let /*<@155>*/ftmp16 = code.newTmp(FP);
        let /*<@155>*/ftmp15 = code.newTmp(FP);
        let /*<@155>*/ftmp14 = code.newTmp(FP);
        let /*<@155>*/ftmp13 = code.newTmp(FP);
        let /*<@155>*/ftmp12 = code.newTmp(FP);
        let /*<@155>*/ftmp11 = code.newTmp(FP);
        let /*<@155>*/ftmp10 = code.newTmp(FP);
        let /*<@155>*/ftmp9 = code.newTmp(FP);
        let /*<@155>*/ftmp8 = code.newTmp(FP);
        let /*<@155>*/ftmp7 = code.newTmp(FP);
        let /*<@155>*/ftmp6 = code.newTmp(FP);
        let /*<@155>*/ftmp5 = code.newTmp(FP);
        let /*<@155>*/ftmp4 = code.newTmp(FP);
        let /*<@155>*/ftmp3 = code.newTmp(FP);
        let /*<@155>*/ftmp2 = code.newTmp(FP);
        let /*<@155>*/ftmp1 = code.newTmp(FP);
        let /*<@155>*/ftmp0 = code.newTmp(FP);
        let /*<@15>*/inst;
        let /*<@17>*/arg;
        bb0.successors.push(new FrequentedBlock(bb2, Normal));
        bb0.successors.push(new FrequentedBlock(bb1, Rare));
        inst = new Inst(Move);
        arg = Arg.createBigImm(144305904, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rbp, 16);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbp);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.extraEarlyClobberedRegs.add(Reg.r11);
        inst.extraClobberedRegs.add(Reg.r11);
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Scratch, type: GP, width: 64 });
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(142547168, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rax, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(142547184, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rax, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(142547192, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rax, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(142547200, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rax, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(142547208, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rax, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(142547216, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rax, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r10);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(142547224, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rax, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r11);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(142547232, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rax, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(142547240, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rdi, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(0, -65536);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Add64);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move64ToDouble);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm2);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(BranchDouble);
        arg = Arg.createDoubleCond(DoubleEqual);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm2);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm2);
        inst.args.push(arg);
        bb0.append(inst);
        bb1.successors.push(new FrequentedBlock(bb2, Normal));
        bb1.predecessors.push(bb0);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(Below);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r10);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r11);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb1.append(inst);
        inst = new Inst(ConvertInt32ToDouble);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm2);
        inst.args.push(arg);
        bb1.append(inst);
        inst = new Inst(Jump);
        bb1.append(inst);
        bb2.successors.push(new FrequentedBlock(bb4, Normal));
        bb2.successors.push(new FrequentedBlock(bb3, Rare));
        bb2.predecessors.push(bb0);
        bb2.predecessors.push(bb1);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(Below);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r10);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r11);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb2.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(Below);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r10);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r11);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb2.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(Below);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r10);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r11);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb2.append(inst);
        inst = new Inst(Add64);
        arg = Arg.createTmp(Reg.r10);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        bb2.append(inst);
        inst = new Inst(Move64ToDouble);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm3);
        inst.args.push(arg);
        bb2.append(inst);
        inst = new Inst(BranchDouble);
        arg = Arg.createDoubleCond(DoubleEqual);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm3);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm3);
        inst.args.push(arg);
        bb2.append(inst);
        bb3.successors.push(new FrequentedBlock(bb4, Normal));
        bb3.predecessors.push(bb2);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(Below);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r10);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r10);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r10);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r11);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb3.append(inst);
        inst = new Inst(ConvertInt32ToDouble);
        arg = Arg.createTmp(Reg.r10);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm3);
        inst.args.push(arg);
        bb3.append(inst);
        inst = new Inst(Jump);
        bb3.append(inst);
        bb4.successors.push(new FrequentedBlock(bb6, Normal));
        bb4.successors.push(new FrequentedBlock(bb5, Rare));
        bb4.predecessors.push(bb2);
        bb4.predecessors.push(bb3);
        inst = new Inst(Add64);
        arg = Arg.createTmp(Reg.r11);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        bb4.append(inst);
        inst = new Inst(Move64ToDouble);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm1);
        inst.args.push(arg);
        bb4.append(inst);
        inst = new Inst(BranchDouble);
        arg = Arg.createDoubleCond(DoubleEqual);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm1);
        inst.args.push(arg);
        bb4.append(inst);
        bb5.successors.push(new FrequentedBlock(bb6, Normal));
        bb5.predecessors.push(bb4);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(Below);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r11);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r11);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r10);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r11);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb5.append(inst);
        inst = new Inst(ConvertInt32ToDouble);
        arg = Arg.createTmp(Reg.r11);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm1);
        inst.args.push(arg);
        bb5.append(inst);
        inst = new Inst(Jump);
        bb5.append(inst);
        bb6.successors.push(new FrequentedBlock(bb8, Normal));
        bb6.successors.push(new FrequentedBlock(bb7, Rare));
        bb6.predecessors.push(bb4);
        bb6.predecessors.push(bb5);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(Below);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r10);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r11);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb6.append(inst);
        inst = new Inst(Add64);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        bb6.append(inst);
        inst = new Inst(Move64ToDouble);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm5);
        inst.args.push(arg);
        bb6.append(inst);
        inst = new Inst(BranchDouble);
        arg = Arg.createDoubleCond(DoubleEqual);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm5);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm5);
        inst.args.push(arg);
        bb6.append(inst);
        bb7.successors.push(new FrequentedBlock(bb8, Normal));
        bb7.predecessors.push(bb6);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(Below);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r10);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r11);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb7.append(inst);
        inst = new Inst(ConvertInt32ToDouble);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm5);
        inst.args.push(arg);
        bb7.append(inst);
        inst = new Inst(Jump);
        bb7.append(inst);
        bb8.successors.push(new FrequentedBlock(bb10, Normal));
        bb8.successors.push(new FrequentedBlock(bb9, Rare));
        bb8.predecessors.push(bb6);
        bb8.predecessors.push(bb7);
        inst = new Inst(Move);
        arg = Arg.createBigImm(117076488, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        bb8.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.r8, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r9);
        inst.args.push(arg);
        bb8.append(inst);
        inst = new Inst(Add64);
        arg = Arg.createTmp(Reg.r9);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        bb8.append(inst);
        inst = new Inst(Move64ToDouble);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm6);
        inst.args.push(arg);
        bb8.append(inst);
        inst = new Inst(BranchDouble);
        arg = Arg.createDoubleCond(DoubleEqual);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm6);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm6);
        inst.args.push(arg);
        bb8.append(inst);
        bb9.successors.push(new FrequentedBlock(bb10, Normal));
        bb9.predecessors.push(bb8);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(Below);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r9);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r9);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r10);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r11);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb9.append(inst);
        inst = new Inst(ConvertInt32ToDouble);
        arg = Arg.createTmp(Reg.r9);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm6);
        inst.args.push(arg);
        bb9.append(inst);
        inst = new Inst(Jump);
        bb9.append(inst);
        bb10.successors.push(new FrequentedBlock(bb18, Normal));
        bb10.predecessors.push(bb8);
        bb10.predecessors.push(bb9);
        inst = new Inst(Move);
        arg = Arg.createBigImm(144506584, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        bb10.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rdi, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r9);
        inst.args.push(arg);
        bb10.append(inst);
        inst = new Inst(Move32);
        arg = Arg.createAddr(Reg.r9, -8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        bb10.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(144506544, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        bb10.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(NotEqual);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rdi, 0);
        inst.args.push(arg);
        arg = Arg.createImm(80);
        inst.args.push(arg);
        arg = Arg.createBigImm(144506544, 1);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r10);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r11);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb10.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(144506552, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        bb10.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rdi, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        bb10.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createStack(slot2, 0);
        inst.args.push(arg);
        bb10.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        bb10.append(inst);
        inst = new Inst(Move32);
        arg = Arg.createAddr(Reg.rdi, -8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        bb10.append(inst);
        inst = new Inst(Move32);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createStack(slot3, 0);
        inst.args.push(arg);
        bb10.append(inst);
        inst = new Inst(MoveZeroToDouble);
        arg = Arg.createTmp(Reg.xmm7);
        inst.args.push(arg);
        bb10.append(inst);
        inst = new Inst(Move);
        arg = Arg.createImm(10);
        inst.args.push(arg);
        arg = Arg.createStack(slot4, 0);
        inst.args.push(arg);
        bb10.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(2, -65536);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r10);
        inst.args.push(arg);
        bb10.append(inst);
        inst = new Inst(Jump);
        bb10.append(inst);
        bb11.successors.push(new FrequentedBlock(bb13, Normal));
        bb11.predecessors.push(bb35);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb11.append(inst);
        inst = new Inst(Move);
        arg = Arg.createImm(0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        bb11.append(inst);
        inst = new Inst(Jump);
        bb11.append(inst);
        bb12.successors.push(new FrequentedBlock(bb13, Normal));
        bb12.predecessors.push(bb34);
        inst = new Inst(Move32);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        bb12.append(inst);
        inst = new Inst(Jump);
        bb12.append(inst);
        bb13.successors.push(new FrequentedBlock(bb15, Normal));
        bb13.predecessors.push(bb11);
        bb13.predecessors.push(bb12);
        inst = new Inst(Move);
        arg = Arg.createImm(-6);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb13.append(inst);
        inst = new Inst(MoveDouble);
        arg = Arg.createTmp(Reg.xmm7);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm1);
        inst.args.push(arg);
        bb13.append(inst);
        inst = new Inst(MoveDouble);
        arg = Arg.createTmp(Reg.xmm7);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm2);
        inst.args.push(arg);
        bb13.append(inst);
        inst = new Inst(MoveDouble);
        arg = Arg.createTmp(Reg.xmm7);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm3);
        inst.args.push(arg);
        bb13.append(inst);
        inst = new Inst(MoveDouble);
        arg = Arg.createTmp(Reg.xmm7);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm5);
        inst.args.push(arg);
        bb13.append(inst);
        inst = new Inst(Jump);
        bb13.append(inst);
        bb14.successors.push(new FrequentedBlock(bb15, Normal));
        bb14.predecessors.push(bb31);
        inst = new Inst(Move32);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb14.append(inst);
        inst = new Inst(Jump);
        bb14.append(inst);
        bb15.successors.push(new FrequentedBlock(bb28, Normal));
        bb15.successors.push(new FrequentedBlock(bb16, Normal));
        bb15.predecessors.push(bb13);
        bb15.predecessors.push(bb14);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createResCond(Overflow);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm2);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm3);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm5);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ZDef, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        bb15.append(inst);
        inst = new Inst(Branch32);
        arg = Arg.createRelCond(LessThan);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createImm(0);
        inst.args.push(arg);
        bb15.append(inst);
        bb16.successors.push(new FrequentedBlock(bb29, Normal));
        bb16.successors.push(new FrequentedBlock(bb17, Normal));
        bb16.predecessors.push(bb15);
        inst = new Inst(Branch32);
        arg = Arg.createRelCond(GreaterThanOrEqual);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createImm(267);
        inst.args.push(arg);
        bb16.append(inst);
        bb17.successors.push(new FrequentedBlock(bb18, Normal));
        bb17.predecessors.push(bb16);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        bb17.append(inst);
        inst = new Inst(Move);
        arg = Arg.createImm(-6);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb17.append(inst);
        inst = new Inst(Jump);
        bb17.append(inst);
        bb18.successors.push(new FrequentedBlock(bb20, Normal));
        bb18.successors.push(new FrequentedBlock(bb19, Rare));
        bb18.predecessors.push(bb10);
        bb18.predecessors.push(bb17);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createStack(slot1, 0);
        inst.args.push(arg);
        bb18.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createResCond(Overflow);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm2);
        inst.args.push(arg);
        arg = Arg.createStack(slot1, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm3);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm5);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ZDef, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        bb18.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createResCond(Overflow);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createImm(400);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r11);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm2);
        inst.args.push(arg);
        arg = Arg.createStack(slot1, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm3);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm5);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ZDef, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        bb18.append(inst);
        inst = new Inst(BranchTest32);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r11);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r11);
        inst.args.push(arg);
        bb18.append(inst);
        bb19.successors.push(new FrequentedBlock(bb20, Normal));
        bb19.predecessors.push(bb18);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(LessThan);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createImm(0);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm2);
        inst.args.push(arg);
        arg = Arg.createStack(slot1, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm3);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm5);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        bb19.append(inst);
        inst = new Inst(Jump);
        bb19.append(inst);
        bb20.successors.push(new FrequentedBlock(bb22, Normal));
        bb20.predecessors.push(bb18);
        bb20.predecessors.push(bb19);
        inst = new Inst(Move32);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        bb20.append(inst);
        inst = new Inst(Rshift32);
        arg = Arg.createImm(31);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        bb20.append(inst);
        inst = new Inst(Add32);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        bb20.append(inst);
        inst = new Inst(Xor32);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        bb20.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(LessThan);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createImm(0);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm2);
        inst.args.push(arg);
        arg = Arg.createStack(slot1, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm3);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm5);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        bb20.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(AboveOrEqual);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createStack(slot3, 0);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm2);
        inst.args.push(arg);
        arg = Arg.createStack(slot1, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm3);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm5);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        bb20.append(inst);
        inst = new Inst(Move);
        arg = Arg.createStack(slot2, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        bb20.append(inst);
        inst = new Inst(Move);
        arg = Arg.createIndex(Reg.rsi, Reg.rdi, 8, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        bb20.append(inst);
        inst = new Inst(Move);
        arg = Arg.createImm(10);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        bb20.append(inst);
        inst = new Inst(MoveConditionallyTest64);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createImm(-1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        bb20.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r10);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm2);
        inst.args.push(arg);
        arg = Arg.createStack(slot1, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm3);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm5);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        bb20.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(NotEqual);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rdi, 0);
        inst.args.push(arg);
        arg = Arg.createImm(79);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm2);
        inst.args.push(arg);
        arg = Arg.createStack(slot1, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm3);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm5);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        bb20.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rdi, 8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        bb20.append(inst);
        inst = new Inst(Move32);
        arg = Arg.createAddr(Reg.r12, -8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r13);
        inst.args.push(arg);
        bb20.append(inst);
        inst = new Inst(Jump);
        bb20.append(inst);
        bb21.successors.push(new FrequentedBlock(bb22, Normal));
        bb21.predecessors.push(bb27);
        inst = new Inst(Move32);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb21.append(inst);
        inst = new Inst(Jump);
        bb21.append(inst);
        bb22.successors.push(new FrequentedBlock(bb25, Normal));
        bb22.successors.push(new FrequentedBlock(bb23, Normal));
        bb22.predecessors.push(bb20);
        bb22.predecessors.push(bb21);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createResCond(Overflow);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm2);
        inst.args.push(arg);
        arg = Arg.createStack(slot1, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm3);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm5);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ZDef, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        bb22.append(inst);
        inst = new Inst(Branch32);
        arg = Arg.createRelCond(LessThan);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createImm(0);
        inst.args.push(arg);
        bb22.append(inst);
        bb23.successors.push(new FrequentedBlock(bb26, Normal));
        bb23.successors.push(new FrequentedBlock(bb24, Normal));
        bb23.predecessors.push(bb22);
        inst = new Inst(Branch32);
        arg = Arg.createRelCond(GreaterThanOrEqual);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createImm(400);
        inst.args.push(arg);
        bb23.append(inst);
        bb24.successors.push(new FrequentedBlock(bb27, Normal));
        bb24.predecessors.push(bb23);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createResCond(Overflow);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r11);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm2);
        inst.args.push(arg);
        arg = Arg.createStack(slot1, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm3);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm5);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r11);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ZDef, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        bb24.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createResCond(Overflow);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createImm(4);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r15);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm2);
        inst.args.push(arg);
        arg = Arg.createStack(slot1, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm3);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm5);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ZDef, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        bb24.append(inst);
        inst = new Inst(Add32);
        arg = Arg.createImm(3);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r15);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r14);
        inst.args.push(arg);
        bb24.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(AboveOrEqual);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r15);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm2);
        inst.args.push(arg);
        arg = Arg.createStack(slot1, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm3);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm5);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r15);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        bb24.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(AboveOrEqual);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r14);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm2);
        inst.args.push(arg);
        arg = Arg.createStack(slot1, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm3);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm5);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r15);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        bb24.append(inst);
        inst = new Inst(MoveDouble);
        arg = Arg.createIndex(Reg.r9, Reg.r15, 8, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm0);
        inst.args.push(arg);
        bb24.append(inst);
        inst = new Inst(Move32);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        bb24.append(inst);
        inst = new Inst(Rshift32);
        arg = Arg.createImm(31);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        bb24.append(inst);
        inst = new Inst(Add32);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        bb24.append(inst);
        inst = new Inst(Xor32);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        bb24.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(LessThan);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createImm(0);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm2);
        inst.args.push(arg);
        arg = Arg.createStack(slot1, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm3);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm5);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        bb24.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(AboveOrEqual);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r13);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm2);
        inst.args.push(arg);
        arg = Arg.createStack(slot1, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm3);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm5);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        bb24.append(inst);
        inst = new Inst(MoveDouble);
        arg = Arg.createIndex(Reg.r12, Reg.rbx, 8, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm4);
        inst.args.push(arg);
        bb24.append(inst);
        inst = new Inst(MulDouble);
        arg = Arg.createTmp(Reg.xmm0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm4);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm0);
        inst.args.push(arg);
        bb24.append(inst);
        inst = new Inst(AddDouble);
        arg = Arg.createTmp(Reg.xmm1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm1);
        inst.args.push(arg);
        bb24.append(inst);
        inst = new Inst(Add32);
        arg = Arg.createImm(1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r15);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        bb24.append(inst);
        inst = new Inst(MulDouble);
        arg = Arg.createIndex(Reg.r9, Reg.rsi, 8, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm4);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm0);
        inst.args.push(arg);
        bb24.append(inst);
        inst = new Inst(AddDouble);
        arg = Arg.createTmp(Reg.xmm2);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm2);
        inst.args.push(arg);
        bb24.append(inst);
        inst = new Inst(Add32);
        arg = Arg.createImm(2);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r15);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r15);
        inst.args.push(arg);
        bb24.append(inst);
        inst = new Inst(MulDouble);
        arg = Arg.createIndex(Reg.r9, Reg.r15, 8, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm4);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm0);
        inst.args.push(arg);
        bb24.append(inst);
        inst = new Inst(AddDouble);
        arg = Arg.createTmp(Reg.xmm3);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm3);
        inst.args.push(arg);
        bb24.append(inst);
        inst = new Inst(MulDouble);
        arg = Arg.createIndex(Reg.r9, Reg.r14, 8, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm4);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm4);
        inst.args.push(arg);
        bb24.append(inst);
        inst = new Inst(AddDouble);
        arg = Arg.createTmp(Reg.xmm5);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm4);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm5);
        inst.args.push(arg);
        bb24.append(inst);
        inst = new Inst(Jump);
        bb24.append(inst);
        bb25.successors.push(new FrequentedBlock(bb27, Normal));
        bb25.predecessors.push(bb22);
        inst = new Inst(Jump);
        bb25.append(inst);
        bb26.successors.push(new FrequentedBlock(bb27, Normal));
        bb26.predecessors.push(bb23);
        inst = new Inst(Jump);
        bb26.append(inst);
        bb27.successors.push(new FrequentedBlock(bb21, Normal));
        bb27.successors.push(new FrequentedBlock(bb30, Normal));
        bb27.predecessors.push(bb24);
        bb27.predecessors.push(bb26);
        bb27.predecessors.push(bb25);
        inst = new Inst(Move32);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        bb27.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createResCond(Overflow);
        inst.args.push(arg);
        arg = Arg.createImm(1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm2);
        inst.args.push(arg);
        arg = Arg.createStack(slot1, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm3);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm5);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.UseZDef, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        bb27.append(inst);
        inst = new Inst(Branch32);
        arg = Arg.createRelCond(LessThan);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createImm(7);
        inst.args.push(arg);
        bb27.append(inst);
        bb28.successors.push(new FrequentedBlock(bb31, Normal));
        bb28.predecessors.push(bb15);
        inst = new Inst(Jump);
        bb28.append(inst);
        bb29.successors.push(new FrequentedBlock(bb31, Normal));
        bb29.predecessors.push(bb16);
        inst = new Inst(Jump);
        bb29.append(inst);
        bb30.successors.push(new FrequentedBlock(bb31, Normal));
        bb30.predecessors.push(bb27);
        inst = new Inst(Move);
        arg = Arg.createStack(slot1, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb30.append(inst);
        inst = new Inst(Jump);
        bb30.append(inst);
        bb31.successors.push(new FrequentedBlock(bb14, Normal));
        bb31.successors.push(new FrequentedBlock(bb32, Normal));
        bb31.predecessors.push(bb30);
        bb31.predecessors.push(bb29);
        bb31.predecessors.push(bb28);
        inst = new Inst(Move32);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        bb31.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createResCond(Overflow);
        inst.args.push(arg);
        arg = Arg.createImm(1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm2);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm3);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm5);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.UseZDef, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        bb31.append(inst);
        inst = new Inst(Branch32);
        arg = Arg.createRelCond(LessThan);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createImm(7);
        inst.args.push(arg);
        bb31.append(inst);
        bb32.successors.push(new FrequentedBlock(bb34, Normal));
        bb32.successors.push(new FrequentedBlock(bb33, Rare));
        bb32.predecessors.push(bb31);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createResCond(Overflow);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createImm(400);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm2);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm3);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm5);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ZDef, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        bb32.append(inst);
        inst = new Inst(BranchTest32);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb32.append(inst);
        bb33.successors.push(new FrequentedBlock(bb34, Normal));
        bb33.predecessors.push(bb32);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(LessThan);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createImm(0);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm2);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm3);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm5);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        bb33.append(inst);
        inst = new Inst(Jump);
        bb33.append(inst);
        bb34.successors.push(new FrequentedBlock(bb12, Normal));
        bb34.successors.push(new FrequentedBlock(bb35, Normal));
        bb34.predecessors.push(bb32);
        bb34.predecessors.push(bb33);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createResCond(Overflow);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm2);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm3);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm5);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ZDef, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        bb34.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createResCond(Overflow);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createImm(4);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm2);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm3);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm5);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ZDef, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        bb34.append(inst);
        inst = new Inst(DivDouble);
        arg = Arg.createTmp(Reg.xmm6);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm1);
        inst.args.push(arg);
        bb34.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(AboveOrEqual);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm2);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm3);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm5);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm1);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        bb34.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createDoubleCond(DoubleNotEqualOrUnordered);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm1);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm2);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm3);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm5);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm1);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        bb34.append(inst);
        inst = new Inst(MoveDouble);
        arg = Arg.createTmp(Reg.xmm1);
        inst.args.push(arg);
        arg = Arg.createIndex(Reg.r9, Reg.rsi, 8, 0);
        inst.args.push(arg);
        bb34.append(inst);
        inst = new Inst(Move32);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        bb34.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createResCond(Overflow);
        inst.args.push(arg);
        arg = Arg.createImm(1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm2);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm3);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm5);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.UseZDef, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        bb34.append(inst);
        inst = new Inst(DivDouble);
        arg = Arg.createTmp(Reg.xmm6);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm2);
        inst.args.push(arg);
        bb34.append(inst);
        inst = new Inst(Add32);
        arg = Arg.createImm(1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r11);
        inst.args.push(arg);
        bb34.append(inst);
        inst = new Inst(Add32);
        arg = Arg.createImm(3);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb34.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(AboveOrEqual);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r11);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm3);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm5);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm2);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        bb34.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(AboveOrEqual);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm3);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm5);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm2);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        bb34.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createDoubleCond(DoubleNotEqualOrUnordered);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm2);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm2);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm2);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm3);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm5);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm2);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        bb34.append(inst);
        inst = new Inst(MoveDouble);
        arg = Arg.createTmp(Reg.xmm2);
        inst.args.push(arg);
        arg = Arg.createIndex(Reg.r9, Reg.rdi, 8, 0);
        inst.args.push(arg);
        bb34.append(inst);
        inst = new Inst(Add32);
        arg = Arg.createImm(2);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        bb34.append(inst);
        inst = new Inst(DivDouble);
        arg = Arg.createTmp(Reg.xmm6);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm3);
        inst.args.push(arg);
        bb34.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createDoubleCond(DoubleNotEqualOrUnordered);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm3);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm3);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm3);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm5);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm3);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        bb34.append(inst);
        inst = new Inst(MoveDouble);
        arg = Arg.createTmp(Reg.xmm3);
        inst.args.push(arg);
        arg = Arg.createIndex(Reg.r9, Reg.rsi, 8, 0);
        inst.args.push(arg);
        bb34.append(inst);
        inst = new Inst(DivDouble);
        arg = Arg.createTmp(Reg.xmm6);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm5);
        inst.args.push(arg);
        bb34.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createDoubleCond(DoubleNotEqualOrUnordered);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm5);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm5);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm5);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm5);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: FP, width: 64 });
        bb34.append(inst);
        inst = new Inst(MoveDouble);
        arg = Arg.createTmp(Reg.xmm5);
        inst.args.push(arg);
        arg = Arg.createIndex(Reg.r9, Reg.rax, 8, 0);
        inst.args.push(arg);
        bb34.append(inst);
        inst = new Inst(Move32);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb34.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createResCond(Overflow);
        inst.args.push(arg);
        arg = Arg.createImm(1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.UseZDef, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        bb34.append(inst);
        inst = new Inst(Branch32);
        arg = Arg.createRelCond(LessThan);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createImm(400);
        inst.args.push(arg);
        bb34.append(inst);
        bb35.successors.push(new FrequentedBlock(bb11, Normal));
        bb35.successors.push(new FrequentedBlock(bb36, Normal));
        bb35.predecessors.push(bb34);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb35.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createResCond(Overflow);
        inst.args.push(arg);
        arg = Arg.createImm(1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.UseZDef, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        bb35.append(inst);
        inst = new Inst(Branch32);
        arg = Arg.createRelCond(LessThan);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createImm(267);
        inst.args.push(arg);
        bb35.append(inst);
        bb36.predecessors.push(bb35);
        inst = new Inst(Move);
        arg = Arg.createBigImm(144506576, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb36.append(inst);
        inst = new Inst(Ret64);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb36.append(inst);
        return code;
    }
    /*
     * Copyright (C) 2016 Apple Inc. All rights reserved.
     *
     * Redistribution and use in source and binary forms, with or without
     * modification, are permitted provided that the following conditions
     * are met:
     * 1. Redistributions of source code must retain the above copyright
     *    notice, this list of conditions and the following disclaimer.
     * 2. Redistributions in binary form must reproduce the above copyright
     *    notice, this list of conditions and the following disclaimer in the
     *    documentation and/or other materials provided with the distribution.
     *
     * THIS SOFTWARE IS PROVIDED BY APPLE INC. ``AS IS'' AND ANY
     * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
     * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
     * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE INC. OR
     * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
     * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
     * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
     * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
     * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
     * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
     * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
     */
    class /*<@18>*/Arg {
        constructor() {
            this._kind = Arg.Invalid;
        }
        static /*<@64>*/isAnyUse(/*<@7>*/role) {
            switch (role) {
                case Arg.Use:
                case Arg.ColdUse:
                case Arg.UseDef:
                case Arg.UseZDef:
                case Arg.LateUse:
                case Arg.LateColdUse:
                case Arg.Scratch:
                    return true;
                case Arg.Def:
                case Arg.ZDef:
                case Arg.UseAddr:
                case Arg.EarlyDef:
                    return false;
                default:
                    throw new Error("Bad role");
            }
        }
        static /*<@65>*/isColdUse(/*<@7>*/role) {
            switch (role) {
                case Arg.ColdUse:
                case Arg.LateColdUse:
                    return true;
                case Arg.Use:
                case Arg.UseDef:
                case Arg.UseZDef:
                case Arg.LateUse:
                case Arg.Def:
                case Arg.ZDef:
                case Arg.UseAddr:
                case Arg.Scratch:
                case Arg.EarlyDef:
                    return false;
                default:
                    throw new Error("Bad role");
            }
        }
        static /*<@66>*/isWarmUse(/*<@7>*/role) {
            return Arg.isAnyUse(role) && !Arg.isColdUse(role);
        }
        static /*<@67>*/cooled(/*<@7>*/role) {
            switch (role) {
                case Arg.ColdUse:
                case Arg.LateColdUse:
                case Arg.UseDef:
                case Arg.UseZDef:
                case Arg.Def:
                case Arg.ZDef:
                case Arg.UseAddr:
                case Arg.Scratch:
                case Arg.EarlyDef:
                    return role;
                case Arg.Use:
                    return Arg.ColdUse;
                case Arg.LateUse:
                    return Arg.LateColdUse;
                default:
                    throw new Error("Bad role");
            }
        }
        static /*<@68>*/isEarlyUse(/*<@7>*/role) {
            switch (role) {
                case Arg.Use:
                case Arg.ColdUse:
                case Arg.UseDef:
                case Arg.UseZDef:
                    return true;
                case Arg.Def:
                case Arg.ZDef:
                case Arg.UseAddr:
                case Arg.LateUse:
                case Arg.LateColdUse:
                case Arg.Scratch:
                case Arg.EarlyDef:
                    return false;
                default:
                    throw new Error("Bad role");
            }
        }
        static /*<@69>*/isLateUse(/*<@7>*/role) {
            switch (role) {
                case Arg.LateUse:
                case Arg.LateColdUse:
                case Arg.Scratch:
                    return true;
                case Arg.ColdUse:
                case Arg.Use:
                case Arg.UseDef:
                case Arg.UseZDef:
                case Arg.Def:
                case Arg.ZDef:
                case Arg.UseAddr:
                case Arg.EarlyDef:
                    return false;
                default:
                    throw new Error("Bad role");
            }
        }
        static /*<@70>*/isAnyDef(/*<@7>*/role) {
            switch (role) {
                case Arg.Use:
                case Arg.ColdUse:
                case Arg.UseAddr:
                case Arg.LateUse:
                case Arg.LateColdUse:
                    return false;
                case Arg.Def:
                case Arg.UseDef:
                case Arg.ZDef:
                case Arg.UseZDef:
                case Arg.EarlyDef:
                case Arg.Scratch:
                    return true;
                default:
                    throw new Error("Bad role");
            }
        }
        static /*<@71>*/isEarlyDef(/*<@7>*/role) {
            switch (role) {
                case Arg.Use:
                case Arg.ColdUse:
                case Arg.UseAddr:
                case Arg.LateUse:
                case Arg.Def:
                case Arg.UseDef:
                case Arg.ZDef:
                case Arg.UseZDef:
                case Arg.LateColdUse:
                    return false;
                case Arg.EarlyDef:
                case Arg.Scratch:
                    return true;
                default:
                    throw new Error("Bad role");
            }
        }
        static /*<@72>*/isLateDef(/*<@7>*/role) {
            switch (role) {
                case Arg.Use:
                case Arg.ColdUse:
                case Arg.UseAddr:
                case Arg.LateUse:
                case Arg.EarlyDef:
                case Arg.Scratch:
                case Arg.LateColdUse:
                    return false;
                case Arg.Def:
                case Arg.UseDef:
                case Arg.ZDef:
                case Arg.UseZDef:
                    return true;
                default:
                    throw new Error("Bad role");
            }
        }
        static /*<@73>*/isZDef(/*<@7>*/role) {
            switch (role) {
                case Arg.Use:
                case Arg.ColdUse:
                case Arg.UseAddr:
                case Arg.LateUse:
                case Arg.Def:
                case Arg.UseDef:
                case Arg.EarlyDef:
                case Arg.Scratch:
                case Arg.LateColdUse:
                    return false;
                case Arg.ZDef:
                case Arg.UseZDef:
                    return true;
                default:
                    throw new Error("Bad role");
            }
        }
        static /*<@74>*/typeForB3Type(/*<@7>*/type) {
            switch (type) {
                case Int32:
                case Int64:
                    return GP;
                case Float:
                case Double:
                    return FP;
                default:
                    throw new Error("Bad B3 type");
            }
        }
        static /*<@75>*/widthForB3Type(/*<@7>*/type) {
            switch (type) {
                case Int32:
                case Float:
                    return 32;
                case Int64:
                case Double:
                    return 64;
                default:
                    throw new Error("Bad B3 type");
            }
        }
        static /*<@76>*/conservativeWidth(/*<@7>*/type) {
            return type == GP ? Ptr : 64;
        }
        static /*<@77>*/minimumWidth(/*<@7>*/type) {
            return type == GP ? 8 : 32;
        }
        static /*<@78>*/bytes(/*<@5>*/width) {
            return width / 8;
        }
        static /*<@79>*/widthForBytes(/*<@5>*/bytes) {
            switch (bytes) {
                case 0:
                case 1:
                    return 8;
                case 2:
                    return 16;
                case 3:
                case 4:
                    return 32;
                default:
                    if (bytes > 8)
                        throw new Error("Bad number of bytes");
                    return 64;
            }
        }
        static /*<@80>*/createTmp(/*<@19>*/tmp) {
            let /*<@17>*/result = new Arg();
            result._kind = Arg.Tmp;
            result._tmp = tmp;
            return result;
        }
        static /*<@81>*/fromReg(/*<@19>*/reg) {
            return Arg.createTmp(reg);
        }
        static /*<@82>*/createImm(/*<@5>*/value) {
            let /*<@17>*/result = new Arg();
            result._kind = Arg.Imm;
            result._value = value;
            return result;
        }
        static /*<@83>*/createBigImm(/*<@5>*/lowValue, /*<@5>*/highValue = 0) {
            let /*<@17>*/result = new Arg();
            result._kind = Arg.BigImm;
            result._lowValue = lowValue;
            result._highValue = highValue;
            return result;
        }
        static /*<@84>*/createBitImm(/*<@5>*/value) {
            let /*<@17>*/result = new Arg();
            result._kind = Arg.BitImm;
            result._value = value;
            return result;
        }
        static /*<@85>*/createBitImm64(/*<@5>*/lowValue, /*<@5>*/highValue = 0) {
            let /*<@17>*/result = new Arg();
            result._kind = Arg.BitImm64;
            result._lowValue = lowValue;
            result._highValue = highValue;
            return result;
        }
        static /*<@86>*/createAddr(/*<@19>*/base, /*<@5>*/offset = 0) {
            let /*<@17>*/result = new Arg();
            result._kind = Arg.Addr;
            result._base = base;
            result._offset = offset;
            return result;
        }
        static /*<@87>*/createStack(/*<@47>*/slot, /*<@5>*/offset = 0) {
            let /*<@17>*/result = new Arg();
            result._kind = Arg.Stack;
            result._slot = slot;
            result._offset = offset;
            return result;
        }
        static /*<@88>*/createCallArg(/*<@5>*/offset) {
            let /*<@17>*/result = new Arg();
            result._kind = Arg.CallArg;
            result._offset = offset;
            return result;
        }
        static /*<@89>*/createStackAddr(/*<@5>*/offsetFromFP, /*<@5>*/frameSize, /*<@5>*/width) {
            let /*<@17>*/result = Arg.createAddr(Reg.callFrameRegister, offsetFromFP);
            if (!result.isValidForm(width))
                result = Arg.createAddr(Reg.stackPointerRegister, offsetFromFP + frameSize);
            return result;
        }
        static /*<@90>*/isValidScale(/*<@5>*/scale, /*<@5>*/width) {
            switch (scale) {
                case 1:
                case 2:
                case 4:
                case 8:
                    return true;
                default:
                    return false;
            }
        }
        static /*<@91>*/logScale(/*<@5>*/scale) {
            switch (scale) {
                case 1:
                    return 0;
                case 2:
                    return 1;
                case 4:
                    return 2;
                case 8:
                    return 3;
                default:
                    throw new Error("Bad scale");
            }
        }
        static /*<@92>*/createIndex(/*<@19>*/base, /*<@19>*/index, /*<@5>*/scale = 1, /*<@5>*/offset = 0) {
            let /*<@17>*/result = new Arg();
            result._kind = Arg.Index;
            result._base = base;
            result._index = index;
            result._scale = scale;
            result._offset = offset;
            return result;
        }
        static /*<@93>*/createRelCond(/*<@7>*/condition) {
            let /*<@17>*/result = new Arg();
            result._kind = Arg.RelCond;
            result._condition = condition;
            return result;
        }
        static /*<@94>*/createResCond(/*<@7>*/condition) {
            let /*<@17>*/result = new Arg();
            result._kind = Arg.ResCond;
            result._condition = condition;
            return result;
        }
        static /*<@95>*/createDoubleCond(/*<@7>*/condition) {
            let /*<@17>*/result = new Arg();
            result._kind = Arg.DoubleCond;
            result._condition = condition;
            return result;
        }
        static /*<@96>*/createWidth(/*<@5>*/width) {
            let /*<@17>*/result = new Arg();
            result._kind = Arg.Width;
            result._width = width;
            return result;
        }
        static /*<@97>*/createSpecial() {
            let /*<@17>*/result = new Arg();
            result._kind = Arg.Special;
            return result;
        }
        get /*<@98>*/kind() { return this._kind; }
        get /*<@99>*/isTmp() { return this._kind == Arg.Tmp; }
        get /*<@100>*/isImm() { return this._kind == Arg.Imm; }
        get /*<@101>*/isBigImm() { return this._kind == Arg.BigImm; }
        get /*<@102>*/isBitImm() { return this._kind == Arg.BitImm; }
        get /*<@103>*/isBitImm64() { return this._kind == Arg.BitImm64; }
        get /*<@104>*/isSomeImm() {
            switch (this._kind) {
                case Arg.Imm:
                case Arg.BitImm:
                    return true;
                default:
                    return false;
            }
        }
        get /*<@105>*/isSomeBigImm() {
            switch (this._kind) {
                case Arg.BigImm:
                case Arg.BitImm64:
                    return true;
                default:
                    return false;
            }
        }
        get /*<@106>*/isAddr() { return this._kind == Arg.Addr; }
        get /*<@107>*/isStack() { return this._kind == Arg.Stack; }
        get /*<@108>*/isCallArg() { return this._kind == Arg.CallArg; }
        get /*<@109>*/isIndex() { return this._kind == Arg.Index; }
        get /*<@110>*/isMemory() {
            switch (this._kind) {
                case Arg.Addr:
                case Arg.Stack:
                case Arg.CallArg:
                case Arg.Index:
                    return true;
                default:
                    return false;
            }
        }
        get /*<@111>*/isStackMemory() {
            switch (this._kind) {
                case Arg.Addr:
                    return this._base == Reg.callFrameRegister
                        || this._base == Reg.stackPointerRegister;
                case Arg.Stack:
                case Arg.CallArg:
                    return true;
                default:
                    return false;
            }
        }
        get /*<@112>*/isRelCond() { return this._kind == Arg.RelCond; }
        get /*<@113>*/isResCond() { return this._kind == Arg.ResCond; }
        get /*<@114>*/isDoubleCond() { return this._kind == Arg.DoubleCond; }
        get /*<@115>*/isCondition() {
            switch (this._kind) {
                case Arg.RelCond:
                case Arg.ResCond:
                case Arg.DoubleCond:
                    return true;
                default:
                    return false;
            }
        }
        get /*<@116>*/isWidth() { return this._kind == Arg.Width; }
        get /*<@117>*/isSpecial() { return this._kind == Arg.Special; }
        get /*<@118>*/isAlive() { return this.isTmp || this.isStack; }
        get /*<@119>*/tmp() {
            if (this._kind != Arg.Tmp)
                throw new Error("Called .tmp for non-tmp");
            return this._tmp;
        }
        get /*<@120>*/value() {
            if (!this.isSomeImm)
                throw new Error("Called .value for non-imm");
            return this._value;
        }
        get /*<@121>*/lowValue() {
            if (!this.isSomeBigImm)
                throw new Error("Called .lowValue for non-big-imm");
            return this._lowValue;
        }
        get /*<@122>*/highValue() {
            if (!this.isSomeBigImm)
                throw new Error("Called .highValue for non-big-imm");
            return this._highValue;
        }
        get /*<@123>*/base() {
            switch (this._kind) {
                case Arg.Addr:
                case Arg.Index:
                    return this._base;
                default:
                    throw new Error("Called .base for non-address");
            }
        }
        get /*<@124>*/hasOffset() { return this.isMemory; }
        get /*<@125>*/offset() {
            switch (this._kind) {
                case Arg.Addr:
                case Arg.Index:
                case Arg.Stack:
                case Arg.CallArg:
                    return this._offset;
                default:
                    throw new Error("Called .offset for non-address");
            }
        }
        get /*<@126>*/stackSlot() {
            if (this._kind != Arg.Stack)
                throw new Error("Called .stackSlot for non-address");
            return this._slot;
        }
        get /*<@127>*/index() {
            if (this._kind != Arg.Index)
                throw new Error("Called .index for non-Index");
            return this._index;
        }
        get /*<@128>*/scale() {
            if (this._kind != Arg.Index)
                throw new Error("Called .scale for non-Index");
            return this._scale;
        }
        get /*<@129>*/logScale() {
            return Arg.logScale(this.scale);
        }
        get /*<@130>*/width() {
            if (this._kind != Arg.Width)
                throw new Error("Called .width for non-Width");
            return this._width;
        }
        get /*<@131>*/isGPTmp() { return this.isTmp && this.tmp.isGP; }
        get /*<@132>*/isFPTmp() { return this.isTmp && this.tmp.isFP; }
        get /*<@133>*/isGP() {
            switch (this._kind) {
                case Arg.Imm:
                case Arg.BigImm:
                case Arg.BitImm:
                case Arg.BitImm64:
                case Arg.Addr:
                case Arg.Index:
                case Arg.Stack:
                case Arg.CallArg:
                case Arg.RelCond:
                case Arg.ResCond:
                case Arg.DoubleCond:
                case Arg.Width:
                case Arg.Special:
                    return true;
                case Arg.Tmp:
                    return this.isGPTmp;
                case Arg.Invalid:
                    return false;
                default:
                    throw new Error("Bad kind");
            }
        }
        get /*<@134>*/isFP() {
            switch (this._kind) {
                case Arg.Imm:
                case Arg.BitImm:
                case Arg.BitImm64:
                case Arg.RelCond:
                case Arg.ResCond:
                case Arg.DoubleCond:
                case Arg.Width:
                case Arg.Special:
                case Arg.Invalid:
                    return false;
                case Arg.Addr:
                case Arg.Index:
                case Arg.Stack:
                case Arg.CallArg:
                case Arg.BigImm:
                    return true;
                case Arg.Tmp:
                    return this.isFPTmp;
                default:
                    throw new Error("Bad kind");
            }
        }
        get /*<@135>*/hasType() {
            switch (this._kind) {
                case Arg.Imm:
                case Arg.BitImm:
                case Arg.BitImm64:
                case Arg.Tmp:
                    return true;
                default:
                    return false;
            }
        }
        get /*<@136>*/type() {
            return this.isGP ? GP : FP;
        }
        /*<@137>*/isType(/*<@7>*/type) {
            switch (type) {
                case Arg.GP:
                    return this.isGP;
                case Arg.FP:
                    return this.isFP;
                default:
                    throw new Error("Bad type");
            }
        }
        /*<@138>*/isCompatibleType(/*<@17>*/other) {
            if (this.hasType)
                return other.isType(this.type);
            if (other.hasType)
                return this.isType(other.type);
            return true;
        }
        get /*<@139>*/isGPR() { return this.isTmp && this.tmp.isGPR; }
        get /*<@140>*/gpr() { return this.tmp.gpr; }
        get /*<@141>*/isFPR() { return this.isTmp && this.tmp.isFPR; }
        get /*<@142>*/fpr() { return this.tmp.fpr; }
        get /*<@143>*/isReg() { return this.isTmp && this.tmp.isReg; }
        get /*<@144>*/reg() { return this.tmp.reg; }
        static /*<@145>*/isValidImmForm(/*<@5>*/value) {
            return isRepresentableAsInt32(value);
        }
        static /*<@146>*/isValidBitImmForm(/*<@5>*/value) {
            return isRepresentableAsInt32(value);
        }
        static /*<@147>*/isValidBitImm64Form(/*<@5>*/value) {
            return isRepresentableAsInt32(value);
        }
        static /*<@148>*/isValidAddrForm(/*<@5>*/offset, /*<@5>*/width) {
            return true;
        }
        static /*<@149>*/isValidIndexForm(/*<@5>*/scale, /*<@5>*/offset, /*<@5>*/width) {
            if (!Arg.isValidScale(scale, width))
                return false;
            return true;
        }
        /*<@150>*/isValidForm(/*<@5>*/width) {
            switch (this._kind) {
                case Arg.Invalid:
                    return false;
                case Arg.Tmp:
                    return true;
                case Arg.Imm:
                    return Arg.isValidImmForm(this.value);
                case Arg.BigImm:
                    return true;
                case Arg.BitImm:
                    return Arg.isValidBitImmForm(this.value);
                case Arg.BitImm64:
                    return Arg.isValidBitImm64Form(this.value);
                case Arg.Addr:
                case Arg.Stack:
                case Arg.CallArg:
                    return Arg.isValidAddrForm(this.offset, width);
                case Arg.Index:
                    return Arg.isValidIndexForm(this.scale, this.offset, width);
                case Arg.RelCond:
                case Arg.ResCond:
                case Arg.DoubleCond:
                case Arg.Width:
                case Arg.Special:
                    return true;
                default:
                    throw new Error("Bad kind");
            }
        }
        /*<@151>*/forEachTmpFast(func) {
            switch (this._kind) {
                case Arg.Tmp: {
                    let /*<@19>*/replacement;
                    if (replacement = func(this._tmp))
                        return Arg.createTmp(replacement);
                    break;
                }
                case Arg.Addr: {
                    let /*<@19>*/replacement;
                    if (replacement = func(this._base))
                        return Arg.createAddr(replacement, this._offset);
                    break;
                }
                case Arg.Index: {
                    let /*<@19>*/baseReplacement = func(this._base);
                    let /*<@19>*/indexReplacement = func(this._index);
                    if (baseReplacement || indexReplacement) {
                        return Arg.createIndex(baseReplacement ? baseReplacement : this._base, indexReplacement ? indexReplacement : this._index, this._scale, this._offset);
                    }
                    break;
                }
                default:
                    break;
            }
        }
        /*<@152>*/usesTmp(/*<@19>*/expectedTmp) {
            let /*<@2>*/usesTmp = false;
            this.forEachTmpFast(/*<@322>*/(/*<@19>*/tmp) => {
                usesTmp = (tmp == expectedTmp);
            });
            return usesTmp;
        }
        /*<@153>*/forEachTmp(/*<@7>*/role, /*<@7>*/type, /*<@5>*/width, func) {
            switch (this._kind) {
                case Arg.Tmp: {
                    let /*<@19>*/replacement;
                    if (replacement = func(this._tmp, role, type, width))
                        return Arg.createTmp(replacement);
                    break;
                }
                case Arg.Addr: {
                    let /*<@19>*/replacement;
                    if (replacement = func(this._base, Arg.Use, GP, role == Arg.UseAddr ? width : Ptr))
                        return Arg.createAddr(replacement, this._offset);
                    break;
                }
                case Arg.Index: {
                    let /*<@19>*/baseReplacement = func(this._base, Arg.Use, GP, role == Arg.UseAddr ? width : Ptr);
                    let /*<@19>*/indexReplacement = func(this._index, Arg.Use, GP, role == Arg.UseAddr ? width : Ptr);
                    if (baseReplacement || indexReplacement) {
                        return Arg.createIndex(baseReplacement ? baseReplacement : this._base, indexReplacement ? indexReplacement : this._index, this._scale, this._offset);
                    }
                    break;
                }
                default:
                    break;
            }
        }
        /*<@154>*/is(/*<@166>*/thing) { return !!thing.extract(this); }
        /*<@167>*/as(/*<@166>*/thing) { return thing.extract(this); }
        // This lets you say things like:
        // arg.forEach(Tmp | Reg | Arg | StackSlot, ...)
        //
        // It's used for abstract liveness analysis.
        /*<@169>*/forEachFast(/*<@48>*/thing, func) {
            return thing.forEachFast(this, func);
        }
        /*<@170>*/forEach(/*<@48>*/thing, /*<@7>*/role, /*<@7>*/type, /*<@5>*/width, func) {
            return thing.forEach(this, role, type, width, func);
        }
        static /*<@171>*/extract(/*<@17>*/arg) { return arg; }
        static /*<@172>*/forEachFast(/*<@17>*/arg, func) { return func(arg); }
        static /*<@173>*/forEach(/*<@17>*/arg, /*<@7>*/role, /*<@7>*/type, /*<@5>*/width, func) { return func(arg, role, type, width); }
        get /*<@174>*/condition() {
            switch (this._kind) {
                case Arg.RelCond:
                case Arg.ResCond:
                case Arg.DoubleCond:
                    return this._condition;
                default:
                    throw new Error("Called .condition for non-condition");
            }
        }
        get /*<@175>*/isInvertible() {
            switch (this._kind) {
                case Arg.RelCond:
                case Arg.DoubleCold:
                    return true;
                case Arg.ResCond:
                    switch (this._condition) {
                        case Zero:
                        case NonZero:
                        case Signed:
                        case PositiveOrZero:
                            return true;
                        default:
                            return false;
                    }
                default:
                    return false;
            }
        }
        static /*<@176>*/kindCode(/*<@7>*/kind) {
            switch (kind) {
                case Arg.Invalid:
                    return 0;
                case Arg.Tmp:
                    return 1;
                case Arg.Imm:
                    return 2;
                case Arg.BigImm:
                    return 3;
                case Arg.BitImm:
                    return 4;
                case Arg.BitImm64:
                    return 5;
                case Arg.Addr:
                    return 6;
                case Arg.Stack:
                    return 7;
                case Arg.CallArg:
                    return 8;
                case Arg.Index:
                    return 9;
                case Arg.RelCond:
                    return 10;
                case Arg.ResCond:
                    return 11;
                case Arg.DoubleCond:
                    return 12;
                case Arg.Special:
                    return 13;
                case Arg.WidthArg:
                    return 14;
                default:
                    throw new Error("Bad kind");
            }
        }
        /*<@177>*/hash() {
            let /*<@5>*/result = Arg.kindCode(this._kind);
            switch (this._kind) {
                case Arg.Invalid:
                case Arg.Special:
                    break;
                case Arg.Tmp:
                    result += this._tmp.hash();
                    result |= 0;
                    break;
                case Arg.Imm:
                case Arg.BitImm:
                    result += this._value;
                    result |= 0;
                    break;
                case Arg.BigImm:
                case Arg.BitImm64:
                    result += this._lowValue;
                    result |= 0;
                    result += this._highValue;
                    result |= 0;
                    break;
                case Arg.CallArg:
                    result += this._offset;
                    result |= 0;
                    break;
                case Arg.RelCond:
                    result += relCondCode(this._condition);
                    result |= 0;
                    break;
                case Arg.ResCond:
                    result += resCondCode(this._condition);
                    result |= 0;
                    break;
                case Arg.DoubleCond:
                    result += doubleCondCode(this._condition);
                    result |= 0;
                    break;
                case Arg.WidthArg:
                    result += this._width;
                    result |= 0;
                    break;
                case Arg.Addr:
                    result += this._offset;
                    result |= 0;
                    result += this._base.hash();
                    result |= 0;
                    break;
                case Arg.Index:
                    result += this._offset;
                    result |= 0;
                    result += this._scale;
                    result |= 0;
                    result += this._base.hash();
                    result |= 0;
                    result += this._index.hash();
                    result |= 0;
                    break;
                case Arg.Stack:
                    result += this._offset;
                    result |= 0;
                    result += this.stackSlot.index;
                    result |= 0;
                    break;
            }
            return result >>> 0;
        }
        /*<@178>*/toString() {
            switch (this._kind) {
                case Arg.Invalid:
                    return "<invalid>";
                case Arg.Tmp:
                    return this._tmp.toString();
                case Arg.Imm:
                    return "$" + this._value;
                case Arg.BigImm:
                case Arg.BitImm64:
                    return "$0x" + this._highValue.toString(16) + ":" + this._lowValue.toString(16);
                case Arg.Addr:
                    return "" + (this._offset ? this._offset : "") + "(" + this._base + ")";
                case Arg.Index:
                    return "" + (this._offset ? this._offset : "") + "(" + this._base +
                        "," + this._index + (this._scale == 1 ? "" : "," + this._scale) + ")";
                case Arg.Stack:
                    return "" + (this._offset ? this._offset : "") + "(" + this._slot + ")";
                case Arg.CallArg:
                    return "" + (this._offset ? this._offset : "") + "(callArg)";
                case Arg.RelCond:
                case Arg.ResCond:
                case Arg.DoubleCond:
                    return symbolName(this._condition);
                case Arg.Special:
                    return "special";
                case Arg.Width:
                    return "" + this._value;
                default:
                    throw new Error("Bad kind");
            }
        }
    }
    // Arg kinds
    Arg.Invalid = Symbol("Invalid");
    Arg.Tmp = Symbol("Tmp");
    Arg.Imm = Symbol("Imm");
    Arg.BigImm = Symbol("BigImm");
    Arg.BitImm = Symbol("BitImm");
    Arg.BitImm64 = Symbol("BitImm64");
    Arg.Addr = Symbol("Addr");
    Arg.Stack = Symbol("Stack");
    Arg.CallArg = Symbol("CallArg");
    Arg.Index = Symbol("Index");
    Arg.RelCond = Symbol("RelCond");
    Arg.ResCond = Symbol("ResCond");
    Arg.DoubleCond = Symbol("DoubleCond");
    Arg.Special = Symbol("Special");
    Arg.Width = Symbol("Width");
    // Arg roles
    Arg.Use = Symbol("Use");
    Arg.ColdUse = Symbol("ColdUse");
    Arg.LateUse = Symbol("LateUse");
    Arg.LateColdUse = Symbol("LateColdUse");
    Arg.Def = Symbol("Def");
    Arg.ZDef = Symbol("ZDef");
    Arg.UseDef = Symbol("UseDef");
    Arg.UseZDef = Symbol("UseZDef");
    Arg.EarlyDef = Symbol("EarlyDef");
    Arg.Scratch = Symbol("Scratch");
    Arg.UseAddr = Symbol("UseAddr");
    /*
     * Copyright (C) 2016 Apple Inc. All rights reserved.
     *
     * Redistribution and use in source and binary forms, with or without
     * modification, are permitted provided that the following conditions
     * are met:
     * 1. Redistributions of source code must retain the above copyright
     *    notice, this list of conditions and the following disclaimer.
     * 2. Redistributions in binary form must reproduce the above copyright
     *    notice, this list of conditions and the following disclaimer in the
     *    documentation and/or other materials provided with the distribution.
     *
     * THIS SOFTWARE IS PROVIDED BY APPLE INC. ``AS IS'' AND ANY
     * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
     * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
     * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE INC. OR
     * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
     * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
     * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
     * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
     * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
     * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
     * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
     */
    function /*<@323>*/allocateStack(/*<@258>*/code) {
        if (code.frameSize)
            throw new Error("Frame size already determined");
        function /*<@324>*/attemptAssignment(/*<@47>*/slot, /*<@5>*/offsetFromFP, /*<@228>*/otherSlots) {
            if (offsetFromFP > 0)
                throw new Error("Expect negative offset");
            offsetFromFP = -roundUpToMultipleOf(slot.alignment, -offsetFromFP);
            for (let /*<@47>*/otherSlot of otherSlots) {
                if (!otherSlot.offsetFromFP)
                    continue;
                let /*<@2>*/overlap = rangesOverlap(offsetFromFP, offsetFromFP + slot.byteSize, otherSlot.offsetFromFP, otherSlot.offsetFromFP + otherSlot.byteSize);
                if (overlap)
                    return false;
            }
            slot.setOffsetFromFP(offsetFromFP);
            return true;
        }
        function /*<@325>*/assign(/*<@47>*/slot, /*<@228>*/otherSlots) {
            if (attemptAssignment(slot, -slot.byteSize, otherSlots))
                return;
            for (let /*<@47>*/otherSlot of otherSlots) {
                if (!otherSlot.offsetFromFP)
                    continue;
                if (attemptAssignment(slot, otherSlot.offsetFromFP - slot.byteSize, otherSlots))
                    return;
            }
            throw new Error("Assignment failed");
        }
        // Allocate all of the escaped slots in order. This is kind of a crazy algorithm to allow for
        // the possibility of stack slots being assigned frame offsets before we even get here.
        let /*<@228>*/assignedEscapedStackSlots = /*<@228>*/[];
        let /*<@228>*/escapedStackSlotsWorklist = /*<@228>*/[];
        for (let /*<@47>*/slot of code.stackSlots) {
            if (slot.isLocked) {
                if (slot.offsetFromFP)
                    assignedEscapedStackSlots.push(slot);
                else
                    escapedStackSlotsWorklist.push(slot);
            }
            else {
                if (slot.offsetFromFP)
                    throw new Error("Offset already assigned");
            }
        }
        // This is a fairly espensive loop, but it's OK because we'll usually only have a handful of
        // escaped stack slots.
        while (escapedStackSlotsWorklist.length) {
            let /*<@47>*/slot = escapedStackSlotsWorklist.pop();
            assign(slot, assignedEscapedStackSlots);
            assignedEscapedStackSlots.push(slot);
        }
        // Now we handle the spill slots.
        let /*<@287>*/liveness = new Liveness(StackSlot, code);
        let /*<@289>*/interference = new Map();
        for (let /*<@47>*/slot of code.stackSlots)
            interference.set(slot, new Set());
        let /*<@256>*/slots = /*<@256>*/[];
        for (let /*<@13>*/block of code) {
            let /*<@285>*/localCalc = liveness.localCalc(block);
            function /*<@326>*/interfere(/*<@5>*/instIndex) {
                Inst.forEachDef(StackSlot, block.get(instIndex), block.get(instIndex + 1), /*<@327>*/(/*<@47>*/slot, /*<@7>*/role, /*<@7>*/type, /*<@5>*/width) => {
                    if (!slot.isSpill)
                        return;
                    for (let /*<@236>*/otherSlot of localCalc.liveSet) {
                        interference.get(slot).add(otherSlot);
                        interference.get(otherSlot).add(slot);
                    }
                });
            }
            for (let /*<@5>*/instIndex = block.size; instIndex--;) {
                // Kill dead stores. For simplicity we say that a store is killable if it has only late
                // defs and those late defs are to things that are dead right now. We only do that
                // because that's the only kind of dead stack store we will see here.
                let /*<@15>*/inst = block.at(instIndex);
                if (!inst.hasNonArgEffects) {
                    let /*<@2>*/ok = true;
                    inst.forEachArg(/*<@328>*/(/*<@17>*/arg, /*<@7>*/role, /*<@7>*/type, /*<@5>*/width) => {
                        if (Arg.isEarlyDef(role)) {
                            ok = false;
                            return;
                        }
                        if (!Arg.isLateDef(role))
                            return;
                        if (!arg.isStack) {
                            ok = false;
                            return;
                        }
                        let /*<@47>*/slot = arg.stackSlot;
                        if (!slot.isSpill) {
                            ok = false;
                            return;
                        }
                        if (localCalc.liveSet.has(slot)) {
                            ok = false;
                            return;
                        }
                    });
                    if (ok)
                        inst.clear();
                }
                interfere(instIndex);
                localCalc.execute(instIndex);
            }
            interfere(-1);
            removeAllMatching(block.insts, /*<@329>*/(/*<@15>*/inst) => inst.opcode == Nop);
        }
        // Now we assign stack locations. At its heart this algorithm is just first-fit. For each
        // StackSlot we just want to find the offsetFromFP that is closest to zero while ensuring no
        // overlap with other StackSlots that this overlaps with.
        for (let /*<@47>*/slot of code.stackSlots) {
            if (slot.offsetFromFP)
                continue;
            assign(slot, assignedEscapedStackSlots.concat(Array.from(interference.get(slot))));
        }
        // Figure out how much stack we're using for stack slots.
        let /*<@5>*/frameSizeForStackSlots = 0;
        for (let /*<@47>*/slot of code.stackSlots) {
            frameSizeForStackSlots = Math.max(frameSizeForStackSlots, -slot.offsetFromFP);
        }
        frameSizeForStackSlots = roundUpToMultipleOf(stackAlignmentBytes, frameSizeForStackSlots);
        // No we need to deduce how much argument area we need.
        for (let /*<@13>*/block of code) {
            for (let /*<@15>*/inst of block) {
                for (let /*<@17>*/arg of inst.args) {
                    if (arg.isCallArg) {
                        // For now, we assume that we use 8 bytes of the call arg. But that's not
                        // such an awesome assumption.
                        // FIXME: https://bugs.webkit.org/show_bug.cgi?id=150454
                        if (arg.offset < 0)
                            throw new Error("Did not expect negative offset for callArg");
                        code.requestCallArgAreaSize(arg.offset + 8);
                    }
                }
            }
        }
        code.setFrameSize(frameSizeForStackSlots + code.callArgAreaSize);
        // Finally transform the code to use Addrs instead of StackSlots. This is a lossless
        // transformation since we can search the StackSlots array to figure out which StackSlot any
        // offset-from-FP refers to.
        // FIXME: This may produce addresses that aren't valid if we end up with a ginormous stack frame.
        // We would have to scavenge for temporaries if this happened. Fortunately, this case will be
        // extremely rare so we can do crazy things when it arises.
        // https://bugs.webkit.org/show_bug.cgi?id=152530
        let /*<@250>*/insertionSet = new InsertionSet();
        for (let /*<@13>*/block of code) {
            for (let /*<@5>*/instIndex = 0; instIndex < block.size; ++instIndex) {
                let /*<@15>*/inst = block.at(instIndex);
                inst.forEachArg(/*<@330>*/(/*<@17>*/arg, /*<@7>*/role, /*<@7>*/type, /*<@5>*/width) => {
                    function /*<@331>*/stackAddr(/*<@5>*/offset) {
                        return Arg.createStackAddr(offset, code.frameSize, width);
                    }
                    switch (arg.kind) {
                        case Arg.Stack: {
                            let /*<@47>*/slot = arg.stackSlot;
                            if (Arg.isZDef(role)
                                && slot.isSpill
                                && slot.byteSize > Arg.bytes(width)) {
                                // Currently we only handle this simple case because it's the only one
                                // that arises: ZDef's are only 32-bit right now. So, when we hit these
                                // assertions it means that we need to implement those other kinds of
                                // zero fills.
                                if (slot.byteSize != 8) {
                                    throw new Error(`Bad spill slot size for ZDef: ${slot.byteSize}, width is ${width}`);
                                }
                                if (width != 32)
                                    throw new Error("Bad width for ZDef");
                                insertionSet.append(instIndex + 1, new Inst(StoreZero32, /*<@179>*/[stackAddr(arg.offset + 4 + slot.offsetFromFP)]));
                            }
                            return stackAddr(arg.offset + slot.offsetFromFP);
                        }
                        case Arg.CallArg:
                            return stackAddr(arg.offset - code.frameSize);
                        default:
                            break;
                    }
                });
            }
            insertionSet.execute(block.insts);
        }
    }
    // Generated by Air::dumpAsJS from #ACLj8C in Air.js
    function /*<@332>*/createPayloadAirJSACLj8C() {
        let /*<@258>*/code = new Code();
        let /*<@13>*/bb0 = code.addBlock();
        let /*<@13>*/bb1 = code.addBlock();
        let /*<@13>*/bb2 = code.addBlock();
        let /*<@13>*/bb3 = code.addBlock();
        let /*<@13>*/bb4 = code.addBlock();
        let /*<@13>*/bb5 = code.addBlock();
        let /*<@13>*/bb6 = code.addBlock();
        let /*<@13>*/bb7 = code.addBlock();
        let /*<@13>*/bb8 = code.addBlock();
        let /*<@13>*/bb9 = code.addBlock();
        let /*<@13>*/bb10 = code.addBlock();
        let /*<@13>*/bb11 = code.addBlock();
        let /*<@13>*/bb12 = code.addBlock();
        let /*<@13>*/bb13 = code.addBlock();
        let /*<@13>*/bb14 = code.addBlock();
        let /*<@13>*/bb15 = code.addBlock();
        let /*<@47>*/slot0 = code.addStackSlot(160, Locked);
        let /*<@47>*/slot1 = code.addStackSlot(8, Spill);
        let /*<@47>*/slot2 = code.addStackSlot(8, Spill);
        let /*<@47>*/slot3 = code.addStackSlot(8, Spill);
        let /*<@47>*/slot4 = code.addStackSlot(40, Locked);
        slot4.setOffsetFromFP(-40);
        let /*<@155>*/tmp61 = code.newTmp(GP);
        let /*<@155>*/tmp60 = code.newTmp(GP);
        let /*<@155>*/tmp59 = code.newTmp(GP);
        let /*<@155>*/tmp58 = code.newTmp(GP);
        let /*<@155>*/tmp57 = code.newTmp(GP);
        let /*<@155>*/tmp56 = code.newTmp(GP);
        let /*<@155>*/tmp55 = code.newTmp(GP);
        let /*<@155>*/tmp54 = code.newTmp(GP);
        let /*<@155>*/tmp53 = code.newTmp(GP);
        let /*<@155>*/tmp52 = code.newTmp(GP);
        let /*<@155>*/tmp51 = code.newTmp(GP);
        let /*<@155>*/tmp50 = code.newTmp(GP);
        let /*<@155>*/tmp49 = code.newTmp(GP);
        let /*<@155>*/tmp48 = code.newTmp(GP);
        let /*<@155>*/tmp47 = code.newTmp(GP);
        let /*<@155>*/tmp46 = code.newTmp(GP);
        let /*<@155>*/tmp45 = code.newTmp(GP);
        let /*<@155>*/tmp44 = code.newTmp(GP);
        let /*<@155>*/tmp43 = code.newTmp(GP);
        let /*<@155>*/tmp42 = code.newTmp(GP);
        let /*<@155>*/tmp41 = code.newTmp(GP);
        let /*<@155>*/tmp40 = code.newTmp(GP);
        let /*<@155>*/tmp39 = code.newTmp(GP);
        let /*<@155>*/tmp38 = code.newTmp(GP);
        let /*<@155>*/tmp37 = code.newTmp(GP);
        let /*<@155>*/tmp36 = code.newTmp(GP);
        let /*<@155>*/tmp35 = code.newTmp(GP);
        let /*<@155>*/tmp34 = code.newTmp(GP);
        let /*<@155>*/tmp33 = code.newTmp(GP);
        let /*<@155>*/tmp32 = code.newTmp(GP);
        let /*<@155>*/tmp31 = code.newTmp(GP);
        let /*<@155>*/tmp30 = code.newTmp(GP);
        let /*<@155>*/tmp29 = code.newTmp(GP);
        let /*<@155>*/tmp28 = code.newTmp(GP);
        let /*<@155>*/tmp27 = code.newTmp(GP);
        let /*<@155>*/tmp26 = code.newTmp(GP);
        let /*<@155>*/tmp25 = code.newTmp(GP);
        let /*<@155>*/tmp24 = code.newTmp(GP);
        let /*<@155>*/tmp23 = code.newTmp(GP);
        let /*<@155>*/tmp22 = code.newTmp(GP);
        let /*<@155>*/tmp21 = code.newTmp(GP);
        let /*<@155>*/tmp20 = code.newTmp(GP);
        let /*<@155>*/tmp19 = code.newTmp(GP);
        let /*<@155>*/tmp18 = code.newTmp(GP);
        let /*<@155>*/tmp17 = code.newTmp(GP);
        let /*<@155>*/tmp16 = code.newTmp(GP);
        let /*<@155>*/tmp15 = code.newTmp(GP);
        let /*<@155>*/tmp14 = code.newTmp(GP);
        let /*<@155>*/tmp13 = code.newTmp(GP);
        let /*<@155>*/tmp12 = code.newTmp(GP);
        let /*<@155>*/tmp11 = code.newTmp(GP);
        let /*<@155>*/tmp10 = code.newTmp(GP);
        let /*<@155>*/tmp9 = code.newTmp(GP);
        let /*<@155>*/tmp8 = code.newTmp(GP);
        let /*<@155>*/tmp7 = code.newTmp(GP);
        let /*<@155>*/tmp6 = code.newTmp(GP);
        let /*<@155>*/tmp5 = code.newTmp(GP);
        let /*<@155>*/tmp4 = code.newTmp(GP);
        let /*<@155>*/tmp3 = code.newTmp(GP);
        let /*<@155>*/tmp2 = code.newTmp(GP);
        let /*<@155>*/tmp1 = code.newTmp(GP);
        let /*<@155>*/tmp0 = code.newTmp(GP);
        let /*<@15>*/inst;
        let /*<@17>*/arg;
        bb0.successors.push(new FrequentedBlock(bb1, Normal));
        bb0.successors.push(new FrequentedBlock(bb15, Normal));
        inst = new Inst(Move);
        arg = Arg.createBigImm(276424800, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rbp, 16);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbp);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.extraEarlyClobberedRegs.add(Reg.r11);
        inst.extraClobberedRegs.add(Reg.r11);
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Scratch, type: GP, width: 64 });
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rbp, 72);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rbp, 64);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rbp, 56);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rbp, 48);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(2, -65536);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r15);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r15);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rbp, 24);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rax, 16);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(0, -65536);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r14);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r15);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r14);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.extraEarlyClobberedRegs.add(Reg.r11);
        inst.extraClobberedRegs.add(Reg.r11);
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Def, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateUse, type: GP, width: 64 });
        bb0.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rcx, 32);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rcx, 40);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r15);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(276327648, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(NotEqual);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb0.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(NotEqual);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.r8, 5);
        inst.args.push(arg);
        arg = Arg.createImm(21);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 8 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 8 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb0.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r15);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb0.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(NotEqual);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.r12, 0);
        inst.args.push(arg);
        arg = Arg.createImm(372);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.r12, 8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rax, -40);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r15);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb0.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r15);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(276321024, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(NotEqual);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createStack(slot0, 72);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createStack(slot0, 64);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createStack(slot0, 56);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createStack(slot0, 48);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        arg = Arg.createStack(slot0, 40);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r15);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r14);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.extraEarlyClobberedRegs.add(Reg.r11);
        inst.extraClobberedRegs.add(Reg.r11);
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Def, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateUse, type: GP, width: 64 });
        bb0.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Xor64);
        arg = Arg.createImm(6);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createImm(-2);
        inst.args.push(arg);
        arg = Arg.createStack(slot2, 0);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createImm(-2);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r9);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r9);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createImm(1);
        inst.args.push(arg);
        arg = Arg.createStack(slot3, 0);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createImm(1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(BranchTest64);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb0.append(inst);
        bb1.successors.push(new FrequentedBlock(bb3, Normal));
        bb1.successors.push(new FrequentedBlock(bb2, Normal));
        bb1.predecessors.push(bb0);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(NotEqual);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.r8, 0);
        inst.args.push(arg);
        arg = Arg.createImm(468);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb1.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.r8, 16);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb1.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(276741160, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb1.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rcx, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb1.append(inst);
        inst = new Inst(Branch64);
        arg = Arg.createRelCond(Equal);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rax, 8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb1.append(inst);
        bb2.predecessors.push(bb1);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb2.append(inst);
        inst = new Inst(Oops);
        bb2.append(inst);
        bb3.successors.push(new FrequentedBlock(bb4, Normal));
        bb3.successors.push(new FrequentedBlock(bb7, Normal));
        bb3.predecessors.push(bb1);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.r8, 24);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r13);
        inst.args.push(arg);
        bb3.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(NotEqual);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rbx, 5);
        inst.args.push(arg);
        arg = Arg.createImm(23);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r13);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 8 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 8 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb3.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(275739616, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb3.append(inst);
        inst = new Inst(Branch64);
        arg = Arg.createRelCond(Equal);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rbx, 24);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb3.append(inst);
        bb4.successors.push(new FrequentedBlock(bb5, Normal));
        bb4.successors.push(new FrequentedBlock(bb6, Normal));
        bb4.predecessors.push(bb3);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createStack(slot0, 0);
        inst.args.push(arg);
        bb4.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rbx, 16);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb4.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rax, 32);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb4.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createStack(slot1, 0);
        inst.args.push(arg);
        bb4.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r15);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r13);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb4.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createStack(slot0, 32);
        inst.args.push(arg);
        bb4.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createStack(slot0, 24);
        inst.args.push(arg);
        bb4.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createStack(slot0, 16);
        inst.args.push(arg);
        bb4.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.r13);
        inst.args.push(arg);
        arg = Arg.createStack(slot0, 8);
        inst.args.push(arg);
        bb4.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(276645872, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb4.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(276646496, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb4.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createCallArg(8);
        inst.args.push(arg);
        bb4.append(inst);
        inst = new Inst(Move32);
        arg = Arg.createImm(2);
        inst.args.push(arg);
        arg = Arg.createCallArg(16);
        inst.args.push(arg);
        bb4.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createCallArg(24);
        inst.args.push(arg);
        bb4.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createCallArg(32);
        inst.args.push(arg);
        bb4.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createCallArg(8);
        inst.args.push(arg);
        arg = Arg.createCallArg(16);
        inst.args.push(arg);
        arg = Arg.createCallArg(24);
        inst.args.push(arg);
        arg = Arg.createCallArg(32);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r15);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r14);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.extraEarlyClobberedRegs.add(Reg.r11);
        inst.extraClobberedRegs.add(Reg.rcx);
        inst.extraClobberedRegs.add(Reg.rdx);
        inst.extraClobberedRegs.add(Reg.rsi);
        inst.extraClobberedRegs.add(Reg.rdi);
        inst.extraClobberedRegs.add(Reg.r8);
        inst.extraClobberedRegs.add(Reg.r9);
        inst.extraClobberedRegs.add(Reg.r10);
        inst.extraClobberedRegs.add(Reg.r11);
        inst.extraClobberedRegs.add(Reg.xmm0);
        inst.extraClobberedRegs.add(Reg.xmm1);
        inst.extraClobberedRegs.add(Reg.xmm2);
        inst.extraClobberedRegs.add(Reg.xmm3);
        inst.extraClobberedRegs.add(Reg.xmm4);
        inst.extraClobberedRegs.add(Reg.xmm5);
        inst.extraClobberedRegs.add(Reg.xmm6);
        inst.extraClobberedRegs.add(Reg.xmm7);
        inst.extraClobberedRegs.add(Reg.xmm8);
        inst.extraClobberedRegs.add(Reg.xmm9);
        inst.extraClobberedRegs.add(Reg.xmm10);
        inst.extraClobberedRegs.add(Reg.xmm11);
        inst.extraClobberedRegs.add(Reg.xmm12);
        inst.extraClobberedRegs.add(Reg.xmm13);
        inst.extraClobberedRegs.add(Reg.xmm14);
        inst.extraClobberedRegs.add(Reg.xmm15);
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Def, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        bb4.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createStack(slot1, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb4.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb4.append(inst);
        inst = new Inst(Xor64);
        arg = Arg.createImm(6);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb4.append(inst);
        inst = new Inst(Move);
        arg = Arg.createImm(-2);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        bb4.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createStack(slot1, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb4.append(inst);
        inst = new Inst(Move);
        arg = Arg.createImm(1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb4.append(inst);
        inst = new Inst(BranchTest64);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb4.append(inst);
        bb5.successors.push(new FrequentedBlock(bb8, Normal));
        bb5.predecessors.push(bb4);
        inst = new Inst(Move);
        arg = Arg.createStack(slot1, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb5.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r15);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r14);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.extraEarlyClobberedRegs.add(Reg.r11);
        inst.extraClobberedRegs.add(Reg.r11);
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Def, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateUse, type: GP, width: 64 });
        bb5.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb5.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r15);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb5.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(NotEqual);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rcx, 0);
        inst.args.push(arg);
        arg = Arg.createImm(419);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb5.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(276168608, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb5.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createCallArg(8);
        inst.args.push(arg);
        bb5.append(inst);
        inst = new Inst(Move32);
        arg = Arg.createImm(2);
        inst.args.push(arg);
        arg = Arg.createCallArg(16);
        inst.args.push(arg);
        bb5.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createCallArg(24);
        inst.args.push(arg);
        bb5.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.r13);
        inst.args.push(arg);
        arg = Arg.createCallArg(32);
        inst.args.push(arg);
        bb5.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createCallArg(8);
        inst.args.push(arg);
        arg = Arg.createCallArg(16);
        inst.args.push(arg);
        arg = Arg.createCallArg(24);
        inst.args.push(arg);
        arg = Arg.createCallArg(32);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r15);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r14);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.extraEarlyClobberedRegs.add(Reg.r11);
        inst.extraClobberedRegs.add(Reg.rcx);
        inst.extraClobberedRegs.add(Reg.rdx);
        inst.extraClobberedRegs.add(Reg.rsi);
        inst.extraClobberedRegs.add(Reg.rdi);
        inst.extraClobberedRegs.add(Reg.r8);
        inst.extraClobberedRegs.add(Reg.r9);
        inst.extraClobberedRegs.add(Reg.r10);
        inst.extraClobberedRegs.add(Reg.r11);
        inst.extraClobberedRegs.add(Reg.xmm0);
        inst.extraClobberedRegs.add(Reg.xmm1);
        inst.extraClobberedRegs.add(Reg.xmm2);
        inst.extraClobberedRegs.add(Reg.xmm3);
        inst.extraClobberedRegs.add(Reg.xmm4);
        inst.extraClobberedRegs.add(Reg.xmm5);
        inst.extraClobberedRegs.add(Reg.xmm6);
        inst.extraClobberedRegs.add(Reg.xmm7);
        inst.extraClobberedRegs.add(Reg.xmm8);
        inst.extraClobberedRegs.add(Reg.xmm9);
        inst.extraClobberedRegs.add(Reg.xmm10);
        inst.extraClobberedRegs.add(Reg.xmm11);
        inst.extraClobberedRegs.add(Reg.xmm12);
        inst.extraClobberedRegs.add(Reg.xmm13);
        inst.extraClobberedRegs.add(Reg.xmm14);
        inst.extraClobberedRegs.add(Reg.xmm15);
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Def, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        bb5.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createStack(slot1, 0);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb5.append(inst);
        inst = new Inst(Move);
        arg = Arg.createImm(10);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb5.append(inst);
        inst = new Inst(Jump);
        bb5.append(inst);
        bb6.successors.push(new FrequentedBlock(bb8, Normal));
        bb6.predecessors.push(bb4);
        inst = new Inst(Move);
        arg = Arg.createImm(10);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb6.append(inst);
        inst = new Inst(Jump);
        bb6.append(inst);
        bb7.successors.push(new FrequentedBlock(bb12, Normal));
        bb7.successors.push(new FrequentedBlock(bb9, Normal));
        bb7.predecessors.push(bb3);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb7.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createCallArg(8);
        inst.args.push(arg);
        bb7.append(inst);
        inst = new Inst(Move32);
        arg = Arg.createImm(5);
        inst.args.push(arg);
        arg = Arg.createCallArg(16);
        inst.args.push(arg);
        bb7.append(inst);
        inst = new Inst(Move);
        arg = Arg.createImm(10);
        inst.args.push(arg);
        arg = Arg.createCallArg(24);
        inst.args.push(arg);
        bb7.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.r13);
        inst.args.push(arg);
        arg = Arg.createCallArg(32);
        inst.args.push(arg);
        bb7.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createCallArg(40);
        inst.args.push(arg);
        bb7.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createCallArg(48);
        inst.args.push(arg);
        bb7.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createCallArg(56);
        inst.args.push(arg);
        bb7.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createCallArg(8);
        inst.args.push(arg);
        arg = Arg.createCallArg(16);
        inst.args.push(arg);
        arg = Arg.createCallArg(24);
        inst.args.push(arg);
        arg = Arg.createCallArg(32);
        inst.args.push(arg);
        arg = Arg.createCallArg(40);
        inst.args.push(arg);
        arg = Arg.createCallArg(48);
        inst.args.push(arg);
        arg = Arg.createCallArg(56);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r15);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r14);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.extraEarlyClobberedRegs.add(Reg.r11);
        inst.extraClobberedRegs.add(Reg.rcx);
        inst.extraClobberedRegs.add(Reg.rdx);
        inst.extraClobberedRegs.add(Reg.rsi);
        inst.extraClobberedRegs.add(Reg.rdi);
        inst.extraClobberedRegs.add(Reg.r8);
        inst.extraClobberedRegs.add(Reg.r9);
        inst.extraClobberedRegs.add(Reg.r10);
        inst.extraClobberedRegs.add(Reg.r11);
        inst.extraClobberedRegs.add(Reg.xmm0);
        inst.extraClobberedRegs.add(Reg.xmm1);
        inst.extraClobberedRegs.add(Reg.xmm2);
        inst.extraClobberedRegs.add(Reg.xmm3);
        inst.extraClobberedRegs.add(Reg.xmm4);
        inst.extraClobberedRegs.add(Reg.xmm5);
        inst.extraClobberedRegs.add(Reg.xmm6);
        inst.extraClobberedRegs.add(Reg.xmm7);
        inst.extraClobberedRegs.add(Reg.xmm8);
        inst.extraClobberedRegs.add(Reg.xmm9);
        inst.extraClobberedRegs.add(Reg.xmm10);
        inst.extraClobberedRegs.add(Reg.xmm11);
        inst.extraClobberedRegs.add(Reg.xmm12);
        inst.extraClobberedRegs.add(Reg.xmm13);
        inst.extraClobberedRegs.add(Reg.xmm14);
        inst.extraClobberedRegs.add(Reg.xmm15);
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Def, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        bb7.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb7.append(inst);
        inst = new Inst(BranchTest64);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r15);
        inst.args.push(arg);
        bb7.append(inst);
        bb8.successors.push(new FrequentedBlock(bb13, Normal));
        bb8.successors.push(new FrequentedBlock(bb10, Normal));
        bb8.predecessors.push(bb6);
        bb8.predecessors.push(bb5);
        inst = new Inst(BranchTest64);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r15);
        inst.args.push(arg);
        bb8.append(inst);
        bb9.successors.push(new FrequentedBlock(bb11, Normal));
        bb9.predecessors.push(bb7);
        inst = new Inst(Jump);
        bb9.append(inst);
        bb10.successors.push(new FrequentedBlock(bb11, Normal));
        bb10.predecessors.push(bb8);
        inst = new Inst(Jump);
        bb10.append(inst);
        bb11.predecessors.push(bb9);
        bb11.predecessors.push(bb10);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(Below);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rax, 5);
        inst.args.push(arg);
        arg = Arg.createImm(20);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 8 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 8 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb11.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb11.append(inst);
        inst = new Inst(Oops);
        bb11.append(inst);
        bb12.successors.push(new FrequentedBlock(bb14, Normal));
        bb12.predecessors.push(bb7);
        inst = new Inst(Jump);
        bb12.append(inst);
        bb13.successors.push(new FrequentedBlock(bb14, Normal));
        bb13.predecessors.push(bb8);
        inst = new Inst(Jump);
        bb13.append(inst);
        bb14.predecessors.push(bb12);
        bb14.predecessors.push(bb13);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb14.append(inst);
        inst = new Inst(And64);
        arg = Arg.createImm(-9);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb14.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(NotEqual);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createImm(2);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb14.append(inst);
        inst = new Inst(Move);
        arg = Arg.createImm(10);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb14.append(inst);
        inst = new Inst(Ret64);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb14.append(inst);
        bb15.predecessors.push(bb0);
        inst = new Inst(Move);
        arg = Arg.createImm(10);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb15.append(inst);
        inst = new Inst(Ret64);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb15.append(inst);
        return code;
    }
    class /*<@20>*/Reg extends TmpBase {
        constructor(/*<@5>*/index, /*<@7>*/type, /*<@3>*/name, /*<@21>*/isCalleeSave) {
            super();
            this._index = index;
            this._type = type;
            this._name = name;
            this._isCalleeSave = !!isCalleeSave;
        }
        static /*<@23>*/fromReg(/*<@19>*/reg) {
            return reg;
        }
        get /*<@24>*/index() { return this._index; }
        get /*<@25>*/type() { return this._type; }
        get /*<@26>*/name() { return this._name; }
        get /*<@27>*/isCalleeSave() { return this._isCalleeSave; }
        get /*<@28>*/isReg() { return true; }
        /*<@29>*/hash() {
            if (this.isGP)
                return 1 + this._index;
            return -1 - this._index;
        }
        /*<@30>*/toString() {
            return `%${this._name}`;
        }
        static /*<@31>*/extract(/*<@17>*/arg) {
            if (arg.isReg)
                return arg.reg;
            return null;
        }
        static /*<@33>*/forEachFast(/*<@17>*/arg, func) {
            return arg.forEachTmpFast(/*<@333>*/(/*<@19>*/tmp) => {
                if (!tmp.isReg)
                    return;
                return func(tmp);
            });
        }
        static /*<@35>*/forEach(/*<@17>*/arg, /*<@7>*/argRole, /*<@7>*/argType, /*<@5>*/argWidth, func) {
            return arg.forEachTmp(argRole, argType, argWidth, /*<@334>*/(/*<@19>*/tmp, /*<@7>*/role, /*<@7>*/type, /*<@5>*/width) => {
                if (!tmp.isReg)
                    return;
                return func(tmp, role, type, width);
            });
        }
    }
    {
        Reg.regs = /*<@256>*/[];
        function /*<@335>*/newReg(/*<@5>*/index, /*<@7>*/type, /*<@3>*/name, /*<@21>*/isCalleeSave) {
            let /*<@19>*/result = new Reg(index, type, name, isCalleeSave);
            Reg.regs.push(result);
            return result;
        }
        // Define X86_64 GPRs
        {
            let /*<@5>*/index = 0;
            function /*<@336>*/newGPR(/*<@3>*/name, /*<@21>*/isCalleeSave) { return newReg(index++, GP, name, isCalleeSave); }
            Reg.rax = newGPR("rax");
            Reg.rcx = newGPR("rcx");
            Reg.rdx = newGPR("rdx");
            Reg.rbx = newGPR("rbx", true);
            Reg.rsp = newGPR("rsp");
            Reg.rbp = newGPR("rbp", true);
            Reg.rsi = newGPR("rsi");
            Reg.rdi = newGPR("rdi");
            for (let /*<@5>*/i = 8; i <= 15; ++i)
                Reg[`r${i}`] = newGPR(`r${i}`, i >= 12);
        }
        // Define X86_64 FPRs.
        for (let /*<@5>*/i = 0; i <= 15; ++i)
            Reg[`xmm${i}`] = newReg(i, FP, `xmm${i}`);
        Reg.gprs = /*<@256>*/[];
        Reg.fprs = /*<@256>*/[];
        Reg.calleeSaveGPRs = /*<@256>*/[];
        Reg.calleeSaveFPRs = /*<@256>*/[];
        Reg.calleeSaves = /*<@256>*/[];
        for (let /*<@19>*/reg of Reg.regs) {
            if (reg.isGP) {
                Reg.gprs.push(reg);
                if (reg.isCalleeSave)
                    Reg.calleeSaveGPRs.push(reg);
            }
            else {
                Reg.fprs.push(reg);
                if (reg.isCalleeSave)
                    Reg.calleeSaveFPRs.push(reg);
            }
            if (reg.isCalleeSave)
                Reg.calleeSaves.push(reg);
        }
        Reg.callFrameRegister = Reg.rbp;
        Reg.stackPointerRegister = Reg.rsp;
    }
    /*
     * Copyright (C) 2016 Apple Inc. All rights reserved.
     *
     * Redistribution and use in source and binary forms, with or without
     * modification, are permitted provided that the following conditions
     * are met:
     * 1. Redistributions of source code must retain the above copyright
     *    notice, this list of conditions and the following disclaimer.
     * 2. Redistributions in binary form must reproduce the above copyright
     *    notice, this list of conditions and the following disclaimer in the
     *    documentation and/or other materials provided with the distribution.
     *
     * THIS SOFTWARE IS PROVIDED BY APPLE INC. ``AS IS'' AND ANY
     * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
     * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
     * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE INC. OR
     * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
     * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
     * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
     * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
     * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
     * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
     * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
     */
    class /*<@48>*/StackSlot {
        constructor(/*<@5>*/index, /*<@5>*/byteSize, /*<@7>*/kind) {
            this._index = index;
            this._byteSize = byteSize;
            this._kind = kind;
        }
        get /*<@49>*/byteSize() { return this._byteSize; }
        get /*<@50>*/kind() { return this._kind; }
        get /*<@51>*/isLocked() { return this._kind == Locked; }
        get /*<@52>*/isSpill() { return this._kind == Spill; }
        get /*<@53>*/index() { return this._index; }
        /*<@54>*/ensureSize(/*<@5>*/size) {
            if (this._offsetFromFP)
                throw new Error("Stack slot already allocated");
            this._byteSize = Math.max(this._byteSize, size);
        }
        get /*<@55>*/alignment() {
            if (this._byteSize <= 1)
                return 1;
            if (this._byteSize <= 2)
                return 2;
            if (this._byteSize <= 4)
                return 4;
            return 8;
        }
        get /*<@56>*/offsetFromFP() { return this._offsetFromFP; }
        /*<@57>*/setOffsetFromFP(/*<@5>*/value) { this._offsetFromFP = value; }
        /*<@58>*/hash() {
            return ((this._kind == Spill ? 1 : 0) + this._byteSize * 3 + (this._offsetFromFP ? this._offsetFromFP * 7 : 0)) >>> 0;
        }
        /*<@59>*/toString() {
            return "" + (this.isSpill ? "spill" : "stack") + this._index + "<" + this._byteSize +
                (this._offsetFromFP ? ", offset = " + this._offsetFromFP : "") + ">";
        }
        static /*<@60>*/extract(/*<@17>*/arg) {
            if (arg.isStack)
                return arg.stackSlot;
            return null;
        }
        static /*<@62>*/forEachFast(/*<@17>*/arg, func) {
            if (!arg.isStack)
                return;
            let /*<@47>*/replacement;
            if (replacement = func(arg.stackSlot))
                return Arg.createStack(replacement, this._offset);
        }
        static /*<@63>*/forEach(/*<@17>*/arg, /*<@7>*/role, /*<@7>*/type, /*<@5>*/width, func) {
            if (!arg.isStack)
                return;
            let /*<@47>*/replacement;
            if (replacement = func(arg.stackSlot, role, type, width))
                return Arg.createStack(replacement, this._offset);
        }
    }
    // Generated by Air::dumpAsJS from executeIteration#EVx8pJ in Octane/gbemu
    function /*<@337>*/createPayloadGbemuExecuteIteration() {
        let /*<@258>*/code = new Code();
        let /*<@13>*/bb0 = code.addBlock();
        let /*<@13>*/bb1 = code.addBlock();
        let /*<@13>*/bb2 = code.addBlock();
        let /*<@13>*/bb3 = code.addBlock();
        let /*<@13>*/bb4 = code.addBlock();
        let /*<@13>*/bb5 = code.addBlock();
        let /*<@13>*/bb6 = code.addBlock();
        let /*<@13>*/bb7 = code.addBlock();
        let /*<@13>*/bb8 = code.addBlock();
        let /*<@13>*/bb9 = code.addBlock();
        let /*<@13>*/bb10 = code.addBlock();
        let /*<@13>*/bb11 = code.addBlock();
        let /*<@13>*/bb12 = code.addBlock();
        let /*<@13>*/bb13 = code.addBlock();
        let /*<@13>*/bb14 = code.addBlock();
        let /*<@13>*/bb15 = code.addBlock();
        let /*<@13>*/bb16 = code.addBlock();
        let /*<@13>*/bb17 = code.addBlock();
        let /*<@13>*/bb18 = code.addBlock();
        let /*<@13>*/bb19 = code.addBlock();
        let /*<@13>*/bb20 = code.addBlock();
        let /*<@13>*/bb21 = code.addBlock();
        let /*<@13>*/bb22 = code.addBlock();
        let /*<@13>*/bb23 = code.addBlock();
        let /*<@13>*/bb24 = code.addBlock();
        let /*<@13>*/bb25 = code.addBlock();
        let /*<@13>*/bb26 = code.addBlock();
        let /*<@13>*/bb27 = code.addBlock();
        let /*<@13>*/bb28 = code.addBlock();
        let /*<@13>*/bb29 = code.addBlock();
        let /*<@13>*/bb30 = code.addBlock();
        let /*<@13>*/bb31 = code.addBlock();
        let /*<@13>*/bb32 = code.addBlock();
        let /*<@13>*/bb33 = code.addBlock();
        let /*<@13>*/bb34 = code.addBlock();
        let /*<@13>*/bb35 = code.addBlock();
        let /*<@13>*/bb36 = code.addBlock();
        let /*<@13>*/bb37 = code.addBlock();
        let /*<@13>*/bb38 = code.addBlock();
        let /*<@13>*/bb39 = code.addBlock();
        let /*<@13>*/bb40 = code.addBlock();
        let /*<@13>*/bb41 = code.addBlock();
        let /*<@13>*/bb42 = code.addBlock();
        let /*<@47>*/slot0 = code.addStackSlot(64, Locked);
        let /*<@47>*/slot1 = code.addStackSlot(8, Spill);
        let /*<@47>*/slot2 = code.addStackSlot(8, Spill);
        let /*<@47>*/slot3 = code.addStackSlot(8, Spill);
        let /*<@47>*/slot4 = code.addStackSlot(8, Spill);
        let /*<@47>*/slot5 = code.addStackSlot(8, Spill);
        let /*<@47>*/slot6 = code.addStackSlot(8, Spill);
        let /*<@47>*/slot7 = code.addStackSlot(8, Spill);
        let /*<@47>*/slot8 = code.addStackSlot(8, Spill);
        let /*<@47>*/slot9 = code.addStackSlot(8, Spill);
        let /*<@47>*/slot10 = code.addStackSlot(8, Spill);
        let /*<@47>*/slot11 = code.addStackSlot(8, Spill);
        let /*<@47>*/slot12 = code.addStackSlot(40, Locked);
        slot12.setOffsetFromFP(-40);
        let /*<@155>*/tmp190 = code.newTmp(GP);
        let /*<@155>*/tmp189 = code.newTmp(GP);
        let /*<@155>*/tmp188 = code.newTmp(GP);
        let /*<@155>*/tmp187 = code.newTmp(GP);
        let /*<@155>*/tmp186 = code.newTmp(GP);
        let /*<@155>*/tmp185 = code.newTmp(GP);
        let /*<@155>*/tmp184 = code.newTmp(GP);
        let /*<@155>*/tmp183 = code.newTmp(GP);
        let /*<@155>*/tmp182 = code.newTmp(GP);
        let /*<@155>*/tmp181 = code.newTmp(GP);
        let /*<@155>*/tmp180 = code.newTmp(GP);
        let /*<@155>*/tmp179 = code.newTmp(GP);
        let /*<@155>*/tmp178 = code.newTmp(GP);
        let /*<@155>*/tmp177 = code.newTmp(GP);
        let /*<@155>*/tmp176 = code.newTmp(GP);
        let /*<@155>*/tmp175 = code.newTmp(GP);
        let /*<@155>*/tmp174 = code.newTmp(GP);
        let /*<@155>*/tmp173 = code.newTmp(GP);
        let /*<@155>*/tmp172 = code.newTmp(GP);
        let /*<@155>*/tmp171 = code.newTmp(GP);
        let /*<@155>*/tmp170 = code.newTmp(GP);
        let /*<@155>*/tmp169 = code.newTmp(GP);
        let /*<@155>*/tmp168 = code.newTmp(GP);
        let /*<@155>*/tmp167 = code.newTmp(GP);
        let /*<@155>*/tmp166 = code.newTmp(GP);
        let /*<@155>*/tmp165 = code.newTmp(GP);
        let /*<@155>*/tmp164 = code.newTmp(GP);
        let /*<@155>*/tmp163 = code.newTmp(GP);
        let /*<@155>*/tmp162 = code.newTmp(GP);
        let /*<@155>*/tmp161 = code.newTmp(GP);
        let /*<@155>*/tmp160 = code.newTmp(GP);
        let /*<@155>*/tmp159 = code.newTmp(GP);
        let /*<@155>*/tmp158 = code.newTmp(GP);
        let /*<@155>*/tmp157 = code.newTmp(GP);
        let /*<@155>*/tmp156 = code.newTmp(GP);
        let /*<@155>*/tmp155 = code.newTmp(GP);
        let /*<@155>*/tmp154 = code.newTmp(GP);
        let /*<@155>*/tmp153 = code.newTmp(GP);
        let /*<@155>*/tmp152 = code.newTmp(GP);
        let /*<@155>*/tmp151 = code.newTmp(GP);
        let /*<@155>*/tmp150 = code.newTmp(GP);
        let /*<@155>*/tmp149 = code.newTmp(GP);
        let /*<@155>*/tmp148 = code.newTmp(GP);
        let /*<@155>*/tmp147 = code.newTmp(GP);
        let /*<@155>*/tmp146 = code.newTmp(GP);
        let /*<@155>*/tmp145 = code.newTmp(GP);
        let /*<@155>*/tmp144 = code.newTmp(GP);
        let /*<@155>*/tmp143 = code.newTmp(GP);
        let /*<@155>*/tmp142 = code.newTmp(GP);
        let /*<@155>*/tmp141 = code.newTmp(GP);
        let /*<@155>*/tmp140 = code.newTmp(GP);
        let /*<@155>*/tmp139 = code.newTmp(GP);
        let /*<@155>*/tmp138 = code.newTmp(GP);
        let /*<@155>*/tmp137 = code.newTmp(GP);
        let /*<@155>*/tmp136 = code.newTmp(GP);
        let /*<@155>*/tmp135 = code.newTmp(GP);
        let /*<@155>*/tmp134 = code.newTmp(GP);
        let /*<@155>*/tmp133 = code.newTmp(GP);
        let /*<@155>*/tmp132 = code.newTmp(GP);
        let /*<@155>*/tmp131 = code.newTmp(GP);
        let /*<@155>*/tmp130 = code.newTmp(GP);
        let /*<@155>*/tmp129 = code.newTmp(GP);
        let /*<@155>*/tmp128 = code.newTmp(GP);
        let /*<@155>*/tmp127 = code.newTmp(GP);
        let /*<@155>*/tmp126 = code.newTmp(GP);
        let /*<@155>*/tmp125 = code.newTmp(GP);
        let /*<@155>*/tmp124 = code.newTmp(GP);
        let /*<@155>*/tmp123 = code.newTmp(GP);
        let /*<@155>*/tmp122 = code.newTmp(GP);
        let /*<@155>*/tmp121 = code.newTmp(GP);
        let /*<@155>*/tmp120 = code.newTmp(GP);
        let /*<@155>*/tmp119 = code.newTmp(GP);
        let /*<@155>*/tmp118 = code.newTmp(GP);
        let /*<@155>*/tmp117 = code.newTmp(GP);
        let /*<@155>*/tmp116 = code.newTmp(GP);
        let /*<@155>*/tmp115 = code.newTmp(GP);
        let /*<@155>*/tmp114 = code.newTmp(GP);
        let /*<@155>*/tmp113 = code.newTmp(GP);
        let /*<@155>*/tmp112 = code.newTmp(GP);
        let /*<@155>*/tmp111 = code.newTmp(GP);
        let /*<@155>*/tmp110 = code.newTmp(GP);
        let /*<@155>*/tmp109 = code.newTmp(GP);
        let /*<@155>*/tmp108 = code.newTmp(GP);
        let /*<@155>*/tmp107 = code.newTmp(GP);
        let /*<@155>*/tmp106 = code.newTmp(GP);
        let /*<@155>*/tmp105 = code.newTmp(GP);
        let /*<@155>*/tmp104 = code.newTmp(GP);
        let /*<@155>*/tmp103 = code.newTmp(GP);
        let /*<@155>*/tmp102 = code.newTmp(GP);
        let /*<@155>*/tmp101 = code.newTmp(GP);
        let /*<@155>*/tmp100 = code.newTmp(GP);
        let /*<@155>*/tmp99 = code.newTmp(GP);
        let /*<@155>*/tmp98 = code.newTmp(GP);
        let /*<@155>*/tmp97 = code.newTmp(GP);
        let /*<@155>*/tmp96 = code.newTmp(GP);
        let /*<@155>*/tmp95 = code.newTmp(GP);
        let /*<@155>*/tmp94 = code.newTmp(GP);
        let /*<@155>*/tmp93 = code.newTmp(GP);
        let /*<@155>*/tmp92 = code.newTmp(GP);
        let /*<@155>*/tmp91 = code.newTmp(GP);
        let /*<@155>*/tmp90 = code.newTmp(GP);
        let /*<@155>*/tmp89 = code.newTmp(GP);
        let /*<@155>*/tmp88 = code.newTmp(GP);
        let /*<@155>*/tmp87 = code.newTmp(GP);
        let /*<@155>*/tmp86 = code.newTmp(GP);
        let /*<@155>*/tmp85 = code.newTmp(GP);
        let /*<@155>*/tmp84 = code.newTmp(GP);
        let /*<@155>*/tmp83 = code.newTmp(GP);
        let /*<@155>*/tmp82 = code.newTmp(GP);
        let /*<@155>*/tmp81 = code.newTmp(GP);
        let /*<@155>*/tmp80 = code.newTmp(GP);
        let /*<@155>*/tmp79 = code.newTmp(GP);
        let /*<@155>*/tmp78 = code.newTmp(GP);
        let /*<@155>*/tmp77 = code.newTmp(GP);
        let /*<@155>*/tmp76 = code.newTmp(GP);
        let /*<@155>*/tmp75 = code.newTmp(GP);
        let /*<@155>*/tmp74 = code.newTmp(GP);
        let /*<@155>*/tmp73 = code.newTmp(GP);
        let /*<@155>*/tmp72 = code.newTmp(GP);
        let /*<@155>*/tmp71 = code.newTmp(GP);
        let /*<@155>*/tmp70 = code.newTmp(GP);
        let /*<@155>*/tmp69 = code.newTmp(GP);
        let /*<@155>*/tmp68 = code.newTmp(GP);
        let /*<@155>*/tmp67 = code.newTmp(GP);
        let /*<@155>*/tmp66 = code.newTmp(GP);
        let /*<@155>*/tmp65 = code.newTmp(GP);
        let /*<@155>*/tmp64 = code.newTmp(GP);
        let /*<@155>*/tmp63 = code.newTmp(GP);
        let /*<@155>*/tmp62 = code.newTmp(GP);
        let /*<@155>*/tmp61 = code.newTmp(GP);
        let /*<@155>*/tmp60 = code.newTmp(GP);
        let /*<@155>*/tmp59 = code.newTmp(GP);
        let /*<@155>*/tmp58 = code.newTmp(GP);
        let /*<@155>*/tmp57 = code.newTmp(GP);
        let /*<@155>*/tmp56 = code.newTmp(GP);
        let /*<@155>*/tmp55 = code.newTmp(GP);
        let /*<@155>*/tmp54 = code.newTmp(GP);
        let /*<@155>*/tmp53 = code.newTmp(GP);
        let /*<@155>*/tmp52 = code.newTmp(GP);
        let /*<@155>*/tmp51 = code.newTmp(GP);
        let /*<@155>*/tmp50 = code.newTmp(GP);
        let /*<@155>*/tmp49 = code.newTmp(GP);
        let /*<@155>*/tmp48 = code.newTmp(GP);
        let /*<@155>*/tmp47 = code.newTmp(GP);
        let /*<@155>*/tmp46 = code.newTmp(GP);
        let /*<@155>*/tmp45 = code.newTmp(GP);
        let /*<@155>*/tmp44 = code.newTmp(GP);
        let /*<@155>*/tmp43 = code.newTmp(GP);
        let /*<@155>*/tmp42 = code.newTmp(GP);
        let /*<@155>*/tmp41 = code.newTmp(GP);
        let /*<@155>*/tmp40 = code.newTmp(GP);
        let /*<@155>*/tmp39 = code.newTmp(GP);
        let /*<@155>*/tmp38 = code.newTmp(GP);
        let /*<@155>*/tmp37 = code.newTmp(GP);
        let /*<@155>*/tmp36 = code.newTmp(GP);
        let /*<@155>*/tmp35 = code.newTmp(GP);
        let /*<@155>*/tmp34 = code.newTmp(GP);
        let /*<@155>*/tmp33 = code.newTmp(GP);
        let /*<@155>*/tmp32 = code.newTmp(GP);
        let /*<@155>*/tmp31 = code.newTmp(GP);
        let /*<@155>*/tmp30 = code.newTmp(GP);
        let /*<@155>*/tmp29 = code.newTmp(GP);
        let /*<@155>*/tmp28 = code.newTmp(GP);
        let /*<@155>*/tmp27 = code.newTmp(GP);
        let /*<@155>*/tmp26 = code.newTmp(GP);
        let /*<@155>*/tmp25 = code.newTmp(GP);
        let /*<@155>*/tmp24 = code.newTmp(GP);
        let /*<@155>*/tmp23 = code.newTmp(GP);
        let /*<@155>*/tmp22 = code.newTmp(GP);
        let /*<@155>*/tmp21 = code.newTmp(GP);
        let /*<@155>*/tmp20 = code.newTmp(GP);
        let /*<@155>*/tmp19 = code.newTmp(GP);
        let /*<@155>*/tmp18 = code.newTmp(GP);
        let /*<@155>*/tmp17 = code.newTmp(GP);
        let /*<@155>*/tmp16 = code.newTmp(GP);
        let /*<@155>*/tmp15 = code.newTmp(GP);
        let /*<@155>*/tmp14 = code.newTmp(GP);
        let /*<@155>*/tmp13 = code.newTmp(GP);
        let /*<@155>*/tmp12 = code.newTmp(GP);
        let /*<@155>*/tmp11 = code.newTmp(GP);
        let /*<@155>*/tmp10 = code.newTmp(GP);
        let /*<@155>*/tmp9 = code.newTmp(GP);
        let /*<@155>*/tmp8 = code.newTmp(GP);
        let /*<@155>*/tmp7 = code.newTmp(GP);
        let /*<@155>*/tmp6 = code.newTmp(GP);
        let /*<@155>*/tmp5 = code.newTmp(GP);
        let /*<@155>*/tmp4 = code.newTmp(GP);
        let /*<@155>*/tmp3 = code.newTmp(GP);
        let /*<@155>*/tmp2 = code.newTmp(GP);
        let /*<@155>*/tmp1 = code.newTmp(GP);
        let /*<@155>*/tmp0 = code.newTmp(GP);
        let /*<@155>*/ftmp7 = code.newTmp(FP);
        let /*<@155>*/ftmp6 = code.newTmp(FP);
        let /*<@155>*/ftmp5 = code.newTmp(FP);
        let /*<@155>*/ftmp4 = code.newTmp(FP);
        let /*<@155>*/ftmp3 = code.newTmp(FP);
        let /*<@155>*/ftmp2 = code.newTmp(FP);
        let /*<@155>*/ftmp1 = code.newTmp(FP);
        let /*<@155>*/ftmp0 = code.newTmp(FP);
        let /*<@15>*/inst;
        let /*<@17>*/arg;
        bb0.successors.push(new FrequentedBlock(bb2, Normal));
        bb0.successors.push(new FrequentedBlock(bb1, Normal));
        inst = new Inst(Move);
        arg = Arg.createBigImm(286904960, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rbp, 16);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbp);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.extraEarlyClobberedRegs.add(Reg.r11);
        inst.extraClobberedRegs.add(Reg.r11);
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Scratch, type: GP, width: 64 });
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rbp, 40);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(2, -65536);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r15);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r15);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb0.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(NotEqual);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rbx, 5);
        inst.args.push(arg);
        arg = Arg.createImm(21);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 8 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 8 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb0.append(inst);
        inst = new Inst(Move32);
        arg = Arg.createAddr(Reg.rbx, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(286506544, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createStack(slot10, 0);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(286455168, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createStack(slot4, 0);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(287131344, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createStack(slot6, 0);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createImm(10);
        inst.args.push(arg);
        arg = Arg.createStack(slot3, 0);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(286474592, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createStack(slot2, 0);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(287209728, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createStack(slot11, 0);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createImm(1);
        inst.args.push(arg);
        arg = Arg.createStack(slot1, 0);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(0, -65536);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r14);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(287112728, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createStack(slot8, 0);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(0, 65536);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createStack(slot9, 0);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(287112720, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createStack(slot5, 0);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(286506192, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createStack(slot7, 0);
        inst.args.push(arg);
        bb0.append(inst);
        inst = new Inst(Branch32);
        arg = Arg.createRelCond(Equal);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createImm(862);
        inst.args.push(arg);
        bb0.append(inst);
        bb1.successors.push(new FrequentedBlock(bb41, Normal));
        bb1.successors.push(new FrequentedBlock(bb3, Normal));
        bb1.predecessors.push(bb0);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(NotEqual);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createImm(881);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb1.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rbx, 224);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb1.append(inst);
        inst = new Inst(BranchTest32);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb1.append(inst);
        bb2.successors.push(new FrequentedBlock(bb41, Normal));
        bb2.successors.push(new FrequentedBlock(bb3, Normal));
        bb2.predecessors.push(bb0);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rbx, 224);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb2.append(inst);
        inst = new Inst(BranchTest32);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb2.append(inst);
        bb3.successors.push(new FrequentedBlock(bb5, Normal));
        bb3.successors.push(new FrequentedBlock(bb4, Normal));
        bb3.predecessors.push(bb1);
        bb3.predecessors.push(bb40);
        bb3.predecessors.push(bb39);
        bb3.predecessors.push(bb2);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rbx, 8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        bb3.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rsi, -1144);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        bb3.append(inst);
        inst = new Inst(Branch32);
        arg = Arg.createRelCond(Equal);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createImm(1);
        inst.args.push(arg);
        bb3.append(inst);
        bb4.successors.push(new FrequentedBlock(bb6, Normal));
        bb4.successors.push(new FrequentedBlock(bb7, Normal));
        bb4.predecessors.push(bb3);
        inst = new Inst(Branch32);
        arg = Arg.createRelCond(Equal);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createImm(2);
        inst.args.push(arg);
        bb4.append(inst);
        bb5.successors.push(new FrequentedBlock(bb6, Normal));
        bb5.predecessors.push(bb3);
        inst = new Inst(Move);
        arg = Arg.createImm(7);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rbx, 232);
        inst.args.push(arg);
        bb5.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rbx, 256);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb5.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rbx, 248);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb5.append(inst);
        inst = new Inst(And32);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb5.append(inst);
        inst = new Inst(And32);
        arg = Arg.createImm(31);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb5.append(inst);
        inst = new Inst(Add64);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r14);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb5.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rbx, 240);
        inst.args.push(arg);
        bb5.append(inst);
        inst = new Inst(Jump);
        bb5.append(inst);
        bb6.successors.push(new FrequentedBlock(bb7, Normal));
        bb6.predecessors.push(bb4);
        bb6.predecessors.push(bb5);
        inst = new Inst(Add32);
        arg = Arg.createImm(-1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        bb6.append(inst);
        inst = new Inst(Add64);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r14);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        bb6.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rsi, -1144);
        inst.args.push(arg);
        bb6.append(inst);
        inst = new Inst(Jump);
        bb6.append(inst);
        bb7.successors.push(new FrequentedBlock(bb8, Normal));
        bb7.successors.push(new FrequentedBlock(bb9, Normal));
        bb7.predecessors.push(bb4);
        bb7.predecessors.push(bb6);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rbx, 240);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb7.append(inst);
        inst = new Inst(Branch32);
        arg = Arg.createRelCond(GreaterThan);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createImm(0);
        inst.args.push(arg);
        bb7.append(inst);
        bb8.successors.push(new FrequentedBlock(bb9, Normal));
        bb8.predecessors.push(bb7);
        inst = new Inst(Move);
        arg = Arg.createBigImm(286455168, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb8.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(286455168, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb8.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createCallArg(8);
        inst.args.push(arg);
        bb8.append(inst);
        inst = new Inst(Move32);
        arg = Arg.createImm(1);
        inst.args.push(arg);
        arg = Arg.createCallArg(16);
        inst.args.push(arg);
        bb8.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createCallArg(24);
        inst.args.push(arg);
        bb8.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createCallArg(8);
        inst.args.push(arg);
        arg = Arg.createCallArg(16);
        inst.args.push(arg);
        arg = Arg.createCallArg(24);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r15);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r14);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.extraEarlyClobberedRegs.add(Reg.r11);
        inst.extraClobberedRegs.add(Reg.rcx);
        inst.extraClobberedRegs.add(Reg.rdx);
        inst.extraClobberedRegs.add(Reg.rsi);
        inst.extraClobberedRegs.add(Reg.rdi);
        inst.extraClobberedRegs.add(Reg.r8);
        inst.extraClobberedRegs.add(Reg.r9);
        inst.extraClobberedRegs.add(Reg.r10);
        inst.extraClobberedRegs.add(Reg.r11);
        inst.extraClobberedRegs.add(Reg.xmm0);
        inst.extraClobberedRegs.add(Reg.xmm1);
        inst.extraClobberedRegs.add(Reg.xmm2);
        inst.extraClobberedRegs.add(Reg.xmm3);
        inst.extraClobberedRegs.add(Reg.xmm4);
        inst.extraClobberedRegs.add(Reg.xmm5);
        inst.extraClobberedRegs.add(Reg.xmm6);
        inst.extraClobberedRegs.add(Reg.xmm7);
        inst.extraClobberedRegs.add(Reg.xmm8);
        inst.extraClobberedRegs.add(Reg.xmm9);
        inst.extraClobberedRegs.add(Reg.xmm10);
        inst.extraClobberedRegs.add(Reg.xmm11);
        inst.extraClobberedRegs.add(Reg.xmm12);
        inst.extraClobberedRegs.add(Reg.xmm13);
        inst.extraClobberedRegs.add(Reg.xmm14);
        inst.extraClobberedRegs.add(Reg.xmm15);
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Def, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        bb8.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb8.append(inst);
        inst = new Inst(Jump);
        bb8.append(inst);
        bb9.successors.push(new FrequentedBlock(bb12, Normal));
        bb9.successors.push(new FrequentedBlock(bb10, Normal));
        bb9.predecessors.push(bb7);
        bb9.predecessors.push(bb8);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rbx, 304);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        bb9.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rbx, 128);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        bb9.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(NotEqual);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.r8, 0);
        inst.args.push(arg);
        arg = Arg.createImm(80);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb9.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.r8, 8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb9.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(AboveOrEqual);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rax, -8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        bb9.append(inst);
        inst = new Inst(Move32);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        bb9.append(inst);
        inst = new Inst(Move);
        arg = Arg.createIndex(Reg.rax, Reg.rsi, 8, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb9.append(inst);
        inst = new Inst(Move);
        arg = Arg.createImm(10);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb9.append(inst);
        inst = new Inst(MoveConditionallyTest64);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createImm(-1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb9.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r15);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb9.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(NotEqual);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rcx, 5);
        inst.args.push(arg);
        arg = Arg.createImm(23);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 8 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 8 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb9.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rcx, 24);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb9.append(inst);
        inst = new Inst(Branch64);
        arg = Arg.createRelCond(Equal);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createStack(slot7, 0);
        inst.args.push(arg);
        bb9.append(inst);
        bb10.successors.push(new FrequentedBlock(bb11, Normal));
        bb10.successors.push(new FrequentedBlock(bb13, Normal));
        bb10.predecessors.push(bb9);
        inst = new Inst(Branch64);
        arg = Arg.createRelCond(Equal);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createStack(slot10, 0);
        inst.args.push(arg);
        bb10.append(inst);
        bb11.successors.push(new FrequentedBlock(bb14, Normal));
        bb11.predecessors.push(bb10);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createStack(slot0, 0);
        inst.args.push(arg);
        bb11.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rbx, 344);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        bb11.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(NotEqual);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rdi, 0);
        inst.args.push(arg);
        arg = Arg.createImm(502);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb11.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rdi, 16);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb11.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(AboveOrEqual);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rdi, 24);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb11.append(inst);
        inst = new Inst(Load8);
        arg = Arg.createIndex(Reg.rsi, Reg.rax, 1, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb11.append(inst);
        inst = new Inst(Jump);
        bb11.append(inst);
        bb12.successors.push(new FrequentedBlock(bb14, Normal));
        bb12.predecessors.push(bb9);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createStack(slot0, 0);
        inst.args.push(arg);
        bb12.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rbx, 336);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        bb12.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rbx, 456);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        bb12.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createResCond(Overflow);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ZDef, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        bb12.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(NotEqual);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rdi, 0);
        inst.args.push(arg);
        arg = Arg.createImm(502);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        bb12.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rdi, 16);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        bb12.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(AboveOrEqual);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rdi, 24);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        bb12.append(inst);
        inst = new Inst(Load8);
        arg = Arg.createIndex(Reg.rsi, Reg.rax, 1, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb12.append(inst);
        inst = new Inst(Jump);
        bb12.append(inst);
        bb13.predecessors.push(bb10);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb13.append(inst);
        inst = new Inst(Oops);
        bb13.append(inst);
        bb14.successors.push(new FrequentedBlock(bb15, Normal));
        bb14.successors.push(new FrequentedBlock(bb16, Normal));
        bb14.predecessors.push(bb11);
        bb14.predecessors.push(bb12);
        inst = new Inst(Add32);
        arg = Arg.createImm(1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        bb14.append(inst);
        inst = new Inst(ZeroExtend16To32);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb14.append(inst);
        inst = new Inst(Add64);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r14);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb14.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rbx, 128);
        inst.args.push(arg);
        bb14.append(inst);
        inst = new Inst(BranchTest32);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rbx, 216);
        inst.args.push(arg);
        arg = Arg.createImm(1);
        inst.args.push(arg);
        bb14.append(inst);
        bb15.predecessors.push(bb14);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb15.append(inst);
        inst = new Inst(Oops);
        bb15.append(inst);
        bb16.successors.push(new FrequentedBlock(bb18, Normal));
        bb16.successors.push(new FrequentedBlock(bb17, Normal));
        bb16.predecessors.push(bb14);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rbx, 8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rax, -1752);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rdx, 16);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(AboveOrEqual);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rdx, 24);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb16.append(inst);
        inst = new Inst(Load8);
        arg = Arg.createIndex(Reg.rax, Reg.rcx, 1, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(Add64);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r14);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rbx, 272);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(287112720, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(NotEqual);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rax, 0);
        inst.args.push(arg);
        arg = Arg.createImm(80);
        inst.args.push(arg);
        arg = Arg.createBigImm(287112720, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        bb16.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(287112728, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rax, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(AboveOrEqual);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rax, -8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        bb16.append(inst);
        inst = new Inst(Move);
        arg = Arg.createIndex(Reg.rax, Reg.rcx, 8, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(Move);
        arg = Arg.createImm(10);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(MoveConditionallyTest64);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createImm(-1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createCallArg(8);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(Move32);
        arg = Arg.createImm(2);
        inst.args.push(arg);
        arg = Arg.createCallArg(16);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(287112720, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createCallArg(24);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createCallArg(32);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createCallArg(8);
        inst.args.push(arg);
        arg = Arg.createCallArg(16);
        inst.args.push(arg);
        arg = Arg.createCallArg(24);
        inst.args.push(arg);
        arg = Arg.createCallArg(32);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r15);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r14);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.extraEarlyClobberedRegs.add(Reg.r11);
        inst.extraClobberedRegs.add(Reg.rcx);
        inst.extraClobberedRegs.add(Reg.rdx);
        inst.extraClobberedRegs.add(Reg.rsi);
        inst.extraClobberedRegs.add(Reg.rdi);
        inst.extraClobberedRegs.add(Reg.r8);
        inst.extraClobberedRegs.add(Reg.r9);
        inst.extraClobberedRegs.add(Reg.r10);
        inst.extraClobberedRegs.add(Reg.r11);
        inst.extraClobberedRegs.add(Reg.xmm0);
        inst.extraClobberedRegs.add(Reg.xmm1);
        inst.extraClobberedRegs.add(Reg.xmm2);
        inst.extraClobberedRegs.add(Reg.xmm3);
        inst.extraClobberedRegs.add(Reg.xmm4);
        inst.extraClobberedRegs.add(Reg.xmm5);
        inst.extraClobberedRegs.add(Reg.xmm6);
        inst.extraClobberedRegs.add(Reg.xmm7);
        inst.extraClobberedRegs.add(Reg.xmm8);
        inst.extraClobberedRegs.add(Reg.xmm9);
        inst.extraClobberedRegs.add(Reg.xmm10);
        inst.extraClobberedRegs.add(Reg.xmm11);
        inst.extraClobberedRegs.add(Reg.xmm12);
        inst.extraClobberedRegs.add(Reg.xmm13);
        inst.extraClobberedRegs.add(Reg.xmm14);
        inst.extraClobberedRegs.add(Reg.xmm15);
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Def, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        bb16.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb16.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rbx, 8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rdx, -1088);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rbx, 272);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rbx, 280);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(Rshift32);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createResCond(Overflow);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ZDef, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        bb16.append(inst);
        inst = new Inst(Add64);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r14);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rdx, -1088);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rdx, -88);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rdx, -1176);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r15);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb16.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(NotEqual);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rcx, 0);
        inst.args.push(arg);
        arg = Arg.createImm(80);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb16.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rcx, 8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(AboveOrEqual);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rax, -8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        bb16.append(inst);
        inst = new Inst(Move32);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(Move);
        arg = Arg.createIndex(Reg.rax, Reg.rdx, 8, 0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(Move);
        arg = Arg.createImm(10);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(MoveConditionallyTest64);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createImm(-1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r15);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb16.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(NotEqual);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rax, 5);
        inst.args.push(arg);
        arg = Arg.createImm(23);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 8 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 8 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb16.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createCallArg(8);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(Move32);
        arg = Arg.createImm(2);
        inst.args.push(arg);
        arg = Arg.createCallArg(16);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createCallArg(24);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createCallArg(32);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createCallArg(8);
        inst.args.push(arg);
        arg = Arg.createCallArg(16);
        inst.args.push(arg);
        arg = Arg.createCallArg(24);
        inst.args.push(arg);
        arg = Arg.createCallArg(32);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r15);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r14);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.extraEarlyClobberedRegs.add(Reg.r11);
        inst.extraClobberedRegs.add(Reg.rcx);
        inst.extraClobberedRegs.add(Reg.rdx);
        inst.extraClobberedRegs.add(Reg.rsi);
        inst.extraClobberedRegs.add(Reg.rdi);
        inst.extraClobberedRegs.add(Reg.r8);
        inst.extraClobberedRegs.add(Reg.r9);
        inst.extraClobberedRegs.add(Reg.r10);
        inst.extraClobberedRegs.add(Reg.r11);
        inst.extraClobberedRegs.add(Reg.xmm0);
        inst.extraClobberedRegs.add(Reg.xmm1);
        inst.extraClobberedRegs.add(Reg.xmm2);
        inst.extraClobberedRegs.add(Reg.xmm3);
        inst.extraClobberedRegs.add(Reg.xmm4);
        inst.extraClobberedRegs.add(Reg.xmm5);
        inst.extraClobberedRegs.add(Reg.xmm6);
        inst.extraClobberedRegs.add(Reg.xmm7);
        inst.extraClobberedRegs.add(Reg.xmm8);
        inst.extraClobberedRegs.add(Reg.xmm9);
        inst.extraClobberedRegs.add(Reg.xmm10);
        inst.extraClobberedRegs.add(Reg.xmm11);
        inst.extraClobberedRegs.add(Reg.xmm12);
        inst.extraClobberedRegs.add(Reg.xmm13);
        inst.extraClobberedRegs.add(Reg.xmm14);
        inst.extraClobberedRegs.add(Reg.xmm15);
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Def, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        bb16.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb16.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rbx, 272);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rbx, 280);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(Move32);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(Rshift32);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rbx, 8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rsi);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rsi, -1048);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createResCond(Overflow);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ZDef, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        bb16.append(inst);
        inst = new Inst(Add64);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r14);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rsi, -1048);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rsi, -1072);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb16.append(inst);
        inst = new Inst(Branch64);
        arg = Arg.createRelCond(Below);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r14);
        inst.args.push(arg);
        bb16.append(inst);
        bb17.successors.push(new FrequentedBlock(bb19, Normal));
        bb17.predecessors.push(bb16);
        inst = new Inst(ConvertInt32ToDouble);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm0);
        inst.args.push(arg);
        bb17.append(inst);
        inst = new Inst(Jump);
        bb17.append(inst);
        bb18.successors.push(new FrequentedBlock(bb19, Normal));
        bb18.predecessors.push(bb16);
        inst = new Inst(Add64);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r14);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb18.append(inst);
        inst = new Inst(Move64ToDouble);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm0);
        inst.args.push(arg);
        bb18.append(inst);
        inst = new Inst(Jump);
        bb18.append(inst);
        bb19.successors.push(new FrequentedBlock(bb20, Normal));
        bb19.successors.push(new FrequentedBlock(bb32, Normal));
        bb19.predecessors.push(bb17);
        bb19.predecessors.push(bb18);
        inst = new Inst(ConvertInt32ToDouble);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm1);
        inst.args.push(arg);
        bb19.append(inst);
        inst = new Inst(AddDouble);
        arg = Arg.createTmp(Reg.xmm0);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm1);
        inst.args.push(arg);
        bb19.append(inst);
        inst = new Inst(MoveDoubleTo64);
        arg = Arg.createTmp(Reg.xmm1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb19.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(0, 65536);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb19.append(inst);
        inst = new Inst(Add64);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb19.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rsi, -1072);
        inst.args.push(arg);
        bb19.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rsi, -1080);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb19.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createResCond(Overflow);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ZDef, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        bb19.append(inst);
        inst = new Inst(Add64);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r14);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb19.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rsi, -1080);
        inst.args.push(arg);
        bb19.append(inst);
        inst = new Inst(BranchTest32);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rsi, -1104);
        inst.args.push(arg);
        arg = Arg.createImm(1);
        inst.args.push(arg);
        bb19.append(inst);
        bb20.successors.push(new FrequentedBlock(bb21, Normal));
        bb20.successors.push(new FrequentedBlock(bb32, Normal));
        bb20.predecessors.push(bb19);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rsi, -1096);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb20.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createResCond(Overflow);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ZDef, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        bb20.append(inst);
        inst = new Inst(Add64);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r14);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb20.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rsi, -1096);
        inst.args.push(arg);
        bb20.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rsi, -1112);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r11);
        inst.args.push(arg);
        bb20.append(inst);
        inst = new Inst(Branch32);
        arg = Arg.createRelCond(GreaterThanOrEqual);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r11);
        inst.args.push(arg);
        bb20.append(inst);
        bb21.successors.push(new FrequentedBlock(bb23, Normal));
        bb21.predecessors.push(bb20);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rbx, 344);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        bb21.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(NotEqual);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.r12, 0);
        inst.args.push(arg);
        arg = Arg.createImm(502);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb21.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.r12, 16);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdi);
        inst.args.push(arg);
        bb21.append(inst);
        inst = new Inst(Move32);
        arg = Arg.createAddr(Reg.r12, 24);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r9);
        inst.args.push(arg);
        bb21.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(BelowOrEqual);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r9);
        inst.args.push(arg);
        arg = Arg.createImm(65286);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb21.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rbx, 232);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r10);
        inst.args.push(arg);
        bb21.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rbx, 256);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        bb21.append(inst);
        inst = new Inst(Jump);
        bb21.append(inst);
        bb22.successors.push(new FrequentedBlock(bb23, Normal));
        bb22.predecessors.push(bb30);
        bb22.predecessors.push(bb31);
        bb22.predecessors.push(bb29);
        inst = new Inst(Move32);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb22.append(inst);
        inst = new Inst(Jump);
        bb22.append(inst);
        bb23.successors.push(new FrequentedBlock(bb25, Normal));
        bb23.successors.push(new FrequentedBlock(bb24, Normal));
        bb23.predecessors.push(bb21);
        bb23.predecessors.push(bb22);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createResCond(Overflow);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r11);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r11);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.UseZDef, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 32 });
        bb23.append(inst);
        inst = new Inst(Move32);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb23.append(inst);
        inst = new Inst(Add64);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r14);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb23.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rsi, -1096);
        inst.args.push(arg);
        bb23.append(inst);
        inst = new Inst(Load8);
        arg = Arg.createAddr(Reg.rdi, 65285);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        bb23.append(inst);
        inst = new Inst(Move32);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r13);
        inst.args.push(arg);
        bb23.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createResCond(Overflow);
        inst.args.push(arg);
        arg = Arg.createImm(1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r13);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r12);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.UseZDef, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        bb23.append(inst);
        inst = new Inst(Branch32);
        arg = Arg.createRelCond(BelowOrEqual);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r9);
        inst.args.push(arg);
        arg = Arg.createImm(65285);
        inst.args.push(arg);
        bb23.append(inst);
        bb24.successors.push(new FrequentedBlock(bb26, Normal));
        bb24.successors.push(new FrequentedBlock(bb30, Normal));
        bb24.predecessors.push(bb23);
        inst = new Inst(Store8);
        arg = Arg.createTmp(Reg.r13);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rdi, 65285);
        inst.args.push(arg);
        bb24.append(inst);
        inst = new Inst(Branch32);
        arg = Arg.createRelCond(Equal);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r13);
        inst.args.push(arg);
        arg = Arg.createImm(256);
        inst.args.push(arg);
        bb24.append(inst);
        bb25.successors.push(new FrequentedBlock(bb26, Normal));
        bb25.successors.push(new FrequentedBlock(bb30, Normal));
        bb25.predecessors.push(bb23);
        inst = new Inst(Branch32);
        arg = Arg.createRelCond(Equal);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r13);
        inst.args.push(arg);
        arg = Arg.createImm(256);
        inst.args.push(arg);
        bb25.append(inst);
        bb26.successors.push(new FrequentedBlock(bb28, Normal));
        bb26.successors.push(new FrequentedBlock(bb27, Normal));
        bb26.predecessors.push(bb24);
        bb26.predecessors.push(bb25);
        inst = new Inst(Load8);
        arg = Arg.createAddr(Reg.rdi, 65286);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        bb26.append(inst);
        inst = new Inst(Branch32);
        arg = Arg.createRelCond(BelowOrEqual);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r9);
        inst.args.push(arg);
        arg = Arg.createImm(65285);
        inst.args.push(arg);
        bb26.append(inst);
        bb27.successors.push(new FrequentedBlock(bb28, Normal));
        bb27.predecessors.push(bb26);
        inst = new Inst(Store8);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rdi, 65285);
        inst.args.push(arg);
        bb27.append(inst);
        inst = new Inst(Jump);
        bb27.append(inst);
        bb28.successors.push(new FrequentedBlock(bb29, Normal));
        bb28.successors.push(new FrequentedBlock(bb31, Normal));
        bb28.predecessors.push(bb26);
        bb28.predecessors.push(bb27);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rbx, 248);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        bb28.append(inst);
        inst = new Inst(Or32);
        arg = Arg.createImm(4);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        bb28.append(inst);
        inst = new Inst(Move32);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r13);
        inst.args.push(arg);
        bb28.append(inst);
        inst = new Inst(Add64);
        arg = Arg.createTmp(Reg.r13);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r14);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r13);
        inst.args.push(arg);
        bb28.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.r13);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rbx, 248);
        inst.args.push(arg);
        bb28.append(inst);
        inst = new Inst(Move);
        arg = Arg.createImm(1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r13);
        inst.args.push(arg);
        bb28.append(inst);
        inst = new Inst(BranchTest64);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r10);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r13);
        inst.args.push(arg);
        bb28.append(inst);
        bb29.successors.push(new FrequentedBlock(bb22, Normal));
        bb29.successors.push(new FrequentedBlock(bb32, Normal));
        bb29.predecessors.push(bb28);
        inst = new Inst(And32);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        bb29.append(inst);
        inst = new Inst(And32);
        arg = Arg.createImm(31);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        bb29.append(inst);
        inst = new Inst(Add64);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r14);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        bb29.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rbx, 240);
        inst.args.push(arg);
        bb29.append(inst);
        inst = new Inst(Branch32);
        arg = Arg.createRelCond(GreaterThanOrEqual);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r11);
        inst.args.push(arg);
        bb29.append(inst);
        bb30.successors.push(new FrequentedBlock(bb22, Normal));
        bb30.successors.push(new FrequentedBlock(bb32, Normal));
        bb30.predecessors.push(bb24);
        bb30.predecessors.push(bb25);
        inst = new Inst(Branch32);
        arg = Arg.createRelCond(GreaterThanOrEqual);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r11);
        inst.args.push(arg);
        bb30.append(inst);
        bb31.successors.push(new FrequentedBlock(bb22, Normal));
        bb31.successors.push(new FrequentedBlock(bb32, Normal));
        bb31.predecessors.push(bb28);
        inst = new Inst(Branch32);
        arg = Arg.createRelCond(GreaterThanOrEqual);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r11);
        inst.args.push(arg);
        bb31.append(inst);
        bb32.successors.push(new FrequentedBlock(bb33, Normal));
        bb32.successors.push(new FrequentedBlock(bb34, Normal));
        bb32.predecessors.push(bb19);
        bb32.predecessors.push(bb20);
        bb32.predecessors.push(bb30);
        bb32.predecessors.push(bb31);
        bb32.predecessors.push(bb29);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rsi, -1120);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb32.append(inst);
        inst = new Inst(Branch32);
        arg = Arg.createRelCond(GreaterThan);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createImm(0);
        inst.args.push(arg);
        bb32.append(inst);
        bb33.predecessors.push(bb32);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb33.append(inst);
        inst = new Inst(Oops);
        bb33.append(inst);
        bb34.successors.push(new FrequentedBlock(bb36, Normal));
        bb34.successors.push(new FrequentedBlock(bb35, Normal));
        bb34.predecessors.push(bb32);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rbx, 136);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb34.append(inst);
        inst = new Inst(Branch64);
        arg = Arg.createRelCond(Below);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r14);
        inst.args.push(arg);
        bb34.append(inst);
        bb35.successors.push(new FrequentedBlock(bb37, Normal));
        bb35.successors.push(new FrequentedBlock(bb38, Normal));
        bb35.predecessors.push(bb34);
        inst = new Inst(ConvertInt32ToDouble);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm0);
        inst.args.push(arg);
        bb35.append(inst);
        inst = new Inst(BranchDouble);
        arg = Arg.createDoubleCond(DoubleGreaterThanOrEqual);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm0);
        inst.args.push(arg);
        bb35.append(inst);
        bb36.successors.push(new FrequentedBlock(bb37, Normal));
        bb36.successors.push(new FrequentedBlock(bb38, Normal));
        bb36.predecessors.push(bb34);
        inst = new Inst(Add64);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r14);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb36.append(inst);
        inst = new Inst(Move64ToDouble);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm0);
        inst.args.push(arg);
        bb36.append(inst);
        inst = new Inst(BranchDouble);
        arg = Arg.createDoubleCond(DoubleGreaterThanOrEqual);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.xmm0);
        inst.args.push(arg);
        bb36.append(inst);
        bb37.successors.push(new FrequentedBlock(bb38, Normal));
        bb37.predecessors.push(bb35);
        bb37.predecessors.push(bb36);
        inst = new Inst(Move);
        arg = Arg.createBigImm(286474592, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb37.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(286474592, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb37.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createCallArg(8);
        inst.args.push(arg);
        bb37.append(inst);
        inst = new Inst(Move32);
        arg = Arg.createImm(1);
        inst.args.push(arg);
        arg = Arg.createCallArg(16);
        inst.args.push(arg);
        bb37.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createCallArg(24);
        inst.args.push(arg);
        bb37.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createCallArg(8);
        inst.args.push(arg);
        arg = Arg.createCallArg(16);
        inst.args.push(arg);
        arg = Arg.createCallArg(24);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r15);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r14);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.extraEarlyClobberedRegs.add(Reg.r11);
        inst.extraClobberedRegs.add(Reg.rcx);
        inst.extraClobberedRegs.add(Reg.rdx);
        inst.extraClobberedRegs.add(Reg.rsi);
        inst.extraClobberedRegs.add(Reg.rdi);
        inst.extraClobberedRegs.add(Reg.r8);
        inst.extraClobberedRegs.add(Reg.r9);
        inst.extraClobberedRegs.add(Reg.r10);
        inst.extraClobberedRegs.add(Reg.r11);
        inst.extraClobberedRegs.add(Reg.xmm0);
        inst.extraClobberedRegs.add(Reg.xmm1);
        inst.extraClobberedRegs.add(Reg.xmm2);
        inst.extraClobberedRegs.add(Reg.xmm3);
        inst.extraClobberedRegs.add(Reg.xmm4);
        inst.extraClobberedRegs.add(Reg.xmm5);
        inst.extraClobberedRegs.add(Reg.xmm6);
        inst.extraClobberedRegs.add(Reg.xmm7);
        inst.extraClobberedRegs.add(Reg.xmm8);
        inst.extraClobberedRegs.add(Reg.xmm9);
        inst.extraClobberedRegs.add(Reg.xmm10);
        inst.extraClobberedRegs.add(Reg.xmm11);
        inst.extraClobberedRegs.add(Reg.xmm12);
        inst.extraClobberedRegs.add(Reg.xmm13);
        inst.extraClobberedRegs.add(Reg.xmm14);
        inst.extraClobberedRegs.add(Reg.xmm15);
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Def, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        bb37.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb37.append(inst);
        inst = new Inst(Jump);
        bb37.append(inst);
        bb38.successors.push(new FrequentedBlock(bb39, Normal));
        bb38.successors.push(new FrequentedBlock(bb40, Normal));
        bb38.predecessors.push(bb35);
        bb38.predecessors.push(bb37);
        bb38.predecessors.push(bb36);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createRelCond(NotEqual);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rbx, 0);
        inst.args.push(arg);
        arg = Arg.createImm(881);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb38.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rbx, 8);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rdx);
        inst.args.push(arg);
        bb38.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rdx, -1824);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb38.append(inst);
        inst = new Inst(Move32);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb38.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createResCond(Overflow);
        inst.args.push(arg);
        arg = Arg.createImm(1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.UseZDef, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.LateColdUse, type: GP, width: 32 });
        bb38.append(inst);
        inst = new Inst(Move32);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb38.append(inst);
        inst = new Inst(Add64);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r14);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb38.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rdx, -1824);
        inst.args.push(arg);
        bb38.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rdx, -1832);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb38.append(inst);
        inst = new Inst(Branch32);
        arg = Arg.createRelCond(GreaterThan);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb38.append(inst);
        bb39.successors.push(new FrequentedBlock(bb42, Normal));
        bb39.successors.push(new FrequentedBlock(bb3, Normal));
        bb39.predecessors.push(bb38);
        inst = new Inst(Move);
        arg = Arg.createBigImm(286474592, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb39.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(286474592, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb39.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createCallArg(8);
        inst.args.push(arg);
        bb39.append(inst);
        inst = new Inst(Move32);
        arg = Arg.createImm(1);
        inst.args.push(arg);
        arg = Arg.createCallArg(16);
        inst.args.push(arg);
        bb39.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        arg = Arg.createCallArg(24);
        inst.args.push(arg);
        bb39.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createCallArg(8);
        inst.args.push(arg);
        arg = Arg.createCallArg(16);
        inst.args.push(arg);
        arg = Arg.createCallArg(24);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r15);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r14);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.extraEarlyClobberedRegs.add(Reg.r11);
        inst.extraClobberedRegs.add(Reg.rcx);
        inst.extraClobberedRegs.add(Reg.rdx);
        inst.extraClobberedRegs.add(Reg.rsi);
        inst.extraClobberedRegs.add(Reg.rdi);
        inst.extraClobberedRegs.add(Reg.r8);
        inst.extraClobberedRegs.add(Reg.r9);
        inst.extraClobberedRegs.add(Reg.r10);
        inst.extraClobberedRegs.add(Reg.r11);
        inst.extraClobberedRegs.add(Reg.xmm0);
        inst.extraClobberedRegs.add(Reg.xmm1);
        inst.extraClobberedRegs.add(Reg.xmm2);
        inst.extraClobberedRegs.add(Reg.xmm3);
        inst.extraClobberedRegs.add(Reg.xmm4);
        inst.extraClobberedRegs.add(Reg.xmm5);
        inst.extraClobberedRegs.add(Reg.xmm6);
        inst.extraClobberedRegs.add(Reg.xmm7);
        inst.extraClobberedRegs.add(Reg.xmm8);
        inst.extraClobberedRegs.add(Reg.xmm9);
        inst.extraClobberedRegs.add(Reg.xmm10);
        inst.extraClobberedRegs.add(Reg.xmm11);
        inst.extraClobberedRegs.add(Reg.xmm12);
        inst.extraClobberedRegs.add(Reg.xmm13);
        inst.extraClobberedRegs.add(Reg.xmm14);
        inst.extraClobberedRegs.add(Reg.xmm15);
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Def, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        bb39.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb39.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rbx, 224);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb39.append(inst);
        inst = new Inst(Or32);
        arg = Arg.createImm(2);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb39.append(inst);
        inst = new Inst(Move32);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb39.append(inst);
        inst = new Inst(Add64);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r14);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb39.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createAddr(Reg.rbx, 224);
        inst.args.push(arg);
        bb39.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(287131344, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb39.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(287131344, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb39.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createCallArg(8);
        inst.args.push(arg);
        bb39.append(inst);
        inst = new Inst(Move32);
        arg = Arg.createImm(1);
        inst.args.push(arg);
        arg = Arg.createCallArg(16);
        inst.args.push(arg);
        bb39.append(inst);
        inst = new Inst(Move);
        arg = Arg.createBigImm(287209728, 1);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        bb39.append(inst);
        inst = new Inst(Move);
        arg = Arg.createTmp(Reg.rcx);
        inst.args.push(arg);
        arg = Arg.createCallArg(24);
        inst.args.push(arg);
        bb39.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createCallArg(8);
        inst.args.push(arg);
        arg = Arg.createCallArg(16);
        inst.args.push(arg);
        arg = Arg.createCallArg(24);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r15);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.r14);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.extraEarlyClobberedRegs.add(Reg.r11);
        inst.extraClobberedRegs.add(Reg.rcx);
        inst.extraClobberedRegs.add(Reg.rdx);
        inst.extraClobberedRegs.add(Reg.rsi);
        inst.extraClobberedRegs.add(Reg.rdi);
        inst.extraClobberedRegs.add(Reg.r8);
        inst.extraClobberedRegs.add(Reg.r9);
        inst.extraClobberedRegs.add(Reg.r10);
        inst.extraClobberedRegs.add(Reg.r11);
        inst.extraClobberedRegs.add(Reg.xmm0);
        inst.extraClobberedRegs.add(Reg.xmm1);
        inst.extraClobberedRegs.add(Reg.xmm2);
        inst.extraClobberedRegs.add(Reg.xmm3);
        inst.extraClobberedRegs.add(Reg.xmm4);
        inst.extraClobberedRegs.add(Reg.xmm5);
        inst.extraClobberedRegs.add(Reg.xmm6);
        inst.extraClobberedRegs.add(Reg.xmm7);
        inst.extraClobberedRegs.add(Reg.xmm8);
        inst.extraClobberedRegs.add(Reg.xmm9);
        inst.extraClobberedRegs.add(Reg.xmm10);
        inst.extraClobberedRegs.add(Reg.xmm11);
        inst.extraClobberedRegs.add(Reg.xmm12);
        inst.extraClobberedRegs.add(Reg.xmm13);
        inst.extraClobberedRegs.add(Reg.xmm14);
        inst.extraClobberedRegs.add(Reg.xmm15);
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Def, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 32 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        bb39.append(inst);
        inst = new Inst(Patch);
        arg = Arg.createSpecial();
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rbx);
        inst.args.push(arg);
        inst.patchHasNonArgEffects = true;
        inst.extraEarlyClobberedRegs = new Set();
        inst.extraClobberedRegs = new Set();
        inst.patchArgData = /*<@256>*/[];
        inst.patchArgData.push(/*<@182>*/{ role: Arg.Use, type: GP, width: 64 });
        inst.patchArgData.push(/*<@182>*/{ role: Arg.ColdUse, type: GP, width: 64 });
        bb39.append(inst);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rbx, 224);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb39.append(inst);
        inst = new Inst(BranchTest32);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb39.append(inst);
        bb40.successors.push(new FrequentedBlock(bb42, Normal));
        bb40.successors.push(new FrequentedBlock(bb3, Normal));
        bb40.predecessors.push(bb38);
        inst = new Inst(Move);
        arg = Arg.createAddr(Reg.rbx, 224);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb40.append(inst);
        inst = new Inst(BranchTest32);
        arg = Arg.createResCond(NonZero);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb40.append(inst);
        bb41.predecessors.push(bb1);
        bb41.predecessors.push(bb2);
        inst = new Inst(Move);
        arg = Arg.createImm(10);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb41.append(inst);
        inst = new Inst(Ret64);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb41.append(inst);
        bb42.predecessors.push(bb40);
        bb42.predecessors.push(bb39);
        inst = new Inst(Move);
        arg = Arg.createImm(10);
        inst.args.push(arg);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb42.append(inst);
        inst = new Inst(Ret64);
        arg = Arg.createTmp(Reg.rax);
        inst.args.push(arg);
        bb42.append(inst);
        return code;
    }
    class /*<@340>*/Benchmark {
        constructor(/*<@5>*/verbose = 0) {
            this._verbose = false;
            this._payloads = /*<@256>*/[
                /*<@344>*/{ generate: createPayloadGbemuExecuteIteration, earlyHash: 632653144, lateHash: 372715518 },
                /*<@345>*/{ generate: createPayloadImagingGaussianBlurGaussianBlur, earlyHash: 3677819581, lateHash: 1252116304 },
                /*<@346>*/{ generate: createPayloadTypescriptScanIdentifier, earlyHash: 1914852601, lateHash: 837339551 },
                /*<@347>*/{ generate: createPayloadAirJSACLj8C, earlyHash: 1373599940, lateHash: 3981283600 }
            ];
        }
        /*<@343>*/runIteration() {
            for (let /*<@341>*/payload of this._payloads) {
                // Sadly about 17% of our time is in generate. I don't think that's really avoidable,
                // and I don't mind testing VMs' ability to run such "data definition" code quickly. I
                // would not have expected it to be so slow from first principles!
                let /*<@258>*/code = payload.generate();
                if (this._verbose) {
                    print("Before allocateStack:");
                    print(code);
                }
                let /*<@1>*/hash = code.hash();
                if (hash != payload.earlyHash)
                    throw new Error(`Wrong early hash for ${payload.generate.name}: ${hash}`);
                allocateStack(code);
                if (this._verbose) {
                    print("After allocateStack:");
                    print(code);
                }
                hash = code.hash();
                if (hash != payload.lateHash)
                    throw new Error(`Wrong late hash for ${payload.generate.name}: ${hash}`);
            }
        }
    }
    let /*<@1>*/worst4;
    let /*<@1>*/average;
    let /*<@1>*/firstIteration;
    let /*<@1>*/total;
    function /*<@349>*/summation(/*<@255>*/values) {
        assert(values instanceof Array);
        let /*<@5>*/sum = 0;
        for (let /*<@243>*/x of values)
            sum = sum + /*<@1>*/x;
        return sum;
    }
    function /*<@350>*/toScore(/*<@243>*/timeValue) {
        return /*<@1>*/timeValue;
    }
    function /*<@351>*/mean(/*<@255>*/values) {
        assert(values instanceof Array);
        let /*<@1>*/sum = 0;
        for (let /*<@243>*/x of values)
            sum = sum + /*<@1>*/x;
        return sum / values.length;
    }
    function /*<@352>*/assert(/*<@2>*/condition) {
        if (!condition) {
            throw new Error("assert false");
        }
    }
    function /*<@353>*/processResults(/*<@255>*/results) {
        function /*<@354>*/copyArray(/*<@255>*/a) {
            let /*<@256>*/result = /*<@256>*/[];
            for (let /*<@243>*/x of a)
                result.push(x);
            return result;
        }
        results = copyArray(results);
        firstIteration = toScore(results[0]);
        total = summation(results);
        // results = results.slice(1);
        results.sort(/*<@355>*/(/*<@243>*/a, /*<@243>*/b) => a < b ? 1 : -1);
        for (let /*<@5>*/i = 0; i + 1 < results.length; ++i)
            assert(results[i] >= results[i + 1]);
        let /*<@255>*/worstCase = /*<@255>*/[];
        for (let /*<@5>*/i = 0; i < 4; ++i)
            worstCase.push(results[i]);
        worst4 = toScore(mean(worstCase));
        average = toScore(mean(results));
    }
    function /*<@356>*/printScore() {
        // print("First: " + firstIteration);
        // print("worst4: " + worst4);
        print("average: " + average);
        // print("total: " + total);
    }
    function /*<@357>*/main() {
        let /*<@339>*/__benchmark = new Benchmark(60);
        let /*<@256>*/results = /*<@256>*/[];
        for (let /*<@5>*/i = 0; i < 60; i++) {
            let /*<@1>*/start = performance.now();
            __benchmark.runIteration();
            let /*<@1>*/end = performance.now();
            results.push(end - start);
        }
        processResults(results);
        printScore();
    }
    main();
})(air || (air = {}));
