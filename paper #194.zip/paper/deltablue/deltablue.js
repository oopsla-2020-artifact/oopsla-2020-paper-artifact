/*<@type>{
    "header": {
        "version": "3.0.1",
        "filename": "deltablue.js",
        "sound": 1
    },
    "types": [
        "any",
        "number",
        "boolean",
        "string",
        "void",
        "int",
        "object",
        {
            "index": 7,
            "cname": "Planner",
            "fields": {
                "currentMark": -5
            },
            "methods": [
                8,
                9,
                47,
                48,
                49,
                56,
                57,
                58,
                59
            ]
        },
        {
            "index": 8,
            "fname": "constructor",
            "ret": 7
        },
        {
            "index": 9,
            "fname": "incrementalAdd",
            "params": {
                "c": 10
            }
        },
        {
            "index": 10,
            "cname": "Constraint",
            "fields": {
                "strength": -12
            },
            "methods": [
                11,
                19,
                20,
                21,
                22,
                23,
                24,
                39,
                40,
                41,
                42,
                43,
                44,
                45,
                46
            ]
        },
        {
            "index": 11,
            "fname": "constructor",
            "params": {
                "strength": 12
            },
            "ret": 10
        },
        {
            "index": 12,
            "cname": "Strength",
            "fields": {
                "strengthValue": -5,
                "name": -3
            },
            "sfields": {
                "const stronger": 14,
                "const weaker": 15,
                "const weakestOf": 16,
                "const strongest": 17,
                "static REQUIRED": -12,
                "static STRONG_PREFERRED": -12,
                "static PREFERRED": -12,
                "static STRONG_DEFAULT": -12,
                "static NORMAL": -12,
                "static WEAK_DEFAULT": -12,
                "static WEAKEST": -12
            },
            "methods": [
                13,
                18
            ]
        },
        {
            "index": 13,
            "fname": "constructor",
            "params": {
                "strengthValue": 5,
                "name": 3
            },
            "ret": 12
        },
        {
            "index": 14,
            "fname": "static stronger",
            "params": {
                "s1": 12,
                "s2": 12
            },
            "ret": 2
        },
        {
            "index": 15,
            "fname": "static weaker",
            "params": {
                "s1": 12,
                "s2": 12
            },
            "ret": 2
        },
        {
            "index": 16,
            "fname": "static weakestOf",
            "params": {
                "s1": 12,
                "s2": 12
            },
            "ret": 12
        },
        {
            "index": 17,
            "fname": "static strongest",
            "params": {
                "s1": 12,
                "s2": 12
            },
            "ret": 12
        },
        {
            "index": 18,
            "fname": "nextWeaker",
            "ret": 12
        },
        {
            "index": 19,
            "fname": "addToGraph"
        },
        {
            "index": 20,
            "fname": "chooseMethod",
            "params": {
                "mark": 5
            }
        },
        {
            "index": 21,
            "fname": "isSatisfied",
            "ret": 2
        },
        {
            "index": 22,
            "fname": "markInputs",
            "params": {
                "mark": 5
            }
        },
        {
            "index": 23,
            "fname": "removeFromGraph"
        },
        {
            "index": 24,
            "fname": "output",
            "ret": 25
        },
        {
            "index": 25,
            "cname": "Variable",
            "fields": {
                "value": -5,
                "constraints": -27,
                "determinedBy": -36,
                "mark": -5,
                "walkStrength": -12,
                "stay": -2,
                "name": -3
            },
            "methods": [
                26,
                37,
                38
            ]
        },
        {
            "index": 26,
            "fname": "constructor",
            "params": {
                "name": 3,
                "initialValue": 5
            },
            "ret": 25
        },
        {
            "index": 27,
            "cname": "OrderedCollection",
            "fields": {
                "elms": -30
            },
            "methods": [
                28,
                31,
                32,
                33,
                34,
                35
            ]
        },
        {
            "index": 28,
            "fname": "constructor",
            "ret": 27
        },
        {
            "index": 29,
            "uname": "",
            "types": [
                10,
                25
            ]
        },
        {
            "index": 30,
            "aname": "",
            "element": 29,
            "mode": "normal"
        },
        {
            "index": 31,
            "fname": "add",
            "params": {
                "elm": 29
            }
        },
        {
            "index": 32,
            "fname": "at",
            "params": {
                "index": 5
            },
            "ret": 29
        },
        {
            "index": 33,
            "fname": "size",
            "ret": 5
        },
        {
            "index": 34,
            "fname": "removeFirst",
            "ret": 29
        },
        {
            "index": 35,
            "fname": "remove",
            "params": {
                "elm": 10
            }
        },
        {
            "index": 36,
            "uname": "",
            "types": [
                4,
                10
            ]
        },
        {
            "index": 37,
            "fname": "addConstraint",
            "params": {
                "c": 10
            }
        },
        {
            "index": 38,
            "fname": "removeConstraint",
            "params": {
                "c": 10
            }
        },
        {
            "index": 39,
            "fname": "markUnsatisfied"
        },
        {
            "index": 40,
            "fname": "recalculate"
        },
        {
            "index": 41,
            "fname": "inputsKnown",
            "params": {
                "mark": 5
            },
            "ret": 2
        },
        {
            "index": 42,
            "fname": "execute"
        },
        {
            "index": 43,
            "fname": "addConstraint"
        },
        {
            "index": 44,
            "fname": "satisfy",
            "params": {
                "mark": 5
            },
            "ret": 10
        },
        {
            "index": 45,
            "fname": "destroyConstraint"
        },
        {
            "index": 46,
            "fname": "isInput",
            "ret": 2
        },
        {
            "index": 47,
            "fname": "incrementalRemove",
            "params": {
                "c": 10
            }
        },
        {
            "index": 48,
            "fname": "newMark",
            "ret": 5
        },
        {
            "index": 49,
            "fname": "makePlan",
            "params": {
                "sources": 27
            },
            "ret": 50
        },
        {
            "index": 50,
            "cname": "Plan",
            "fields": {
                "v": -27
            },
            "methods": [
                51,
                52,
                53,
                54,
                55
            ]
        },
        {
            "index": 51,
            "fname": "constructor",
            "ret": 50
        },
        {
            "index": 52,
            "fname": "addConstraint",
            "params": {
                "c": 10
            }
        },
        {
            "index": 53,
            "fname": "size",
            "ret": 5
        },
        {
            "index": 54,
            "fname": "constraintAt",
            "params": {
                "index": 5
            },
            "ret": 10
        },
        {
            "index": 55,
            "fname": "execute"
        },
        {
            "index": 56,
            "fname": "extractPlanFromConstraints",
            "params": {
                "constraints": 27
            },
            "ret": 50
        },
        {
            "index": 57,
            "fname": "addPropagate",
            "params": {
                "c": 10,
                "mark": 5
            },
            "ret": 2
        },
        {
            "index": 58,
            "fname": "removePropagateFrom",
            "params": {
                "out": 25
            },
            "ret": 27
        },
        {
            "index": 59,
            "fname": "addConstraintsConsumingTo",
            "params": {
                "v": 25,
                "coll": 27
            }
        },
        {
            "index": 60,
            "cname": "UnaryConstraint",
            "supers": {
                "Constraint": 11
            },
            "fields": {
                "myOutput": -25,
                "satisfied": -2
            },
            "methods": [
                61,
                62,
                63,
                64,
                65,
                66,
                67,
                68,
                69,
                70
            ]
        },
        {
            "index": 61,
            "fname": "constructor",
            "params": {
                "v": 25,
                "strength": 12
            },
            "ret": 60,
            "hobj": 1
        },
        {
            "index": 62,
            "fname": "addToGraph"
        },
        {
            "index": 63,
            "fname": "chooseMethod",
            "params": {
                "mark": 5
            }
        },
        {
            "index": 64,
            "fname": "isSatisfied",
            "ret": 2
        },
        {
            "index": 65,
            "fname": "markInputs",
            "params": {
                "mark": 5
            }
        },
        {
            "index": 66,
            "fname": "output",
            "ret": 25
        },
        {
            "index": 67,
            "fname": "recalculate"
        },
        {
            "index": 68,
            "fname": "markUnsatisfied"
        },
        {
            "index": 69,
            "fname": "inputsKnown",
            "ret": 2
        },
        {
            "index": 70,
            "fname": "removeFromGraph"
        },
        {
            "index": 71,
            "cname": "StayConstraint",
            "supers": {
                "UnaryConstraint": 61
            },
            "methods": [
                72,
                73
            ]
        },
        {
            "index": 72,
            "fname": "constructor",
            "params": {
                "v": 25,
                "str": 12
            },
            "ret": 71,
            "hobj": 1
        },
        {
            "index": 73,
            "fname": "execute"
        },
        {
            "index": 74,
            "cname": "EditConstraint",
            "supers": {
                "UnaryConstraint": 61
            },
            "methods": [
                75,
                76,
                77
            ]
        },
        {
            "index": 75,
            "fname": "constructor",
            "params": {
                "v": 25,
                "str": 12
            },
            "ret": 74,
            "hobj": 1
        },
        {
            "index": 76,
            "fname": "isInput",
            "ret": 2
        },
        {
            "index": 77,
            "fname": "execute"
        },
        {
            "index": 78,
            "oname": "",
            "fields": {
                "NONE": -5,
                "FORWARD": -5,
                "BACKWARD": -5
            }
        },
        {
            "index": 79,
            "cname": "BinaryConstraint",
            "supers": {
                "Constraint": 11
            },
            "fields": {
                "v1": -25,
                "v2": -25,
                "direction": -5,
                "scale": -25,
                "offset": -25
            },
            "methods": [
                80,
                81,
                82,
                83,
                84,
                85,
                86,
                87,
                88,
                89,
                90
            ]
        },
        {
            "index": 80,
            "fname": "constructor",
            "params": {
                "var1": 25,
                "var2": 25,
                "strength": 12,
                "scale": 25,
                "offset": 25
            },
            "ret": 79,
            "hobj": 1
        },
        {
            "index": 81,
            "fname": "chooseMethod",
            "params": {
                "mark": 5
            }
        },
        {
            "index": 82,
            "fname": "addToGraph"
        },
        {
            "index": 83,
            "fname": "isSatisfied",
            "ret": 2
        },
        {
            "index": 84,
            "fname": "markInputs",
            "params": {
                "mark": 5
            }
        },
        {
            "index": 85,
            "fname": "input",
            "ret": 25
        },
        {
            "index": 86,
            "fname": "output",
            "ret": 25
        },
        {
            "index": 87,
            "fname": "recalculate"
        },
        {
            "index": 88,
            "fname": "markUnsatisfied"
        },
        {
            "index": 89,
            "fname": "inputsKnown",
            "params": {
                "mark": 5
            },
            "ret": 2
        },
        {
            "index": 90,
            "fname": "removeFromGraph"
        },
        {
            "index": 91,
            "cname": "ScaleConstraint",
            "supers": {
                "BinaryConstraint": 80
            },
            "methods": [
                92,
                93,
                94,
                95,
                96,
                97
            ]
        },
        {
            "index": 92,
            "fname": "constructor",
            "params": {
                "src": 25,
                "scale": 25,
                "offset": 25,
                "dest": 25,
                "strength": 12
            },
            "ret": 91,
            "hobj": 1
        },
        {
            "index": 93,
            "fname": "addToGraph",
            "hobj": 1
        },
        {
            "index": 94,
            "fname": "removeFromGraph",
            "hobj": 1
        },
        {
            "index": 95,
            "fname": "markInputs",
            "params": {
                "mark": 5
            },
            "hobj": 1
        },
        {
            "index": 96,
            "fname": "execute"
        },
        {
            "index": 97,
            "fname": "recalculate"
        },
        {
            "index": 98,
            "cname": "EqualityConstraint",
            "supers": {
                "BinaryConstraint": 80
            },
            "methods": [
                99,
                100
            ]
        },
        {
            "index": 99,
            "fname": "constructor",
            "params": {
                "var1": 25,
                "var2": 25,
                "strength": 12
            },
            "ret": 98,
            "hobj": 1
        },
        {
            "index": 100,
            "fname": "execute"
        },
        {
            "index": 101,
            "fname": "chainTest",
            "params": {
                "n": 5
            }
        },
        {
            "index": 102,
            "fname": "change",
            "params": {
                "v": 25,
                "newValue": 5
            }
        },
        {
            "index": 103,
            "fname": "projectionTest",
            "params": {
                "n": 5
            }
        },
        {
            "index": 104,
            "fname": "deltaBlue"
        },
        {
            "index": 105,
            "fname": "static now",
            "ret": 1
        },
        {
            "index": 106,
            "fname": "summation",
            "params": {
                "values": 108
            },
            "ret": 5
        },
        {
            "index": 107,
            "bname": "Object"
        },
        {
            "index": 108,
            "aname": "",
            "element": 107,
            "mode": "normal"
        },
        {
            "index": 109,
            "fname": "toScore",
            "params": {
                "timeValue": 107
            },
            "ret": 1
        },
        {
            "index": 110,
            "fname": "mean",
            "params": {
                "values": 108
            },
            "ret": 1
        },
        {
            "index": 111,
            "fname": "assert",
            "params": {
                "condition": 2
            }
        },
        {
            "index": 112,
            "fname": "processResults",
            "params": {
                "results": 108
            }
        },
        {
            "index": 113,
            "fname": "copyArray",
            "params": {
                "a": 108
            },
            "ret": 108
        },
        {
            "index": 114,
            "aname": "",
            "element": 0,
            "mode": "normal"
        },
        {
            "index": 115,
            "fname": "",
            "params": {
                "a": 107,
                "b": 107
            },
            "ret": 5
        },
        {
            "index": 116,
            "fname": "printScore"
        },
        {
            "index": 117,
            "cname": "Benchmark",
            "methods": [
                118,
                119
            ]
        },
        {
            "index": 118,
            "fname": "constructor",
            "ret": 117
        },
        {
            "index": 119,
            "fname": "runIteration"
        },
        {
            "index": 120,
            "fname": "main"
        }
    ]
}*/
"use strict";
// Copyright 2008 the V8 project authors. All rights reserved.
// Copyright 1996 John Maloney and Mario Wolczko.
/**
 * A JavaScript implementation of the DeltaBlue constraint-solving
 * algorithm, as described in:
 *
 * "The DeltaBlue Algorithm: An Incremental Constraint Hierarchy Solver"
 *   Bjorn N. Freeman-Benson and John Maloney
 *   January 1990 Communications of the ACM,
 *   also available as University of Washington TR 89-08-06.
 *
 * Beware: this benchmark is written in a grotesque style where
 * the constraint model is built by side-effects from constructors.
 * I've kept it this way to avoid deviating too much from the original
 * implementation.
 */
/* --- O b j e c t   M o d e l --- */
/*
Object.prototype.inheritsFrom = function (shuper) {
  function Inheriter() { }
  Inheriter.prototype = shuper.prototype;
  this.prototype = new Inheriter();
  this.superConstructor = shuper;
}
*/
var deltablue;
(function (deltablue) {
    // Global variable holding the current planner.
    let /*<@7>*/planner = null;
    class /*<@28>*/OrderedCollection {
        constructor() {
            this.elms = new /*<@30>*/Array();
        }
        /*<@31>*/add(/*<@29>*/elm) {
            this.elms.push(elm);
        }
        /*<@32>*/at(/*<@5>*/index) {
            return this.elms[index];
        }
        /*<@33>*/size() {
            return (this.elms./*<@5>*/length);
        }
        /*<@34>*/removeFirst() {
            return this.elms.pop();
        }
        /*<@35>*/remove(/*<@10>*/elm) {
            var /*<@5>*/index = 0, /*<@5>*/skipped = 0;
            var /*<@5>*/length = (this.elms./*<@5>*/length);
            for (var /*<@5>*/i = 0; i < length; i++) {
                var /*<@6>*/value = (this.elms[i]);
                if (value != elm) {
                    this.elms[index] = value;
                    index++;
                }
                else {
                    skipped++;
                }
            }
            for (var /*<@5>*/i = 0; i < skipped; i++)
                this.elms.pop();
        }
    }
    /* --- *
     * S t r e n g t h
     * --- */
    /**
     * Strengths are used to measure the relative importance of constraints.
     * New strengths may be inserted in the strength hierarchy without
     * disrupting current constraints.  Strengths cannot be created outside
     * this class, so pointer comparison can be used for value comparison.
     */
    class /*<@13>*/Strength {
        constructor(/*<@5>*/strengthValue, /*<@3>*/name) {
            this.strengthValue = strengthValue;
            this.name = name;
        }
        static /*<@14>*/stronger(/*<@12>*/s1, /*<@12>*/s2) {
            return s1.strengthValue < s2.strengthValue;
        }
        static /*<@15>*/weaker(/*<@12>*/s1, /*<@12>*/s2) {
            return s1.strengthValue > s2.strengthValue;
        }
        static /*<@16>*/weakestOf(/*<@12>*/s1, /*<@12>*/s2) {
            return Strength.weaker(s1, s2) ? s1 : s2;
        }
        static /*<@17>*/strongest(/*<@12>*/s1, /*<@12>*/s2) {
            return Strength.stronger(s1, s2) ? s1 : s2;
        }
        /*<@18>*/nextWeaker() {
            switch (this.strengthValue) {
                case 0: return Strength.STRONG_PREFERRED;
                case 1: return Strength.PREFERRED;
                case 2: return Strength.STRONG_DEFAULT;
                case 3: return Strength.NORMAL;
                case 4: return Strength.WEAK_DEFAULT;
                case 5: return Strength.WEAKEST;
            }
        }
    }
    // Strength constants.
    Strength.REQUIRED = new Strength(0, "required");
    Strength.STRONG_PREFERRED = new Strength(1, "strongPreferred");
    Strength.PREFERRED = new Strength(2, "preferred");
    Strength.STRONG_DEFAULT = new Strength(3, "strongDefault");
    Strength.NORMAL = new Strength(4, "normal");
    Strength.WEAK_DEFAULT = new Strength(5, "weakDefault");
    Strength.WEAKEST = new Strength(6, "weakest");
    /* --- *
     * C o n s t r a i n t
     * --- */
    /**
     * An abstract class representing a system-maintainable relationship
     * (or "constraint") between a set of variables. A constraint supplies
     * a strength instance variable; concrete subclasses provide a means
     * of storing the constrained variables and other information required
     * to represent a constraint.
     */
    class /*<@11>*/Constraint {
        constructor(/*<@12>*/strength) {
            this.strength = strength;
        }
        /*<@19>*/addToGraph() { }
        /*<@20>*/chooseMethod(/*<@5>*/mark) { }
        /*<@21>*/isSatisfied() { return false; }
        /*<@22>*/markInputs(/*<@5>*/mark) { }
        /*<@23>*/removeFromGraph() { }
        /*<@24>*/output() { return undefined; }
        /*<@39>*/markUnsatisfied() { }
        /*<@40>*/recalculate() { }
        /*<@41>*/inputsKnown(/*<@5>*/mark) { return false; }
        /*<@42>*/execute() { }
        /**
         * Activate this constraint and attempt to satisfy it.
         */
        /*<@43>*/addConstraint() {
            this.addToGraph();
            planner.incrementalAdd(this);
        }
        /**
         * Attempt to find a way to enforce this constraint. If successful,
         * record the solution, perhaps modifying the current dataflow
         * graph. Answer the constraint that this constraint overrides, if
         * there is one, or nil, if there isn't.
         * Assume: I am not already satisfied.
         */
        /*<@44>*/satisfy(/*<@5>*/mark) {
            this.chooseMethod(mark);
            if (!this.isSatisfied()) {
                if (this.strength == Strength.REQUIRED)
                    alert("Could not satisfy a required constraint!");
                return null;
            }
            this.markInputs(mark);
            var /*<@25>*/out = this.output();
            var /*<@10>*/overridden = out.determinedBy;
            if (overridden != null)
                overridden.markUnsatisfied();
            out.determinedBy = this;
            if (!planner.addPropagate(this, mark))
                alert("Cycle encountered");
            out.mark = mark;
            return overridden;
        }
        /*<@45>*/destroyConstraint() {
            if (this.isSatisfied())
                planner.incrementalRemove(this);
            else
                this.removeFromGraph();
        }
        /**
         * Normal constraints are not input constraints.  An input constraint
         * is one that depends on external state, such as the mouse, the
         * keybord, a clock, or some arbitraty piece of imperative code.
         */
        /*<@46>*/isInput() {
            return false;
        }
    }
    /* --- *
     * U n a r y   C o n s t r a i n t
     * --- */
    /**
     * Abstract superclass for constraints having a single possible output
     * variable.
     */
    class /*<@61>*/UnaryConstraint extends Constraint {
        constructor(/*<@25>*/v, /*<@12>*/strength) {
            super(strength);
            this.myOutput = v;
            this.satisfied = false;
            this.addConstraint();
        }
        // UnaryConstraint.inheritsFrom(Constraint);
        /**
         * Adds this constraint to the constraint graph
         */
        /*<@62>*/addToGraph() {
            this.myOutput.addConstraint(this);
            this.satisfied = false;
        }
        /**
         * Decides if this constraint can be satisfied and records that
         * decision.
         */
        /*<@63>*/chooseMethod(/*<@5>*/mark) {
            this.satisfied = (this.myOutput.mark != mark)
                && Strength.stronger(this.strength, this.myOutput.walkStrength);
        }
        /**
         * Returns true if this constraint is satisfied in the current solution.
         */
        /*<@64>*/isSatisfied() {
            return this.satisfied;
        }
        /*<@65>*/markInputs(/*<@5>*/mark) {
            // has no inputs
        }
        /**
         * Returns the current output variable.
         */
        /*<@66>*/output() {
            return this.myOutput;
        }
        /**
         * Calculate the walkabout strength, the stay flag, and, if it is
         * 'stay', the value for the current output of this constraint. Assume
         * this constraint is satisfied.
         */
        /*<@67>*/recalculate() {
            this.myOutput.walkStrength = this.strength;
            this.myOutput.stay = !this.isInput();
            if (this.myOutput.stay)
                this.execute(); // Stay optimization
        }
        /**
         * Records that this constraint is unsatisfied
         */
        /*<@68>*/markUnsatisfied() {
            this.satisfied = false;
        }
        /*<@69>*/inputsKnown() {
            return true;
        }
        /*<@70>*/removeFromGraph() {
            if (this.myOutput != null)
                this.myOutput.removeConstraint(this);
            this.satisfied = false;
        }
    }
    /* --- *
     * S t a y   C o n s t r a i n t
     * --- */
    /**
     * Variables that should, with some level of preference, stay the same.
     * Planners may exploit the fact that instances, if satisfied, will not
     * change their output during plan execution.  This is called "stay
     * optimization".
     */
    class /*<@72>*/StayConstraint extends UnaryConstraint {
        constructor(/*<@25>*/v, /*<@12>*/str) {
            super(v, str);
        }
        // StayConstraint.inheritsFrom(UnaryConstraint);
        /*<@73>*/execute() {
            // Stay constraints do nothing
        }
    }
    /* --- *
     * E d i t   C o n s t r a i n t
     * --- */
    /**
     * A unary input constraint used to mark a variable that the client
     * wishes to change.
     */
    class /*<@75>*/EditConstraint extends UnaryConstraint {
        constructor(/*<@25>*/v, /*<@12>*/str) {
            super(v, str);
        }
        // EditConstraint.inheritsFrom(UnaryConstraint);
        /**
         * Edits indicate that a variable is to be changed by imperative code.
         */
        /*<@76>*/isInput() {
            return true;
        }
        /*<@77>*/execute() {
            // Edit constraints do nothing
        }
    }
    /* --- *
     * B i n a r y   C o n s t r a i n t
     * --- */
    /*
    var Direction = new Object();
    Direction.NONE     = 0;
    Direction.FORWARD  = 1;
    Direction.BACKWARD = -1;
    */
    var /*<@78>*/Direction = /*<@78>*/{};
    Direction.NONE = 0;
    Direction.FORWARD = 1;
    Direction.BACKWARD = -1;
    class /*<@80>*/BinaryConstraint extends Constraint {
        /**
         * Abstract superclass for constraints having two possible output
         * variables.
         */
        constructor(/*<@25>*/var1, /*<@25>*/var2, /*<@12>*/strength, /*<@25>*/scale, /*<@25>*/offset) {
            super(strength);
            this.v1 = var1;
            this.v2 = var2;
            this.direction = Direction.NONE;
            this.scale = scale;
            this.offset = offset;
            this.addConstraint();
        }
        // BinaryConstraint.inheritsFrom(Constraint);
        /**
         * Decides if this constraint can be satisfied and which way it
         * should flow based on the relative strength of the variables related,
         * and record that decision.
         */
        /*<@81>*/chooseMethod(/*<@5>*/mark) {
            if (this.v1.mark == mark) {
                this.direction = (this.v2.mark != mark && Strength.stronger(this.strength, this.v2.walkStrength))
                    ? Direction.FORWARD
                    : Direction.NONE;
            }
            if (this.v2.mark == mark) {
                this.direction = (this.v1.mark != mark && Strength.stronger(this.strength, this.v1.walkStrength))
                    ? Direction.BACKWARD
                    : Direction.NONE;
            }
            if (Strength.weaker(this.v1.walkStrength, this.v2.walkStrength)) {
                this.direction = Strength.stronger(this.strength, this.v1.walkStrength)
                    ? Direction.BACKWARD
                    : Direction.NONE;
            }
            else {
                this.direction = Strength.stronger(this.strength, this.v2.walkStrength)
                    ? Direction.FORWARD
                    : Direction.BACKWARD;
            }
        }
        /**
         * Add this constraint to the constraint graph
         */
        /*<@82>*/addToGraph() {
            this.v1.addConstraint(this);
            this.v2.addConstraint(this);
            this.direction = Direction.NONE;
        }
        /**
         * Answer true if this constraint is satisfied in the current solution.
         */
        /*<@83>*/isSatisfied() {
            return this.direction != Direction.NONE;
        }
        /**
         * Mark the input variable with the given mark.
         */
        /*<@84>*/markInputs(/*<@5>*/mark) {
            this.input().mark = mark;
        }
        /**
         * Returns the current input variable
         */
        /*<@85>*/input() {
            return (this.direction == Direction.FORWARD) ? this.v1 : this.v2;
        }
        /**
         * Returns the current output variable
         */
        /*<@86>*/output() {
            return (this.direction == Direction.FORWARD) ? this.v2 : this.v1;
        }
        /**
         * Calculate the walkabout strength, the stay flag, and, if it is
         * 'stay', the value for the current output of this
         * constraint. Assume this constraint is satisfied.
         */
        /*<@87>*/recalculate() {
            var /*<@25>*/ihn = this.input(), /*<@25>*/out = this.output();
            out.walkStrength = Strength.weakestOf(this.strength, ihn.walkStrength);
            out.stay = ihn.stay;
            if (out.stay) {
                this.execute();
            }
        }
        /**
         * Record the fact that this constraint is unsatisfied.
         */
        /*<@88>*/markUnsatisfied() {
            this.direction = Direction.NONE;
        }
        /*<@89>*/inputsKnown(/*<@5>*/mark) {
            var /*<@25>*/i = this.input();
            return i.mark == mark || i.stay || i.determinedBy == null;
        }
        /*<@90>*/removeFromGraph() {
            if (this.v1 != null)
                this.v1.removeConstraint(this);
            if (this.v2 != null)
                this.v2.removeConstraint(this);
            this.direction = Direction.NONE;
        }
    }
    /* --- *
     * S c a l e   C o n s t r a i n t
     * --- */
    class /*<@92>*/ScaleConstraint extends BinaryConstraint {
        /**
         * Relates two variables by the linear scaling relationship: "v2 =
         * (v1 * scale) + offset". Either v1 or v2 may be changed to maintain
         * this relationship but the scale factor and offset are considered
         * read-only.
         */
        constructor(/*<@25>*/src, /*<@25>*/scale, /*<@25>*/offset, /*<@25>*/dest, /*<@12>*/strength) {
            super(src, dest, strength, scale, offset);
            //this.direction = Direction.NONE;
            //this.scale = scale;
            //this.offset = offset;
        }
        // ScaleConstraint.inheritsFrom(BinaryConstraint);
        /**
         * Adds this constraint to the constraint graph.
         */
        /*<@93>*/addToGraph() {
            super.addToGraph();
            this.scale.addConstraint(this);
            this.offset.addConstraint(this);
        }
        /*<@94>*/removeFromGraph() {
            super.removeFromGraph();
            if (this.scale != null)
                this.scale.removeConstraint(this);
            if (this.offset != null)
                this.offset.removeConstraint(this);
        }
        /*<@95>*/markInputs(/*<@5>*/mark) {
            super.markInputs(mark);
            this.scale.mark = this.offset.mark = mark;
        }
        /**
         * Enforce this constraint. Assume that it is satisfied.
         */
        /*<@96>*/execute() {
            if (this.direction == Direction.FORWARD) {
                this.v2.value = this.v1.value * this.scale.value + this.offset.value;
            }
            else {
                this.v1.value = ((this.v2.value - this.offset.value) / this.scale.value);
            }
        }
        /**
         * Calculate the walkabout strength, the stay flag, and, if it is
         * 'stay', the value for the current output of this constraint. Assume
         * this constraint is satisfied.
         */
        /*<@97>*/recalculate() {
            var /*<@25>*/ihn = this.input(), /*<@25>*/out = this.output();
            out.walkStrength = Strength.weakestOf(this.strength, ihn.walkStrength);
            out.stay = ihn.stay && this.scale.stay && this.offset.stay;
            if (out.stay)
                this.execute();
        }
    }
    /* --- *
     * E q u a l i t  y   C o n s t r a i n t
     * --- */
    class /*<@99>*/EqualityConstraint extends BinaryConstraint {
        /**
         * Constrains two variables to have the same value.
         */
        constructor(/*<@25>*/var1, /*<@25>*/var2, /*<@12>*/strength) {
            super(var1, var2, strength);
        }
        // EqualityConstraint.inheritsFrom(BinaryConstraint);
        /**
         * Enforce this constraint. Assume that it is satisfied.
         */
        /*<@100>*/execute() {
            this.output().value = this.input().value;
        }
    }
    /* --- *
     * V a r i a b l e
     * --- */
    class /*<@26>*/Variable {
        /**
         * A constrained variable. In addition to its value, it maintain the
         * structure of the constraint graph, the current dataflow graph, and
         * various parameters of interest to the DeltaBlue incremental
         * constraint solver.
         **/
        constructor(/*<@3>*/name, /*<@5>*/initialValue) {
            this.value = initialValue || 0;
            this.constraints = new OrderedCollection();
            this.determinedBy = null;
            this.mark = 0;
            this.walkStrength = Strength.WEAKEST;
            this.stay = true;
            this.name = name;
        }
        /**
         * Add the given constraint to the set of all constraints that refer
         * this variable.
         */
        /*<@37>*/addConstraint(/*<@10>*/c) {
            this.constraints.add(c);
        }
        /**
         * Removes all traces of c from this variable.
         */
        /*<@38>*/removeConstraint(/*<@10>*/c) {
            this.constraints.remove(c);
            if (this.determinedBy == c)
                this.determinedBy = null;
        }
    }
    /* --- *
     * P l a n n e r
     * --- */
    class /*<@8>*/Planner {
        /**
         * The DeltaBlue planner
         */
        constructor() {
            this.currentMark = 0;
        }
        /**
         * Attempt to satisfy the given constraint and, if successful,
         * incrementally update the dataflow graph.  Details: If satifying
         * the constraint is successful, it may override a weaker constraint
         * on its output. The algorithm attempts to resatisfy that
         * constraint using some other method. This process is repeated
         * until either a) it reaches a variable that was not previously
         * determined by any constraint or b) it reaches a constraint that
         * is too weak to be satisfied using any of its methods. The
         * variables of constraints that have been processed are marked with
         * a unique mark value so that we know where we've been. This allows
         * the algorithm to avoid getting into an infinite loop even if the
         * constraint graph has an inadvertent cycle.
         */
        /*<@9>*/incrementalAdd(/*<@10>*/c) {
            var /*<@5>*/mark = this.newMark();
            var /*<@10>*/overridden = c.satisfy(mark);
            while (overridden != null)
                overridden = overridden.satisfy(mark);
        }
        /**
         * Entry point for retracting a constraint. Remove the given
         * constraint and incrementally update the dataflow graph.
         * Details: Retracting the given constraint may allow some currently
         * unsatisfiable downstream constraint to be satisfied. We therefore collect
         * a list of unsatisfied downstream constraints and attempt to
         * satisfy each one in turn. This list is traversed by constraint
         * strength, strongest first, as a heuristic for avoiding
         * unnecessarily adding and then overriding weak constraints.
         * Assume: c is satisfied.
         */
        /*<@47>*/incrementalRemove(/*<@10>*/c) {
            var /*<@25>*/out = c.output();
            c.markUnsatisfied();
            c.removeFromGraph();
            var /*<@27>*/unsatisfied = this.removePropagateFrom(out);
            var /*<@12>*/strength = Strength.REQUIRED;
            do {
                for (var /*<@5>*/i = 0; i < unsatisfied.size(); i++) {
                    var /*<@10>*/u = unsatisfied.at(i);
                    if (u.strength == strength)
                        this.incrementalAdd(u);
                }
                strength = strength.nextWeaker();
            } while (strength != Strength.WEAKEST);
        }
        /**
         * Select a previously unused mark value.
         */
        /*<@48>*/newMark() {
            return ++this.currentMark;
        }
        /**
         * Extract a plan for resatisfaction starting from the given source
         * constraints, usually a set of input constraints. This method
         * assumes that stay optimization is desired; the plan will contain
         * only constraints whose output variables are not stay. Constraints
         * that do no computation, such as stay and edit constraints, are
         * not included in the plan.
         * Details: The outputs of a constraint are marked when it is added
         * to the plan under construction. A constraint may be appended to
         * the plan when all its input variables are known. A variable is
         * known if either a) the variable is marked (indicating that has
         * been computed by a constraint appearing earlier in the plan), b)
         * the variable is 'stay' (i.e. it is a constant at plan execution
         * time), or c) the variable is not determined by any
         * constraint. The last provision is for past states of history
         * variables, which are not stay but which are also not computed by
         * any constraint.
         * Assume: sources are all satisfied.
         */
        /*<@49>*/makePlan(/*<@27>*/sources) {
            var /*<@5>*/mark = this.newMark();
            var /*<@50>*/plan = new Plan();
            var /*<@27>*/todo = sources;
            while (todo.size() > 0) {
                var /*<@10>*/c = todo.removeFirst();
                var /*<@25>*/v = c.output();
                if (v.mark != mark && c.inputsKnown(mark)) {
                    plan.addConstraint(c);
                    v.mark = mark;
                    this.addConstraintsConsumingTo(v, todo);
                }
            }
            return plan;
        }
        /**
         * Extract a plan for resatisfying starting from the output of the
         * given constraints, usually a set of input constraints.
         */
        /*<@56>*/extractPlanFromConstraints(/*<@27>*/constraints) {
            var /*<@27>*/sources = new OrderedCollection();
            for (var /*<@5>*/i = 0; i < constraints.size(); i++) {
                var /*<@10>*/c = constraints.at(i);
                if (c.isInput() && c.isSatisfied())
                    // not in plan already and eligible for inclusion
                    sources.add(c);
            }
            return this.makePlan(sources);
        }
        /**
         * Recompute the walkabout strengths and stay flags of all variables
         * downstream of the given constraint and recompute the actual
         * values of all variables whose stay flag is true. If a cycle is
         * detected, remove the given constraint and answer
         * false. Otherwise, answer true.
         * Details: Cycles are detected when a marked variable is
         * encountered downstream of the given constraint. The sender is
         * assumed to have marked the inputs of the given constraint with
         * the given mark. Thus, encountering a marked node downstream of
         * the output constraint means that there is a path from the
         * constraint's output to one of its inputs.
         */
        /*<@57>*/addPropagate(/*<@10>*/c, /*<@5>*/mark) {
            var /*<@27>*/todo = new OrderedCollection();
            todo.add(c);
            while (todo.size() > 0) {
                var /*<@10>*/d = todo.removeFirst();
                var /*<@25>*/v = d.output();
                if (v.mark == mark) {
                    this.incrementalRemove(/*<@74>*/c);
                    return false;
                }
                d.recalculate();
                this.addConstraintsConsumingTo(v, todo);
            }
            return true;
        }
        /**
         * Update the walkabout strengths and stay flags of all variables
         * downstream of the given constraint. Answer a collection of
         * unsatisfied constraints sorted in order of decreasing strength.
         */
        /*<@58>*/removePropagateFrom(/*<@25>*/out) {
            out.determinedBy = null;
            out.walkStrength = Strength.WEAKEST;
            out.stay = true;
            var /*<@27>*/unsatisfied = new OrderedCollection();
            var /*<@27>*/todo = new OrderedCollection();
            todo.add(out);
            while (todo.size() > 0) {
                var /*<@25>*/v = todo.removeFirst();
                for (var /*<@5>*/i = 0; i < v.constraints.size(); i++) {
                    var /*<@10>*/c = v.constraints.at(i);
                    if (!c.isSatisfied())
                        unsatisfied.add(c);
                }
                var /*<@36>*/determining = v.determinedBy;
                for (var /*<@5>*/i = 0; i < v.constraints.size(); i++) {
                    var /*<@10>*/next = v.constraints.at(i);
                    if (next != determining && next.isSatisfied()) {
                        next.recalculate();
                        todo.add(next.output());
                    }
                }
            }
            return unsatisfied;
        }
        /*<@59>*/addConstraintsConsumingTo(/*<@25>*/v, /*<@27>*/coll) {
            var /*<@10>*/determining = v.determinedBy;
            var /*<@27>*/cc = v.constraints;
            for (var /*<@5>*/i = 0; i < cc.size(); i++) {
                var /*<@10>*/c = cc.at(i);
                if (c != determining && c.isSatisfied())
                    coll.add(c);
            }
        }
    }
    /* --- *
     * P l a n
     * --- */
    class /*<@51>*/Plan {
        /**
         * A Plan is an ordered list of constraints to be executed in sequence
         * to resatisfy all currently satisfiable constraints in the face of
         * one or more changing inputs.
         */
        constructor() {
            this.v = new OrderedCollection();
        }
        /*<@52>*/addConstraint(/*<@10>*/c) {
            this.v.add(c);
        }
        /*<@53>*/size() {
            return this.v.size();
        }
        /*<@54>*/constraintAt(/*<@5>*/index) {
            return this.v.at(index);
        }
        /*<@55>*/execute() {
            for (var /*<@5>*/i = 0; i < this.size(); i++) {
                var /*<@10>*/c = this.constraintAt(i);
                c.execute();
            }
        }
    }
    /* --- *
     * M a i n
     * --- */
    /**
     * This is the standard DeltaBlue benchmark. A long chain of equality
     * constraints is constructed with a stay constraint on one end. An
     * edit constraint is then added to the opposite end and the time is
     * measured for adding and removing this constraint, and extracting
     * and executing a constraint satisfaction plan. There are two cases.
     * In case 1, the added constraint is stronger than the stay
     * constraint and values must propagate down the entire length of the
     * chain. In case 2, the added constraint is weaker than the stay
     * constraint so it cannot be accomodated. The cost in this case is,
     * of course, very low. Typical situations lie somewhere between these
     * two extremes.
     */
    function /*<@101>*/chainTest(/*<@5>*/n) {
        planner = new Planner();
        var /*<@25>*/prev = null, /*<@25>*/first = null, /*<@25>*/last = null;
        // Build chain of n equality constraints
        for (var /*<@5>*/i = 0; i <= n; i++) {
            var /*<@3>*/name = "v" + i;
            var /*<@25>*/v = new Variable(name);
            if (prev != null)
                new EqualityConstraint(prev, v, Strength.REQUIRED);
            if (i == 0)
                first = v;
            if (i == n)
                last = v;
            prev = v;
        }
        new StayConstraint(last, Strength.STRONG_DEFAULT);
        var /*<@74>*/edit = new EditConstraint(first, Strength.PREFERRED);
        var /*<@27>*/edits = new OrderedCollection();
        edits.add(edit);
        var /*<@50>*/plan = planner.extractPlanFromConstraints(edits);
        for (var /*<@5>*/i = 0; i < 100; i++) {
            first.value = i;
            plan.execute();
            if (last.value != i)
                alert("Chain test failed.");
        }
    }
    function /*<@102>*/change(/*<@25>*/v, /*<@5>*/newValue) {
        var /*<@74>*/edit = new EditConstraint(v, Strength.PREFERRED);
        var /*<@27>*/edits = new OrderedCollection();
        edits.add(edit);
        var /*<@50>*/plan = planner.extractPlanFromConstraints(edits);
        for (var /*<@5>*/i = 0; i < 10; i++) {
            v.value = newValue;
            plan.execute();
        }
        edit.destroyConstraint();
    }
    /**
     * This test constructs a two sets of variables related to each
     * other by a simple linear transformation (scale and offset). The
     * time is measured to change a variable on either side of the
     * mapping and to change the scale and offset factors.
     */
    function /*<@103>*/projectionTest(/*<@5>*/n) {
        planner = new Planner();
        var /*<@25>*/scale = new Variable("scale", 10);
        var /*<@25>*/offset = new Variable("offset", 1000);
        let /*<@25>*/src = null, /*<@25>*/dst = null;
        var /*<@27>*/dests = new OrderedCollection();
        for (var /*<@5>*/i = 0; i < n; i++) {
            src = new Variable("src" + i, i);
            dst = new Variable("dst" + i, i);
            dests.add(dst);
            new StayConstraint(src, Strength.NORMAL);
            new ScaleConstraint(src, scale, offset, dst, Strength.REQUIRED);
        }
        change(src, 17);
        if (dst.value != 1170)
            alert("Projection 1 failed");
        change(dst, 1050);
        if (src.value != 5)
            alert("Projection 2 failed");
        change(scale, 5);
        for (var /*<@5>*/i = 0; i < n - 1; i++) {
            let /*<@25>*/c = dests.at(i);
            if (c.value != i * 5 + 1000)
                alert("Projection 3 failed");
        }
        change(offset, 2000);
        for (var /*<@5>*/i = 0; i < n - 1; i++) {
            let /*<@25>*/c = dests.at(i);
            if (c.value != i * 5 + 2000)
                alert("Projection 4 failed");
        }
    }
    function /*<@104>*/deltaBlue() {
        chainTest(100);
        projectionTest(100);
    }
    deltablue.deltaBlue = deltaBlue;
})(deltablue || (deltablue = {}));
let /*<@1>*/worst4;
let /*<@1>*/average;
let /*<@1>*/firstIteration;
let /*<@1>*/total;
function /*<@106>*/summation(/*<@108>*/values) {
    assert(values instanceof Array);
    let /*<@5>*/sum = 0;
    for (let /*<@107>*/x of values)
        sum = sum + /*<@1>*/x;
    return sum;
}
function /*<@109>*/toScore(/*<@107>*/timeValue) {
    return /*<@1>*/timeValue;
}
function /*<@110>*/mean(/*<@108>*/values) {
    assert(values instanceof Array);
    let /*<@1>*/sum = 0;
    for (let /*<@107>*/x of values)
        sum = sum + /*<@1>*/x;
    return sum / values.length;
}
function /*<@111>*/assert(/*<@2>*/condition) {
    if (!condition) {
        throw new Error("assert false");
    }
}
function /*<@112>*/processResults(/*<@108>*/results) {
    function /*<@113>*/copyArray(/*<@108>*/a) {
        let /*<@114>*/result = /*<@114>*/[];
        for (let /*<@107>*/x of a)
            result.push(x);
        return result;
    }
    results = copyArray(results);
    firstIteration = toScore(results[0]);
    total = summation(results);
    // results = results.slice(1);
    results.sort(/*<@115>*/(/*<@107>*/a, /*<@107>*/b) => a < b ? 1 : -1);
    for (let /*<@5>*/i = 0; i + 1 < results.length; ++i)
        assert(results[i] >= results[i + 1]);
    let /*<@108>*/worstCase = /*<@108>*/[];
    for (let /*<@5>*/i = 0; i < 4; ++i)
        worstCase.push(results[i]);
    worst4 = toScore(mean(worstCase));
    average = toScore(mean(results));
}
function /*<@116>*/printScore() {
    // print("First: " + firstIteration);
    // print("worst4: " + worst4);
    print("average: " + average);
    // print("total: " + total);
}
class /*<@118>*/Benchmark {
    /*<@119>*/runIteration() {
        deltablue.deltaBlue();
    }
}
function /*<@120>*/main() {
    let /*<@117>*/__benchmark = new Benchmark();
    let /*<@114>*/results = /*<@114>*/[];
    for (let /*<@5>*/i = 0; i < 60; i++) {
        let /*<@1>*/start = performance.now();
        __benchmark.runIteration();
        let /*<@1>*/end = performance.now();
        results.push(end - start);
    }
    processResults(results);
    printScore();
}
main();
