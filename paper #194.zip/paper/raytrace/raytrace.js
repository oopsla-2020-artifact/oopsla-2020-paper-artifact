/*<@type>{
    "header": {
        "version": "3.0.1",
        "filename": "raytrace.js",
        "sound": 1
    },
    "types": [
        "any",
        "number",
        "boolean",
        "string",
        "void",
        "int",
        "object",
        {
            "index": 7,
            "fname": "objectExtend",
            "params": {
                "destination": 8,
                "source": 8
            },
            "ret": 8
        },
        {
            "index": 8,
            "cname": "EngineOption",
            "fields": {
                "canvasHeight": -1,
                "canvasWidth": -1,
                "pixelWidth": -1,
                "pixelHeight": -1,
                "renderDiffuse": -2,
                "renderShadows": -2,
                "renderHighlights": -2,
                "renderReflections": -2,
                "rayDepth": -5
            },
            "methods": [
                9
            ]
        },
        {
            "index": 9,
            "fname": "constructor",
            "params": {
                "canvasHeight": 5,
                "canvasWidth": 5,
                "pixelWidth": 5,
                "pixelHeight": 5,
                "renderDiffuse": 2,
                "renderShadows": 2,
                "renderHighlights": 2,
                "renderReflections": 2,
                "rayDepth": 5
            },
            "ret": 8
        },
        {
            "index": 10,
            "cname": "Canvas",
            "fields": {
                "fillStyle": 3,
                "fillRect": 12,
                "getContext": 12
            },
            "methods": [
                11
            ]
        },
        {
            "index": 11,
            "fname": "constructor",
            "ret": 10
        },
        {
            "index": 12,
            "bname": "Function"
        },
        {
            "index": 13,
            "cname": "Color",
            "fields": {
                "red": -1,
                "green": -1,
                "blue": -1
            },
            "sfields": {
                "const add": 15,
                "const addScalar": 16,
                "const multiply": 18,
                "const multiplyScalar": 19,
                "const blend": 23
            },
            "methods": [
                14,
                17,
                20,
                21,
                22,
                24,
                25
            ]
        },
        {
            "index": 14,
            "fname": "constructor",
            "params": {
                "r": 1,
                "g": 1,
                "b": 1
            },
            "ret": 13
        },
        {
            "index": 15,
            "fname": "static add",
            "params": {
                "c1": 13,
                "c2": 13
            },
            "ret": 13
        },
        {
            "index": 16,
            "fname": "static addScalar",
            "params": {
                "c1": 13,
                "s": 1
            },
            "ret": 13
        },
        {
            "index": 17,
            "fname": "subtract",
            "private": 1,
            "params": {
                "c1": 13,
                "c2": 13
            },
            "ret": 13
        },
        {
            "index": 18,
            "fname": "static multiply",
            "params": {
                "c1": 13,
                "c2": 13
            },
            "ret": 13
        },
        {
            "index": 19,
            "fname": "static multiplyScalar",
            "params": {
                "c1": 13,
                "f": 1
            },
            "ret": 13
        },
        {
            "index": 20,
            "fname": "divideFactor",
            "private": 1,
            "params": {
                "c1": 13,
                "f": 1
            },
            "ret": 13
        },
        {
            "index": 21,
            "fname": "limit"
        },
        {
            "index": 22,
            "fname": "distance",
            "private": 1,
            "params": {
                "color": 13
            },
            "ret": 1
        },
        {
            "index": 23,
            "fname": "static blend",
            "params": {
                "c1": 13,
                "c2": 13,
                "w": 1
            },
            "ret": 13
        },
        {
            "index": 24,
            "fname": "brightness",
            "ret": 1
        },
        {
            "index": 25,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 26,
            "cname": "Light",
            "fields": {
                "position": -28,
                "color": -13,
                "intensity": -1
            },
            "methods": [
                27,
                40
            ]
        },
        {
            "index": 27,
            "fname": "constructor",
            "params": {
                "pos": 28,
                "color": 13,
                "intensity": 1
            },
            "ret": 26
        },
        {
            "index": 28,
            "cname": "Vector",
            "fields": {
                "x": -1,
                "y": -1,
                "z": -1
            },
            "sfields": {
                "const add": 35,
                "const subtract": 36,
                "const multiplyVector": 37,
                "const multiplyScalar": 38
            },
            "methods": [
                29,
                30,
                31,
                32,
                33,
                34,
                39
            ]
        },
        {
            "index": 29,
            "fname": "constructor",
            "params": {
                "x": 1,
                "y": 1,
                "z": 1
            },
            "ret": 28
        },
        {
            "index": 30,
            "fname": "copy",
            "private": 1,
            "params": {
                "vector": 28
            }
        },
        {
            "index": 31,
            "fname": "normalize",
            "ret": 28
        },
        {
            "index": 32,
            "fname": "magnitude",
            "private": 1,
            "ret": 1
        },
        {
            "index": 33,
            "fname": "cross",
            "params": {
                "w": 28
            },
            "ret": 28
        },
        {
            "index": 34,
            "fname": "dot",
            "params": {
                "w": 28
            },
            "ret": 1
        },
        {
            "index": 35,
            "fname": "static add",
            "params": {
                "v": 28,
                "w": 28
            },
            "ret": 28
        },
        {
            "index": 36,
            "fname": "static subtract",
            "params": {
                "v": 28,
                "w": 28
            },
            "ret": 28
        },
        {
            "index": 37,
            "fname": "static multiplyVector",
            "params": {
                "v": 28,
                "w": 28
            },
            "ret": 28
        },
        {
            "index": 38,
            "fname": "static multiplyScalar",
            "params": {
                "v": 28,
                "w": 1
            },
            "ret": 28
        },
        {
            "index": 39,
            "fname": "toString",
            "private": 1,
            "ret": 3
        },
        {
            "index": 40,
            "fname": "toString",
            "private": 1,
            "ret": 3
        },
        {
            "index": 41,
            "cname": "Ray",
            "fields": {
                "position": -28,
                "direction": -28
            },
            "methods": [
                42,
                43
            ]
        },
        {
            "index": 42,
            "fname": "constructor",
            "params": {
                "pos": 28,
                "dir": 28
            },
            "ret": 41
        },
        {
            "index": 43,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 44,
            "cname": "Scene",
            "fields": {
                "camera": -46,
                "shapes": -70,
                "lights": -71,
                "background": -72
            },
            "methods": [
                45
            ]
        },
        {
            "index": 45,
            "fname": "constructor",
            "ret": 44
        },
        {
            "index": 46,
            "cname": "Camera",
            "fields": {
                "position": -28,
                "lookAt": -28,
                "equator": -28,
                "up": -28,
                "screen": -28
            },
            "methods": [
                47,
                48,
                49
            ]
        },
        {
            "index": 47,
            "fname": "constructor",
            "params": {
                "pos": 28,
                "lookAt": 28,
                "up": 28
            },
            "ret": 46
        },
        {
            "index": 48,
            "fname": "getRay",
            "params": {
                "vx": 1,
                "vy": 1
            },
            "ret": 41
        },
        {
            "index": 49,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 50,
            "cname": "Shape",
            "fields": {
                "position": -28,
                "material": -65
            },
            "methods": [
                51,
                66
            ]
        },
        {
            "index": 51,
            "fname": "constructor",
            "ret": 50
        },
        {
            "index": 52,
            "cname": "Solid",
            "supers": {
                "BaseMaterial": 57
            },
            "fields": {
                "color": -13
            },
            "methods": [
                53,
                54,
                55
            ]
        },
        {
            "index": 53,
            "fname": "constructor",
            "params": {
                "color": 13,
                "reflection": 1,
                "refraction": 1,
                "transparency": 1,
                "gloss": 1
            },
            "ret": 52,
            "hobj": 1
        },
        {
            "index": 54,
            "fname": "getColor",
            "params": {
                "u": 1,
                "v": 1
            },
            "ret": 13
        },
        {
            "index": 55,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 56,
            "cname": "BaseMaterial",
            "fields": {
                "gloss": -1,
                "transparency": -1,
                "reflection": -1,
                "refraction": -1,
                "hasTexture": -2
            },
            "methods": [
                57,
                58,
                59,
                60
            ]
        },
        {
            "index": 57,
            "fname": "constructor",
            "ret": 56
        },
        {
            "index": 58,
            "fname": "getColor",
            "params": {
                "u": 1,
                "v": 1
            },
            "ret": 13
        },
        {
            "index": 59,
            "fname": "wrapUp",
            "params": {
                "t": 1
            },
            "ret": 1
        },
        {
            "index": 60,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 61,
            "cname": "Chessboard",
            "supers": {
                "BaseMaterial": 57
            },
            "fields": {
                "colorEven": -13,
                "colorOdd": -13,
                "density": -1
            },
            "methods": [
                62,
                63,
                64
            ]
        },
        {
            "index": 62,
            "fname": "constructor",
            "params": {
                "colorEven": 13,
                "colorOdd": 13,
                "reflection": 1,
                "transparency": 1,
                "gloss": 1,
                "density": 1
            },
            "ret": 61,
            "hobj": 1
        },
        {
            "index": 63,
            "fname": "getColor",
            "params": {
                "u": 1,
                "v": 1
            },
            "ret": 13
        },
        {
            "index": 64,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 65,
            "uname": "",
            "types": [
                52,
                61
            ]
        },
        {
            "index": 66,
            "fname": "intersect",
            "params": {
                "ray": 41
            },
            "ret": 67
        },
        {
            "index": 67,
            "cname": "IntersectionInfo",
            "fields": {
                "isHit": -2,
                "hitCount": -5,
                "shape": 50,
                "position": -28,
                "normal": -28,
                "color": -13,
                "distance": -1
            },
            "methods": [
                68,
                69
            ]
        },
        {
            "index": 68,
            "fname": "constructor",
            "ret": 67
        },
        {
            "index": 69,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 70,
            "aname": "",
            "element": 50,
            "mode": "normal"
        },
        {
            "index": 71,
            "aname": "",
            "element": 26,
            "mode": "normal"
        },
        {
            "index": 72,
            "cname": "Background",
            "fields": {
                "color": -13,
                "ambience": -1
            },
            "methods": [
                73
            ]
        },
        {
            "index": 73,
            "fname": "constructor",
            "params": {
                "color": 13,
                "ambience": 1
            },
            "ret": 72
        },
        {
            "index": 74,
            "cname": "Sphere",
            "supers": {
                "Shape": 51
            },
            "fields": {
                "radius": -1
            },
            "methods": [
                75,
                76,
                77
            ]
        },
        {
            "index": 75,
            "fname": "constructor",
            "params": {
                "pos": 28,
                "radius": 1,
                "material": 52
            },
            "ret": 74,
            "hobj": 1
        },
        {
            "index": 76,
            "fname": "intersect",
            "params": {
                "ray": 41
            },
            "ret": 67
        },
        {
            "index": 77,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 78,
            "cname": "Plane",
            "supers": {
                "Shape": 51
            },
            "fields": {
                "d": -1
            },
            "methods": [
                79,
                80,
                81
            ]
        },
        {
            "index": 79,
            "fname": "constructor",
            "params": {
                "pos": 28,
                "d": 1,
                "material": 61
            },
            "ret": 78,
            "hobj": 1
        },
        {
            "index": 80,
            "fname": "intersect",
            "params": {
                "ray": 41
            },
            "ret": 67
        },
        {
            "index": 81,
            "fname": "toString",
            "ret": 3
        },
        {
            "index": 82,
            "cname": "Engine",
            "fields": {
                "canvas": 10,
                "options": -8
            },
            "methods": [
                83,
                84,
                85,
                86,
                87,
                88,
                89
            ]
        },
        {
            "index": 83,
            "fname": "constructor",
            "params": {
                "options": 8
            },
            "ret": 82
        },
        {
            "index": 84,
            "fname": "setPixel",
            "private": 1,
            "params": {
                "x": 5,
                "y": 5,
                "color": 13
            }
        },
        {
            "index": 85,
            "fname": "renderScene",
            "params": {
                "scene": 44,
                "canvas": 10,
                "tmp": 1
            }
        },
        {
            "index": 86,
            "fname": "getPixelColor",
            "private": 1,
            "params": {
                "ray": 41,
                "scene": 44
            },
            "ret": 13
        },
        {
            "index": 87,
            "fname": "testIntersection",
            "private": 1,
            "params": {
                "ray": 41,
                "scene": 44,
                "exclude": 50
            },
            "ret": 67
        },
        {
            "index": 88,
            "fname": "getReflectionRay",
            "private": 1,
            "params": {
                "P": 28,
                "N": 28,
                "V": 28
            },
            "ret": 41
        },
        {
            "index": 89,
            "fname": "rayTrace",
            "private": 1,
            "params": {
                "info": 67,
                "ray": 41,
                "scene": 44,
                "depth": 1
            },
            "ret": 13
        },
        {
            "index": 90,
            "fname": "renderScene"
        },
        {
            "index": 91,
            "aname": "",
            "element": 3,
            "mode": "normal"
        },
        {
            "index": 92,
            "fname": "static now",
            "ret": 1
        },
        {
            "index": 93,
            "fname": "summation",
            "params": {
                "values": 95
            },
            "ret": 5
        },
        {
            "index": 94,
            "bname": "Object"
        },
        {
            "index": 95,
            "aname": "",
            "element": 94,
            "mode": "normal"
        },
        {
            "index": 96,
            "fname": "toScore",
            "params": {
                "timeValue": 94
            },
            "ret": 1
        },
        {
            "index": 97,
            "fname": "mean",
            "params": {
                "values": 95
            },
            "ret": 1
        },
        {
            "index": 98,
            "fname": "assert",
            "params": {
                "condition": 2
            }
        },
        {
            "index": 99,
            "fname": "processResults",
            "params": {
                "results": 95
            }
        },
        {
            "index": 100,
            "fname": "copyArray",
            "params": {
                "a": 95
            },
            "ret": 95
        },
        {
            "index": 101,
            "aname": "",
            "element": 0,
            "mode": "normal"
        },
        {
            "index": 102,
            "fname": "",
            "params": {
                "a": 94,
                "b": 94
            },
            "ret": 5
        },
        {
            "index": 103,
            "fname": "printScore"
        },
        {
            "index": 104,
            "cname": "Benchmark",
            "methods": [
                105,
                106
            ]
        },
        {
            "index": 105,
            "fname": "constructor",
            "ret": 104
        },
        {
            "index": 106,
            "fname": "runIteration"
        },
        {
            "index": 107,
            "fname": "main"
        }
    ]
}*/
"use strict";
// The ray tracer code in this file is written by Adam Burmister. It
// is available in its original form from:
//
//   http://labs.flog.nz.co/raytracer/
//
// It has been modified slightly by Google to work as a standalone
// benchmark, but the all the computational code remains
// untouched. This file also contains a copy of parts of the Prototype
// JavaScript framework which is used by the ray tracer.
var rt;
(function (rt) {
    // Variable used to hold a number that can be used to verify that
    // the scene was ray traced correctly.
    var /*<@1>*/checkNumber;
    // ------------------------------------------------------------------------
    // ------------------------------------------------------------------------
    // The following is a copy of parts of the Prototype JavaScript library:
    // Prototype JavaScript framework, version 1.5.0
    // (c) 2005-2007 Sam Stephenson
    //
    // Prototype is freely distributable under the terms of an MIT-style license.
    // For details, see the Prototype web site: http://prototype.conio.net/
    function /*<@7>*/objectExtend(/*<@8>*/destination, /*<@8>*/source) {
        destination.canvasHeight = source.canvasHeight;
        destination.canvasWidth = source.canvasWidth;
        destination.pixelHeight = source.pixelHeight;
        destination.pixelWidth = source.pixelWidth;
        destination.renderDiffuse = source.renderDiffuse;
        destination.renderShadows = source.renderShadows;
        destination.renderHighlights = source.renderHighlights;
        destination.renderReflections = source.renderReflections;
        destination.rayDepth = source.rayDepth;
        return destination;
    }
    ;
    class /*<@9>*/EngineOption {
        constructor(/*<@5>*/canvasHeight, /*<@5>*/canvasWidth, /*<@5>*/pixelWidth, /*<@5>*/pixelHeight, /*<@2>*/renderDiffuse, /*<@2>*/renderShadows, /*<@2>*/renderHighlights, /*<@2>*/renderReflections, /*<@5>*/rayDepth) {
            this.canvasHeight = canvasHeight;
            this.canvasWidth = canvasWidth;
            this.pixelWidth = pixelWidth;
            this.pixelHeight = pixelHeight;
            this.renderDiffuse = renderDiffuse;
            this.renderShadows = renderShadows;
            this.renderHighlights = renderHighlights;
            this.renderReflections = renderReflections;
            this.rayDepth = rayDepth;
        }
    }
    class /*<@11>*/Canvas {
    }
    // ------------------------------------------------------------------------
    // ------------------------------------------------------------------------
    // The rest of this file is the actual ray tracer written by Adam
    // Burmister. It's a concatenation of the following files:
    //
    //   flog/color.js
    //   flog/light.js
    //   flog/vector.js
    //   flog/ray.js
    //   flog/scene.js
    //   flog/material/basematerial.js
    //   flog/material/solid.js
    //   flog/material/chessboard.js
    //   flog/shape/baseshape.js
    //   flog/shape/sphere.js
    //   flog/shape/plane.js
    //   flog/intersectioninfo.js
    //   flog/camera.js
    //   flog/background.js
    //   flog/engine.js
    class /*<@14>*/Color {
        constructor(/*<@1>*/r, /*<@1>*/g, /*<@1>*/b) {
            this.red = 0.0;
            this.green = 0.0;
            this.blue = 0.0;
            if (!r)
                r = 0.0;
            if (!g)
                g = 0.0;
            if (!b)
                b = 0.0;
            this.red = r;
            this.green = g;
            this.blue = b;
        }
        static /*<@15>*/add(/*<@13>*/c1, /*<@13>*/c2) {
            var /*<@13>*/result = new Color(0, 0, 0);
            result.red = c1.red + c2.red;
            result.green = c1.green + c2.green;
            result.blue = c1.blue + c2.blue;
            return result;
        }
        static /*<@16>*/addScalar(/*<@13>*/c1, /*<@1>*/s) {
            var /*<@13>*/result = new Color(0, 0, 0);
            result.red = c1.red + s;
            result.green = c1.green + s;
            result.blue = c1.blue + s;
            result.limit();
            return result;
        }
        /*<@17>*/subtract(/*<@13>*/c1, /*<@13>*/c2) {
            var /*<@13>*/result = new Color(0, 0, 0);
            result.red = c1.red - c2.red;
            result.green = c1.green - c2.green;
            result.blue = c1.blue - c2.blue;
            return result;
        }
        static /*<@18>*/multiply(/*<@13>*/c1, /*<@13>*/c2) {
            var /*<@13>*/result = new Color(0, 0, 0);
            result.red = c1.red * c2.red;
            result.green = c1.green * c2.green;
            result.blue = c1.blue * c2.blue;
            return result;
        }
        static /*<@19>*/multiplyScalar(/*<@13>*/c1, /*<@1>*/f) {
            var /*<@13>*/result = new Color(0, 0, 0);
            result.red = c1.red * f;
            result.green = c1.green * f;
            result.blue = c1.blue * f;
            return result;
        }
        /*<@20>*/divideFactor(/*<@13>*/c1, /*<@1>*/f) {
            var /*<@13>*/result = new Color(0, 0, 0);
            result.red = c1.red / f;
            result.green = c1.green / f;
            result.blue = c1.blue / f;
            return result;
        }
        /*<@21>*/limit() {
            this.red = (this.red > 0.0) ? ((this.red > 1.0) ? 1.0 : this.red) : 0.0;
            this.green = (this.green > 0.0) ? ((this.green > 1.0) ? 1.0 : this.green) : 0.0;
            this.blue = (this.blue > 0.0) ? ((this.blue > 1.0) ? 1.0 : this.blue) : 0.0;
        }
        /*<@22>*/distance(/*<@13>*/color) {
            var /*<@1>*/d = Math.abs(this.red - color.red) + Math.abs(this.green - color.green) + Math.abs(this.blue - color.blue);
            return d;
        }
        static /*<@23>*/blend(/*<@13>*/c1, /*<@13>*/c2, /*<@1>*/w) {
            var /*<@13>*/result = new Color(0, 0, 0);
            result = Color.add(Color.multiplyScalar(c1, 1 - w), Color.multiplyScalar(c2, w));
            return result;
        }
        /*<@24>*/brightness() {
            var /*<@1>*/r = Math.floor(this.red * 255);
            var /*<@1>*/g = Math.floor(this.green * 255);
            var /*<@1>*/b = Math.floor(this.blue * 255);
            return (r * 77 + g * 150 + b * 29) >> 8;
        }
        /*<@25>*/toString() {
            var /*<@1>*/r = Math.floor(this.red * 255);
            var /*<@1>*/g = Math.floor(this.green * 255);
            var /*<@1>*/b = Math.floor(this.blue * 255);
            return "rgb(" + r + "," + g + "," + b + ")";
        }
    }
    class /*<@27>*/Light {
        constructor(/*<@28>*/pos, /*<@13>*/color, /*<@1>*/intensity) {
            this.intensity = 10.0;
            this.position = pos;
            this.color = color;
            this.intensity = (intensity ? intensity : 10.0);
        }
        /*<@40>*/toString() {
            return 'Light [' + this.position.x + ',' + this.position.y + ',' + this.position.z + ']';
        }
    }
    class /*<@29>*/Vector {
        constructor(/*<@1>*/x, /*<@1>*/y, /*<@1>*/z) {
            this.x = 0.0;
            this.y = 0.0;
            this.z = 0.0;
            this.x = (x ? x : 0);
            this.y = (y ? y : 0);
            this.z = (z ? z : 0);
        }
        /*<@30>*/copy(/*<@28>*/vector) {
            this.x = vector.x;
            this.y = vector.y;
            this.z = vector.z;
        }
        /*<@31>*/normalize() {
            var /*<@1>*/m = this.magnitude();
            return new Vector(this.x / m, this.y / m, this.z / m);
        }
        /*<@32>*/magnitude() {
            return Math.sqrt((this.x * this.x) + (this.y * this.y) + (this.z * this.z));
        }
        /*<@33>*/cross(/*<@28>*/w) {
            return new Vector(-this.z * w.y + this.y * w.z, this.z * w.x - this.x * w.z, -this.y * w.x + this.x * w.y);
        }
        /*<@34>*/dot(/*<@28>*/w) {
            return this.x * w.x + this.y * w.y + this.z * w.z;
        }
        static /*<@35>*/add(/*<@28>*/v, /*<@28>*/w) {
            return new Vector(w.x + v.x, w.y + v.y, w.z + v.z);
        }
        static /*<@36>*/subtract(/*<@28>*/v, /*<@28>*/w) {
            if (!w || !v)
                throw 'Vectors must be defined [' + v + ',' + w + ']';
            return new Vector(v.x - w.x, v.y - w.y, v.z - w.z);
        }
        static /*<@37>*/multiplyVector(/*<@28>*/v, /*<@28>*/w) {
            return new Vector(v.x * w.x, v.y * w.y, v.z * w.z);
        }
        static /*<@38>*/multiplyScalar(/*<@28>*/v, /*<@1>*/w) {
            return new Vector(v.x * w, v.y * w, v.z * w);
        }
        /*<@39>*/toString() {
            return 'Vector [' + this.x + ',' + this.y + ',' + this.z + ']';
        }
    }
    class /*<@42>*/Ray {
        constructor(/*<@28>*/pos, /*<@28>*/dir) {
            this.position = pos;
            this.direction = dir;
        }
        /*<@43>*/toString() {
            return 'Ray [' + this.position + ',' + this.direction + ']';
        }
    }
    class /*<@45>*/Scene {
        constructor() {
            this.camera = new Camera(new Vector(0, 0, -5), new Vector(0, 0, 1), new Vector(0, 1, 0));
            this.shapes = new /*<@70>*/Array();
            this.lights = new /*<@71>*/Array();
            this.background = new Background(new Color(0, 0, 0.5), 0.2);
        }
    }
    // namespace Material {
    class /*<@57>*/BaseMaterial {
        constructor() {
            this.gloss = 2.0; // [0...infinity] 0 = matt
            this.transparency = 0.0; // 0=opaque
            this.reflection = 0.0; // [0...infinity] 0 = no reflection
            this.refraction = 0.50;
            this.hasTexture = false;
        }
        /*<@58>*/getColor(/*<@1>*/u, /*<@1>*/v) {
            return undefined;
        }
        /*<@59>*/wrapUp(/*<@1>*/t) {
            t = t % 2.0;
            if (t < -1)
                t += 2.0;
            if (t >= 1)
                t -= 2.0;
            return t;
        }
        /*<@60>*/toString() {
            return 'Material [gloss=' + this.gloss + ', transparency=' + this.transparency + ', hasTexture=' + this.hasTexture + ']';
        }
    }
    class /*<@53>*/Solid extends BaseMaterial {
        constructor(/*<@13>*/color, /*<@1>*/reflection, /*<@1>*/refraction, /*<@1>*/transparency, /*<@1>*/gloss) {
            super();
            this.color = color;
            this.reflection = reflection;
            this.transparency = transparency;
            this.gloss = gloss;
            this.hasTexture = false;
        }
        /*<@54>*/getColor(/*<@1>*/u, /*<@1>*/v) {
            return this.color;
        }
        /*<@55>*/toString() {
            return 'SolidMaterial [gloss=' + this.gloss + ', transparency=' + this.transparency + ', hasTexture=' + this.hasTexture + ']';
        }
    }
    class /*<@62>*/Chessboard extends BaseMaterial {
        constructor(/*<@13>*/colorEven, /*<@13>*/colorOdd, /*<@1>*/reflection, /*<@1>*/transparency, /*<@1>*/gloss, /*<@1>*/density) {
            super();
            this.density = 0.5;
            this.colorEven = colorEven;
            this.colorOdd = colorOdd;
            this.reflection = reflection;
            this.transparency = transparency;
            this.gloss = gloss;
            this.density = density;
            this.hasTexture = true;
        }
        /*<@63>*/getColor(/*<@1>*/u, /*<@1>*/v) {
            var /*<@1>*/t = this.wrapUp(u * this.density) * this.wrapUp(v * this.density);
            if (t < 0.0)
                return this.colorEven;
            else
                return this.colorOdd;
        }
        /*<@64>*/toString() {
            return 'ChessMaterial [gloss=' + this.gloss + ', transparency=' + this.transparency + ', hasTexture=' + this.hasTexture + ']';
        }
    }
    // }
    // namespace Shape {
    class /*<@51>*/Shape {
        /*<@66>*/intersect(/*<@41>*/ray) {
            return undefined;
        }
    }
    class /*<@75>*/Sphere extends Shape {
        constructor(/*<@28>*/pos, /*<@1>*/radius, /*<@52>*/material) {
            super();
            this.radius = radius;
            this.position = pos;
            this.material = material;
        }
        /*<@76>*/intersect(/*<@41>*/ray) {
            var /*<@67>*/info = new IntersectionInfo();
            info.shape = this;
            var /*<@28>*/dst = Vector.subtract(ray.position, this.position);
            var /*<@1>*/B = dst.dot(ray.direction);
            var /*<@1>*/C = dst.dot(dst) - (this.radius * this.radius);
            var /*<@1>*/D = (B * B) - C;
            if (D > 0) { // intersection!
                info.isHit = true;
                info.distance = (-B) - Math.sqrt(D);
                info.position = Vector.add(ray.position, Vector.multiplyScalar(ray.direction, info.distance));
                info.normal = Vector.subtract(info.position, this.position).normalize();
                info.color = this.material.getColor(0, 0);
            }
            else {
                info.isHit = false;
            }
            return info;
        }
        /*<@77>*/toString() {
            return 'Sphere [position=' + this.position + ', radius=' + this.radius + ']';
        }
    }
    class /*<@79>*/Plane extends Shape {
        constructor(/*<@28>*/pos, /*<@1>*/d, /*<@61>*/material) {
            super();
            this.d = 0.0;
            this.position = pos;
            this.d = d;
            this.material = material;
        }
        /*<@80>*/intersect(/*<@41>*/ray) {
            var /*<@67>*/info = new IntersectionInfo();
            var /*<@1>*/Vd = this.position.dot(ray.direction);
            if (Vd == 0)
                return info; // no intersection
            var /*<@1>*/t = -(this.position.dot(ray.position) + this.d) / Vd;
            if (t <= 0)
                return info;
            info.shape = this;
            info.isHit = true;
            info.position = Vector.add(ray.position, Vector.multiplyScalar(ray.direction, t));
            info.normal = this.position;
            info.distance = t;
            if (this.material.hasTexture) {
                var /*<@28>*/vU = new Vector(this.position.y, this.position.z, -this.position.x);
                var /*<@28>*/vV = vU.cross(this.position);
                var /*<@1>*/u = info.position.dot(vU);
                var /*<@1>*/v = info.position.dot(vV);
                info.color = this.material.getColor(u, v);
            }
            else {
                info.color = this.material.getColor(0, 0);
            }
            return info;
        }
        /*<@81>*/toString() {
            return 'Plane [' + this.position + ', d=' + this.d + ']';
        }
    }
    // }
    class /*<@68>*/IntersectionInfo {
        constructor() {
            this.isHit = false;
            this.hitCount = 0;
            this.color = new Color(0, 0, 0);
            this.position = null;
            this.normal = null;
            this.distance = 0;
        }
        /*<@69>*/toString() {
            return 'Intersection [' + this.position + ']';
        }
    }
    class /*<@47>*/Camera {
        constructor(/*<@28>*/pos, /*<@28>*/lookAt, /*<@28>*/up) {
            this.position = pos;
            this.lookAt = lookAt;
            this.up = up;
            this.equator = lookAt.normalize().cross(this.up);
            this.screen = Vector.add(this.position, this.lookAt);
        }
        /*<@48>*/getRay(/*<@1>*/vx, /*<@1>*/vy) {
            var /*<@28>*/pos = Vector.subtract(this.screen, Vector.subtract(Vector.multiplyScalar(this.equator, vx), Vector.multiplyScalar(this.up, vy)));
            pos.y = pos.y * -1;
            var /*<@28>*/dir = Vector.subtract(pos, this.position);
            var /*<@41>*/ray = new Ray(pos, dir.normalize());
            return ray;
        }
        /*<@49>*/toString() {
            return 'Ray []';
        }
    }
    class /*<@73>*/Background {
        constructor(/*<@13>*/color, /*<@1>*/ambience) {
            this.ambience = 0.0;
            this.color = color;
            this.ambience = ambience;
        }
    }
    class /*<@83>*/Engine {
        constructor(/*<@8>*/options) {
            this.options = objectExtend(new EngineOption(100, 100, 2, 2, false, false, false, false, 2), options || {});
            this.options.canvasHeight = (this.options.canvasHeight / this.options.pixelHeight);
            this.options.canvasWidth = (this.options.canvasWidth / this.options.pixelWidth);
            /* TODO: dynamically include other scripts */
        }
        /*<@84>*/setPixel(/*<@5>*/x, /*<@5>*/y, /*<@13>*/color) {
            var /*<@5>*/pxW, /*<@5>*/pxH;
            pxW = this.options.pixelWidth;
            pxH = this.options.pixelHeight;
            if (this.canvas) {
                this.canvas.fillStyle = color.toString();
                this.canvas.fillRect(x * pxW, y * pxH, pxW, pxH);
            }
            else {
                if (x === y) {
                    checkNumber += color.brightness();
                }
                // print(x * pxW, y * pxH, pxW, pxH);
            }
        }
        /*<@85>*/renderScene(/*<@44>*/scene, /*<@10>*/canvas, /*<@1>*/tmp) {
            checkNumber = 0;
            /* Get canvas */
            if (canvas) {
                this.canvas = canvas.getContext("2d");
            }
            else {
                this.canvas = null;
            }
            var /*<@1>*/canvasHeight = this.options.canvasHeight;
            var /*<@1>*/canvasWidth = this.options.canvasWidth;
            for (var /*<@5>*/y = 0; y < canvasHeight; y++) {
                for (var /*<@5>*/x = 0; x < canvasWidth; x++) {
                    var /*<@1>*/yp = y * 1.0 / canvasHeight * 2 - 1;
                    var /*<@1>*/xp = x * 1.0 / canvasWidth * 2 - 1;
                    var /*<@41>*/ray = scene.camera.getRay(xp, yp);
                    var /*<@13>*/color = this.getPixelColor(ray, scene);
                    this.setPixel(x, y, color);
                }
            }
            if (checkNumber !== 2321) {
                throw new Error("Scene rendered incorrectly");
            }
        }
        /*<@86>*/getPixelColor(/*<@41>*/ray, /*<@44>*/scene) {
            var /*<@67>*/info = this.testIntersection(ray, scene, null);
            if (info.isHit) {
                var /*<@13>*/color = this.rayTrace(info, ray, scene, 0);
                return color;
            }
            return scene.background.color;
        }
        /*<@87>*/testIntersection(/*<@41>*/ray, /*<@44>*/scene, /*<@50>*/exclude) {
            var /*<@5>*/hits = 0;
            var /*<@67>*/best = new IntersectionInfo();
            best.distance = 2000;
            for (var /*<@5>*/i = 0; i < scene.shapes.length; i++) {
                var /*<@50>*/shape = scene.shapes[i];
                if (shape != exclude) {
                    var /*<@67>*/info = shape.intersect(ray);
                    if (info.isHit && info.distance >= 0 && info.distance < best.distance) {
                        best = info;
                        hits++;
                    }
                }
            }
            best.hitCount = hits;
            return best;
        }
        /*<@88>*/getReflectionRay(/*<@28>*/P, /*<@28>*/N, /*<@28>*/V) {
            var /*<@1>*/c1 = -N.dot(V);
            var /*<@28>*/R1 = Vector.add(Vector.multiplyScalar(N, 2 * c1), V);
            return new Ray(P, R1);
        }
        /*<@89>*/rayTrace(/*<@67>*/info, /*<@41>*/ray, /*<@44>*/scene, /*<@1>*/depth) {
            // Calc ambient
            var /*<@13>*/color = Color.multiplyScalar(info.color, scene.background.ambience);
            var /*<@13>*/oldColor = color;
            var /*<@1>*/shininess = Math.pow(10, info.shape.material.gloss + 1);
            for (var /*<@5>*/i = 0; i < scene.lights.length; i++) {
                var /*<@26>*/light = scene.lights[i];
                // Calc diffuse lighting
                var /*<@28>*/v = Vector.subtract(light.position, info.position).normalize();
                if (this.options.renderDiffuse) {
                    var /*<@1>*/L = v.dot(info.normal);
                    if (L > 0.0) {
                        color = Color.add(color, Color.multiply(info.color, Color.multiplyScalar(light.color, L)));
                    }
                }
                // The greater the depth the more accurate the colours, but
                // this is exponentially (!) expensive
                if (depth <= this.options.rayDepth) {
                    // calculate reflection ray
                    if (this.options.renderReflections && info.shape.material.reflection > 0) {
                        var /*<@41>*/reflectionRay = this.getReflectionRay(info.position, info.normal, ray.direction);
                        var /*<@67>*/refl = this.testIntersection(reflectionRay, scene, info.shape);
                        if (refl.isHit && refl.distance > 0) {
                            refl.color = this.rayTrace(refl, reflectionRay, scene, depth + 1);
                        }
                        else {
                            refl.color = scene.background.color;
                        }
                        color = Color.blend(color, refl.color, info.shape.material.reflection);
                    }
                    // Refraction
                    /* TODO */
                }
                /* Render shadows and highlights */
                var /*<@67>*/shadowInfo = new IntersectionInfo();
                if (this.options.renderShadows) {
                    var /*<@41>*/shadowRay = new Ray(info.position, v);
                    shadowInfo = this.testIntersection(shadowRay, scene, info.shape);
                    if (shadowInfo.isHit && shadowInfo.shape != info.shape /*&& shadowInfo.shape.type != 'PLANE'*/) {
                        var /*<@13>*/vA = Color.multiplyScalar(color, 0.5);
                        var /*<@1>*/dB = (0.5 * Math.pow(shadowInfo.shape.material.transparency, 0.5));
                        color = Color.addScalar(vA, dB);
                    }
                }
                // Phong specular highlights
                if (this.options.renderHighlights && !shadowInfo.isHit && info.shape.material.gloss > 0) {
                    var /*<@28>*/Lv = Vector.subtract(info.shape.position, light.position).normalize();
                    var /*<@28>*/E = Vector.subtract(scene.camera.position, info.shape.position).normalize();
                    var /*<@28>*/H = Vector.subtract(E, Lv).normalize();
                    var /*<@1>*/glossWeight = Math.pow(Math.max(info.normal.dot(H), 0), shininess);
                    color = Color.add(Color.multiplyScalar(light.color, glossWeight), color);
                }
            }
            color.limit();
            return color;
        }
    }
    function /*<@90>*/renderScene() {
        var /*<@44>*/scene = new Scene();
        scene.camera = new Camera(new Vector(0, 0, -15), new Vector(-0.2, 0, 5), new Vector(0, 1, 0));
        scene.background = new Background(new Color(0.5, 0.5, 0.5), 0.4);
        var /*<@74>*/sphere = new Sphere(new Vector(-1.5, 1.5, 2), 1.5, new Solid(new Color(0, 0.5, 0.5), 0.3, 0.0, 0.0, 2.0));
        var /*<@74>*/sphere1 = new Sphere(new Vector(1, 0.25, 1), 0.5, new Solid(new Color(0.9, 0.9, 0.9), 0.1, 0.0, 0.0, 1.5));
        var /*<@78>*/plane = new Plane(new Vector(0.1, 0.9, -0.5).normalize(), 1.2, new Chessboard(new Color(1, 1, 1), new Color(0, 0, 0), 0.2, 0.0, 1.0, 0.7));
        scene.shapes.push(plane);
        scene.shapes.push(sphere);
        scene.shapes.push(sphere1);
        var /*<@26>*/light = new Light(new Vector(5, 10, -1), new Color(0.8, 0.8, 0.8));
        var /*<@26>*/light1 = new Light(new Vector(-3, 5, -15), new Color(0.8, 0.8, 0.8), 100);
        scene.lights.push(light);
        scene.lights.push(light1);
        var /*<@5>*/imageWidth = 100; // $F('imageWidth');
        var /*<@5>*/imageHeight = 100; // $F('imageHeight');
        var /*<@91>*/pixelSize = "5,5".split(','); //  $F('pixelSize').split(',');
        var /*<@2>*/renderDiffuse = true; // $F('renderDiffuse');
        var /*<@2>*/renderShadows = true; // $F('renderShadows');
        var /*<@2>*/renderHighlights = true; // $F('renderHighlights');
        var /*<@2>*/renderReflections = true; // $F('renderReflections');
        var /*<@5>*/rayDepth = 2; //$F('rayDepth');
        let /*<@8>*/option = new EngineOption(imageWidth, imageHeight, Number(pixelSize[0]), Number(pixelSize[1]), renderDiffuse, renderHighlights, renderShadows, renderReflections, rayDepth);
        var /*<@82>*/raytracer = new Engine(option);
        raytracer.renderScene(scene, null, 0);
    }
    rt.renderScene = renderScene;
})(rt || (rt = {}));
let /*<@1>*/worst4;
let /*<@1>*/average;
let /*<@1>*/firstIteration;
let /*<@1>*/total;
function /*<@93>*/summation(/*<@95>*/values) {
    assert(values instanceof Array);
    let /*<@5>*/sum = 0;
    for (let /*<@94>*/x of values)
        sum = sum + /*<@1>*/x;
    return sum;
}
function /*<@96>*/toScore(/*<@94>*/timeValue) {
    return /*<@1>*/timeValue;
}
function /*<@97>*/mean(/*<@95>*/values) {
    assert(values instanceof Array);
    let /*<@1>*/sum = 0;
    for (let /*<@94>*/x of values)
        sum = sum + /*<@1>*/x;
    return sum / values.length;
}
function /*<@98>*/assert(/*<@2>*/condition) {
    if (!condition) {
        throw new Error("assert false");
    }
}
function /*<@99>*/processResults(/*<@95>*/results) {
    function /*<@100>*/copyArray(/*<@95>*/a) {
        let /*<@101>*/result = /*<@101>*/[];
        for (let /*<@94>*/x of a)
            result.push(x);
        return result;
    }
    results = copyArray(results);
    firstIteration = toScore(results[0]);
    total = summation(results);
    // results = results.slice(1);
    results.sort(/*<@102>*/(/*<@94>*/a, /*<@94>*/b) => a < b ? 1 : -1);
    for (let /*<@5>*/i = 0; i + 1 < results.length; ++i)
        assert(results[i] >= results[i + 1]);
    let /*<@95>*/worstCase = /*<@95>*/[];
    for (let /*<@5>*/i = 0; i < 4; ++i)
        worstCase.push(results[i]);
    worst4 = toScore(mean(worstCase));
    average = toScore(mean(results));
}
function /*<@103>*/printScore() {
    // print("First: " + firstIteration);
    // print("worst4: " + worst4);
    print("average: " + average);
    // print("total: " + total);
}
class /*<@105>*/Benchmark {
    /*<@106>*/runIteration() {
        rt.renderScene();
    }
}
function /*<@107>*/main() {
    let /*<@104>*/__benchmark = new Benchmark();
    let /*<@101>*/results = /*<@101>*/[];
    for (let /*<@5>*/i = 0; i < 60; i++) {
        let /*<@1>*/start = performance.now();
        __benchmark.runIteration();
        let /*<@1>*/end = performance.now();
        results.push(end - start);
    }
    processResults(results);
    printScore();
}
main();
